package goal;
import goal.tools.PlatformManager;
import goal.explanation.*;
import java.util.*;

public class Global {
	public static PlatformManager platformManager;
	public static boolean RL_ON=false;
	public static boolean RL_REGENERATE_AFTER_EPISODE=true;
	public static int LEARNING_PHASE=250;
	public static int EXPLOITATION_PHASE=30;
	public static HashMap<String, Explanation> explanations;
}
