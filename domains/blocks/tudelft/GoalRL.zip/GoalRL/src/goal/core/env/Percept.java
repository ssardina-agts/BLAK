package goal.core.env;

import goal.core.kr.language.Formula;

/**
 * 
 * @author Koen Hindriks
 *
 */

/**
 * It is assumed that the environment interface can turn perceptual input from an environment into a sentence from
 * some knowledge representation language, as a plain string. 
 * From the point of view of the agent, a percept thus simply is a sentence from that language.
 */

public class Percept {
	
	private String formula;
	private String language;
	
	public Percept(String pFormula, String pLanguage) {
		formula = pFormula;
		language = pLanguage;
	}
	
	public String getContent() {
		return formula;
	}
	
	public String getLanguage() {
		return language;
	}
	
	public String toString() { return formula; }
}
