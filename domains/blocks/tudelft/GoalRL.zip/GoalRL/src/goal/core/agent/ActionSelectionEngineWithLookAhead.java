package goal.core.agent;

public class ActionSelectionEngineWithLookAhead extends ActionSelectionEngine {

	// Class fields
	private int horizon;
	
	public ActionSelectionEngineWithLookAhead() {
		initCostFuncs();
	}
	
	// Class methods
	// ADHOC: Only use this in blocks world.
	public void initCostFuncs() {
		//initCostFuncsGreedyBuildPreferSelfDeadlocksToTableFirst();
		//initCostFuncsGreedyBuildPreferSelfDeadlocksToTableFirst2();
		//initCostFuncsSimulateGN1();
		//initCostFuncsSimulateGN1withSelfDeadlock();
		//initCostFuncsVersion22January(); // this appears to give the GN1 line from slaney.
		//initCostFuncsWithDeficiency();
		//initCostFuncsWithDeficiency2();
	}

}
