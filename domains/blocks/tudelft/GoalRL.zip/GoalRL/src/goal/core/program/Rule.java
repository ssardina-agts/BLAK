package goal.core.program;

import goal.core.kr.language.Var;
import goal.tools.errorhandling.Warning;

/**
 * 
 * @author Koen Hindriks
 *
 */

public class Rule {
	
	// Class fields
	MentalStateCond fMsc;
	Action fAct;
	private int state;
	
	// Constructor
	public Rule(MentalStateCond pMsc, Action pAct) {
		// DOC: Only references here, no clones created; in this case avoids redundancy.
		fMsc = pMsc;
		fAct = pAct;
		// TODO: Move code below to parser; more efficient. See Mantis 174 for explanation.
		for (MentalAtom ma:pMsc.getLiterals())
			if (ma.getType()==LITERALTYPE.GOAL) {
				for (Var v:ma.getFormula().getFreeVar())
					if (v.getVarName().equals("_")) // TODO: Only applies to Prolog.
						new Warning(" Mental atom "+ma+" contains anonymous variable.");
			}
	}
	
	// Class methods
	public MentalStateCond getCondition() {
		return fMsc;
	}
	
	public int getState(){
		return state;
	}
	
	public void setState(int state){
		this.state=state;
	}
	public Action getAction() {
		return fAct;
	}
	
	public String toString() {
		return "if "+fMsc+" then "+fAct;
	}

}
