package goal.core.mentalstate;

import goal.core.kr.Database;
import goal.core.kr.KRlanguage;
import goal.core.kr.language.Formula;

public interface Base {

	public Database getDatabase();
	
	public KRlanguage getLanguage();
	
	public boolean insert(Formula formula);
	public boolean delete(Formula formula);
	
	public void eraseContent();
	
}
