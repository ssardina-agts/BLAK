package goal.core.kr;

import goal.core.kr.language.*;
import java.util.*;
import goal.tools.debugger.Debugger;

/**
 * 
 * @author Koen Hindriks
 *
 */

public interface InferenceEngine {

	// Class methods
	
	/**
	 * The 'query' method is a generic method that defines the inference mechanism associated with a KRlanguage.
	 * The GOAL programming language requires that at least this method is specified in order to be able to
	 * effectively operate with the KRlanguage.
	 * @return set of substitutions. This set is empty if there are no solutions.
	 * If there is a one solution without substitutions, returns set with one empty substitution
	 */
	public Set<Substitution> query(QueryExpression pQuery, Database pDB, Debugger dbg) throws Exception;

	 /** Wouter: rawquery directy sends a query string to an inference engine.
	  * We still need it as users can type raw strings inside the introspector query panel
	  */
	public Set<Substitution> rawquery(String query,Debugger debugger) throws Exception;
	
	
	/**
	 * The method 'getAllSentences' collects all sentences which are explicit elements of the database viewed as a
	 * SET. The method essentially is a SYNTACTIC operator instead of a SEMANTIC one such as the 'query' method.
	 * @return The method returns a list of all sentences that are elements in the set-theoretical sense of the
	 * database.
	 */
	public Formula[] getAllSentences(Database pDB) throws Exception;
	
}
