package goal.core.env;

import goal.core.program.UserSpecAction;
import java.util.ArrayList;

/**
 * 
 * @author Koen Hindriks
 *
 */

public interface Environment {

	/**
	 * The method 'executeAction' defines an interface with an external (simulation) environment for executing
	 * actions in that environment.
	 * ASSUMPTION: here, it is assumed that the method completely executes an action and only then returns the flow
	 * of control to the interpreter, i.e. only after finishing (successfully or not) executing the action the method
	 * terminates.
	 * @param pAct The method requires an action that provides the name and possibly parameters of the action.
	 * @return The method returns a flag indicating whether the action was recognised by environment ('true') or
	 * not ('false'). This is needed because GOAL can not see whether a userspecaction is something
	 * that the environment understands or a "fake" action that is needed just to do some drops and adopts.
	 * @throws exception if action is recognised by the environment but an attempt to execute it fails.
	 * @version 2 accepts String instead of UserSpecAction as action.
	 */
	public boolean executeAction(String pAgent, String pAct) throws Exception;
	
	/**
	 * The method 'sendPercepts' returns a list of percepts obtained through 'observing' the environment. In a
	 * sense, this method defines the perceptual capabilities of an agent.
	 * @param pAgentName should be a name of an existing agent. If no agent with that name is known to exist in the
	 * environment, the method should issue a warning and throw an exception. 
	 * @version 2 returns String for each percept, instead of a Percept
	 * @version 3 now throws Exception if problem occurs eg agent name does not exist, no percepts available, etc.
	 * Note, the wumpus world returns null if the agent is dead, instead of throwing.
	 */
	public ArrayList<Percept> sendPercepts(String pAgentName) throws Exception;
	
	public boolean availableForInput();
	
	/** Wouter: close closes the environment. 
	 * Needed because otherwise old environment windows will stay open. */
	public void close();

	/** 
	 * @author W.Pasman
	 * Reset environment to initial state. May fail to actually reset environment if this functionality is supported.
	 */
	public void reset() throws Exception;
	
	/**
	 * The method reGenerate is almost identical to reset with the exception that this generates a new initial environment state
	 * As such, it can be used to generate variations of the same environment (if supported by the environment)
	 */
	public void reGenerate() throws Exception;
}
