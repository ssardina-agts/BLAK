package goal.core.program;

import goal.core.kr.language.*;
//import goal.core.kr.language.Substitution;
import java.util.*;

/**
 * 
 * @author Koen Hindriks
 * Modified by: Wouter Pasman
 *
 */

public class ActionSpec {
	
	// Class fields
	/**
	 * 
	 * Each action in the program section of a GOAL agent (program) must come with a specification, i.e. a pre-
	 * and post-condition, defined in the action specification section of the agent.
	 * The parser checks this, and issues a warning if an action is specified in the Action
	 * Specification section but never used in the Program section.
	 *  ASSUMPTION: The variables in action, pre- and post-conditions are in one-to-one correspondence with those
	 * in the action specification section of the GOAL agent.
	 * All variables that occur in the parameters or post-condition of an action must occur in the pre-condition
	 * of that action.
	 */ 
	 
	 /** Wouter: an un-expressed ASSUMPTION by Koen is that there is only ONE action spec for each action.
	 * This is un-expressed but reflected in the fact that a HashMap is used to couple actions to their "unique" precondition.
	 * But that uniqueness is just not true. Consider turn(X) { :pre {X=left,...}..}, turn (X) {:pre {X=right,...},..}
	 * 
	 * CHECK THESE ARE CHOICES THAT NEED TO BE DISCUSSED
	
	private HashMap<String,Formula> fPreCond; // preconditions as specified in action specification section of GOAL program.
	private HashMap<String,Formula> fPostCond; // postcondition as specified in action specification section of GOAL program.
	// TODO: String used in above to avoid having to write a new hashCode method for Action class. Consider writing such a
	// method later...
	 */

	private ArrayList<ActionRule> actionrules;
	
	/** Wouter: if you want no rules, just give an empty rule set!*/	
	public ActionSpec(ArrayList<ActionRule> rules) throws NullPointerException {
		if (rules==null) {
			throw new NullPointerException("No action specifications found");
		}
		actionrules=rules;
	}

	/**
	 * @author W.Pasman
	 * @return the rules that match given action, with the vars instantiated properly
	 */
	public ArrayList<ActionRule> getMatchingRules(Action a) {
		ArrayList<ActionRule> result=new ArrayList<ActionRule>();
		
		for (ActionRule ar: actionrules) {
			Substitution s = ar.getAction().mgu(a);
			if (s!=null) result.add(ar.substitute(s));
		}
		return result;
	}
	
	public String toString() {
		String s="";
		for (ActionRule r: actionrules)
			s=s+r+"\n";
		return s;
	}
}