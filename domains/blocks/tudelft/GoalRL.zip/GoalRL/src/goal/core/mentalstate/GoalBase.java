package goal.core.mentalstate;

import goal.core.kr.*;
import goal.core.kr.language.*;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

import java.util.*;

/**
 * 
 * @author Koen Hindriks
 * 
 */

public class GoalBase implements Base {
	
	// Class fields
	private String name;
	private Database database;
	private Theory theory;
	
	/** DOC:
	 * The theory represents the "visible" contents of the goalbase. It should correspond with the database, except
	 * possibly for background knowledge present in the database which is not reflected in the theory. In order to
	 * ensure the theory corresponds correctly in this sense with the database, any changes to the belief base need
	 * to be made by using the methods provided by this class. By directly modifying the underlying database, the
	 * correspondence may be lost.
	 * Background knowledge added to the database is assumed to be static. Additionally, the predicates declared/defined
	 * in the goal base's theory and in background theories should not overlap (this will raise exceptions when
	 * inserting the background knowledge into a Prolog database).
	 */
	
	// Class constructor
	public GoalBase(String name, Theory theory, KRlanguage language) throws Exception {
		this.name = name;
		database = language.makeDatabase("goalbase", theory); // makeDatabase creates a clone of theory.
		this.theory = theory.clone();
	}

	// Class methods
	public String getName() {
		return name;
	}
	
	public Database getDatabase() {
		return database;
	}
	
	public Theory getTheory() {
		return theory;
	}

	public KRlanguage getLanguage() {
		return database.getLanguage();
	}
	
	/**
	 * Adds a theory as background knowledge. The formulae from the theory are added to the database associated with
	 * the belief base, but not to the theory associated with the belief base. The theory thus functions only in the
	 * background of the belief base, as part of the database, but is "invisible" from the perspective of the
	 * associated theory.
	 * @param theory that contains the background knowledge.
	 * @throws Exception when some failure occurs while adding the background knowledge to the database.
	 */
	public void addBackgroundKnowledge(Theory theory) throws Exception {
		database.add(theory);
	}

	public void eraseContent() {
		database.eraseContent();
		theory.clear();
	}
	
	/**
	 * Entailment from a goal base is not defined in the same way as entailment from a belief base.
	 * The method 'query' which implements the entailment relation on goal bases verifies if a formula follows
	 * from any one sentence that is contained in a goal base, properly instantiated if needed.
	 * @param pSusbt A list of substitutions that when applied to the formula result in instances of the formula
	 * that follow from SOME sentence in the goal base. If the formula is closed, i.e. does not have any free
	 * variables, then pSubst is an empty list.
	 * @return The method returns a boolean value 'true' if at least one instance of the formula follows from
	 * the goal base. The possible bindings of variables that upon substitution result in instances of the
	 * formula that follow from the goal base are returned as a list via the variable pSubst.
	 */
	// DOC: Although conceptually correct, the method is probably quite inefficient.
	public final Set<Substitution> query(QueryExpression pForm, Debugger debugger) {
		//Formula[] lSnt;
		//GoalBase lGB;
		Set<Substitution> lSubst ;
		
		// TODO: Code below is SWI Prolog specific hack. Maybe reconsider how to setup things here?
		// In SWI Prolog, each goal is defined in a separate database (module). Therefore step 1 below does
		// not have to be performed; a database by definition contains a single goal only. This may be the
		// a generic setup which can be used to implement goal bases...
		
		try {
			lSubst=this.getDatabase().getLanguage().getInferenceEngine().query(pForm, this.getDatabase(), debugger);
		} catch (Exception e) {
			new Warning("query failed",e);
			lSubst=new LinkedHashSet<Substitution>();
		}
		return lSubst;
	}
	
	public boolean insert(Formula formula) {
		theory.add(formula);
		return database.getLanguage().getUpdateEngine().expand(formula, database);
	}
	
	public boolean delete(Formula formula) {
		theory.remove(formula);
		return database.getLanguage().getUpdateEngine().delete(formula, database);
	}
	
	public boolean drop(Formula pForm) {
		// TODO: needs to be defined according to GOAL semantics.
		return true;
	}
	
	/**
	 * TODO CHECK This is not quite true right now. The method 'getAllSentences' is only used for goal bases.
	 * It is not needed for belief bases due to the different semantics for both.
	 */
	public ArrayList<Formula> getAllSentences() {
		return theory.toArrayList();
		/* OBSOLETE: direct access to database will also return background knowledge, which is invisible. 
		try {
			return this.fBase.getLanguage().getInferenceEngine().getAllSentences(fBase);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
		*/
	}
	
	public String toString() {
		return "GoalBase["+theory+"]";
	}

}
