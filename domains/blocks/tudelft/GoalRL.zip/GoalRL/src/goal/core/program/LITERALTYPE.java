package goal.core.program;

/**
 * 
 * @author Koen Hindriks
 *
 */

public enum LITERALTYPE {
	BELIEF, GOAL, AGOAL, GOALA;
}
