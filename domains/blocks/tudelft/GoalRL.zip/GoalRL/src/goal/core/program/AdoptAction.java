package goal.core.program;

import java.util.Set;
import goal.kr.implementations.swiprolog.*;

import goal.core.kr.language.*;

public class AdoptAction implements Action {
	
	// Class field
	QueryExpression fQuery;
	
	// Class constructor
	public AdoptAction(QueryExpression pQuery) {
		fQuery = pQuery;
	}
	
	// Class methods
	public String getName() {
		return "adopt";
	}

	public QueryExpression getGoal() {
		return fQuery;
	}
	
	public Action applySubst(Substitution pSubst) {
		return new AdoptAction(new SWIQueryExpression((SWIExpression)fQuery.applySubst(pSubst)));
	}

	public Set<Var> getFreeVar() {
		return fQuery.getFreeVar();
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public AdoptAction clone() {
		return new AdoptAction(fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof AdoptAction)) {
			return false;
		}
		return fQuery.equals(((AdoptAction)pObj).getGoal());
	}
	
	public boolean reserved() {
		return true;
	}

	public Substitution mgu(Action pAct) {
		return null; // TODO: implement
	}
	
	public String toString() {
		return "adopt("+fQuery.toString()+")";
	}

}
