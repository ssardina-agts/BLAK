package goal.core.kr.language;

/** Wouter: A QueryExpression is an expression that can be Queried, i.e.
 * has the value true or false.  Usually this is called a predicate.
 * CHECK please Koen add and check this documentation. 
 * @author Koen */

public interface QueryExpression extends Expression {
	
	 /* Wouter: note on applySubst....
	  the result may NOT be a Query anymore. You will have to re-cast this back to a Query 
	 */ 
}
