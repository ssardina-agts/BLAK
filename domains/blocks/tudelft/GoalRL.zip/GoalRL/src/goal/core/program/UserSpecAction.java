package goal.core.program;

import goal.core.kr.language.*;
import goal.kr.implementations.swiprolog.SWITerm;
import java.util.*;

/**
 * 
 * @author Koen Hindriks, W.Pasman
 *
 * Wouter: a UserSpecAction is strictly of the form name(params) where
 * (params) is optional and params must be a list of variables.
 * Note, the parser allows arbitrary prolog terms at the place where we really expect vars?!?
 * 
 */

public class UserSpecAction implements Action {
	
	// Class fields
	String fName;      // name of action.
	Term[] fParam;	   // parameter-list of action.
	
	/** Wouter: currently I use only Term[0] if anything, 
	 * as a Term can hold any number of comma separated terms */
	public UserSpecAction(String pName, Term[] pParam) {
		fName = new String(pName);
		fParam = new Term[pParam.length];
		System.arraycopy(pParam, 0, fParam, 0, pParam.length);
	}
	
	// Class methods
	public String getName() {
		return fName;
	}
	
	public Term[] getParam() {
		return fParam;
	}
	
	public String toString() {
		String lParList = new String();
		
		if (fParam.length!=0) {
			lParList += "("+fParam[0].toString();
			for (int i=1; i<fParam.length; i++) {
				lParList += ","+fParam[i].toString();
			}
			lParList += ")";
		}
		return this.getName()+lParList;
	}
	
	public boolean equals(Object lAction) {
		
		if (!(lAction instanceof UserSpecAction)) {
			return false;	
		}
		UserSpecAction usa=(UserSpecAction)lAction;
		
		if (!(this.fName.equals(usa.getName()))) {
			return false;
		}
		for (int i=0; i<fParam.length; i++) {
			if (!fParam[i].equals(usa.getParam()[i])) return false;
		}
		return true;
	}
	
	public UserSpecAction clone() {
		return new UserSpecAction(this.fName, this.fParam);
	}
	
	public boolean isClosed() {
		boolean lResult = true;
		for (Term lTerm : fParam) {
			lResult = lResult && lTerm.isClosed();
		}
		return lResult;
	}
	
	public Set<Var> getFreeVar() {
		Set<Var> lFree = new LinkedHashSet<Var>();
		
		lFree.clear();
		for (Term lTerm : fParam) {
			lFree.addAll(lTerm.getFreeVar());
		}
		return lFree;
	}

	
	/**
	 * The method 'applySubst' applies a given substitution and instantiates/binds ALL occurrences of free
	 * variables in pre- and post-conditions as well as in action parameters that are bound by the substitution.
	 * @param pSubst A substitution, i.e. conceptually a list of variable/term pairs.
	 * @return An action whose associated free variables that are bound by pSubst have been instantiated with the
	 * corresponding terms.
	 */
	public UserSpecAction applySubst(Substitution pSubst) {
		Term[] lParam = new Term[fParam.length];
		
		for (int i=0;i< fParam.length;i++) {
			Term lTerm = fParam[i];
			lParam[i] = new SWITerm(lTerm.applySubst(pSubst)); 
				// FIXME we can NOT cast from Expression to Term (narrowing cast). But we don't want to get
				// SWI specific here either... 
		}
		return new UserSpecAction(fName, lParam);
	}
	
	public boolean reserved() {
		return false;
	}

	/**
	 * Determine mgu of two actions. Similar to matching 2 expressions.
	 * @author W.Pasman
	 */
	public Substitution mgu(Action pAct) {

		if (!(pAct instanceof UserSpecAction)) {
			return null; // action type mismatch
		}
		if (!fName.equals(pAct.getName())) {
			return null; // name mismatch
		}
		Term[] lParam = ((UserSpecAction)pAct).getParam();
		if (fParam.length != lParam.length) {
			return null; // arity mismatch
		}
		
		Substitution lMGU = new Substitution();
		for (int i=0; i<fParam.length; i++) {
			lMGU = lMGU.combine(fParam[i].mgu(lParam[i]));
			if (lMGU==null) {
				return null;	// combine failure
			}
		}
		return lMGU; // return resulting substitution.
	}

}
