package goal.core.agent;

import goal.core.program.ActionRule;
import goal.tools.errorhandling.Warning;

import java.util.Random;

public class ActionSelectionEngine {
	
	// Class fields
	private Random random = new java.util.Random(); // uses time (in ms) as default seed.
	private Long fLastSeed = null;
	
	// Constructor
	public ActionSelectionEngine() {
		
	}
	
	// Class methods
	// Main method: select action in mental state.
	public ActionRule selectAction(Agent pAgent) {
		return null;
	}
	
	
	public void setRandomSeed(Long pSeed) {
		random.setSeed(pSeed);
		fLastSeed = pSeed;
		new Warning("Using "+pSeed+" as seed for random generator.");
	}
	
	public void resetRandomSeed() {
		if (fLastSeed!=null) {
			setRandomSeed(fLastSeed);
		} else {
			new Warning("No seed available when trying to reset random seed.");
		}
	}

}
