package goal.core.kr;


import goal.core.kr.language.*;
import goal.tools.debugger.Debugger;

/**
 * 
 * @author Koen Hindriks
 *
 * Wouter: the KRLanguage interface is the hook to make
 * the implementation SWIProlog-independent.
 * For instance, by calling KRLanguage.makeDatabase instead of
 * directly new SWIPrologDatabase()
 * 
 */

public interface KRlanguage {
	
	/** @return a String containing the UNIQUE name of the language. */
	public String getName();
	
	public boolean equals(Object pLangue);
	
	/** 
	 * The method 'parser' takes a string a returns an expression object that
	 * correspondsin to the grammar category associated with a language.
	 * @param pStr A string.
	 * @return An 'Expression' object if string pStr is part of the language.
	 * @throws if parse problem occurs 
	 * (by W.Pasman, 23sept08; previously null was returned, causing all kind of 
	 * extra exception handling that should have been for free)
	 */
	public Expression parser(String pStr) throws Exception;
	
	/**
	 * The method 'getInferernceEngine' returns the associated inference engine of the
	 * knowledge representation (KR) language. An API for a language should always
	 * supply an inference engine, otherwise the GOAL programming language will not be
	 * able to operate with the KR language. 
	 * @return The inference engine that is associated with the language, if no
	 * inference engine is available an exception should be thrown.
	 */
	public InferenceEngine getInferenceEngine();
	
	
	
	/**
	 * The method 'getUpdateEngine' returns the associated update engine of the
	 * knowledge representation (KR) language. An API for a language only needs to
	 * supply an update engine with a language if the language is used to specify the
	 * POSTconditions of actions of agents, or one of the actions 'insert' or 'delete'
	 * are used in an agent program to insert/delete sentences from the language.
	 * (Note that this can be verified at parse time.)
	 * @return The inference engine that is associated with the language, if no
	 * inference engine is available an exception should be thrown.
	 */
	public UpdateEngine getUpdateEngine();

	/**
	 * returns new Database
	 * Wouter: Koen wrote in BeliefBase.java: makeDatabase makes CLONE of theory.
	 */
	public Database makeDatabase(String name, Theory theory) throws Exception;
	
}
