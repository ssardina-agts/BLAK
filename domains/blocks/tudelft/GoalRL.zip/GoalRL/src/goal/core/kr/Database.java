package goal.core.kr;

/**
 * 
 * Each database can be viewed as a set of sentences, i.e. closed formula.
 * DOC: An API implementation of the Database interface needs to comply with
 * this set-theoretic view of a database and come with a set of associated
 * set-theoretic methods such as defined in the UpdateEngine interface. 
 *
 * @author Koen Hindriks
 */

public interface Database {
	
	/**
	 * Initialise database. Perform whatever operations are necessary to setup a new
	 * database.
	 */
	// TODO: Unquote 'initialise' method.
	//public Database initialise();
	
	/** Get name of database. ASSUMPTION: Each database is provided with a name for internal reference
	 * by the GOAL interpreter.
	 */
	public String getName();
	
	public Theory getTheory();
	
	public void add(Theory theory);
	
	/**
	 * eraseContent erases all content from the database, in order to free memory.
	 */
	public void eraseContent();
	
	/**
	 * Load the contents of a file  into the database. This
	 * method is typically used directly after initialisation to add content to a database.
	 * It can also be used to handle #include statements.
	 * @param pFilename The name of the file.
	 */
	public void loadFromFile(String pFilename) throws Exception;
		
	/**
	 * Each database consists of sentences from a UNIQUE language.
	 * @return The method 'getLanguage' returns the knowledge representation language
	 * associated with the database.  
	 */
	public KRlanguage getLanguage();
	
	public void showStatistics(); // for debugging. Added by Wouter.
	
	/**
	 * Clone all database contents to a new database.
	 * This will also clone all predicates on the prolog level!
	 * NOTE: currently we do NOT remove the predicates from prolog level when the 
	 * Database is deleted. I have no idea how you can do this, as 
	 * delete of Database does not really happen until the Java garbage collector kicks in.
	 * By then, all prolog memory may be full already...
	 */	
	public Database clone(); 
	
	public String toString();
	

	
}
