package goal.core.program;

import java.util.ArrayList;
/**
 * 
 * @author Koen Hindriks
 * Wouter: Program is datastructure to store the program section of the agent's goal specification.
 * @modified W.Pasman 11jul08 to use ArrayList instead of plain java array
 * (array needs conversion about everywhere where we use it...)
 */

public class Program {
	
	// Class fields
	ArrayList<Rule> fRules;
	
	/**
	 * A rulebase has a fixed size and does not change during runtime.
	 * Parser should generate rule base for each agent (program). 
	 */
	public Program(ArrayList<Rule> Rules) throws Exception {
		if (Rules.isEmpty()) throw new Exception("Empty rule base upon initialisation attempt!");
		fRules=Rules;
	}
	
	public ArrayList<Rule> getRules() {
		return fRules;
	}

}
