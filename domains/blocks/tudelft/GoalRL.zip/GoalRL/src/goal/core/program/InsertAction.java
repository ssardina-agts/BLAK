package goal.core.program;

import java.util.Set;import goal.kr.implementations.swiprolog.*;

import goal.core.kr.language.*;

/** @author W.Pasman 25feb09 
 * TODO use Formula instead of QueryExpression. 
 * I copied this from the other actions but I think this is not right.
 * */
public class InsertAction implements Action {
	
	// Class field
	QueryExpression fQuery;
	
	// Class constructor
	public InsertAction(QueryExpression pQuery) {
		fQuery = pQuery;
	}
	
	// Class methods
	public String getName() {
		return "insert";
	}

	public QueryExpression getBelief() {
		return fQuery;
	}
	
	public Action applySubst(Substitution pSubst) {
		//Expression newexp=fQuery.applySubst(pSubst);
		return new InsertAction(new SWIQueryExpression((SWIExpression)fQuery.applySubst(pSubst)));
	}

	public Set<Var> getFreeVar() {
		return fQuery.getFreeVar();
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public InsertAction clone() {
		return new InsertAction(fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof InsertAction)) {
			return false;
		}
		return fQuery.equals(((InsertAction)pObj).getGoal());
	}
	
	public boolean reserved() {
		return true;
	}

	public Substitution mgu(Action pAct) {
		return null; // TODO: implement
	}
	
	public String toString() {
		return "insert("+fQuery.toString()+")";
	}

}
