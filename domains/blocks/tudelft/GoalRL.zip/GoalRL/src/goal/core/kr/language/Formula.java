package goal.core.kr.language;

import java.util.ArrayList;

/** Wouter: A formula is an object that can be put in (or retrieved from) a database.
 * Actually Prolog accepts about everything to be put in database,
 * but I think Koen wants restrictions eg sin(3) should not be in a database,
 * and not(3,3,4) also not.
 *  
 * @author Koen
 */
public interface Formula extends Expression {
	
	public Formula applySubst(Substitution pSubst);
	
	//public boolean equals(Object o);
	
	//public Set<Formula> getClausesAndFacts(); // ASSUMES Prolog is used (ADHOC). Problem with hashCode.
	/** Wouter: Order of clauses IS important. Replaced Set with ArrayList, 1oct08.*/
	public ArrayList<String> getClauses(); // ASSUMES Prolog is used (ADHOC).
	
	//public Set<Formula> getNegations(); // ASSUMES Prolog is used (ADHOC). Problem with hashCode.
	public ArrayList<String> getNegations(); // ASSUMES Prolog is used (ADHOC). Problem with hashCode.

}
