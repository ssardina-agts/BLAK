package goal.core.scheduler;

import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.env.Percept;
import goal.core.program.UserSpecAction;
import java.util.ArrayList;


/**
 * 
 * @author Koen Hindriks
 * 
 */

public interface Scheduler {
	
	/**
	 * Wouter: removed, setting up is the job of the platform manager.
	 * 'Initialiser': sets up e.g. communication infrastructure, agent threads, etc.
	 */
	// public void initialiser();

	/** the method step makes pAgent do one step in perception-action cycle.
	 * Override only this method if you want the platform manager to be able to control your agent.
	 *  @returns true if system still runnable. false if it has stopped.
 	 *  @throws exception if init of agent's database fails.
	 */
	public boolean step(Agent pAgent) throws Exception ;
	
	/**
	 * The method 'controlLoop' executes the top-level cycle of control.
	 *  @throws exception if init of agent's database fails.
	 */
	public void controlLoop() throws Exception;
	
	/**
	 *  Scheduler receives actions from agents via this method. The method can be implemented in many different ways,
	 *  e.g. by implementing channels connecting the scheduler to each agent and collecting actions from these agents
	 *  via such a channel.
	 *  @throws exception if init of agent's database fails.
	 *  @param pAgent An agent that wants to execute the action.
	 *  @param pAct Must be a closed action, i.e. action without occurrences of free variables.
	 *  @version 2: now returns String instead of UserSpecAction. "" is the null-action(no action available)
	 *  @version 3: now can throw exception if agent database init fails.
	 */
	public String receiveAction(Agent pAgent) throws Exception ;
	

	/**
	 * This method selects the agent that is scheduled to perform an action next (, or possibly to receive a
	 * percept next.). Throws Exception if no agent can be selected.
	 */
	public Agent selectAgent() throws Exception;
	
	/**
	 * Connectors to the environment.
	 */
	/**
	 * The method requests environment to execute action.
	 *  @version 2: now takes String instead of UserSpecAction.
	 * @return boolean indicating whether the action was performed successfully ('true') or
	 * not at all ('false'). This is needed because GOAL can not see whether a userspecaction is something
	 * that the environment understands or a "fake" action that is needed just to do some drops and adopts.
	 * This should be identical to Environment.executeAction.
	 * @version 3: now can throw if error occurs
	 * @throws error if action was recognised by environment but failed to execute properly.
	 */
	public boolean executeAction(Agent agent, String action) throws Exception ;
	
	/**
	 * The method receives new percepts from environment, accessible to agent pAgent.
	 * @version 2 now receives Strings as Percept, instead of Percept.
	 * @return arraylist of percepts, or null if the environment does not allow you perception.
	 * @version 3 now throws exception if no percepts available for that agent (eg agent does not exist)
	 * @version 4 --- adapted for mas's with agents having no connection with environment.
	 * @return empty list of percepts if the agent is not connected to an environment.
	 */
	public ArrayList<Percept> receivePercepts(Agent pAgent) throws Exception;
	
	/**
	 * @author W.Pasman
	 * @return the total number of actions performed so far by the Agent.
	 * TODO not clear what this means when multiple agents available. Maybe add agent parameter?
	 */
	public int getTotalNumberOfActions();
	
	public ArrayList<Agent> getAgents() throws Exception;
	
	public Environment getEnvironment();

	/** @author W.Pasman 3mar09
	 * @return the environment name that this agent is conected to. Currently allowed: "" and "environment". 
	 * "" means no connection with environment.
	 * "environment" means connected with the environment  (we have only 1 now) */
	public String getEnvironmentConnection(Agent pAgent);
}
