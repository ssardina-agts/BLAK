package goal.core.agent;

import java.util.Hashtable;
import java.util.Set;
import java.util.HashMap;
import java.util.ArrayList;

import jpl.Query;

import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;
import goal.core.kr.language.Substitution.Binding;
import goal.core.program.Action;
import goal.core.program.UserSpecAction;
import goal.core.mentalstate.MentalState;


/**
 * NodeOnFrontier is a node in a search tree, 
 * at the frontier of the current search. 
 * @author W.Pasman
 *
 */


public class NodeOnFrontier {
	public ArrayList<InstantiatedAction> pathToNode;
	public MentalState mentalstate;
	
	public NodeOnFrontier(MentalState ms, ArrayList<InstantiatedAction> p)  { mentalstate=ms; pathToNode=p; }

	public String toString()
	{	return "node["+mentalstate+","+pathToNode+",Cost["+cost()+"]]"; }
	
	public double cost() { 
		double cost=0;
		for (InstantiatedAction a:pathToNode) cost+=costOfAction(a);
		return cost;
	}	
	
	public boolean equals(Object n)
	{
		if (!(n instanceof NodeOnFrontier)) return false;
		System.out.println("NodeOnFrontier.equals"+this+","+n);
		boolean eq=pathToNode.equals(((NodeOnFrontier)n).pathToNode);
		System.out.println("equal="+eq);
		return eq;
	}
	/**
	* costOfAction is a heuristic, not a hard value.
	* Therefore we put it here, instead of making it part of Action or InstantiatedAction.
	*/	
	public double costOfAction(InstantiatedAction a) 
	{
		return costOfActionUseProlog(a); 
		//return costOfActionAllTableFirst(a); 
		//return costOfActionPreferBuilding(a);
	}


	/**
	 * cost function to get behaviour that uses prolog predicate cost(+a,-C).
	 * with a the action under consideration and C the cost of that action.
	 * Make sure that you call the right Agent.initCostFuncs() to make this work.
	 */
	public double costOfActionUseProlog(InstantiatedAction a) {
		
		Query query = new Query("cost("+a+",C)");
		Hashtable[] costs =query.allSolutions();
		String res=""+costs[0].get("C");
		System.out.println("cost of "+a+"="+res);

		return (new Double(res).doubleValue());
	}
	
	/**
	 * cost function to get behaviour that puts all blocks to table first.
	 * Set the lookahead to 1 in Agent.selectAction to make this work properly.
	 */
	public double costOfActionAllTableFirst(InstantiatedAction a) {
		if (!(a.getAction() instanceof UserSpecAction)) return 0; 
			// all mental actions have low value. Think before acting. 
			// BTW blocksworld has no thinking, only actions ;-)

		 // get the instantiated action
		UserSpecAction usa=(UserSpecAction)a.getAction().applySubst(a.getSubstitution());
		 // OK. Following works for the blocks world only.
		if (usa.getName().equals("putOn")) {
			//System.out.println("PutOn action found"+usa);
			// if table then return 1 else return 10
			//System.out.println("arg1="+usa.getParam()[1]);
			if (usa.getParam()[1].toString().equals("table")) return (1); // prefer putting to table.
			return 2;
		}
		return 0;
	}
	
	/**
	 * cost function to get behaviour that strongly prefers building towers over putting
	 * blocks to the table.
	 * Set the lookahead high, e.g. 5, in Agent.selectAction to make this work properly.
	 */

	public double costOfActionPreferBuilding(InstantiatedAction a) {
		if (!(a.getAction() instanceof UserSpecAction)) return 0; 
			// all mental actions have low value. Think before acting. 
			// BTW blocksworld has no thinking, only actions ;-)

		 // get the instantiated action
		UserSpecAction usa=(UserSpecAction)a.getAction().applySubst(a.getSubstitution());
		 // OK. Following works for the blocks world only.
		if (usa.getName().equals("putOn")) {
			//System.out.println("PutOn action found"+usa);
			// if table then return 1 else return 10
			//System.out.println("arg1="+usa.getParam()[1]);
			if (usa.getParam()[1].toString().equals("table")) return (10); // try avoid putting on table.
			return 1;
		}
		return 0;
	}

}