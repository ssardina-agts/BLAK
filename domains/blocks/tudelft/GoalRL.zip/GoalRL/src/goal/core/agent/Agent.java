package goal.core.agent;

import goal.core.env.Percept;
import goal.core.kr.Theory;
import goal.core.kr.language.*;
import goal.core.mentalstate.*;
import goal.core.program.*;
import goal.kr.implementations.swiprolog.SWIPrologLanguage;
import goal.parser.*;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;
import goal.kr.implementations.swiprolog.*;
import goal.kr.language.prolog.FuncTerm;
import goal.kr.language.prolog.PrologTerm;

import edu.liacs.dlt.associative.Network;
import edu.liacs.dlt.associative.ReasoningSystem;
import edu.liacs.dlt.associative.utils.*;

import goal.explanation.*;

import java.rmi.AlreadyBoundException;
import java.util.*;

/**
 * @author Koen Hindriks
 * Modified: W.Pasman,22feb08: lookAhead1Step (the old actionSelectionEngine) rewritten totally to cope with
 * multiple enabled actions in the action spec.
 * Wouter: added lookahead value, 16 jan...
 * Wouter: 28mar added Debugger hook.
 */

// TODO: Clean up this class: see code labeled OBSOLETE below

public final class Agent {
	
	// Class fields
	private String fName;
	private MentalState fMS=null; // call initMS to init fMS, fProg, etc.
	private Program fProg;
	private HashMap<String, ActionSpecification> fSpec;
	
	//for RL learning
	private HashMap<UpdateAction, Integer>actionToRule;
	private int lastRule=-1;
	private float reward;
	private String lastState;
	private Network MDPLearner;
	private ReasoningSystem MDPAction;
	private int steps=0;
	private int episode=0;
	private final int RANDOM=1;
	private final int GREEDY=2;
	private Tree actionList;//the list of action-value pairs (rule-value pairs in our case) 
	
	private Explanation expl;
	private ArrayList<PerceptRule> fPerceptRules;
	// TODO: Add: ActionSelectionEngine fASE;
	private Debugger fDebugger;
	private GOALProgram fParsedProgram;
	
	private Random random = new java.util.Random(); // uses time (in ms) as default seed.
	//private int horizon;
	
	// Class constructor
	public Agent(GOALProgram program, String agentName) throws Exception {
		//BeliefBase lKB1;

		fName = program.getAgentName(); // Wouter 27jul09: how about using the real agentName instead of the program name???
		// Initialize fParsedProgram and fDebugger first, needed in other methods for initializing agent
		if (program.checkDeclarationClashes())
			throw new Exception("Cannot start agent due to declaration clashes.");
		fParsedProgram = program;
		fDebugger = new Debugger(agentName);
		initMS(); // we do not yet have debug observers so debugger should not block on this call.
		 // note, this constructor is running in the CALLER's thread, not the agent's thread 
		 // therefore initMS() adds a SWI inference engine to the caller's thread
		 // and we should clean that up after use or we have a memory leak!
		 goal.kr.implementations.swiprolog.SWIQuery.FreeEngine(); // HACK this is SWI specific.
		// TODO: Lookahead 
		 
		 //Joost: Learning
		 MDPLearner=new Network(10000, 1);
		 MDPAction=new ReasoningSystem();
		 
		 //Explanation init the expl in goal.Global
		 if (goal.Global.explanations==null)
			 goal.Global.explanations=new HashMap<String, Explanation>();
		 goal.Global.explanations.put(this.getName(), new Explanation(this.getName()));
		 expl=goal.Global.explanations.get(this.getName());
	}
	
	/**
	 * call this to init MS. If fMS already initialised this returns straight away
	 * This call is under debug control so call may block until debugger gets permission to proceed.
	 * Therefore call this only from the Agent's thread (that is supposed to get blocked if requested so)
	 */
	private void initMS() throws Exception {
		if (fMS!=null) throw new AlreadyBoundException("Mental state is already initialized");
		System.out.println("Initializing agent "+fName);

		// CHECK: doesn't seem right to create databases here; move to Class MentalState... now need to pass agent to this class and make method createInitialGB public.
		ArrayList<BeliefBase> beliefbases = new ArrayList<BeliefBase>();
		// ADHOC: Duplicate knowledge to allow access from belief and goal base to it separately. Is there a better way to do this?
		beliefbases.add(createInitialBB(fParsedProgram.getBeliefs(), fDebugger));
		ArrayList<GoalBase> goalbases = createInitialGB(fParsedProgram.getGoals(), fDebugger);
		
		fMS = new MentalState(beliefbases, goalbases, this);

		fProg = new Program(fParsedProgram.getProgram());
		// FIXME: how many action specs do we have??
		fSpec = fParsedProgram.getActionSpec();
		fPerceptRules = fParsedProgram.getPerceptRules();
	}

	// Class methods
	public String getName() {
		return fName;
	}
	
	public void setName(String pName) {
		fName = pName;
	}
	
	public MentalState getMentalState() {
		return fMS;
	}

	public Program getProgram() {
		return fProg;
	}
	
	public GOALProgram getGOALProgram() {
		return fParsedProgram;
	}
	
	public Debugger getDebugger() {
		return fDebugger;
	}
	
	public void reset() throws Exception {
		if (fMS==null) return; // not even initialised, silent return. 
		// TODO: Cleanup.
		ArrayList<BeliefBase> beliefbases = new ArrayList<BeliefBase>();
		// ADHOC: Duplicate knowledge to allow access from belief and goal base to it separately. Is there a better way to do this?
		//beliefbases.add(lKB1 = createInitialKB(fDebugger));
		//beliefbases.add(createInitialBB(program.getBeliefs(), lKB1, fDebugger));
		beliefbases.add(createInitialBB(fParsedProgram.getBeliefs(), fDebugger));
		ArrayList<GoalBase> goalbases = createInitialGB(fParsedProgram.getGoals(), fDebugger);
		
		fMS = new MentalState(beliefbases, goalbases, this);
		
		//new Warning("Reset functionality has not yet been implemented!");
	}
	
	public void showStatistics() {
		fMS.showStatistics();
	}
	
	// Main capabilities of an agent: methods to process percepts and select & execute actions 
	
	/**
	 * @param percepts that the agent has received.
	 * Called by scheduler after new percepts become available.
	 * @version 2 now handling array of strings instead of array of Percept objects.
	 * @version 3 now taking pairs (percept,language) passed as two String arrays that have to have equal length.
	 * @version 4: now after inserting percepts applies all percept rules to process and removes percepts again
	 * CHECK
	 */
	// 
	public void processPercepts(ArrayList<Percept> pPercepts) throws Exception {
		fDebugger.bp("PP",  "Received percepts: "+pPercepts.toString(), 3);
		
		// First, clear the contents of the percept base
		fMS.getPerceptBase().eraseContent();
		// Note that method eraseContent() should NOT be called by the scheduler.
		// The scheduler should not query databases. Cf. Mantis 491.
		
		// Second, insert percepts into percept base.
		for (Percept percept: pPercepts) {
			// ADHOC: SWI-Prolog specific code here (assumed percept base is SWI-Prolog database).
			SWIFormula lForm = new SWIFormula(((SWIPrologLanguage.getInstance().parser(percept.getContent()+". ")))); // DOC: ". " is ISO Prolog END TOKEN.
			fMS.getPerceptBase().insert(lForm);
		}
		
		// Third, apply percept rules to update agent's mental state.
		// TODO: 09Mar07KH: percept rule order should be irrelevant
		for (PerceptRule perceptrule : fPerceptRules)
			perceptrule.applyRule(fMS, expl, fDebugger, steps);
		
		// Fourth, check whether goals have been achieved (just by perceiving ;-)
		fMS.updateGoalState(fDebugger);
	}

	/**
	 * @return parsed percept as QueryExpression, or null 
	 * @throws Exception if language is OK but parsing fails.
	 * @author W.Pasman
	 * */
	public QueryExpression parsePercept(Percept perceptP) throws Exception {

		ArrayList<BeliefBase> beliefBasesL=getMentalState().getBeliefBase();
		for (int n=0; n<beliefBasesL.size(); n++)
			if (perceptP.getLanguage().equals(beliefBasesL.get(n).getLanguage().getName())) {
				// Wouter: a SWIPredicate is used as a Formula.
				new Warning("parsing of percepts not implemented");
				//Formula 
				//SWIPredicate lPred = (SWIPredicate)lCept.getContent();
				//SWILiteral lLit = new SWILiteral(lPred,true);
				//getMentalState().updateState((QueryExpression)lLit);
			}
		return null;
	}

	/** @return selected action. Wouter 15jul08: now returns null if no action available.  
	 * @throws exception if initialization fails of the databases. */
	public Action performAction() throws Exception {
		
		//first get all possible actions and generate the RL state based on rule activation
		Set<UpdateAction> lActions = getEnabledActions(fMS);
		UpdateAction lUpdate;
		
		
		//start learning based on current state, previous selected action, and current reward
		if (goal.Global.RL_ON){
			if (lastRule!=-1)
				lastState=buildRLState(lastRule+":");
	        else
	        	lastState=buildRLState("-:");
			if (episode<goal.Global.LEARNING_PHASE){
				/*
				if (nrOfRulesActive()==1)
					Constants.DISCOUNT=1;
				else
					Constants.DISCOUNT=0.9;
					*/
				MDPLearner.train(lastState, getReward(), 0);
				//System.out.println(MDPLearner.printState());
			} else {
				MDPLearner.input(lastState, false, 0);
				//System.out.println(MDPLearner.printState());
			}
			
			if (fMS.getGoalBase().size()==0){
				
				//all goals resolved
				if (episode<goal.Global.EXPLOITATION_PHASE+goal.Global.LEARNING_PHASE){
					System.out.println((episode++)+", "+steps);
					telin.logger.client.ClientLWM.sendEvent("localhost", this.getName(), episode+"\t"+steps, "");
		    		this.reset();
					lastRule=-1;
					MDPLearner.reset();
					steps=0;
					if (!goal.Global.RL_REGENERATE_AFTER_EPISODE){
					try {
						goal.Global.platformManager.resetEnvironment();
					}catch (Exception e){}
					} else
					{
						try {//try to regenerate, if failed, try to reset
							goal.Global.platformManager.regenerateEnvironment();
						} catch (Exception e){
							try {
								goal.Global.platformManager.resetEnvironment();
							}catch (Exception ee){}
						}
					}
	    		} else
	    			goal.Global.platformManager.killAgent(getName());
				return null;
			}
			
		}
		//end learning
		
		//now use an action selection mechanism to select one
		if (episode<goal.Global.LEARNING_PHASE || !goal.Global.RL_ON) //if learning or RL disabled -> use RANDOM selection
			lUpdate = actionSelectionEngine(lActions, RANDOM);//change this to one that uses rule vales
		else {//learning is done 
			actionList=MDPAction.getActionList(MDPLearner);
			if (actionList.childs!=null && actionList.childs.size()>0 && !actionList.getBest().event.equals("-")){
				//if we have best action to select, use that one in the action selection method
				System.out.println("State:"+lastState+":"+actionList.print(1));
				System.out.println("State:"+lastState+" Proposed Rule:"+fProg.getRules().get((new Integer(actionList.getBest().event)).intValue()));
				lUpdate = actionSelectionEngine(lActions, GREEDY);
			} else //if there is no action from the learning model, use random selection
				lUpdate = actionSelectionEngine(lActions, RANDOM);
		}
		
		if (lUpdate==null)
			return null; 
		try {
			lUpdate.executeAction(fMS, fDebugger);
			//for RL
			lastRule=actionToRule.get(lUpdate);
			
			//for explanation
			expl.select(lUpdate, steps);
			
			steps++;
			return lUpdate.getAction();
		}
		catch (Exception e) {
			new Warning("executeAction "+lUpdate+" failed",e);
			steps++;
			return null;
		}
	}
	
	private String buildRLState(String action){
		//RL state is conjunction of action,subgoalsactive,rulestates
		String result=action;
		try {
			result+=""+fMS.countActiveGoalSentences(fDebugger);
		} catch (Exception e){result+="";}
		for (int i=0;i<fProg.getRules().size();i++) {
			result+=fProg.getRules().get(i).getState();
		}
		//count if this state equals the last state, i.e. count state occurences in a row
		/*
		if (lastState!=null && lastState.substring(lastState.indexOf(":")+1, lastState.indexOf("=")).equals(result.substring(result.indexOf(":")+1, result.length())))
			result+="="+(new Integer(lastState.substring(lastState.indexOf("=")+1, lastState.length()))+1);
		else
			result+="=0";
			*/
		lastState=result;
		return result;
	}
	
	private float getReward(){
		if (fMS.getGoalBase().size()==0)
			return 1;
		else
			return 0;
	}
	
	private int nrOfRulesActive(){
		int ruleCount=0;
		for (Rule actionrule : fProg.getRules())
			if (actionrule.getState()==2)
				ruleCount++;
		return ruleCount;
	
	}
	/** called by scheduler to inform agent about results of his performAction 
	 * @param environmentRecognisedAction is true if environment recognised this action
	 * @param exc contains an exception string if the environment threw an error due to your action.
	 * Added W.Pasman 19jan08 to improve feedback to agent on what happened with his action
	 * so that it can properly inform the user if he is debugging. */
	public void actionWasPerformed(String act, boolean environmentRecognisedAction, Exception exc) {
		if (!environmentRecognisedAction) {
			fDebugger.bp("WP",  "Environment ignored, "+act, 4);
		} else {
			if (exc==null) fDebugger.bp("WP",  "Environment executed "+act, 4);
			else {
				fDebugger.bp("WP",  "Environment failed execution of action"+act+":"+exc, 4);
				new Warning("Environment failed execution of action "+act,exc);
			}
		}

	}
	
	/**
	 * The method 'actionSelectionEngine' defines the heartbeat of all GOAL agents and makes them 'tick'.
	 * It selects an action that is enabled, i.e. an action of a rule whose mental state condition is satisfied and
	 * whose precondition is satisfied.  
	 * @return Corresponding update operator for selected action; returns null if no action is enabled.
	 * 
	 */
	public final UpdateAction actionSelectionEngine(Set<UpdateAction> lActions, int policy) {
		
		if (lActions.isEmpty()) {
			fDebugger.bp("AS","There are no enabled actions",1);
			return null;
		} else { //select an action according to the policy
			UpdateAction action=null;
			if (policy==RANDOM){
				// return random action from list of all enabled action
				int index = random.nextInt(lActions.size());
				action = (UpdateAction)(lActions.toArray())[index];
			} 
			if (policy==GREEDY){
				// return a random best action from best rule (random action in action list coming from the best rule)
				int best=(new Integer(actionList.getBest().event)).intValue();
				Vector<UpdateAction> actions=new Vector<UpdateAction>();
				for (int i=0;i<lActions.size();i++){
					if (actionToRule.get(lActions.toArray()[i])==best)
						actions.add((UpdateAction)(lActions.toArray())[i]);
				}
				action=actions.elementAt((int)(Math.random()*(double)actions.size()));
				
			}
			
			
			
			fDebugger.bp("AS","Picked action "+action,1);			
			return action;
		}
	}
	
	
	/**
	 * TODO: document.
	 * @return list of all applicable actions (may be empty)
	 */
	Set<UpdateAction> getEnabledActions(MentalState pMS) {
		Set<UpdateAction> lUpdateActions = new LinkedHashSet<UpdateAction>();
		actionToRule=new HashMap<UpdateAction, Integer>();
		
		fDebugger.bp("AS", "getting applicable actions", 3);
		// Compute actions that are selected, i.e. those actions instantiated such that their associated
		// rule conditions are satisfied. Then compute whether action preconditions are satisfied.
		int ruleCount=0;
		for (Rule actionrule : fProg.getRules()) {
			
			fDebugger.bp("AS", "Checking actionrule "+actionrule, 4);
			Set<Substitution> lSubstSet = new LinkedHashSet<Substitution>();
	
			lSubstSet = pMS.mscQuery(actionrule.getCondition(), fDebugger);
			if (lSubstSet.isEmpty())  fDebugger.bp("AS", "Rule not applicable:"+actionrule+lSubstSet, 5);
			else fDebugger.bp("AS", "Testing if rule preconditions hold:"+actionrule+lSubstSet, 5);
			 // Wouter: suggestion: avoid deep if() to make code more readable. eg by using return 
			if (!lSubstSet.isEmpty()) { // check preconditions of action of the rule
				//Joost: the Rule is in any case triggered--> Rule state is set to 1
				actionrule.setState(1);
				
				
				Action action = actionrule.getAction();
				if (!action.reserved()) { // check preconditions of user specified action
					ActionSpecification specification = fSpec.get(action.toString());
					if (specification==null) {
						new Warning("BUG (Agent): Could not find action specification for action "+action);
						break;
					}
					/* Wouter: fix for Mantis 405. restrict substitution to vars in head of actionrule 
					 * Maybe not necessary anymore since we now  rename all vars of the actionspec.
					Set<Var> varsToPassOn=action.getFreeVar();
					for (Substitution s: lSubstSet) {
						s.union(varsToPassOn);
					}
					*/
					ActionSpecification instantiatedSpec = specification.evalPreconditions(pMS, lSubstSet, fDebugger);
					if (instantiatedSpec==null) {
						fDebugger.bp("AS", "Actionrule Preconditions failed for "+specification, 5);
					}
					else {
						fDebugger.bp("AS", "Actionrule Precondition holds: "+instantiatedSpec, 5);
						//Joost: the precond for the actions in the rule hold --> Rule state is set to 2
						actionrule.setState(2);
						//instantiate the actions and add to the result
						ArrayList<UpdateAction> temp=instantiatedSpec.getUpdateActions(pMS, lSubstSet, fDebugger);
						lUpdateActions.addAll(temp);

						//Explanation: create an explanation for each instantiated action
						for (UpdateAction u: temp) {
							expl.createExplanationForGoalAction(u, actionrule.getCondition().getLiterals(), steps);
						}
						//end explanation
						
						
						while (temp.size()>0)//built the reverse mapping for knowing which action came form which rule
							actionToRule.put(temp.remove(0), new Integer(ruleCount));
						
						
						
					}
				} else { // handle reserved actions, 'adopt', 'drop', 'send'
					if (action instanceof AdoptAction) { // adopt is enabled if goal to be adopted does not follow from belief base
						for (Substitution lSubst : lSubstSet) {
							Boolean lEnabled;
							Expression newexp=((AdoptAction)action).getGoal().applySubst(lSubst);
							// ADHOC following only supported for SWI.
							QueryExpression lQuery = new SWIQueryExpression((SWIExpression)newexp);
							if (lQuery.isClosed()) {
								// DOC: adopt is enabled when agent does not have goal lQuery already nor believes lQuery to be the case
								lEnabled = (pMS.beliefQuery(lQuery, fDebugger).isEmpty()) && (pMS.goalQuery(lQuery, fDebugger).isEmpty());
								if (lEnabled) {
									fDebugger.bp("AS","enabled "+actionrule,3);
									//Joost: the Rule in total is active. --> Rule state is set to 2
									actionrule.setState(2);
									UpdateAction temp=new UpdateAction(actionrule.getAction().applySubst(lSubst), null);
									temp.setSubstitution(lSubst);
									lUpdateActions.add(temp);
									actionToRule.put(temp, new Integer(ruleCount));
									
									//Explanation: create an explanation for this instantiated adopt
									expl.createExplanationForGoalAction(temp, actionrule.getCondition().getLiterals(), steps);
									
								}
							} else
								// Wouter: Following message is not OK, no attempt is done to execute action.
								// KH 29Jul08 DOC: WE blocked it... but GOAL PROGRAMMER did not...
								// TODO: Actually, what we need is a parser that filters out this possibility...
								new Warning("Attempt to execute action "+action.applySubst(lSubst)+" with free variables.");
						}
					} else {
						// TODO introducing adoptone action requires functionality from kr language that is currently not available
						if (action instanceof AdoptOneAction) { // adoptone is enabled if no other "similar" instance of goal has been adopted and the goal does not follow from belief base
							for (Substitution lSubst : lSubstSet) {
								Boolean lEnabled;
								Expression newexp = ((AdoptOneAction)action).getGoal().applySubst(lSubst);
								// ADHOC SWI Prolog
								if (((SWIExpression)newexp).isPredicate()==null) {
									PrologTerm term = ((SWIExpression)newexp).getTerm(); 
									// String name = term.getName();
									if (term instanceof FuncTerm) {
										// ((FuncTerm)term).getArguments()
									}
								} else 
									new Warning("Attempt to execute adoptone action "+action.applySubst(lSubst)+" with something else than predicate.");
									
									
								// ADHOC following only supported for SWI.
								QueryExpression lQuery = new SWIQueryExpression((SWIExpression)newexp);
								if (lQuery.isClosed()) {
									// DOC: adoptone is enabled when agent does not have goal lQuery already nor believes lQuery to be the case
									lEnabled = (pMS.beliefQuery(lQuery, fDebugger).isEmpty()) && (pMS.goalQuery(lQuery, fDebugger).isEmpty());
									if (lEnabled) {
										fDebugger.bp("AS","enabled "+actionrule,3);
										UpdateAction temp=new UpdateAction(actionrule.getAction().applySubst(lSubst), null);
										temp.setSubstitution(lSubst);
										lUpdateActions.add(temp);
										actionToRule.put(temp, new Integer(ruleCount));
										//Joost: the Rule in total is active. --> Rule state is set to 2
										actionrule.setState(2);
										
										//Explanation: create an explanation for this instantiated adoptone
										expl.createExplanationForGoalAction(temp, actionrule.getCondition().getLiterals(), steps);
										
										
									}
								} else
									// TODO: Actually, what we need is a parser that filters out this possibility...
									new Warning("Attempt to execute action "+action.applySubst(lSubst)+" with free variables.");
							}
						} else { // drop, send
						for (Substitution lSubst : lSubstSet) {
							if (actionrule.getAction().applySubst(lSubst).isClosed()) { // TODO: might want to allow free variables in SOME send actions
								//Joost: the Rule in total is active. --> Rule state is set to 2
								actionrule.setState(2);
								fDebugger.bp("AS","enabled "+actionrule,3);
								UpdateAction temp=new UpdateAction(actionrule.getAction().applySubst(lSubst),null);
								temp.setSubstitution(lSubst);
								lUpdateActions.add(temp);
								actionToRule.put(temp, new Integer(ruleCount));
								
								//Explanation: create an explanation for this instantiated drop or send
								expl.createExplanationForGoalAction(temp, actionrule.getCondition().getLiterals(), steps);

								
							} else {
								// Wouter: Following message is not OK, no attempt is done to execute action.
								// KH 29Jul08 DOC: Yeah, right, WE blocked it... but GOAL PROGRAMMER did not...
								new Warning("Attempt to execute action "+actionrule.getAction().applySubst(lSubst)+" with free variables.");
							}
						}
						}
					}
				}
			} else{
				//the preconsition of the rule is not met so we set the state of the rule to 0 (not active) 
				actionrule.setState(0);
			}
			ruleCount++;
		}
		
		return lUpdateActions;
	}


	
	// Helper methods to create (initial) mental state TODO need to move this to mental state class.
	
	/** Added W.Pasman 11jul08: determine type of databases and load knowledge into them
	 * This was part of the parser but that is not possible be in the long term, as Agent may be on even
	 * a different machine than the parser.
	 * Also the exact choice of database is probably up to the Agent, not the parser. 
	 * @param formulae is Arraylist of SWIFormulas, one per goal. For each goal a new dbase will be made.
	 * 
	 * KH Jul08: Added code to handle imports/exports and declare dynamic predicates.
	 * 
	 */
	
	private BeliefBase createInitialBB(ArrayList<Formula> formulae, Debugger debugger)  throws Exception {
		
		Set<String> reserved = new LinkedHashSet<String>(), kbCalls, dynDecl, check = new LinkedHashSet<String>();
		LinkedHashSet<String> bbDecl, kbDecl;
		reserved.add("percept(_,_)");
		reserved.add("percept(_)");
		reserved.add("received(_,_)");
		reserved.add("sent(_,_)");
		bbDecl = fParsedProgram.getDeclarations(formulae);
		kbDecl = fParsedProgram.getDeclarations(fParsedProgram.getKnowledge());
		kbCalls = fParsedProgram.getCalls(fParsedProgram.getKnowledge());

		// check for name clashes
		check.addAll(bbDecl);
		check.retainAll(kbDecl);
		if (!check.isEmpty())
			throw new Exception("Agent "+fName+"'s belief section defines "+check.toString().substring(1,check.toString().length()-1)+" which "+(check.size()==1 ? "has" : "have")+" been defined in the knowledge section already.");

		BeliefBase lBB = new BeliefBase("beliefbase", new Theory(formulae), SWIPrologLanguage.getInstance());
		lBB.addBackgroundKnowledge(new Theory(fParsedProgram.getKnowledge()));
		
		// check for predicates that need to be declared dynamic in the belief base
		dynDecl = kbCalls;
		dynDecl.addAll(fParsedProgram.getCalls(formulae));
		dynDecl.addAll(fParsedProgram.getBBConditionDeclarationsFromRules());
		// next line needed if 'goal' operator refers to achievement goals that require a check on the belief base
		dynDecl.addAll(fParsedProgram.getGBConditionDeclarationsFromRules());
		dynDecl.addAll(fParsedProgram.getPreConditionDeclarations());
		dynDecl.addAll(fParsedProgram.getPostConditionDeclarations());
		dynDecl.addAll(fParsedProgram.getPerceptRuleCondDeclarations());
		dynDecl.addAll(fParsedProgram.getDeclarations(fParsedProgram.getGoals()));
		dynDecl.removeAll(bbDecl); // bb declared predicates are covered
		dynDecl.removeAll(kbDecl); // kb declared predicates are covered
		dynDecl.removeAll(reserved); // exclude GOAL reserved predicates
		declareDynamic(lBB, dynDecl);
		
		return lBB;
	}
	
	public ArrayList<GoalBase> createInitialGB(ArrayList<Formula> formulae , Debugger debugger) throws Exception {
		
		ArrayList<GoalBase> lGBs = new ArrayList<GoalBase>();
		
		for(Formula formula: formulae) {
			
			Set<String> kbCalls, dynDecl, kbDecl;

			kbDecl = fParsedProgram.getDeclarations(fParsedProgram.getKnowledge());
			kbCalls = fParsedProgram.getCalls(fParsedProgram.getKnowledge());
			
			// It seems we have to duplicate the knowledge base to get things working correctly...;
			// DOC: this is where using SWI-Prolog becomes really limiting, for every goal we would simply like
			// to combine it with the knowledge the agent has (not its beliefs!) when we query the corresponding
			// database; can we do this with 2p/Tu Prolog?
			ArrayList<Formula> content = new ArrayList<Formula>();
			content.add(formula);
			
			GoalBase lGB = new GoalBase("goalbase", new Theory(content), SWIPrologLanguage.getInstance());
			lGB.addBackgroundKnowledge(new Theory(fParsedProgram.getKnowledge()));

			// check for predicates that need to be declared dynamic in the goal base
			dynDecl = kbCalls;
			dynDecl.addAll(fParsedProgram.getCalls(formulae));
			dynDecl.addAll(fParsedProgram.getGBConditionDeclarationsFromRules());
			
			ArrayList<Formula> currentgoal = new ArrayList<Formula>();
			currentgoal.add(formula);
			dynDecl.removeAll(fParsedProgram.getDeclarations(currentgoal)); // predicates introduced in current goal base are covered
			dynDecl.removeAll(kbDecl); // kb declared predicates are covered
			declareDynamic(lGB, dynDecl);

			lGBs.add(lGB);
		}
		return lGBs;
	}
	
	private void declareDynamic(Base base, Set<String> dynamicpred) {
		// Declare predicates as dynamic predicates in base so they can be updated and queried
		// ASSUMES that all bases are implemented as Prolog databases
		try {
			for (String name : dynamicpred) {
				SWIQuery.synchronizedRawquery("dynamic("+base.getDatabase().getName()+":"+name +")");
			}
		} catch (Exception e) { new Warning("Did not succeed in declaring predicates dynamic in base "+base.getDatabase().getName(),e); }
	}
	
	/**
	 * Take down this agent.  This is currently called by the JadeGOALAgent when the agent is taken down.
	 * CHECK who really should call this.
	 *  @author W.Pasman. 
	 */
	public void takeDown() throws Exception {
		 goal.kr.implementations.swiprolog.SWIQuery.FreeEngine();
	}
	
	


}