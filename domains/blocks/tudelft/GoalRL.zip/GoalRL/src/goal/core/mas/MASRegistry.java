package goal.core.mas;

import goal.core.agent.Agent;
import goal.tools.errorhandling.Warning;
import jade.wrapper.AgentController;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author K.Hindriks
 * @modified 19jun08 W.Pasman
 * The mas registry is a datastructure that is used to store info about a GOAL multi-agent system that is needed when
 * the mas is launched (i.e. runtime information). In the mas registry the information present in a mas file is stored,
 * where a mas file is a recipe for launching a GOAL project.
 * ASSUMPTION: Agents referenced in a mas file each have a unique identifier.
 * Other info about a GOAL project (such as old files not used anymore at runtime) is stored in the edit environment.
 * TODO: add functionality to add/save a GOAL project to store the latter info. 
 * The info kept in the registry is loaded at various stages:
 * 	- agent and file names for GOAL agents when a mas file is loaded by the IOManager.
 *  - GOAL agent (object) when agent is launched in runtime environment.
 *  - JADE controller agent when corresponding JADE agent is launched in runtime environment.
 *  
 *  From discussion 28aug I infer that now the registry records
 *  (1) instances of agents as they were loaded&parsed when the user pressed RUN on the .mas file
 *  (2) the links to the controllers of these agents.
 *  
 *  The idea is now that you can re-start an agent by stopping it and re-starting, even if you have been
 *  editing the .goal file (it will not be parsed, we just reset() the existing agent instantiation)
 *  
 */
public class MASRegistry {
	
	// Class fields
	String fMASFilename;
	// Hashmap maps agent name to corresponding GOAL agent file.
	// All agent names that occur in the other hashmaps below should occur in fFilenames hashmap!
	HashMap<String, String> fFilenames = new HashMap<String, String>();
	// Hashmap maps agent name to number of instances that should be created when agent is launched.
	// This data structure is used to implement #nr option in mas file associated with agent name.
	// WOUTER: removed the following 30jun09, it is not used anyway except incorrectly in killMAS - seem mantis 528
	// HashMap<String,Integer> fInstances = new HashMap<String,Integer>();
    // Hasmap maps agent names to corresponding GOAL agent (object).
	HashMap<String, Agent> fAgents = new HashMap<String, Agent>();
	// Wouter, 3mar09: map agent to environment. Currently we only have "" (not connected) and "environment"
	HashMap<String,String> fEnvironmentConnections=new HashMap<String,String>();

	// Hasmap maps agent names to corresponding JADE agent controller (object).
	
	/** ASSUMPTION: We have a controller <=> the agent is 'running' (not 'killed', maybe in PAUSE). */
	HashMap<String,AgentController> fControllers = new HashMap<String, AgentController>();
	// TODO: Add data structures to implement e.g. #include:filename.bb and #overrride:filename.bb functionality.
	// TODO: Add functionality to ensure consistency between various hashmaps?
	boolean fRunning = false;
	
	 /** Wouter: added following 28oct08. 
	  * We use the base path if you specify a relative path. */
	String EnvironmentClassPath=null; // path to root of environment package. May be a .jar file.
	String EnvironmentClassName=null; // full name of environment class. Eg wumpusenv.WumpusWorld.
	

	// Class constructor
	public MASRegistry(String pMASFilename) {
		fMASFilename = pMASFilename;
	}

	// Class methods

	/*
	 * Methods to initialize or update registry. 
	 */
	public void addAgentFilename(String pAgentName, String pEnvironment, String pFilename) {
		String lFilename = fFilenames.get(pAgentName);
		if (lFilename != null)
			new Warning("Could not associate "+pAgentName+" with "+pFilename+"; agent name already present in registry and associated with "+lFilename+".");
		else {
			fFilenames.put(pAgentName, pFilename);
			fEnvironmentConnections.put(pAgentName,pEnvironment); //Added W.Pasman 3mar09
		}
	}
	
	/** @returns base path for all .goal files. The base path is the directory containing the .mas file. 
	 * @author W.Pasman
	 * @deprecated 9apr09 as IOManager now has functionality for this.*/
	public String getBasePath()
	{
		// compute base path to be pre-pended to the specified goal filenames.
		// this basePath includes the '/' at the end.
		int indexofsep = fMASFilename.lastIndexOf('/');
		String basePath="";
		if (indexofsep>0) basePath=fMASFilename.substring(0,indexofsep+1);
		return basePath;
	}
	
	/** @returns the absolute path for a given path name. 
	 * The idea is that
	 * PathName is specified by the user and may contain an absolute or a relative path.
	 * Absolute paths start with a "/", eg /Volumes/Documents/Wouter/Desktop/wumpus/Environment.class,
	 * and relative paths do not start with "/", eg Environment.class.
	 * Relative paths are prefixed with the base path (see getBasePath() ). 
	 * @author W.Pasman 28oct08. 
	 * @deprecated 9apr09 as IOManager now has functionality for this */
	public String getAbsolutePath(String PathName){
		if (PathName.startsWith("/")) return PathName;
		return getBasePath()+PathName;
	}
	
	public void addAgent(String pAgentName, Agent pAgent) throws Exception {
		// ASSUMPTION: Agent pAgentName not already present!
			pAgent.setName(pAgentName); // make sure agent name matches with name in mas file; TODO: name specified in GOAL file is not used.
			fAgents.put(pAgentName, pAgent);
	}
	
	public void addController(String pAgentName, AgentController pAgentController) {
		fControllers.put(pAgentName, pAgentController);
	}

	public void setEnvironment(String ClassPath, String ClassName) {
		EnvironmentClassPath=ClassPath; 
		EnvironmentClassName=ClassName;
	}
	
	/** get absolute environment class Path.
	 * 11mar09: now returns null if there is no environment available. 
	 */
	public String getEnvironmentClassPath() {
		return EnvironmentClassPath;
		// 9mar09: resolvation against other paths now is done in PM.
		//if (EnvironmentClassPath==null) return null;
		//return getAbsolutePath(EnvironmentClassPath);
	}
	
	public String getEnvironmentClassName() {
		return EnvironmentClassName;
	}
	
	/** method kills agent process from runtime environment upon user request to do so. This only involves killing the
	 JADE controller and references to the agent in the environment and scheduler(s). It does not remove the GOAL
	 agent (object) although it does perform a reset of the belief and goal base of the agent.
	 It does NOT remove any open introspectors for this agent!
	 */
	public void killAgent(String pAgentName) throws Exception {
		
		// STEP 1: Cleanup. Unregister agent from environment and scheduler(s).
		// TODO: Need to extend environment interface. Requires functionality provided by environment to do so.
		// TODO: Need to have access to both environment and scheduler(s), which should be part of mas registry.
		// This cleanup may need to be done before actual killing of agent object and controller to avoid problems
		// with runtime environment.

		// STEP 2: Reinitialize databases of GOAL agent (object). Does NOT remove GOAL agent from registry.
		// TODO: This reset needs to be performed by using initial database contents stored in memory(!) and not by
		// means of reload from file since user may have edited the file in the mean time.
		// Resetting cannot be done simply by inspecting associated GOAL file since in mas file belief base may have
		// been overridden, etc. Thus need to inspect mas file to do it properly.
		
		// Wouter: CHECK: Following is ugly. why are we reset()ting agent ? 
		// And note, this is a HARD CALL, agent is still running in its own thread?!!
		// Wouter: removed reset(), see mantis 698
		//getAgent(pAgentName).reset();

		// STEP 3: Kill JADE controller
		AgentController ct=fControllers.get(pAgentName);
		if (ct==null) throw new RuntimeException("internal problem: agent " + pAgentName +	"was already killed");
		ct.kill();
		fControllers.remove(pAgentName);
	}
	
	/* Cleanup registry. Called when runtime environment associated with registry is terminated.
	 TODO: remove all references to GOAL agents, including JADE controllers, references in environment and scheduler,
	 clean up database space, terminate scheduler (an environment if possible? I.e. when restart functionality is
	 available for environment).
	 */
	public void KillMAS() {
		String agtname="not set";
		 // Wouter: modified: now this kills all agents and removes them from the registry.
		while (!(fControllers.isEmpty()))
			try {
				agtname=(String)(fControllers.keySet().toArray()[0]);
				killAgent(agtname);
				//AgentController ct=fControllers.get(agtname);
				//if (ct!=null) { ct.kill(); fControllers.remove(agtname); }
				//fAgents.remove(agtname); 
			} catch (Exception e) { new Warning("Kill of agent '"+agtname+"' failed",e); }
	}
		
	// fRunning keeps track of whether mas has already been launched, i.e. is running and runtime environment
	// has been started. User has to first terminate runtime environment before mas can be (re)started.
	public void setStatus(boolean pRunning) {
		fRunning = pRunning;
	}

	/*
	 * Methods to inspect registry.
	 */
	public boolean getStatus() {
		return fRunning;
	}
	
	public String getMASFilename() {
		return fMASFilename;
	}
	
	// returns HashMap with keys being the agent names and value being the filenames
	public HashMap<String, String> getFilenames() {
		return fFilenames;
	}

	public String getFilename(String pAgentName) {
		return fFilenames.get(pAgentName);
	}
	
	public ArrayList<String> getAgentNames() {
		ArrayList<String> lAgentNames = new ArrayList<String>();
		for (String lAgentName: fFilenames.keySet())
				lAgentNames.add(lAgentName);
		return lAgentNames;
	}

	// @return all running instantiations of a given GOAL file. @param pFilename must be full path to a GOAL file
	public ArrayList<String> getInstantiationsOf(String pFilename) {
		ArrayList<String> lAgentNames = new ArrayList<String>();
		for (String lAgentName: fFilenames.keySet())
			if (fFilenames.get(lAgentName).equals(pFilename))
				lAgentNames.add(lAgentName);
		return lAgentNames;
	}
	
	public boolean containsAgentName(String pAgentName) {
		return fFilenames.containsKey(pAgentName);
	}
	
	// @return GOAL agent with name pAgentName. Returns null if GOAL agent with that name does not exist.
	public Agent getAgent(String pAgentName) {
		return fAgents.get(pAgentName);
	}

	public ArrayList<Agent> getAgents() {
		ArrayList<Agent> lAgents = new ArrayList<Agent>();
		for (Agent lAgt : fAgents.values().toArray(new Agent[fAgents.size()])) {
			lAgents.add(lAgt);
		}
		return lAgents;
	}

	 /** @returns true if registry contains agent with this name (Wouter added docu 6aug09) */
	public boolean containsAgent(String pAgentName) {
		return fAgents.containsKey(pAgentName);
	}
	
	public AgentController getController(String pAgent) {
		return fControllers.get(pAgent);
	}
	
	public boolean containsController(String pAgentName) {
		return fControllers.containsKey(pAgentName);
	}
	
	public ArrayList<Agent> getRunningAgents() {
		ArrayList<Agent> agts = new ArrayList<Agent>();
		for (String runningagtname : fControllers.keySet()) {
			agts.add(fAgents.get(runningagtname));
		}
		return agts;
		
	}
	
	public String getEnvironmentConnection(String pAgent) {
		return fEnvironmentConnections.get(pAgent);
	}
	

}
