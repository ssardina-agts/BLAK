package goal.core.program;

import java.util.Set;

import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;
import goal.kr.implementations.swiprolog.SWIVariable;
import goal.tools.errorhandling.Warning;

public class SendAction implements Action {
	
	// Class field
	String fAgentName; // name of agent to which message is sent
	QueryExpression fQuery;	// message that is being sent
	
	// Class constructor
	public SendAction(String pName, QueryExpression pQuery) {
		fAgentName = pName;
		fQuery = pQuery;
	}
	
	// Class methods
	public String getAgentName() {
		return fAgentName;
	}

	public QueryExpression getMessage() {
		return fQuery;
	}
	
	public String toString() {
		return "send("+fAgentName+","+fQuery.toString()+")";
	}

	public Action applySubst(Substitution pSubst) {
		// HACK: need to implement a decent way of handling variables for agent parameter
		// FIXME:
		try{
			SWIVariable lVar;
			if (Character.isUpperCase(fAgentName.charAt(0))) {
				lVar = new SWIVariable(fAgentName);
			} else {
				lVar = new SWIVariable("_");
			}
			if (pSubst.get(lVar)!=null) {
				return new SendAction(pSubst.get(lVar).toString(), (QueryExpression)fQuery.applySubst(pSubst));
			} else
				return new SendAction(fAgentName, (QueryExpression)fQuery.applySubst(pSubst));
		} catch (Exception e) { new Warning("Internal error: apply substitution failed",e); return null; }
	}

	public Set<Var> getFreeVar() {
		// ADHOC: TODO: need to allow for genuine variables here. Should not be a SWI variable...
		SWIVariable lVar = null;
		if (Character.isUpperCase(fAgentName.charAt(0))) {
			try{
				lVar = new SWIVariable(fAgentName);
			} catch (Exception e) {
				new Warning("can't get var from "+fAgentName,e);
			}
			Set<Var> lFreeVar = fQuery.getFreeVar();
			lFreeVar.add(lVar);
			return lFreeVar;
		}
		return fQuery.getFreeVar();
	}

	public String getName() {
		return "send";
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public SendAction clone() {
		return new SendAction(fAgentName, fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof SendAction)) return false;
		return fQuery.equals(((SendAction)pObj).getMessage());
	}

	public boolean reserved() {
		return true;
	}
	
	public Substitution mgu(Action pAct) {
		return null; // TODO:
	}
}
