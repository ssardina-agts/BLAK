package goal.core.kr.language;

import goal.core.kr.*;
import java.util.Set;

/**
 * 
 * Wouter: an Expression is a general database object, for instance
 * aap, 12, blabla(3,4), sin(3.2), :-(:-(2)) or sum(1,2,3). It can have either boolean or non-boolean "return value"
 * BTW in Prolog you still can query these expressions, as prolog has no types.

 * CHECK Koen please check & update this documentation.
 * @author Koen Hindriks
 *
 */

public interface Expression {
		
	// Class methods
	
	public KRlanguage getLanguage();
	
	/** Wouter: reverse engineered: objects are equal if all fields are literally equal,
	 * even the variable names have to be equal. */
	public boolean equals(Object obj);
	
	public int hashCode();
	
	/**
	 * Initialise new memory for clone copy of expression.
	 */
	public Expression clone();
	
	public boolean isClosed();
	
	public boolean isVar();
	
	/**
	 * @return This method returns all free variables in an expression.
	 */
	public Set<Var> getFreeVar();
	
	/**
	 * Methods to instantiate free variables by applying substitutions and to compute a most general unifier
	 * of two terms. (Assume? this method) "Destroys"/"replaces" old expression (object) and returns new instantiated one. 
	 */
	public Expression applySubst(Substitution pSubst);
	
	/** Wouter: I assume that mgu is the 'most general unifier' algorithm of this with the given expression.
	 * Wouter: this should use the occurs check.
	 * @returns Substitution that makes expressions equal, or null if unification is impossible.
	*/
	public Substitution mgu(Expression pExpr) ;
	
	/**
	 * Methods to convert back and forth between expressions and strings.
	 * @return
	 */
	public String toString();
	
	/**
	 * No method to convert strings to expressions here. Use the parser method in the associated KRlanguage class.
	 */

}
