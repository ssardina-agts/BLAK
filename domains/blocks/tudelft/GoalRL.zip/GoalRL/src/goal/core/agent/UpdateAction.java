package goal.core.agent;

import goal.core.kr.language.*;
import goal.kr.implementations.swiprolog.*;
import goal.core.kr.language.QueryExpression;
import goal.core.mentalstate.MentalState;
import goal.core.program.Action;
import goal.core.program.AdoptAction;
import goal.core.program.DropAction;
import goal.core.program.SendAction;
import goal.tools.errorhandling.Warning;
import goal.tools.debugger.Debugger;

/**
 * 
 * @author Koen Hindriks
 *
 */

/**
 * This class apparently contains a wrapper for an Action, with the post condition included. 
 * TODO: update this info.
 * Class added to facilitate action selection, which involves two things:
 * (i) selecting an enabled action, and
 * (ii) computing the corresponding variable bindings (substitution) for any free variables in action parameters.
 * 
 */
public class UpdateAction {
	
	// Class fields
	private Action fAct;
	private Formula fPostcondition;
	
	//Joost: Explanation backlink to substitution used for this update action
	private Substitution subst;
	
	// Constructor 
	public UpdateAction(Action pAct, Formula pForm) {
		// ASSUMPTION: pAct is closed, as is pForm.
		fAct = pAct;
		fPostcondition = pForm;
	} 
	
	// Class methods
	public Action getAction() {
		return fAct;
	}
	
	public Formula getUpdate() {
		return fPostcondition;
	}
	
	/**
	 * Only update actions can be executed, i.e. the instantiated postcondition can be
	 * used to update the mental state of the agent.
	 * @throws Exception if update can not be done, eg becuase no database with appropriate language exists.
	 * @param pMS
	 */
	public void executeAction(MentalState pMS,Debugger debugger) throws Exception {
		if (fAct.reserved()) { 
			pMS.executeAction(fAct, debugger);	
		} else { // User specified action. The MS is changed by the postcondition, not by the action.
			if ((fAct.isClosed()) && (fPostcondition.isClosed())) {
				// do not update with postcondition 'true'
				if (!fPostcondition.toString().equals("true")) {
					try {
						pMS.updateState(new SWIQueryExpression((SWIFormula)fPostcondition),debugger); // TODO what if not SWIFormula.
					} catch (Exception e) {
						new Warning("Update "+this+" failed: ",e);
					}
				}
			} else { // only warning is issued if action or postcondition has free variables 
				new Warning("Attempt to execute action "+this+" with free variable.");
			}
		}
	}

	/**
	 * Returns true if object pObj is equal to this update action.
	 * This is the case whenever the object is an update action and has the same
	 * field values. 
	 */
	public boolean equals(Object pObj) {
		if (!(pObj instanceof UpdateAction)) {
			return false;
		}
		return ((fAct.equals(((UpdateAction)pObj).getAction())) &&
				(fPostcondition.equals(((UpdateAction)pObj).getUpdate())));
	}
	
	public String toString() {
		return "Update("+fAct+",postcond["+fPostcondition+"])";
	}
	
	//Joost: Explanation backlink to substitution used for this update action methods
	public void setSubstitution(Substitution s){
		subst=s;
	}
	public Substitution getSubstitution(){
		return subst;
	}
}