package goal.core.program;

import java.util.Set;
import goal.kr.implementations.swiprolog.*;

import goal.core.kr.language.*;

public class AdoptOneAction implements Action {
	
	// Class field
	QueryExpression fQuery;
	
	// Class constructor
	public AdoptOneAction(QueryExpression pQuery) {
		fQuery = pQuery;
	}
	
	// Class methods
	public String getName() {
		return "adoptone";
	}

	public QueryExpression getGoal() {
		return fQuery;
	}
	
	public Action applySubst(Substitution pSubst) {
		return new AdoptOneAction(new SWIQueryExpression((SWIExpression)fQuery.applySubst(pSubst)));
	}

	public Set<Var> getFreeVar() {
		return fQuery.getFreeVar();
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public AdoptOneAction clone() {
		return new AdoptOneAction(fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof AdoptOneAction)) {
			return false;
		}
		return fQuery.equals(((AdoptOneAction)pObj).getGoal());
	}
	
	public boolean reserved() {
		return true;
	}

	public Substitution mgu(Action pAct) {
		return null; // TODO: implement
	}
	
	public String toString() {
		return "adoptone("+fQuery.toString()+")";
	}

}
