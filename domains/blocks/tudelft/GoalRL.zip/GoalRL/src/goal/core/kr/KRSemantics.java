package goal.core.kr;

import goal.core.kr.language.*;

public interface KRSemantics {
	
	public Term parseTerm(String pValue);
	
	public Formula parseFormula(String pValue);
	
}
