package goal.core.agent;

import java.util.Set;

import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;
import goal.core.kr.language.Substitution.Binding;
import goal.core.program.Action;
import goal.core.mentalstate.MentalState;

import java.util.HashMap;

/**
 * LookAheadTreeNode is a node in a lookahead tree.
 * The algorithm buildLookaheadTree in Agent.java builds a tree
 * with these nodes, to figure out all possible next actions and their
 * consequences.
 * 
 * @author W.Pasman
 *
 */


public class LookAheadTreeNode {
	
	private HashMap<InstantiatedAction,LookAheadTreeNode> children=new HashMap<InstantiatedAction,LookAheadTreeNode> (); 	
	private MentalState mentalstate;
	
	

	public LookAheadTreeNode(MentalState ms)  { mentalstate=ms;}

	public void addchild(InstantiatedAction act,LookAheadTreeNode newchild )
	{
		children.put(act,newchild);
	}

	public String toString()
	{	return "node["+mentalstate+","+children+"]"; }
	
	
	public int nodeCount()
	{
		int n=1;
		for (LookAheadTreeNode c:children.values()) n=n+c.nodeCount(); 
		return n;
	}
	
}