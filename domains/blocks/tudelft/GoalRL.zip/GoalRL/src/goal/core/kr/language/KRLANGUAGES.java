package goal.core.kr.language;

/**
 * 
 * @author Koen Hindriks
 *
 */

public enum KRLANGUAGES {
	SWIProlog;
}
