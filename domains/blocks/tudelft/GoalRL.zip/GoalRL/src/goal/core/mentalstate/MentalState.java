package goal.core.mentalstate;

import goal.core.agent.Agent;
import goal.core.kr.*;
import goal.core.kr.language.*;
import goal.core.program.*;
import goal.kr.implementations.swiprolog.*;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

import java.util.*;
import java.lang.IllegalArgumentException;



/**
 * 
 * @author Koen Hindriks
 *
 */

// TODO: Clean up this class. Use of various query methods and update methods not clear anymore.

public class MentalState {
	
	// Class fields
	/**
	 * A mental state of an agent conceptually is a pair, consisting of a belief base and a goal base.
	 * Technically, both a belief base and a goal base may however consist of multiple components, or databases,
	 * each with a different associated knowledge representation language.
	 * ASSUMPTION: The number of belief bases and goal bases is static during execution. 
	 */
	ArrayList<BeliefBase> fBB;
	BeliefBase fPercepts;
	BeliefBase fMailbox;
	ArrayList<GoalBase> fGB;
	
	Agent agent; // DOC: Used when creating new goal base.
		
	// Constructor
	public MentalState(ArrayList<BeliefBase> pBB, ArrayList<GoalBase> pGB, Agent pAgent) {
		if (pBB.size() == 0) new Warning("belief base is empty!");
		if (pGB.size() == 0) new Warning("goal base is empty!");

		fBB = pBB;
		fGB = pGB;
		
		agent = pAgent; // See remark above.

		initMailbox(agent.getDebugger());		// Initialise a Mailbox
		fBB.add(fMailbox);	// HACK: to make mailbox visible... HACK: using SWIProlog to handle mailbox
		initPerceptBase(agent.getDebugger());	// Initialise a Percept Base
		fBB.add(fPercepts); // HACK: to make percept base visible... HACK: using SWIProlog to handle perceptbase
	}

	// Class methods

	// Initialisation methods
	public void initMailbox(Debugger debugger) {
		// ADHOC: SWI-Prolog specific code below. ASSUMPTION: agents communicate in uniform language, Prolog for now.
		// NICETOHAVE: Extend this code to allow for multiple mailboxes to receive statements in different kr languages.
		// MAY need to move this code to platform manager (only platform manager may be assumed to know specifics of
		// communication languages used), and use new 'initMailbox' here.
		try {
			fMailbox = new BeliefBase("mailbox", new Theory(), SWIPrologLanguage.getInstance());
			//fMailbox = new BeliefBase(SWIPrologLanguage.getInstance().makeDatabase("mailbox", new Theory()));
		} catch (Exception e) {
			new Warning("Mailbox could not be created.",e);
		}
		// TODO: need to make nr of arg of 'received' dependent on timestamping if turned on. 
		// Declare 'received/2' as in 'received(AgentName,MessageContent)' and 'sent/2' dynamic.

		// HACK obviously this is SWI dependent.		
		try {
			SWIQuery.synchronizedRawquery("dynamic("+fMailbox.getDatabase().getName()+":received(_,_))");
			SWIQuery.synchronizedRawquery("dynamic("+fMailbox.getDatabase().getName()+":sent(_,_))");
			SWIQuery.rawquery(fMailbox.getDatabase().getName()+":(export("+fMailbox.getDatabase().getName()+":received(_,_)))", debugger);
			SWIQuery.rawquery(fMailbox.getDatabase().getName()+":(export("+fMailbox.getDatabase().getName()+":sent(_,_)))", debugger);
		} catch (Exception e) { new Warning("Problem while interfacing with mailbox:",e); }
		for (BeliefBase lBB: fBB) {
			try { // ASSUMES: all belief bases are implemented as Prolog databases
				// TODO: following does not work, but should be made to work... lBB.getLanguage().getInferenceEngine().rawquery("module("+lBB.getDatabase().getName()+"),"+"(import("+fMailbox.getDatabase().getName()+":received(_,_)))");
				// CHECK: Unclear why the "true," part is needed below... Query only works with this present!! 
				// Wouter: it's not unclear I think, its a bug in JPL.
				SWIQuery.synchronizedRawquery("true,"+lBB.getDatabase().getName()+":(import("+fMailbox.getDatabase().getName()+":received(_,_)))");
				SWIQuery.synchronizedRawquery("true,"+lBB.getDatabase().getName()+":(import("+fMailbox.getDatabase().getName()+":sent(_,_)))");
			} catch (Exception e) { new Warning("Problem doing import of mailbox info into main database"+e); }
		}
		// ADHOC: End adhoc code fragment.
	}

	 /** Wouter: IMHO this should throw an exception if init fails */
	public void initPerceptBase(Debugger debugger) {
		// ADHOC: SWI-Prolog specific code below.
		// ASSUMPTION: all percepts added to percept base are of form 'percept/2' (with time stamping).
		// CONVENTION: SECOND argument represents time!
		// TODO: Move this code to platform manager (only platform manager may be assumed to know specifics of
		// perceptual information received from a particular environment), and use new 'initPerceptBase' method here.
		try {
			fPercepts = new BeliefBase("perceptbase", new Theory(), SWIPrologLanguage.getInstance());
			//fPercepts = new BeliefBase(SWIPrologLanguage.getInstance().makeDatabase("perceptbase", new Theory()));
		} catch (Exception e) {
			//Wouter: catching here and still going on seems useless?
			new Warning("Percept base could not be created.",e);
		}
		// Declare 'percept/2' (and/or 'percept/1') dynamic.
		// TODO: need to make nr of arg of 'percept' dependent on timestamping if turned on.
		try {
			SWIQuery.synchronizedRawquery("dynamic("+fPercepts.getDatabase().getName()+":percept(_,_))");
			SWIQuery.synchronizedRawquery("dynamic("+fPercepts.getDatabase().getName()+":percept(_))");
			SWIQuery.rawquery(fPercepts.getDatabase().getName()+":(export("+fPercepts.getDatabase().getName()+":percept(_,_)))",debugger);
			SWIQuery.rawquery(fPercepts.getDatabase().getName()+":(export("+fPercepts.getDatabase().getName()+":percept(_)))",debugger);
		} catch (Exception e) { new Warning("export failed:",e); }
		for (BeliefBase lBB: fBB) {
			try { // ASSUMPTION: all belief bases are implemented as Prolog databases
				// TODO: following does not work, but should be made to work... lBB.getLanguage().getInferenceEngine().rawquery("module("+lBB.getDatabase().getName()+"),"+"import("+fPercepts.getDatabase().getName()+":percept(_,_))");
				// CHECK: Unclear why the "true," part is needed below... Query only works with this present!! 
				SWIQuery.synchronizedRawquery("true,"+lBB.getDatabase().getName()+":(import("+fPercepts.getDatabase().getName()+":percept(_,_)))");
				SWIQuery.synchronizedRawquery("true,"+lBB.getDatabase().getName()+":(import("+fPercepts.getDatabase().getName()+":percept(_)))");
			} catch (Exception e) { new Warning("BUG: Perceptbase initialization failure",e); }
		}
		// ADHOC: End adhoc code fragment.
	}

	
	
	// Get and set methods
	// CHECK: Check negation and handling of substitutions...!
	public ArrayList<BeliefBase> getBeliefBase() {
		return fBB;
	}
	
	public ArrayList<GoalBase> getGoalBase() {
		return fGB;
	}
	
	public BeliefBase getPerceptBase() {
		return fPercepts;
	}
	
	public BeliefBase getMailbox() {
		return fMailbox;
	}
	
	// Querying
	/**
	 * The entailment relation evaluates mental state conditions on a mental state.
	 * @return set of substitutions that make mental state condition true, if any.
	 * @param pMsc typically something like "not goal(goingto(X,O)),bel(not(hasgold),not(atgold),explorable(Pos))"
	 */
	public Set<Substitution> mscQuery(MentalStateCond pMsc, Debugger debugger) {
		MentalAtom[] lLit = pMsc.getLiterals();
		Set<Substitution> resultingSubstSet;
		
		// Evaluate literals
		if (lLit.length==0) { // By default, the 'empty' mental state condition is true.
			resultingSubstSet = new LinkedHashSet<Substitution>();
			resultingSubstSet.add(new Substitution());
			return resultingSubstSet;
		}
		// TODO: The parser should ensure that rules with 'FALSE' as condition are not taken into
		// account, i.e. removed from the set of rules as well as issue a warning.

		resultingSubstSet = query(lLit[0], debugger);
		int i = 1;
		while (!resultingSubstSet.isEmpty() && i<lLit.length) {
			Set<Substitution> updatedSubstSet = new LinkedHashSet<Substitution>();
			for (Substitution lSubst : resultingSubstSet) {
				Set<Substitution> result = query(lLit[i].applySubst(lSubst), debugger);
				if (!result.isEmpty())
					for (Substitution lSubst0 : result)
						updatedSubstSet.add(lSubst.combine(lSubst0));
			}
			resultingSubstSet = updatedSubstSet;
			i++;
		}

		return resultingSubstSet;
	}
	
	/**
	 * check if a formula follows from the belief/goal base.
	 * The literal is either Bel(X) or Goal(X) and this determines which database is queried.
	 * @param pLit is the literal to be checked.
	 * @param pSusbt is a RETURN value: 
	 * A list of substitutions that when applied to the formula result in instances of the formula
	 * that follow from the belief base. 
	 * If the formula is closed, i.e. does not have any free variables, then pSubst
	 * is an empty list.
	 * @return true if at least one instance of the formula follows from
	 * the belief base. The possible bindings of variables that upon substitution result in instances of the
	 * formula that follow from the belief base are returned as a list via the variable pSubst.	
	 * @author originally by Koen, modified Wouter Pasman 8feb08
	*/
	
	public final Set<Substitution> query(MentalAtom pLit, Debugger debugger) {
		// Wouter 15jul08: tightened type checking here. CHECK Why?
		Expression x=pLit.getFormula();
		if (!(x instanceof SWIExpression))
			throw new IllegalArgumentException("BUG (MentalState): Unsupported expression type "+x.getClass());
		
		QueryExpression lForm = new SWIQueryExpression((SWIExpression)x);
		Set<Substitution> resultingSubstSet;
		switch(pLit.getType()) {
		case BELIEF:
			resultingSubstSet = beliefQuery(lForm, debugger);
			break;
		case GOAL:
			resultingSubstSet = goalQuery(lForm, debugger);
			break;
		case AGOAL:
			resultingSubstSet = agoalQuery(lForm, debugger);
			break;
		case GOALA:
			resultingSubstSet = goalaQuery(lForm, debugger);
			break;
		default: 
			new Warning("BUG (MentalState): mentalstate query of unknown type"+pLit.getType());
			return new LinkedHashSet<Substitution>();
		}
		
		if (!pLit.getPosNeg()) // evaluate negation if mental atom is negation, i.e. not(belief(...)) or not(goal(...))
			if (resultingSubstSet.isEmpty()) // negation is true
				resultingSubstSet.add(new Substitution());	
			else // negation is false, make resultingSubstSet empty
				resultingSubstSet = new LinkedHashSet<Substitution>();
		
		return resultingSubstSet;
	}
	
	/**
	 * The method 'beliefQuery' is used to evaluate a formula with respect to the belief base. The semantics
	 * is derived from the modal belief operator 'bel'.
	 * @param pForm is a formula to be queried.
	 * @return a set of substitutions that make pForm true wrt the belief base, if any; otherwise returns empty
	 * set, implying that no instantiation of pForm follows from the belief base.
	 */
	public final Set<Substitution> beliefQuery(QueryExpression pForm, Debugger debugger) {
        // ASSUMES there is a single 'dynamic' belief base that should be queried, first(ADHOC!) in list of all belief bases
		return fBB.get(0).query(pForm, debugger);
	}
	
	/**
	 * used to evaluate a formula with respect to the goal base only.
	 * @param pForm is a formula to be queried.
	 * @return a set of possible substitutions that make pForm true wrt goal base, if any;
	 * otherwise returns empty set, implying that no instantiation of pForm follows from the goal base.
	 * Complexity estimate: #calls to query = #substitutions that make pForm true in the goal base.
	 */
	public final Set<Substitution> goalQuery(QueryExpression pForm, Debugger debugger) {
		KRlanguage lLangue = pForm.getLanguage();

		debugger.bp("GQ", "Testing goal "+pForm, 5);
		// First, retrieve all substitutions such that the formula that results from applying the substitution to
		// the formula pForm is entailed by the goal base. If formula pForm does not contain any variables, then
		// simply return 'true' if pForm follows from the goal base, otherwise return 'false'.
		Set<Substitution> resultingSubstSet = new LinkedHashSet<Substitution>();
		for (int i=0; i<fGB.size(); i++)
			if (fGB.get(i).getLanguage().equals(lLangue)) {
				Set<Substitution> additions=fGB.get(i).query(pForm, debugger);
				resultingSubstSet.addAll(additions);
			}

		return resultingSubstSet;
	}
	
	/**
	 * used to evaluate a formula with respect to the goal base.
	 * @param pForm is a formula to be queried.
	 * @return a set of possible substitutions that make pForm true wrt goal base AND NOT wrt belief base, if any;
	 * otherwise returns empty set, implying that no instantiation of pForm follows from the goal base OR such an
	 * instantiation is also follows from the belief base.
	 * Complexity estimate: #calls to query = #substitutions that make pForm true in the goal base.
	 */
	public final Set<Substitution> agoalQuery(QueryExpression pForm, Debugger debugger) {
		KRlanguage lLangue = pForm.getLanguage();
		QueryExpression lForm;
		debugger.bp("GQ", "Testing a-goal "+pForm, 5);
		// First, retrieve all substitutions such that the formula that results from applying the substitution to
		// the formula pForm is entailed by the goal base. If formula pForm does not contain any variables, then
		// simply return 'true' if pForm follows from the goal base, otherwise return 'false'.
		Set<Substitution> resultingSubstSet = new LinkedHashSet<Substitution>();
		for (int i=0; i<fGB.size(); i++)
			if (fGB.get(i).getLanguage().equals(lLangue)) {
				Set<Substitution> additions=fGB.get(i).query(pForm, debugger);
				resultingSubstSet.addAll(additions);
			}

		// Second, remove any substitutions from the list pSubst for which the formula that results from applying
		// that substitution to pForm also follows from the belief base.
		// Complexity: length of resultingSubstSet
		Set<Substitution> removeSubstSet = new LinkedHashSet<Substitution>();
		for (Substitution lSubst : resultingSubstSet) {
			lForm = new SWIQueryExpression((SWIExpression)pForm.applySubst(lSubst));
			if (!lForm.isClosed()) // lForm should be closed
				new Warning("BUG (MentalState): goal query with "+pForm.toString()+" did not result in closed formula but returned "+lForm.toString()+" instead.");
			// Wouter: NO IT DOES NOT HAVE TO BE. For instance if I use not(goal(at(_))) then the _ will NOT be substituted.
			// DOC: KH 28Jul08 We do not allow anonymous variables within scope of goal operator; see Mantis 174.
			if (!beliefQuery(lForm, debugger).isEmpty()) // remove lSubst from resultingSubstSet
				removeSubstSet.add(lSubst);
		}
		resultingSubstSet.removeAll(removeSubstSet);

		return resultingSubstSet;
	}
	
	/**
	 * used to evaluate a formula with respect to the goal base.
	 * @param pForm is a formula to be queried.
	 * @return a set of possible substitutions that make pForm true wrt goal base AND wrt belief base, if any;
	 * otherwise returns empty set, implying that no instantiation of pForm follows from the goal base AND the belief base.
	 * Complexity estimate: #calls to query = #substitutions that make pForm true in the goal base.
	 */
	public final Set<Substitution> goalaQuery(QueryExpression pForm, Debugger debugger) {
		KRlanguage lLangue = pForm.getLanguage();
		QueryExpression lForm;
		debugger.bp("GQ", "Testing goal-a "+pForm, 5);
		// First, retrieve all substitutions such that the formula that results from applying the substitution to
		// the formula pForm is entailed by the goal base. If formula pForm does not contain any variables, then
		// simply return 'true' if pForm follows from the goal base, otherwise return 'false'.
		Set<Substitution> resultingSubstSet = new LinkedHashSet<Substitution>();
		for (int i=0; i<fGB.size(); i++)
			if (fGB.get(i).getLanguage().equals(lLangue)) {
				Set<Substitution> additions=fGB.get(i).query(pForm, debugger);
				resultingSubstSet.addAll(additions);
			}

		// Second, retain only those substitutions from the list pSubst for which the formula that results from applying
		// that substitution to pForm also follows from the belief base.
		// Complexity: length of resultingSubstSet
		Set<Substitution> retainSubstSet = new LinkedHashSet<Substitution>();
		for (Substitution lSubst : resultingSubstSet) {
			lForm = new SWIQueryExpression((SWIExpression)pForm.applySubst(lSubst));
			if (!lForm.isClosed()) // lForm should be closed
				new Warning("BUG (MentalState): goal query with "+pForm.toString()+" did not result in closed formula but returned "+lForm.toString()+" instead.");
			// Wouter: NO IT DOES NOT HAVE TO BE. For instance if I use not(goal(at(_))) then the _ will NOT be substituted.
			// DOC: KH 28Jul08 We do not allow anonymous variables within scope of goal operator; see Mantis 174.
			if (!beliefQuery(lForm, debugger).isEmpty()) // remove lSubst from resultingSubstSet
				retainSubstSet.add(lSubst);
		}
		resultingSubstSet.retainAll(retainSubstSet);

		return resultingSubstSet;
	}
	
	
	/**
	 * compile a query and query it.
	 * This should be more efficient than querying all parts separately.
	 * BUT it is currently highly dependent on SWI prolog, using rawquery
	 * @return true if pSubst was extended with new substitutions.
	 * @param pSubst can contain empty substitutions, if there is a solution with no substs required.
	 * if there is no solution, no substitutions are added.
	 */
	public boolean compiledMsQuery(MentalStateCond pMsc, Set<Substitution> pSubst, Debugger debugger) {
		MentalAtom[] lLit = pMsc.getLiterals();
		
		// Evaluate literals
		if (lLit.length==0) // By default, the 'empty' mental state condition is true.
							  // TODO: The parser should ensure that rules with 'FALSE' as condition are not taken into
							  // account, i.e. removed from the set of rules as well as issue a warning.
			return true;
		
		// Compile mental state condition into Prolog.
		// NOTE that without adopt/drop actions mental state conditions can be compiled at compile-time.
		// ADHOC: Prolog specific code!
		// Compile mental state query in two steps: (i) compile goal querier, (ii) compile belief queries.
		// ASSUMPTION: It is more efficient to first process goal queries since the goal base typically is much smaller than the belief base

		// TODO: error or fallback if there are non-swiprolog beliefs or goals.
		
		String lQuery = new String("("), lLitQuery, lSignGB, lSignBB;
		// First process goal queries
	    for (int i=0; i<lLit.length; i++) {
	    	if (lLit[i].getType()==LITERALTYPE.GOAL) {
	    		lLitQuery = lLit[i].getFormula().toString();
	    		lQuery += "(";
	            for (int j=0; j<fGB.size(); j++) {
	            	if (j>0) lQuery += ";(";
	                for (int k=0; k<fBB.size(); k++) {
	                	if (lLit[i].getPosNeg()) {
	                		lSignGB = ""; lSignBB = "not";
	                    } else {
	                    	lSignGB = "not"; lSignBB = "";
	                    }
	                    lQuery += lSignGB+"("+fGB.get(j).getDatabase().getName()+":"+lLitQuery+"),"+lSignBB+"("+fBB.get(k).getDatabase().getName()+":"+lLitQuery+"))";
	                }
	            }
	    	}
	    }
	    lQuery += ")";
	    
	     // Second process belief queries
	    for (int i=0; i<lLit.length; i++) {
	    	if (lLit[i].getType()==LITERALTYPE.BELIEF) {
	    		if (!lQuery.equals("")) lQuery += ",";
	            lLitQuery = lLit[i].getFormula().toString();
	            if (!lLit[i].getPosNeg()) lLitQuery = "not("+lLitQuery+")";
	            // BELOW: code that queries all belief databases.
	            //for (int j=0; j<fBB.size(); j++) {
	            //	lQuery += fBB.get(j).getDatabase().getName()+":("+lLitQuery+")";
	            //}
	            // ASSUMPTION: single 'dynamic' belief database should be queried. 
	            lQuery += fBB.get(0).getDatabase().getName()+":("+lLitQuery+")";
	    	}
	    }
		
	    //System.out.println("created raw query:"+lQuery);
		// now the dirty part of the trick: query directly to SWI prolog
	    
	    Set<Substitution> lSubst=new LinkedHashSet<Substitution>();
	    try {
	    	//lSubst = fBB.get(0).getLanguage().getInferenceEngine().rawquery(lQuery,debugger);
	    	lSubst=SWIQuery.rawquery(lQuery, debugger); //Wouter: quick hack. I think this is already SWI dependent anyway?
	    }
	    catch (Exception e) { new Warning("Exception in rawquery:",e); }

	    pSubst.addAll(lSubst);
		//fBB.get(0).getDatabase().showStatistics();
		return !lSubst.isEmpty();
	}

	// Update methods
	/**
	 * The method 'updateState' is used to update a mental state after executing an action, 
	 * or receiving other information that the state of the environment has changed.
 	 * @throw exception if something fails. 
	 */
	public void updateState(QueryExpression update, Debugger debugger) throws Exception {
		updateBeliefState(update, debugger);
		updateGoalState(debugger);
	}
	
	/** Wouter: why is there a queryExpression as argument? This is not a query, right? */
	public final void updateBeliefState(QueryExpression update, Debugger debugger) throws Exception {
		
		//if (update.toString().contains("received")) {
		//	System.out.println("update;"+update);
		//}
		// STEP 1: check if 'update' is a sentence.
		if (!update.isClosed()){
			throw new Exception("updateState received formula "+update.toString()+", which is not a sentence (not closed)!");
		}
		
		// STEP 2: update the corresponding database. ASSUMES that there is only one beliefbase that matches with the
		// KR language of parameter 'update'.
		int i=0;
		boolean updated=false;
		while (i<fBB.size() && !updated) {
			if (update.getLanguage() == fBB.get(i).getLanguage()) {
				fBB.get(i).update(new SWIFormula(update));
				updated = true;
			}
		}
		
		// Wouter: added 8sep09 trac 736
		if (update.getLanguage() == fMailbox.getLanguage()) {
			Formula f=new SWIFormula(update);
			fMailbox.getTheory().removeAll(f.getNegations());
			updated=true;
		}

		if (!updated) {
			throw new Exception("Could not find belief base that uses KR language "+update.getLanguage().getName()+".");
		}
	}

	/**
	 * Wouter: apparently checks goals after a belief update
	 * @throws exception if update fails.
	 */
	public void updateGoalState(Debugger debugger) throws Exception {
		//  ASSUMES that each goal of the agent is implemented as a separate database.
		for(int i=0; i<fGB.size(); i++) { // check each separate goal
			ArrayList<Formula> goal = fGB.get(i).getAllSentences();
			debugger.bp("UG", "Checking whether "+goal+" was achieved", 3);
			int j=0;
			boolean achieved = true; // assume that the goal has been achieved; check whether this can be falsified.
			while(j<goal.size() && achieved) { // check whether one of the (sub)goals has not been achieved.
				int k=0;
				boolean bbEntailed = false; // assume the (sub)goal has not been achieved.
				while(k<fBB.size() && !bbEntailed) {
					BeliefBase bb=fBB.get(k);
					if (bb!=fMailbox && bb!=fPercepts) { 
							// HACK Wouter to get around 'not declared dynamic' issue
							// because mail and percept base are imported in the normal beliefbase we can safely skip these anyway.
						bbEntailed = bbEntailed || !bb.query(new SWIQueryExpression((SWIFormula)goal.get(j)), debugger).isEmpty();
					}
					k++;
				}
				achieved = bbEntailed;
				j++;
			}
			if (achieved) { // remove goal (database) if goal has been achieved.
				String debugMsg = "Goal achieved: " + fGB.get(i)+". removing it";
				debugger.bp("UG", debugMsg, 4);
				
				fGB.get(i).eraseContent(); // cleanup database
				fGB.remove(i);
				
			}
		}
	}
	public int countActiveGoalSentences(Debugger debugger) throws Exception {
		//  ASSUMES that each goal of the agent is implemented as a separate database.
		int count=0;
		for(int i=0; i<fGB.size(); i++) { // check each separate goal
			ArrayList<Formula> goal = fGB.get(i).getAllSentences();
			int j=0;
			while(j<goal.size()) { // check whether one of the (sub)goals has not been achieved.
				int k=0;
				boolean bbEntailed = false; // assume the (sub)goal has not been achieved.
				while(k<fBB.size() && !bbEntailed) {
					BeliefBase bb=fBB.get(k);
					if (bb!=fMailbox && bb!=fPercepts) { 
							// HACK Wouter to get around 'not declared dynamic' issue
							// because mail and percept base are imported in the normal beliefbase we can safely skip these anyway.
						bbEntailed = bbEntailed || !bb.query(new SWIQueryExpression((SWIFormula)goal.get(j)), debugger).isEmpty();
					}
					k++;
				}
				if (!bbEntailed)//the subgoal has not been achieved, so count it (still active)
					count++;
				j++;
			}
		}
		return count;
	}
	
	public final boolean addGoal(Formula pForm) {
		// ASSUMES that each goal of the agent is implemented as a separate database.
		
		// Wouter added 5aug09 trac 717...
		 // syntax check, does formula already occur literally?
		 // TODO we may consider more powerful logic equivalence checks.
		for(int i=0; i<fGB.size(); i++) { // check each separate goal
			if (fGB.get(i).getTheory().contains(pForm)) return true;
		}
		
		ArrayList<Formula> singleformulalist = new ArrayList<Formula>();
		singleformulalist.add(pForm);
		try{
			fGB.add(agent.createInitialGB(singleformulalist, agent.getDebugger()).get(0));
		} catch (Exception e) { new Warning("Could not add goal "+pForm+" to goal base.",e); }
		
		// CHECK:
		/*
		try{
			KRlanguage lLangue = pForm.getLanguage();
			Database GB = lLangue.makeDatabase("dynamic");
			lLangue.getUpdateEngine().expand(pForm, GB);
			fGB.add(new GoalBase(GB));
		}
		catch (Exception e) { System.out.println("Err in addGoal:"+e.getMessage()); e.printStackTrace();}
		*/
		return true;
	}
	
	/**
	 * Drop all goalbases that make given expression e true.
	 * This implements the drop(..) action.
	 * @author W.Pasman
	 */
	public void dropGoal(QueryExpression e, Debugger debugger) {
		for (int i=0; i<fGB.size(); i++) {
			if (!fGB.get(i).query(e, debugger).isEmpty()) {
				fGB.get(i).eraseContent(); // cleanup database
				fGB.remove(i);
			}
		}
	}
	
	
	/** @author W.Pasman 25feb09 */
	public final void deleteBelief(QueryExpression belief, Debugger debugger) throws Exception {
		
		// STEP 1: check if 'update' is a sentence.
		if (!belief.isClosed()){
			throw new Exception("updateState received formula "+belief.toString()+", which is not a sentence (not closed)!");
		}
		
		// STEP 2: update the corresponding database. ASSUMES that there is only one beliefbase that matches with the
		// KR language of parameter 'update'.
		int i=0;
		boolean updated=false;
		while (i<fBB.size() && !updated) {
			if (belief.getLanguage() == fBB.get(i).getLanguage()) {
				fBB.get(i).delete(new SWIFormula(belief));
				updated = true;
			}
		}
		if (!updated) {
			throw new Exception("Could not find belief base that uses KR language "+belief.getLanguage().getName()+".");
		}
	}
	
	
	public void showStatistics() { // DOC: ADHOC Only shows statistics of first belief base...
		Database lBB=fBB.get(0).getDatabase();
		lBB.showStatistics();
	}

	public String toString() {
		return "MentalState["+fBB+", "+fGB+"]";
	}
	
	/** convert only beliefs or goals to text string. */
	public String toString(boolean addbeliefs, boolean addgoals) throws Exception {

		String text="";

		if (addbeliefs) {
			text+="% ----- beliefs -----\n";
			for (BeliefBase b: getBeliefBase())
				text += b.getTheory();
		}
		
		if (addgoals) {
			text+="% ----- goals -----\n";
			for (GoalBase g: getGoalBase())
				text=text+g.getTheory().toStringSingleLine();
		}
		
		return text;
	}

	
	/**
	 * Moved to here from UpdateAction by W.Pasman 25feb09
	 * reason is that we need a unified view on applying an action on a mental state.
	 * Actions can be applied both from an action rule (in the program section)
	 * and from a percept rule
	 * executeAction only handles the effect of the action on the mental state,
	 * and has no side effects on the environment or messages in the middleware layer
	 * Note that you may need to check yourself whether the action may be applied at all,
	 * eg a PerceptRule may not execute a send action.
	 * You also may need to handle post conditions of the action (in case of UserSpecActions)
	 * That may of cause be done with another call to executeAction.
	 * @modified W.Pasman 25feb09
	 * @param act is the action to be applied
	 * @param debugger is the debugger controlling this agent.
	 * @throws Exception if action can not be executed, e.g. when there is no database
	 * that supports the language of the action (SWI prolog at this time)
	 * or when you try to apply a UserSpecAction to the MS
	 */
	public void executeAction(Action act, Debugger debugger) throws Exception {
		debugger.bp("EA","executing mental state action: "+act, 5);
		if (act instanceof AdoptAction) {
			addGoal(new SWIFormula((SWIQueryExpression)((AdoptAction)act).getGoal()));
		} else if (act instanceof DropAction) {
			dropGoal( ((DropAction)act).getGoal(),debugger);
		} else if (act instanceof SendAction) {
			String lReceiver = ((SendAction)act).getAgentName();
			String lContent = ((SendAction)act).getMessage().toString();
			getMailbox().insert("sent("+lReceiver+","+lContent+")");
			// Otherwise, do nothing: leave handling of messaging to comm. infrastructure! E.g. for JADE, use the GOAL agent's JADE buddy to do this work :-)
		} else if (act instanceof InsertAction) {
			updateBeliefState(((InsertAction)act).getBelief(), debugger);
		} else if (act instanceof DeleteAction) {
			deleteBelief(((DeleteAction)act).getBelief(), debugger);
		}
		else  throw new IllegalArgumentException("attempt to update MS with non-reserved action "+act);	
	}

}
