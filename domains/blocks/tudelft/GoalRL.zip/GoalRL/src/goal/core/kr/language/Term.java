package goal.core.kr.language;

/**
 * 
 * @author Koen Hindriks
 * Wouter: so a Term is ??
 */

public interface Term extends Expression {

}
