package goal.core.scheduler;

import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.env.Percept;
import goal.core.program.Action;
import goal.core.mas.MASRegistry;
import goal.tools.errorhandling.Warning;

import java.util.ArrayList;
import java.util.LinkedHashSet;


/**
 * 
 * @author W.Pasman
 * @author K.Hindriks
 * @modified W.Pasman 10sept07
 * all other schedulers are (near-trivial) derivatives of this generic scheduler now.
 * @modified W.Pasman 19jun08
 * we now need dynamic scheduling: list of available agents may change over time.
 * We need to call on the platform manager to see which agents are available at a time.
 * Also implemented round-robin in this default scheduler.
 * 
 * We do not want to introduce hard dependence on the PlatformManager as this is just a "tool"
 * nevertheless we need a function to call that will give us the currently available agents.
 * Therefore we implement a getAgents() function that <em>must be overridden</em>. 
 * 
*/

public class GenericScheduler implements Scheduler {
	
	// Class fields
	//ArrayList<Agent> fAgents = null;
	
	int lastAgentServed=0; // round-robin: last agent in the list that we served.
	
	 // Wouter: DO NOT USE HashSet!
	LinkedHashSet<Agent> resettingAgents = new LinkedHashSet<Agent>(); // agents under reset
	Environment fEnv;
	int totalNumberOfActions=0;
	MASRegistry MASreg=null;
	
	// Constructor
	public GenericScheduler(Environment pEnv, MASRegistry pReg) {
		assert(pEnv!=null);
		fEnv = pEnv;
		MASreg=pReg;
		//for (Agent a:fAgents) resettingAgents.add(a);
	}
	
	public GenericScheduler() {	}
		
	// Class methods
	public Environment getEnvironment() {
		return fEnv;
	}
	
	// TODO: Move this to platform manager.
	/** check and handle reset. returns true if agent was reset.
	 * In that case, step should not do a step but return */
	public boolean checkReset(Agent pAgent) {
		if (resettingAgents.contains(pAgent)) {
			try { 
				resettingAgents.remove(pAgent);
				pAgent.reset();
				//debugger.setLevel(0);
				//debugger.Info(0, "AGENT WAS RESET.");
				return true;
			}
			catch (Exception e) { new Warning("Reset failed",e); }
		}
		return false;
	}
	
	/**
	 * Let the agent pAgent make a step.
	 *  @returns true if system still runnable. false if it has stopped.
	 * This is used only in stand-alone GOAL run, not when using JADE.
	 * Therfore we need to call sendPercepts and executeAction 
	 */
	public boolean step(Agent pAgent) throws Exception {
		
		if (checkReset(pAgent)) return true;
		
		 // moved this from bottom to top 20feb.
		 // now that agent can be reset, we have to push percept first.
		try {
			ArrayList<Percept> percepts = receivePercepts(pAgent);
			pAgent.processPercepts(percepts);
		} catch (Exception e) {
			// TODO: generically handle error messages
			new Warning("Error in processPercepts: "+e.getMessage(), e);
		}

		//pAgent.showStatistics();
		String lAc = receiveAction(pAgent);
		if (lAc.equals(""))
			return false; // Exit loop when no action can be executed.

		// TODO Wouter: In concept there might be multiple environments involved.
		// But currently, at most ONE environment is supported that handles ALL actions.
		// this is the one given to the platform manager.
		Exception err = null;
		boolean recognised = true;
		try {
			recognised = executeAction(pAgent, lAc);
		} catch (Exception e) { err = e; }
		pAgent.actionWasPerformed(lAc, recognised, err);
		totalNumberOfActions++;
		
		return true;
	}
	
	/** Wouter: this is the actual main perception-action cycle loop,
	 * disguised as a 'step' loop.
	 * Each step does one percept-act cycle 
	 * Note that the JADE scheduler just implements its own controlloop but uses our selectAgent() call.
	 *  @throws exception if init of agent's database fails.
	 * */
	public void controlLoop() throws Exception {
		boolean loop = true;
		Agent lAg;
		
		while (loop) {
			lAg = selectAgent();
			if (lAg!=null) 
				if (!step(lAg)) break; // exit simulator if no more steps.
			else {
				try {
					Thread.sleep(100);
				} catch (InterruptedException ie) { new Warning("Scheduler was interrupted",ie); }
			}
		}
	}
	
	/**
	 *  Scheduler receives actions from agents via this method. The method can be implemented in many different ways,
	 *  e.g. by implementing channels connecting the scheduler to each agent and collecting actions from these agents
	 *  via such a channel.
	 *  Wouter: repeat asking performAction from the agent until we encounter 
	 *  an action acting on the environment (UserSpecAction).
	 *  @param pAgent Agent that wants to execute the action.
	 *  @version 2: works with strings.
	 *  @throws if init of agent database fails.
	 */
	public String receiveAction(Agent pAgent) throws Exception {
		Action lAction;
		String lActionLabel = "";

		boolean lExternalAction = false;
		while (!lExternalAction) {
			// ASSUMES that environment can execute the actions.
			//pAgent.showStatistics();
			//System.out.println("    performAction now");
			lAction = pAgent.performAction();
			if (lAction!=null) {
				lActionLabel = lAction.toString();
			} else {
				lActionLabel = ""; // HACK; TODO: Clean up.
			}
			//pAgent.showStatistics();
			if (lActionLabel.equals("")) return ""; // STOP if end.  
			 //  CHECK is checking the string directly good enough to determine reserved property?
			else lExternalAction = !(lActionLabel.startsWith("drop") || lActionLabel.startsWith("adopt") || lActionLabel.startsWith("send"));
			// TODO: use method !lAct.reserved();
		}
		if (lActionLabel==null) return ("");
		return lActionLabel.toString();
	}
	
	/*
	public ArrayList<Percept> sendPercepts(Agent agt) throws Exception {
		if (!getEnvironmentConnection(agt).equals("environment")) return new ArrayList<Percept>();
		return fEnv.sendPercepts(agt.getName());
	}
	*/

	/**
	 * This method selects the agent that is scheduled to perform an action next (, or possibly to receive a
	 * percept next.)
	 * @return null if no agent can be selected, in which case scheduling will sleep a short while
	 * before trying selectAgent again.
	 * @throws exception if the getAgents() function has not been implemented.
	 */
	public Agent selectAgent() { 
		lastAgentServed++;
		ArrayList<Agent> agents = getAgents();
		if (agents.size()==0)
			return null;
		
		if (lastAgentServed>=agents.size())
			lastAgentServed=0;
		
		return getAgents().get(lastAgentServed); 
	}
	
	// The default scheduler just iterates over the agents in the MAS.
	public ArrayList<Agent> getAgents() {
		return MASreg.getRunningAgents(); 
	}
	
	public int getTotalNumberOfActions() { return totalNumberOfActions; }
	

	
	/**
	 * Connectors to the environment.
	 */
	/**		
	 * The method requests environment to execute action.
	 * We do not call sendPercepts here, to allow JADE and others to separate percept and action handling
	 * @return The method returns a flag indicating whether the action was recognised by environment ('true') or
	 * not ('false'). This is needed because GOAL can not see whether a userspecaction is something
	 * that the environment understands or a "fake" action that is needed just to do some drops and adopts.
	 * This should be identical to Environment.executeAction.
	 */
	public boolean executeAction(Agent agt, String pAct) throws Exception {
		 // Wouter: modified 12mar09, now we have explicit environment hook info in agent and env maybe null
		if (!getEnvironmentConnection(agt).equals("environment")) return false;
		if (fEnv==null) throw new Exception("Agent tries to act in environment which is not available");
		//if (! fEnv.availableForInput())  return false; //Wouter: No check, see mantis 221.
		return fEnv.executeAction(agt.getName(), pAct);
	}
	
	public ArrayList<Percept> receivePercepts(Agent pAgent) throws Exception {
		if (!getEnvironmentConnection(pAgent).equals("environment")) return new ArrayList<Percept>();
		if (fEnv==null) throw new Exception("Agent tries to perceive in environment which is not available");
		return fEnv.sendPercepts(pAgent.getName());
	}
	
	 /** return the environment that the agent is connected to.
	  * Should be either "" or "environment" if the mas file was written properly.
	  * returns null if the agent name does not exist at all */
	public String getEnvironmentConnection(Agent pAgent) {
		return MASreg.getEnvironmentConnection(pAgent.getName());
	}
}
