package goal.core.program;

import java.util.Set;
import goal.kr.implementations.swiprolog.*;

import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;

/** @author W.Pasman 25feb09
 * Why is there a QueryExpression here???? (I copied that from existing actions) */
public class DeleteAction implements Action {
	
	// Class field
	QueryExpression fQuery;
	
	// Class constructor
	public DeleteAction(QueryExpression pQuery) {
		fQuery = pQuery;
	}
	
	// Class methods
	public String getName() {
		return "delete";
	}
	
	public QueryExpression getBelief() {
		return fQuery;
	}

	public Action applySubst(Substitution pSubst) {
		return new DeleteAction(new SWIQueryExpression((SWIExpression)fQuery.applySubst(pSubst)));
	}

	public Set<Var> getFreeVar() {
		return fQuery.getFreeVar();
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public DeleteAction clone() {
		return new DeleteAction(fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof DeleteAction)) {
			return false;
		}
		return fQuery.equals(((DeleteAction)pObj).getBelief());
	}
	
	public boolean reserved() {
		return true;
	}
	
	public Substitution mgu(Action pAct) {
		return null;// TODO: implement.
	}
	
	public String toString() {
		return "delete("+fQuery.toString()+")";
	}
}
