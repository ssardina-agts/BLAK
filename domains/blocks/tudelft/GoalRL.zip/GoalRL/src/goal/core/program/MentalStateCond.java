package goal.core.program;


/**
 * 
 * @author Koen Hindriks
 *
 * Mental state conditions occur as conditions in the rules of a GOAL program. The GOAL parser should return these
 * rules and the associated mental state conditions for processing by the interpreter.
 */

public class MentalStateCond {
	
	// Class fields
	/** ASSUMPTION: For now, we assume that mental state conditions are conjunctions(!) of mental atoms.
	 * Consequently, such conditions can be represented as a list of belief literals and goal literals.
	 * DOC: Note that the order of literals may be important for evaluation!
	 */
	MentalAtom[] fLit;
	
	// Constructor
	public MentalStateCond(MentalAtom[] pAtomList) {
		fLit = new MentalAtom[pAtomList.length];
		System.arraycopy(pAtomList, 0, fLit, 0, pAtomList.length);
	}
	
	// Class methods
	public MentalAtom[] getLiterals() {
		return fLit;
	}
	
	public String toString() {
		String lMSCStr = new String();
		
		if (getLiterals()!=null && getLiterals().length>0) { // Wouter 3oct08: if condition="true" -and not "bel(true)" we have no preconds
			lMSCStr += getLiterals()[0];
		}
		for (int i=1; i<getLiterals().length; i++) {
			lMSCStr += ","+getLiterals()[i].toString();
		}
		return lMSCStr;
	}

}
