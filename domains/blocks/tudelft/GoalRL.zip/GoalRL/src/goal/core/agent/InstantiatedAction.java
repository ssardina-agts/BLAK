package goal.core.agent;

import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;
import goal.core.kr.language.Substitution.Binding;
import goal.core.program.Action;
import goal.tools.errorhandling.Warning;

import java.util.Set;

/**
 * 
 * @author Koen Hindriks
 *
 */

/**
 * Class added to facilitate action selection, which involves two things: (i) selecting an enabled action, and (ii)
 * computing the corresponding variable bindings (substitution) for any free variables in action parameters.
 */
public class InstantiatedAction {
	
	// Class fields
	private Action fAct;
	private Substitution fSubst;
	
	// Constructor 
	public InstantiatedAction(Action pAct, Substitution pSubst) throws Exception {
		fAct = pAct.clone();
		if (pSubst==null) 
			throw new Exception("Action variables not instantiated correctly. Got null pointer instead.");
		fSubst = pSubst; // QUESTION: maybe we do not need clones here, or should we use them anyway?
	} 
	
	// Class methods
	public Action getAction() {
		return fAct;
	}
	
	public Substitution getSubstitution() {
		return fSubst;
	}
	
	public void setSubstitution(Substitution pSubst) {
		this.fSubst = pSubst; // QUESTION: maybe we do not need clones here, or should we use them anyway?
	}
	
	public boolean isClosed() {
		// TODO: Write code to check if all free variables in action parameters are bound by CLOSED terms in
		// substitution.
		Set<Var> lFreeVar = this.fAct.getFreeVar();
		Set<Var> lBoundVar = this.fSubst.getVarDomain();
 		
		for (Binding lBind : this.fSubst.getBindings()) {
			if (!lBind.getTerm().isClosed()) {
				lBoundVar.remove(lBind.getVar());
			}
		}
		return lBoundVar.containsAll(lFreeVar);
			
	}
	
	public InstantiatedAction clone() { // CHECK: Do we need this method??
		try {
			return new InstantiatedAction(this.fAct, this.fSubst);
		} catch (Exception e) {
			new Warning("InstantiatedAction.clone failed",e);
			return null;
		}
	}
	
	public String toString()
	{
		return ""+getInstantiatedAction();
	}
	
	public int hashCode() { return 0; } // override, otherwise Java tries to be smart which will cause errors.
	
	/**
	 * @author W.Pasman
	 * @return this action instantiated with the substitution
	 */
	public Action getInstantiatedAction()
	{
		return fAct.applySubst(fSubst);
	}

	/**
	 * returns true if the instantiated action is the same, that means
	 * that the predicates *after* doing the substitution are the same.
	 * For instance bla(X).X/3,Y/4 is equal to bla(X).X/3,Y/776
	 * @author W.Pasman
	 */
	public boolean equals(Object a)
	{
		if (!(a instanceof InstantiatedAction)) return false;
		return getInstantiatedAction().equals(((InstantiatedAction)a).getInstantiatedAction());
	}
	
	
	
}