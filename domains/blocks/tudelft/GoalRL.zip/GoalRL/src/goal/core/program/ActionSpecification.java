package goal.core.program;

import goal.core.agent.UpdateAction;
import goal.core.kr.language.*;
import goal.core.mentalstate.MentalState;
import goal.tools.errorhandling.Warning;

import java.util.*;
import goal.kr.implementations.swiprolog.SWIQueryExpression; 
import goal.kr.implementations.swiprolog.SWIFormula; // we need to cast from Formula to QueryExpression, currently is not just a cast...
import goal.tools.debugger.Debugger;
/**
 * 
 * @author Koen Hindriks
 * 
 * Each user defined action in the program section of a GOAL agent must come with a
 * specification, i.e. a pre- and post-condition, defined in the action specification
 * section of the agent.
 * CHECK: The parser checks this, and issues a warning if an action is specified in the action
 * specification section but never used in the program section.
 * ASSUMPTION: The variables in action, pre- and post-conditions are in one-to-one correspondence
 * with those in the action specification section of the GOAL agent.
 * 
 * Several pre- and postconditions may be associated with one action. We take a
 * liberal stance here and allow the following:
 * -	the same precondition with various postcondition
 * -	duplicate specifications (is not checked for)
 * -	'empty' pre- and/or postconditions
 * It is left to the user to provide a well-defined action specification for an action.
 * 
 */ 

public class ActionSpecification {
	
	private class PrePost {
		
		private Formula 	 preCondition;	// precondition specified in action specification section of GOAL agent.
		private Formula 	 postCondition;	// postcondition as specified in action specification section of GOAL agent.
		private Substitution subst;
		
		//Joost: Explanation backlink to substitution used for this update action
		public Substitution iSubst;
		
		public PrePost(Formula pPre, Formula pPost, Substitution pSubst) {
			preCondition = pPre;
			postCondition = pPost;
			subst = pSubst;
		}
		
		public Substitution getSubstitution() {
			return subst;
		}
		
		public void applySubstitution(Substitution pSubst) {
			if (subst==null) {
				subst = pSubst;
			} else {
				subst.applySubst(pSubst);
			}
		}
		
		public Formula getPrecondition() {
			return (Formula)preCondition;
		}
		
		public Formula getPostcondition() {
			return (Formula)postCondition;
		}
		
		public boolean equalPrePost(PrePost pPP) {
			return (preCondition.equals(pPP.preCondition) && postCondition.equals(pPP.postCondition));
		}
		
		public PrePost clone() {
			return new PrePost(preCondition, postCondition, subst);
		}
		
		public String toString() {
			if (subst!=null) {
				return ":pre{ "+preCondition.applySubst(subst).toString()+
				" } :post{ "+postCondition.applySubst(subst).toString()+" }";
			} else {
				return ":pre{ "+preCondition.toString()+
				" } :post{ "+postCondition.toString()+" }";
			}
		}
	}
	
	// Class field
	UserSpecAction fAct;
	ArrayList<PrePost> fSpecifications = new ArrayList<PrePost>();
	
	// Constructor
	public ActionSpecification(UserSpecAction pAct) {
		fAct = pAct;
	}
	
	// Class methods
	public Action getAction() {
		return fAct;
	}
	
	// TODO: Not used??
	public void setAction(UserSpecAction pAct) {
		fAct = pAct;
	}
	
	public boolean isEmpty() {
		return fSpecifications.isEmpty();
	}
	
	/**
	 * Method used by parser to construct action specifications.
	 * All variables that occur in the parameters or post-condition of an action must
	 * also occur in the pre-condition of that action (this is checked by parser).
	 */
	public void addSpecification(Formula pPre, Formula pPost) {
		Set<Var> lFree = fAct.getFreeVar();
		lFree.addAll(pPre.getFreeVar());
		
		if (lFree.containsAll(pPost.getFreeVar())) {
			fSpecifications.add(new PrePost(pPre, pPost, null));
		} else {
			lFree=pPost.getFreeVar();
			lFree.removeAll(pPre.getFreeVar());
			new Warning("Variable(s) "+lFree+" in postcondition of action "+fAct+" does not occur in precondition;" +
					" ignoring action specification "+(new PrePost(pPre, pPost, null)).toString());
		}
	}
	
	public void removeSpecification(Formula pPre, Formula pPost) {
		boolean lFound = false;
		PrePost lSpec = new PrePost(pPre, pPost, null);
		
		// remove all specifications that have pre- and postconditions equal to parameters pPre and pPost
		for (PrePost iSpec : fSpecifications) {
			if (iSpec.equalPrePost(lSpec)) {
				fSpecifications.remove(iSpec);
				lFound = true;
			}
		}
		if (!lFound) {
			new Warning("Could not remove specification: "+lSpec+
					"; no such specification for action "+fAct+".");
		}
	}
	
	/**
	 * Use this method to get all possible instantiations of action fAct for which preconditions
	 * have been checked to hold (using previous result of method 'eval' below).
	 * If 'eval' has not been used yet, then no substitutions will have been retrieved and for all
	 * pre- and post-condition pairs the field subst will be null.
	 * @return list of instantiated actions whenever some substitutions are not null (i.e. have been
	 * checked to hold in mental state), otherwise null.
	 */
	public ArrayList<UpdateAction> getUpdateActions(MentalState pMS, Set<Substitution> pSubstSet, Debugger debugger) {
		
		ArrayList<UpdateAction> lActions = new ArrayList<UpdateAction>();
		
		// check whether action is closed performed by method evalPreconditions, see below.
		// check whether postcondition is closed performed by method executeAction in UpdateAction class.
		// we only need to check here whether evalPreconditions has been called at all.
		if (fSpecifications.get(0).getSubstitution()!=null) {
			for (PrePost iSpec : fSpecifications) {
				UpdateAction lUpdate = new UpdateAction(fAct.applySubst(iSpec.getSubstitution()),
						(Formula)iSpec.getPostcondition().applySubst(iSpec.getSubstitution()));
				
				//Joost: Explanation: add back link to the substitution enabling an UpdateAction
				lUpdate.setSubstitution(iSpec.iSubst);
				
				// avoid introducing duplications here
				if (!lActions.contains(lUpdate)) {
					lActions.add(lUpdate);
				}
			}
			return lActions;
		}
		new Warning("BUG (ActionSpecification): Empty action specification...");
		return null;
	}
	
	/**
	 * Checks which preconditions, given the list of substitutions pSubstList, are
	 * satisfied in the mental state pMS. Returns an action specification that consists
	 * of (partially) instantiated pre- and corresponding postconditions whenever the
	 * instantiated precondition holds in the mental state.
	 * 
	 * Wouter: pSubstSet should be applicable to this action specification.
	 * However, what is passed here is a substitution coming straight from the program rule, while
	 * the variables in this action were renamed so that the variable names match.
	 * 
	 * @param: pSubstlist is a list of viable substitutions for variables in preconditions
	 * @return: returns an instantiated action specification, or null if no precondition is
	 * satisfied in mental state
	 */
	public ActionSpecification evalPreconditions(MentalState pMS, Set<Substitution> pSubstSet, Debugger debugger) {
		ActionSpecification lActSpec = new ActionSpecification(fAct);

		// Check all preconditions of all actions; if precondition is satisfied, also
		// check whether resulting instantiated action is closed.
		for (PrePost iSpec : fSpecifications) {
			for (Substitution iSubst : pSubstSet) {
				SWIFormula lPre = (SWIFormula)iSpec.getPrecondition(); // ASSUMES we're working with SWI. TODO how to cast from Formula to QueryExp
				Set<Substitution> lGetSubst = pMS.beliefQuery(new SWIQueryExpression((SWIFormula)lPre.applySubst(iSubst)), debugger);
				// apply substitutions found (if any) to substitution that satisfied condition of actionrule
				// Wouter, 30sept: if we want this to be deterministic we must NOT USE from "HashSet"!
				Set<Substitution> temp = new LinkedHashSet<Substitution>();
				Substitution tempSubst;
				for (Substitution kSubst : lGetSubst) {
					tempSubst = new Substitution(iSubst.getBindings());
					tempSubst.applySubst(kSubst);
					temp.add(tempSubst);
				}
				lGetSubst = temp;
				// add all 'instantiated' pre- and post-condition pairs
				for (Substitution jSubst : lGetSubst) {
					if (fAct.applySubst(jSubst).isClosed()) {
						// CHECK: verify how following check impacts performance
						// avoid introducing duplicates at this stage
						PrePost jSpec = iSpec.clone();
						jSpec.applySubstitution(jSubst);
						
						//Joost: Explanation backlink to substitution used for this action spec
						jSpec.iSubst=iSubst;
						
						if (!lActSpec.fSpecifications.contains(jSpec)) {
							lActSpec.fSpecifications.add(jSpec);
						}
						if (!jSpec.getPostcondition().applySubst(jSpec.getSubstitution()).isClosed()) {
							new Warning("Precondition "+iSpec.preCondition.applySubst(jSubst)+
									" of action '"+fAct+"' is satisfied, but resulting postcondition '"+
									jSpec.getPostcondition().applySubst(jSpec.getSubstitution())+"' is not closed.");
						}
					} else {
						new Warning("BUG (ActionSpecification): Precondition "+iSpec.preCondition.applySubst(jSubst)+
								" of action "+fAct+" is satisfied, but resulting action is not closed.\n" +
								"Ignoring action instantiation "+fAct.applySubst(jSubst)+".");
						// TODO: Parser should filter out these issues.
					}
				}
			}
		}
		if (!lActSpec.fSpecifications.isEmpty()) {
			return lActSpec;
		} else {
			if (fSpecifications.isEmpty()) {
				new Warning("BUG(ActionSpecification): Something went wrong with the action specification for action "+fAct+
				"; could not find any specification.");
			}
		}
		return null;
	}
	
	public String toString() {
		String lSpec = fAct.toString();
		for (PrePost iSpec : fSpecifications) {
			lSpec += "\n"+iSpec.toString();
		}
		return lSpec;
	}
	
}