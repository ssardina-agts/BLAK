package goal.core.kr.language;

/**
 * 
 * @author Koen Hindriks
 *
 */

public interface Var extends Expression {
	 /** Wouter: added 10jul08. Very convenient when converting substitutions */
	public String getVarName(); // CHECK we already have toString()?

	/** Wouter: added 10oct08. gets a similar name, typically by prefixing name with "_".
	 this is used to rename var when going from programrule (actionrule) to action spec. 
	 FIXME HACK Unfortunately we need a TERM and not a var where we need it,
	 I don't know how to cast a VAR into a TERM...  I can not reach Koen,
	 and therefore I return a Term straight away.  */
	public Term getSimilar(); 
	
	public Var clone() ; // CHECK Var extends Expression which includes this already? Introduced only to avoid type casting?
	
}
