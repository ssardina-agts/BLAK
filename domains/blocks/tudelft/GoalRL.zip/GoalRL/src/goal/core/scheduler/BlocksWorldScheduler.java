package goal.core.scheduler;

import java.util.ArrayList;


import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.env.Percept;


/**
 * 
 * @author Koen Hindriks
 * cleaned up W.Pasman
 *
 */

public class BlocksWorldScheduler extends GenericScheduler 
{
	public BlocksWorldScheduler(ArrayList<Agent> pAgents, Environment pEnv)
	{		super(pAgents,pEnv); } // stupid but required by Java.

	
	/**
	 * In the simple Blocks World no percepts are provided.  
	 */
	public void sendPercepts(Agent pAgent, Percept[] pPercepts) 
	{

	}	
}

