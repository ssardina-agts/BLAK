package goal.core.kr;

import goal.core.kr.language.Formula;
import goal.kr.implementations.swiprolog.SWIFormula;
import goal.kr.implementations.swiprolog.SWIPrologLanguage;
import goal.tools.errorhandling.Warning;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * @author koen
 *
 * Wouter 9apr09: added synchronized to all calls to avoid concurrentModificationException (mantis 500)
 */
public  class Theory {
	
	/**
	 * NOTE that a theory is just a SET of formulae (strings). This class ASSUMES that each formula contained in a
	 * theory is either a clause or a fact (and not a conjunction of either clauses or facts, which would complicate
	 * the implementation of the addition or removal of a formula from a theory. This assumption is also needed in 
	 * order to be able to correctly represent the contents of a Prolog database (ADHOC).
	 * 
	 * The main reasons for introducing the Theory class are:
	 * - representing the content of belief and goal bases, as well as databases in general.
	 * - avoiding the need for (complex) access methods to databases maintained by underlying knowledge technology such as Prolog.
	 * - avoiding duplication of clauses or facts in a database (a Theory itself is a set).
	 */
	
	// Class fields
	// private Set<Formula> formulae; CHECK run into problems with generating hashcodes/equals methods here,
	// needed to identify instances in a HashSet implementation of a Set of formulae. Using strings does not raise
	// the need to define these methods...
	private ArrayList<String> formulae; 
	// Wouter: HashSet is NOT OK: hassles order. 
	// Duplicate formulas may have special meaning (eg in Prolog it has: try twice..) 
	// Therefore I replaced HashSet with ArrayList.
	
	/** @return true if formulae changed, false if not changed */
	synchronized boolean addFormula(String f) {
		if (formulae.contains(f)) return false;
		formulae.add(f);
		return true;
	}
	
	 /* safe add of formula. don't use add or addAll directly. 
	  * You can still use remove(All) on it.
	  * Could have used LinkedHashSet but that makes it all more complex at other places.
	  * It might be neat to make special class with this behaviour.
	  * W.Pasman 1oct08 */
	synchronized boolean  addFormulas(ArrayList<String> formulas) {
		boolean changed=false;
		for (String formula:formulas) {
			if (!formulae.contains(formula)) { changed=true; formulae.add(formula); }
		}
		return changed;
	}

	
	// Constructor
	public  Theory() {
		formulae = new ArrayList<String>();
	}
	
	/**
	 * Since a theory is assumed to consist of clauses and facts only, we need to ensure that a formula to be added
	 * to a theory is of this form. A conjunction of clauses and/or facts will be broken down in its constituent
	 * formulae. Note(!) that any negative literals are simply ignored (see also method getClauses()).
	 * Wouter: 1oct08 changed addAll to call to addFormulas, we are now using ArrayList
	 */
	public Theory(ArrayList<Formula> formulae) {
		this.formulae = new ArrayList<String>();
		for (Formula formula : formulae)
			//this.formulae.addAll(formula.getClauses());
			addFormulas(formula.getClauses());
	}

	// Class methods
	synchronized public ArrayList<String> getFormulae() {
		return formulae;
	}

	/**
	 *  NOTE that since a theory is assumed to consist of clauses and facts only combining two theories results in a
	 *  consistent theory again.
	 *  @return Wouter: now returns true if formulae changed, false if not.
	 */
	synchronized public boolean add(Theory theory) { 
		return addFormulas(theory.getFormulae());
		//return this.formulae.addAll(theory.getFormulae());
	}
	
	// see DOC for constructor above.
	synchronized public boolean add(Formula formula) {
		return addFormulas(formula.getClauses());
		//return this.formulae.addAll(formula.getClauses());
	}

	// see DOC for constructor above.
	/** Wouter: modified 1oct08, old code stopped adding formulae whenever a formula was 
	 * envountered that already was in the list of formulae. I also replaced the boolean "success"
	 * with "changed", to match what I think is what Koen wants here.
	 * @return true if formulae were changed, or false if they stayed the same. */
	synchronized public boolean addAll(Collection<? extends Formula> formulae) {
		boolean changed = false;
		for(Formula formula : formulae)
			//changed = changed || this.formulae.addAll(formula.getClauses());
			changed = changed || addFormulas(formula.getClauses());
		return changed;
	}

	// see DOC for constructor above.
	/** Wouter: removeAll can be done also correctly with ArrayList */
	synchronized public boolean remove(Formula formula) {
		return this.formulae.removeAll(formula.getClauses());
	}

	/**
	 * Note that the method removeAll removes all those formulae that occur in the collection (as part of a
	 * formula) and are element of the theory (consisting of clauses and facts).
	 * @param removeformulae the formulae to be removed.
	 */
	synchronized public boolean removeAll(Collection<Formula> removeformulae) {
		boolean success = true;
		for(Formula formula : removeformulae)
			success = success && formulae.removeAll(formula.getClauses());
		return success;
	}
	
	
	/**
	 * Added W.Pasman 8sept09
	 * removes all given formulae in list from the theory.
	 */
	synchronized public boolean removeAll(ArrayList<String> removeformulae) {
		boolean success=false;
		if (!removeformulae.isEmpty())
			success=formulae.removeAll(removeformulae);
		return success;
	}
	
	/**
	 * @param formula is a formula from an underlying knowlede technology.
	 * @return a theory where positive clauses in formula have been added and negated atoms in formula removed.
	 * Wouter: this is incorrect, returns a boolean which is not a theory.
	 * I think it returns true if formulae has been changed. At least that's what it is supposed to do.
	 */
	synchronized public boolean update(Formula formula) {
		 // Wouter: FIXED: remove first and then add, the order was reversed
		boolean removechange=this.formulae.removeAll(formula.getNegations());
		boolean addchange = addFormulas(formula.getClauses());
		return addchange || removechange; // returns true if one of the actions changed the list.
	}
	
	synchronized public boolean contains(Formula formula) {
		return formulae.containsAll(formula.getClauses());
	}
	
	synchronized public void clear() {
		formulae.clear();
	}

	synchronized public int size() {
		return formulae.size();
	}

	synchronized public ArrayList<Formula> toArrayList() {
		ArrayList<Formula> formulae = new ArrayList<Formula>();
		try {
			for(String formula : this.formulae)
				formulae.add(new SWIFormula(SWIPrologLanguage.getInstance().parser(formula+". "))); // ADHOC
		}
		catch (Exception e) { new Warning("Formula conversion failed:",e); }
		return formulae;
	}
	
	@Override
	synchronized public Theory clone() {
		Theory theory = new Theory();
		theory.add(this);
		return theory;
	}

	@Override
	/** prints all formulas in the theory on separate lines. */
	synchronized public String toString() {
		String text = new String();
		for (String formula : formulae)
			text +=formula+"\n";
		return text;
	}

		/** this puts all formulas in the theory on a single line, comma separated . Useful to print the goalbase. */
	synchronized public String toStringSingleLine() {
		String text =null;
		for (String formula : formulae) {
			if (text==null) text=formula;
			else text +=", "+formula;
		}
		return text+"\n";
	}

}
