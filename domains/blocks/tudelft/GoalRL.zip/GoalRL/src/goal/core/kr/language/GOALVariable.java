package goal.core.kr.language;

import goal.core.kr.KRlanguage;
//import goal.kr.language.swiprolog.SWIVariable;
import goal.tools.errorhandling.Warning;

import java.util.LinkedHashSet;
import java.util.Set;

/** Wouter: is this obsolete? It seems to contain bugs preventing compilation?*/
public class GOALVariable implements Var {

	// Class fields
	private String fName;
	
	// Constructor
	public GOALVariable(String pName) throws Exception {
		if (pName==null)
		 	throw new Exception("Variable name not specified.");
		if (Character.isUpperCase(pName.charAt(0))) {
			fName = new String(pName);
		}
		else
			throw new Exception("Variable names must start with an uppercase character.");
	}

	
	public Expression applySubst(Substitution pSubst) {
		// TODO Auto-generated method stub		
		return pSubst.get(this);
	}

	public boolean equals(Object pExpr) {
		if (!(pExpr instanceof GOALVariable))
			return false;
		else return fName.equals(((GOALVariable)pExpr).getName()); 
		
	}
	public GOALVariable clone() {
		try {
			return new GOALVariable(this.fName);
		} catch (Exception e) {
			new Warning("BUG: clone of GOALVariable failed",e);
			return null;
		}
	}
	public String getName() {
		return fName;
	}
	
	public Set<Var> getFreeVar() {
		Set<Var> lVars = new LinkedHashSet<Var>();
		lVars.add(this);
		return lVars;
	}

	public KRlanguage getLanguage() {
		//ASSUMPTION: GOALVariable does not belong to any KR language
		return null;
	}

	public boolean isClosed() {
		return false;
	}

	public boolean isVar() {
		return true;
	}

	public Substitution mgu(Expression pExpr) {
		if (!(pExpr instanceof Term) || pExpr.getFreeVar().contains(this)) {
			return null;
		} else
			return new Substitution((Var)this,(Term)pExpr);
		
	}

	// TODO: Remove here. GOAL does not know any anonymous variables.
	/**
	 * @author W.Pasman 8feb08
	 */
	public boolean isAnonymous()
	{
		return fName.startsWith("_"); // W:Maybe equals("_") is sufficient?
	}
	
}
