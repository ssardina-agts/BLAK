package goal.core.program;

import goal.core.kr.language.Var;
import java.util.Set;
import goal.core.kr.language.Substitution;
import goal.core.mentalstate.MentalState;

/**
 * Wouter: Action is something that can be requested from the environment.
 * this can be done by goal env if the pre- and post conditions hold.
 * There are 3 types: DropAction, AdoptAction and UserSpecAction.
 * Drop and Adopt are mental-state actions, and 
 * the only action acting on the 'real' environment is the UserSpecAction.
*/
public interface Action {

	// Interface methods
	public String getName();
	
	/** @return false if this is a UserSpecAction that should be passed to the environment
	 * and true if this is a GOAL action that is handled by GOAL and not by the environment */
	public boolean reserved();
	
	public boolean isClosed();

	public Set<Var> getFreeVar();

	/**
	 *  method 'applySubst' creates an instantiated action by applying substitution 'pSubst' to action.
	 */
	public Action applySubst(Substitution pSubst);

	/** 
	 * @return: most general unifier that unifies action with action 'pAct', if it exists;
	 * 			otherwise 'null'
	 * 
	 */
	public Substitution mgu(Action pAct);
	
	public String toString();

	public boolean equals(Object lAction);

	public Action clone();
	
}