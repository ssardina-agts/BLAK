package goal.core.program;

import java.util.Set;

import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Var;
import goal.core.mentalstate.MentalState;

public class DropAction implements Action {
	
	// Class field
	QueryExpression fQuery;
	
	// Class constructor
	public DropAction(QueryExpression pQuery) {
		fQuery = pQuery;
	}
	
	// Class methods
	public String getName() {
		return "drop";
	}
	
	public QueryExpression getGoal() {
		return fQuery;
	}

	public Action applySubst(Substitution pSubst) {
		return new DropAction((QueryExpression)fQuery.applySubst(pSubst));
	}

	public Set<Var> getFreeVar() {
		return fQuery.getFreeVar();
	}

	public boolean isClosed() {
		return fQuery.isClosed();
	}
	
	public DropAction clone() {
		return new DropAction(fQuery);
	}
	
	public boolean equals(Object pObj) {
		if (!(pObj instanceof DropAction)) {
			return false;
		}
		return fQuery.equals(((DropAction)pObj).getGoal());
	}
	
	public boolean reserved() {
		return true;
	}
	
	public Substitution mgu(Action pAct) {
		return null;// TODO: implement.
	}
	
	public String toString() {
		return "drop("+fQuery.toString()+")";
	}
}
