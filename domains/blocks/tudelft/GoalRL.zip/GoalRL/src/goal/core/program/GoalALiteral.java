package goal.core.program;

import goal.core.kr.language.Formula;
import goal.core.kr.language.Substitution;

/**
 * 
 * @author Koen Hindriks
 *
 */

public class GoalALiteral implements MentalAtom {
	
	// Class fields
	public boolean fPos;
	public Formula fForm;

	// Constructor
	public GoalALiteral(boolean pPos, Formula pForm) {
		fPos = pPos;
		fForm = (Formula)pForm.clone();
	}
	
	// Class methods
	public LITERALTYPE getType() {
		return LITERALTYPE.GOALA;
	}
	
	public boolean getPosNeg() {
		return fPos;
	}
	
	public Formula getFormula() {
		return fForm;
	}
	
	public String toString() {
		String lSign = new String();
		
		if (!fPos) lSign += "not ";
		return lSign+"goal-a("+fForm.toString()+")";
	}
	
	public boolean isClosed() {
		return fForm.isClosed();
	}
	
	public GoalALiteral applySubst(Substitution pSubst) {
		return new GoalALiteral(fPos, (Formula)fForm.applySubst(pSubst));
	}

}
