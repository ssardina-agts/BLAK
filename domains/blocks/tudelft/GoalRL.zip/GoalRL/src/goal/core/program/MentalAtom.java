package goal.core.program;

import goal.core.kr.language.*;

/**
 * TODO Wouter: add documentation. What is this, who uses it, how?
 * @author Koen Hindriks
 *
 */

public interface MentalAtom {
	
	public LITERALTYPE getType() ;

	public boolean getPosNeg() ; 
	
	public Formula getFormula();
	
	public boolean isClosed() ;
		
	public MentalAtom applySubst(Substitution pSubst);

}
