package goal.core.kr.language;

import goal.tools.errorhandling.Warning;

import java.util.*;

/**
 * 
 * @author Koen Hindriks
 *
 */

public final class Substitution {
	
	// Class fields
	private Set<Binding> fSubst;
	
	// TODO: Need to write hashCode methods for both Substitution as well as Binding classes.
	// (Also for Action class.)
	
	public final class Binding {
		// Class fields
		private Var cVar;
		private Term cTerm;
		
		// Constructor
		public Binding(Var pVar, Term pTerm) {
			cVar = (Var)pVar.clone();
			cTerm = (Term)pTerm.clone();
		}
		
		// Class methods
		public Var getVar() {
			return cVar;
		}
		
		public Term getTerm() {
			return cTerm;
		}
		
		public String toString() {
			return cVar.toString()+"/"+cTerm.toString();
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Binding other = (Binding) obj;
			if (cTerm == null) {
				if (other.cTerm != null)
					return false;
			} else if (!cTerm.equals(other.cTerm))
				return false;
			if (cVar == null) {
				if (other.cVar != null)
					return false;
			} else if (!cVar.equals(other.cVar))
				return false;
			return true;
		}
	}
	
	
	// Class constructor
	public Substitution(Set<Binding> pSubst) {
		if (isLegal(pSubst)) {
			fSubst = new LinkedHashSet<Binding>(pSubst);
		} else
			return; // TODO: Catch exception.
	}
	
	public Substitution(Var pVar, Term pTerm) {
		LinkedHashSet<Binding> lBindingSet = new LinkedHashSet<Binding>();
		
		lBindingSet.add(new Binding(pVar, pTerm));
		fSubst = lBindingSet;
	}
	
	public Substitution() {
		fSubst = new LinkedHashSet<Binding>();
	}
	
//	public Substitution clone() { // CHECK: How to define a proper clone method?
//		HashSet<Binding>lSubst = new HashSet<Binding>();
//		lSubst.addAll(fSubst);
//		return new Substitution(lSubst);
//	}
	
	// Class methods
	public Set<Binding> getBindings() {
		return fSubst;
	}
	
	/**
	 * @return This method returns all variables in the domain of the substitution. It assumes the substitution is legal.
	 */
	public Set<Var> getVarDomain() {
		Set<Var> lVarSet = new LinkedHashSet<Var>();
		
		for (Binding lBind : this.fSubst) {
			lVarSet.add(lBind.getVar());
		}
		return lVarSet;
	}
	
	/**
	 * This method checks that each variable is bound at most once in a set of bindings.
	 * Note that empty set is allowed. 
	 */
	public static boolean isLegal(Set<Binding> pSubst) {
		Set<Var> lVar = new LinkedHashSet<Var>();
		
		// TODO: Check that for-loop can be used to walk through all elements of set.
		for (Binding lBind : pSubst) {
			if (!lVar.contains(lBind.getVar())) {
				lVar.add(lBind.getVar());
			} else
				return false; // TODO: Throw exception.
		}
		return true;
	}
	
	/**
	 * This method extends the substitution with a new binding for a variable. It first checks if variable has already
	 * been bound. If so, nothing happens, else new binding is added.
	 */
	public boolean addBinding(Binding pBind) {
		Set<Var> lVarSet = this.getVarDomain();
		
		if (!lVarSet.contains(pBind.getVar())) {
			this.fSubst.add(pBind);
			return true;
		} else
			return false;
	}
	
	/**
	 * This method combines two substitutions, if such a combinations is 'valid'.
	 * @param pSubst Substitution to be combined with given substitution.
	 * @return Returns 'null' if combination is not valid, otherwise returns combined substitution. 
	 */
	public Substitution combine(Substitution pSubst) {
		if (pSubst==null) return null;
		Substitution lSubst = new Substitution();
		
		lSubst.fSubst.addAll(this.fSubst);
		lSubst.fSubst.addAll(pSubst.getBindings());
		if (isLegal(lSubst.getBindings())) {
			return lSubst;
		} else {
			new Warning("Invalid attempt to combine substitutions "+fSubst+" and "+pSubst+"; returning null.");
			return null;
		}
	}
	
	/**
	 * This method applies a substitution to a given one, destroying the latter; i.e. substitution composition.
	 * TODO: Check this code (cf. e.g. Loyd)!
	 */
	public void applySubst(Substitution pSubst) {

		for (Binding lBind : this.fSubst) {
			lBind.getTerm().applySubst(pSubst);
		}
		for (Binding lBind : pSubst.getBindings()) {
				this.addBinding(lBind);
		}
	}
	
	public Term get(Var pVar) {
		for (Binding lBind : this.fSubst) {
			if (lBind.getVar().equals(pVar)) {
				return lBind.getTerm();
			}
		}
		return null;
	}
	
	public void clear() {
		fSubst.clear();
	}
	
	public String toString() {
		Binding[] lBindings = new Binding[fSubst.size()];
		lBindings = fSubst.toArray(lBindings);
		String lStr = "[";
		
		if (lBindings.length>0) {
			lStr += fSubst.iterator().next().toString();
		}
		for (int i=1; i<lBindings.length; i++) {
			lStr += ","+lBindings[i].toString();
		}
		lStr += "]";
		return lStr;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Substitution other = (Substitution) obj;
		if (fSubst == null) {
			if (other.fSubst != null)
				return false;
		} else if (!fSubst.equals(other.fSubst))
			return false;
		return true;
	}
	
	/** Make union of this substition with given list of var names.
	 * i.e. keep only those substis that are in given list */
	public void union(Set<Var> vars)
	{
		ArrayList<Binding> toRemove=new ArrayList<Binding>();
		for (Binding b : fSubst) {
			if (!vars.contains(b.getVar())) toRemove.add(b);
		}
		fSubst.removeAll(toRemove);
	}

}
