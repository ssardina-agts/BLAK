package goal.core.program;

import goal.core.kr.language.*;
import goal.core.mentalstate.MentalState;
import goal.kr.implementations.swiprolog.SWIFormula;
import goal.kr.implementations.swiprolog.SWIQueryExpression;
import goal.tools.debugger.Debugger;
import goal.explanation.*;

import java.util.*;

/**
 * 
 * @author Koen Hindriks
 * 
 */

public class PerceptRule {
	
	// Class fields
	private Formula condition;
	private Action action;
	
	// Constructor
	public PerceptRule(Formula pCondition, Action act) {
		if ( (act instanceof AdoptAction) || (act instanceof DropAction) || 
				(act instanceof InsertAction) || (act instanceof DeleteAction)) {
			condition = pCondition;
			action = act;
		}
		else throw new IllegalArgumentException("PerceptRule only can have adopt,drop,insert or delete, but found "+act);
	}
	
	// Class methods
	public Formula getCondition() {
		return condition;
	}
	
	public Action getUpdate() {
		return action;
	}

	public void applyRule(MentalState state, Explanation expl, Debugger debugger, int time) throws Exception {
		debugger.bp("PE", "applying perceptrule "+this, 4);
		Set<Substitution> substSet = state.beliefQuery(new SWIQueryExpression((SWIFormula)condition), debugger);
		for (Substitution subst : substSet) {
			Action temp=action.applySubst(subst);
			state.executeAction(temp, debugger);
			
			//explanation: create explanation for percept rule
			expl.createExplanationForPercept(temp, condition.applySubst(subst), time);
		}
	}
	
	public String toString() {
		return "when input "+condition+" do "+action+".";
	}

}
