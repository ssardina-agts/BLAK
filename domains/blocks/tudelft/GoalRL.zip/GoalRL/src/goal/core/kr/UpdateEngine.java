package goal.core.kr;

import goal.core.kr.language.*;

/**
 * 
 * @author Koen Hindriks
 *
 */

public interface UpdateEngine {
	
	// Class methods
	
	/**
	 * The following methods are used to transform the contents of a database
	 * by additing or removing information from it. The method names correspond
	 * to the commonly used names of belief revision operators in the AGM framework,
	 * to suggest their intended semantics.
	 */
	
	/** ASSUMPTION: The Application Programming Interface (API) that implements this UpdateEngine interface
	 * needs to ensure that Formula form is closed!
	 */

	/**
	 * In addition to the common AGM revision operators, a method 'delete' must be provided to remove a
	 * sentence from a database in the set-theoretical sense. That is, the sentence to be deleted is removed
	 * from the database viewed as a set of sentences. After deletion it still may be the case that the
	 * sentence is entailed by the database, but it should no longer be contained explicitly in the database.
	 * @param pForm The sentence (a closed formula) to be removed.
	 * @param pBase The database from which the sentence is removed.
	 * @return A boolean value 'true' upon successful removal of the sentence from the database, otherwise
	 * 'false'. The method should also return 'false' if the sentence is not an element from the database
	 * viewed as a set.
	 */
	public boolean delete(Formula pForm, Database pBase);
	
	/** 
	 * The method 'contract' removes a sentence from a database. After applying the method the sentence that
	 * is removed should no longer follow from the database.
	 * @param pForm The sentence to be removed.
	 * @param pBase The database from which the sentence is removed.
	 * @return A boolean value 'true' upon successful removal of the sentence from the database, otherwise 'false'.
	 */
	public boolean contract(Formula pForm, Database pBase) throws Exception;
	
	/**
	 * The method 'expand' simply adds a sentence to a database in the set-theoretical sense.
	 * As a result, the database will entail the added formula, but also may become logically
	 * inconsistent. The method always succeeds.
	 * @param pForm The sentence to be added.
	 * @param pBase The database to which the sentence has been added.
	 * @return A boolean value 'true' upon successful addition of the sentence, otherwise 'false'.
	 */
	public boolean expand(Formula pForm, Database pBase);
	
	/** The method 'revise' also adds a sentence to a database but at the same time other sentences
	 * are removed if this is needed to ensure that the resulting database is consistent. The resulting
	 * database entails the added sentence if the method was successful in removing all conflicting data.
	 * @param pForm The sentence to be added.
	 * @param pBase The database that is to be revised with the sentence.
	 * @return A boolean value 'true' upon successful revision of the database with the sentence, otherwise 'false'.
	 */
	public boolean revise(Formula pForm, Database pBase);

	/** The method 'update' updates a database with a sentence after some changes have occurred due to actions the
	 * agent performed or other events that changed the agent's environment. The 'update' method is similar to the
	 * 'revision' method in that it removes other sentences if this is needed to ensure that the resulting database
	 * is consistent. The resulting database entails the added sentence if the method was successful in
	 * removing all conflicting data. The 'update' method may be identical to the 'revise' operator (and will be
	 * in many simplified settings) but does not need to be the same.
	 * @param pForm The sentence to be added.
	 * @param pBase The database that is to be revised with the sentence.
	 * @return A boolean value 'true' upon successful revision of the database with the sentence, otherwise 'false'.
	 */
	public boolean update(Formula pForm, Database pBase);


	/** 
	 * @author W.Pasman
	 * Insert tries to insert a formula into the database without parsing pForm.
	 * It is up to the programmer of the GOAL program to ensure that the pForm is compliant with the database.
	 * @param pForm The formula to be inserted.
	 * @param pBase The database to which the formula is to be added.
	 * @return A boolean value 'true' upon successful insertion of the sentence into the database, otherwise 'false'.
	 */
	public boolean insert(String pForm, Database pBase);
}
