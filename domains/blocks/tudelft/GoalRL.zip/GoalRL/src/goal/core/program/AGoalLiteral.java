package goal.core.program;

import goal.core.kr.language.Formula;
import goal.core.kr.language.Substitution;

/**
 * 
 * @author Koen Hindriks
 *
 */

public class AGoalLiteral implements MentalAtom {
	
	// Class fields
	public boolean fPos;
	public Formula fForm;

	// Constructor
	public AGoalLiteral(boolean pPos, Formula pForm) {
		fPos = pPos;
		fForm = (Formula)pForm.clone();
	}
	
	// Class methods
	public LITERALTYPE getType() {
		return LITERALTYPE.AGOAL;
	}
	
	public boolean getPosNeg() {
		return fPos;
	}
	
	public Formula getFormula() {
		return fForm;
	}
	
	public String toString() {
		String lSign = new String();
		
		if (!fPos) lSign += "not ";
		return lSign+"a-goal("+fForm.toString()+")";
	}
	
	public boolean isClosed() {
		return fForm.isClosed();
	}
	
	public AGoalLiteral applySubst(Substitution pSubst) {
		return new AGoalLiteral(fPos, (Formula)fForm.applySubst(pSubst));
	}

}
