package goal.core.scheduler;

import java.util.ArrayList;
import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.env.Percept;
import goal.tools.errorhandling.Warning;

/**
 * 
 * @author Koen Hindriks
 * Wouter: seems deprecated, wumpus now also runs on JadeScheduler which is using genericscheduler.
 */

public class WumpusScheduler extends GenericScheduler 
{
	
	public WumpusScheduler(ArrayList<Agent> pAgents, Environment pEnv)
	{
		super(pAgents,pEnv); 
		
		/*
		 * Wouter: not needed anymore to pre-load percept,
		 * we now send percept before asking next action from agent.
		Agent pAgent=pAgents.get(0); // always just 1 agent 
		ArrayList<Percept> percepts= fEnv.sendPercepts(pAgent.getName());
		try { if (percepts!=null) pAgent.receivePercepts(percepts); }
		catch (Exception e) { System.out.println("Err in receivePercepts: "+e.getMessage()); e.printStackTrace(); }
		*/
	}

	
	// we override the step functionality.
	// Main reason is that the env may be unavailable yet, and we don't want GOAL 
	// to halt because no actions are possible at that moment.
	// TODO: not a very good reason, it seems to me; let's fix this.
	
	public boolean step(Agent pAgent) {
		// false will stop the system.
		if (!fEnv.availableForInput()) {
			return true;
		}

    	debugger.bp("SCH", "Agent going to make next step",1);
		if (checkReset(pAgent)) {
			return true; // check this imm. AFTER the above debug halting point!!
		}
		// NOTE: DO NOT put more debug messages on this level, 
		// this level is used by the debugger!

		// TODO determine stop criterion for Wumpus world and pass it upwards.
		// Wouter: Huh, you can always do a reset and continue?
		
		ArrayList<Percept> percepts= fEnv.sendPercepts(pAgent.getName());
		try {
			if (percepts!=null) {
				pAgent.processPercepts(percepts);
			}
		} catch (Exception e) {
			// TODO: generically handle error messages
			System.out.println("Error in processPercepts: "+e.getMessage()); e.printStackTrace();
		}

		String lAct = receiveAction(pAgent);
		if (lAct!=null) executeAction(lAct);
		
		return true;
	}

}
