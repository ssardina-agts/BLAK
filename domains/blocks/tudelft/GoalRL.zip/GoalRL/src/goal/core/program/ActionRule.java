package goal.core.program;

import goal.core.kr.language.*;

import java.util.*;

/**
 * 
 * @author W.Pasman
 * Wouter: ActionSpec is datastructure to store an actionspec rule of the agent's goal specification.
 */

public class ActionRule 
{	
	private Action action;
	private Formula precondition;
	private Formula postcondition; // can be null
	
	public ActionRule(Action a, Formula pre, Formula post)
	{	action=a; precondition=pre; postcondition=post; }
	
	public Action getAction() { return action; }
	
	public Formula getPreCondition() { return precondition; }
	
	public Formula getPostCondition() { return postcondition; }

	/**
	 * @returns new ActionRule with substitution applied
	 */
	public ActionRule substitute(Substitution s)
	{
		Formula post=null;
		if (postcondition!=null) post=postcondition.applySubst(s);
		return new ActionRule(action.applySubst(s),precondition.applySubst(s),post);
	}
	
	public String toString() {
		String s="";
		s=action+"{ ";
		s=s+":pre { "+precondition+" } ";
		s=s+":post { "+postcondition+" }";
		s=s+" }";
		return s;
	}
}
