package goal.core.mentalstate;

import goal.core.kr.*;
import goal.core.kr.language.*;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

import java.util.*;

/**
 * 
 * @author Koen Hindriks
 *
 * A beliefbase is a database with generic handling and querying capabilities.
 * 
 */

public class BeliefBase implements Base {
	
	// Class fields
	private String name;
	private Database database;
	private Theory theory;
	
	/** DOC:
	 * The theory represents the "visible" contents of the beliefbase. It should correspond with the database, except
	 * possibly for background knowledge present in the database which is not reflected in the theory. In order to
	 * ensure the theory corresponds correctly in this sense with the database, any changes to the belief base need
	 * to be made by using the methods provided by this class. By directly modifying the underlying database, the
	 * correspondence may be lost.
	 * Background knowledge added to the database is assumed to be static. Additionally, the predicates declared/defined
	 * in the belief base's theory and in background theories should not overlap (this will raise exceptions when
	 * inserting the background knowledge into a Prolog database).
	 */

	// Constructor
	/**
	 * Construct a beliefbase using a given database.
	 */
	
	public BeliefBase(String name, Theory theory, KRlanguage language) throws Exception {
		this.name = name;
		database = language.makeDatabase(name, theory); // makeDatabase creates a clone of theory.
		this.theory = theory;
	}
	
	// Class methods
	public String getName() {
		return name;
	}
	
	public Database getDatabase() {
		return database;
	}
	
	public Theory getTheory() {
		return theory;
	}
	
	public KRlanguage getLanguage() {
		return database.getLanguage();
	}
	
	/**
	 * Adds a theory as background knowledge. The formulae from the theory are added to the database associated with
	 * the belief base, but not to the theory associated with the belief base. The theory thus functions only in the
	 * background of the belief base, as part of the database, but is "invisible" from the perspective of the
	 * associated theory.
	 * @param theory that contains the background knowledge.
	 * @throws Exception when some failure occurs while adding the background knowledge to the database.
	 */
	public void addBackgroundKnowledge(Theory theory) throws Exception {
		database.add(theory);
	}
	
	/** erase all content from the belief base */
	public void eraseContent() {
		database.eraseContent();
		theory.clear();
	}
	
	/**
	 * The method 'query' verifies if a formula follows from the belief base.
	 * @param pSusbt A list of substitutions that when applied to the formula result in instances of the formula
	 * that follow from the belief base. If the formula is closed, i.e. does not have any free variables, then pSubst
	 * is an empty list.
	 * @return a set of substitutions that make the query true.	 */
	public final Set<Substitution> query(QueryExpression formula, Debugger debugger) {
		try {
			return database.getLanguage().getInferenceEngine().query(formula, database, debugger);
		} catch (Exception e) {
			new Warning("query failed",e);
			return new LinkedHashSet<Substitution>(); // return empty solution,  to keep system running.
		}
	}
	
	// TODO: include same set of operators here as associated with database updates, e.g. contract, etc.
	public boolean insert(Formula formula) {
		theory.add(formula);
		return database.getLanguage().getUpdateEngine().revise(formula, database);
	}
	
	// CHECK Never used...
	public boolean delete(Formula formula) {
//		 TODO: update belief base's theory
		try {
			return database.getLanguage().getUpdateEngine().contract(formula, database);
		} catch (Exception e) { new Warning("delete failed",e); return false; }
	}
	
	 /**
	  * @return A boolean value 'true' upon successful revision of the database with the sentence, otherwise 'false'.
	  * Wouter: update 1oct08: now returns true if anything changed, or false if nothing changed.
	  */
	public boolean update(Formula formula) {
		theory.update(formula);
		return database.getLanguage().getUpdateEngine().update(formula, database);
	}

	// ASSUMES that formula is an atom (fact). DO NOT use for anything else.
	/** Insert method that works on string in order to avoid parsing, if possible. */
	public boolean insert(String formula) {
		if (formula.contains("received") && formula.contains("accepted"))
				System.out.println("insert:"+formula);
		if (!theory.getFormulae().contains(formula)) {
			theory.getFormulae().add(formula);
			return database.getLanguage().getUpdateEngine().insert(formula, database);
		} else
			return false;
	}

	/** include all contents from given file to database */
	public void include(String pFilename) throws Exception {
		System.out.println("INCLUDE FILE:"+pFilename);
		database.loadFromFile(pFilename);
	}
	
	public String toString() {
		return "BeliefBase["+theory+"]";
	}

}
