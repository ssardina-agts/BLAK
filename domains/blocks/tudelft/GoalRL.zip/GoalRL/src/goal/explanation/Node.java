package goal.explanation;

import java.util.Vector;

public class Node implements GoalActionNode {
	
	Vector<GoalActionNode> children;
	MentalStateConditionEdge msc;
	Vector<GoalActionNode> parents;//usually only one
	boolean action; //if false, is goal
	boolean selected;
	Vector<Long> selectedTimestamp;
	int id;
	String content;
	
	public Node(String content, boolean action, int id){
		this.content=new String(content);
		this.action=action;
		children=new Vector<GoalActionNode>();
		parents=new Vector<GoalActionNode>();
		this.id=id;
		selectedTimestamp=new Vector<Long>();
	}
	public Vector<GoalActionNode> getChildren() {
		// TODO Auto-generated method stub
		return children;
	}

	public String getContent() {
		// TODO Auto-generated method stub
		return content;
	}

	public long getEnabledTimeStamp() {
		// TODO Auto-generated method stub
		return msc.getEnabledTimeStamp();
	}

	public MentalStateConditionEdge getMentalStateCondition() {
		// TODO Auto-generated method stub
		return msc;
	}

	public Vector<GoalActionNode> getParents() {
		// TODO Auto-generated method stub
		return parents;
	}

	public long getSelectedTimeStamp() {
		// TODO Auto-generated method stub
		return selectedTimestamp.lastElement();
	}

	public String getSelectedTimeStamps() {
		String result=" ";
		for (Long t: selectedTimestamp)
			result+=(t+",");
		return result.substring(0, result.length()-1);
	}
	
	public boolean isAction() {
		// TODO Auto-generated method stub
		return action;
	}

	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return msc.isTrue();
	}

	public boolean isGoal() {
		// TODO Auto-generated method stub
		return !action;
	}

	public boolean isSelected() {
		// TODO Auto-generated method stub
		return selected;
	}

	public int getId(){
		return id;
	}
	
	public void addGoalAction(GoalActionNode n) {
		// TODO Auto-generated method stub
		children.add(n);
		
	}

	public void addMSC(MentalStateConditionEdge msc) {
		// TODO Auto-generated method stub
		this.msc=msc;
	}

	public void setSelected(boolean b) {
		// TODO Auto-generated method stub
		this.selected=b;
	}
	public void addSelectedTimeStamp(long t) {
		// TODO Auto-generated method stub
		this.selectedTimestamp.add(new Long(t));
	}
	public void setContent(String c) {
		// TODO Auto-generated method stub
		this.content=new String(content);
	}
	@Override
	public String toString() {
		return content+(selected?" selected":"")+(action?" action":"");
	}
	public String toDOT() {
		// TODO Auto-generated method stub
		return id+" [style=\""+(selected?"solid":"dotted")+"\" label=\""+content+(action?"\\naction":"")+"\\n"+(selected?getSelectedTimeStamps():"")+"\"]";
	}
}
