package goal.explanation;


public interface MentalStateConditionEdge {
	// A mental state condition is the non-goal part of the precondition in a Goal rule
	
	//retrieves the goal this MSC enables
	public GoalActionNode getGoal();
	
	//retrieves the action or subgoal this MSC executes/adopts
	public GoalActionNode getAction();
	
	//retrieves the actual MSC content (either the uninstantiated MSC if not true or the instantiated MSC if true)
	public String getContent();   
	
	//returns true if the MSC was true
	public boolean isTrue();
	
	//returns the last time (cycle) at which the MSC became true
	public long getEnabledTimeStamp();
	
	//returns all time (cycle) at which the MSC became true
	public String getEnabledTimeStamps();
	
	//returns the group to which this MSC belongs
	//grouping is used to represent and, or and sequence relations between MSCs
	//returns null if the MSC does not belong to a group
	public MentalStateConditionGroup getGroup();
	
	//setters
	public void setTrue(boolean b);
	public void setContent(String content);
	public void addEnabledTimeStamp(long t);
	
	public String toString();
	public String toDOT();
}
