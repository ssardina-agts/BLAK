package goal.explanation;
import java.util.*;

public interface MentalStateConditionGroup {
	//returns the type of this group 0=or, 1=and, 2=seq, -1=don't know
	public int getType();
	
	//returns the MSC members that belong to this group 
	public Vector<MentalStateConditionEdge> getMembers();
	
	public void add(MentalStateConditionEdge msc); 
}
