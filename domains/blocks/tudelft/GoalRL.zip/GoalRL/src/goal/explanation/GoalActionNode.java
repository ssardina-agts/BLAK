package goal.explanation;
import java.util.*;

public interface GoalActionNode {
	//A GoalAction is either an action or a goal. GoalActions are linked through 
	//mental state conditions (MSC) in a tree structure.
	
	//retrieves the parents (usually only one, but in some case an action or subgoal is relevant for two or more goals)
	public Vector<GoalActionNode> getParents();

	//retrieves the enabling MSC  
	public MentalStateConditionEdge getMentalStateCondition();

	//retrieves all subgoals/actions for this GoalAction.
	public Vector<GoalActionNode> getChildren();
	
	//retrieves the actual content (either the uninstantiated Goal/Action if isEnabled()==false or the instantiated Goal/Action if isEnbled()==true)
	public String getContent();
	
	//returns true if this is an action
	public boolean isAction();
	
	//returns true if this is a goal (subgoal)
	public boolean isGoal();
	
	//Checks getMentalStateCondition().isTrue() to figure out if this action/goal could fire
	public boolean isEnabled();

	//returns true if the action is executed or the goal is adopted
	public boolean isSelected();
	
	//returns the time (cycle) at which the MSC became true
	public long getEnabledTimeStamp();
	
	//returns the last time (cycle) at which the MSC became true
	public long getSelectedTimeStamp();

	//returns all time (cycle) at which the MSC became true
	public String getSelectedTimeStamps();
	
	//returns the unique ID for this node (is not used for explanation but for graphing the tree)
	public int getId();
	
	//setters
	public void addMSC(MentalStateConditionEdge msc);
	public void addGoalAction(GoalActionNode n);
	public void setContent(String c);
	public void addSelectedTimeStamp(long t);
	public void setSelected(boolean b);
	
	public String toString();
	public String toDOT();
}
