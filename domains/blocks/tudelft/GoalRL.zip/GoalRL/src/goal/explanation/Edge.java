package goal.explanation;

import java.util.Vector;

public class Edge implements MentalStateConditionEdge {
	
	GoalActionNode goal;
	GoalActionNode goalAction;
	boolean instantiated;
	String content;
	MentalStateConditionGroup group;
	Vector<Long> enabledTimestamp;
	
	public Edge(GoalActionNode goal, GoalActionNode goalAction, String content){
		this.goal=goal;
		this.goalAction=goalAction;
		this.content=new String(content);
		enabledTimestamp=new Vector<Long>();
	}
	
	public GoalActionNode getAction() {
		// TODO Auto-generated method stub
		return goalAction;
	}

	public String getContent() {
		// TODO Auto-generated method stub
		return content;
	}

	public long getEnabledTimeStamp() {
		// TODO Auto-generated method stub
		return enabledTimestamp.lastElement();
	}

	public String getEnabledTimeStamps() {
		String result=" ";
		for (Long t: enabledTimestamp)
			result+=(t+",");
		return result.substring(0, result.length()-1);
	}

	public GoalActionNode getGoal() {
		// TODO Auto-generated method stub
		return goal;
	}

	public MentalStateConditionGroup getGroup() {
		// TODO Auto-generated method stub
		return group;
	}

	public boolean isTrue() {
		// TODO Auto-generated method stub
		return instantiated;
	}

	public void setContent(String content) {
		// TODO Auto-generated method stub
		this.content=new String(content);
	}

	public void addEnabledTimeStamp(long t) {
		// TODO Auto-generated method stub
		this.enabledTimestamp.add(new Long(t));
	}

	public void setTrue(boolean b) {
		// TODO Auto-generated method stub
		this.instantiated=b;
	}

	@Override
	public String toString() {
		return goal.getContent()+(isTrue()?"--->":"-!->")+goalAction.getContent()+" "+content;
	}
	public String toDOT() {
		// TODO Auto-generated method stub
		return goal.getId()+"->"+goalAction.getId()+" [ style=\""+(isTrue()?"solid":"dotted")+"\" label=\""+content+"\\n"+(isTrue()?getEnabledTimeStamps():"")+"\"]";
	}

	
}
