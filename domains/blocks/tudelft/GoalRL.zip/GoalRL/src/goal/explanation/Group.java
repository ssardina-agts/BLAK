package goal.explanation;

import java.util.Vector;

public class Group implements MentalStateConditionGroup {
	Vector<MentalStateConditionEdge> members;
	int type;
	
	public Group(int type){
		this.type=type;
	}
	public Vector<MentalStateConditionEdge> getMembers() {
		// TODO Auto-generated method stub
		return members;
	}

	public int getType() {
		// TODO Auto-generated method stub
		return type;
	}

	public void add(MentalStateConditionEdge msc) {
		// TODO Auto-generated method stub
		members.add(msc);
	}
	
}
