package goal.explanation;
import java.util.*;
import goal.core.agent.UpdateAction;
import goal.core.program.*;
import goal.core.kr.language.Formula;
import goal.core.kr.language.Substitution;

import java.io.*;

public class Explanation {
	//just a wrapper class for the explanantion structure for an agent
	public String agent; 
	public HashMap<String,GoalActionNode> nodes;
	public HashMap<String,MentalStateConditionEdge> edges;
	public HashMap<String,MentalStateConditionGroup> groups;
	static int graphCounter;
	
	public Explanation(String agent){
		this.agent=agent;
		nodes=new HashMap<String, GoalActionNode>();
		edges=new HashMap<String, MentalStateConditionEdge>();
		groups=new HashMap<String, MentalStateConditionGroup>();
		
		createNode("perception", "perception", false);
		createNode("reaction", "reaction", false);
		graphCounter=0;
	}
	
	public void select(UpdateAction u, int time){
		GoalActionNode actionNode;
		if (u.getAction() instanceof AdoptAction | u.getAction() instanceof AdoptOneAction)
			actionNode=nodes.get("goal "+parseUpdateActionContent(u.getAction()));
		else
			actionNode=nodes.get("action "+parseUpdateActionContent(u.getAction()));
		
		actionNode.setSelected(true);
		actionNode.addSelectedTimeStamp(time);
	}
	
	public void createExplanationForGoalAction(UpdateAction u, MentalAtom[] atoms, int time){
		//ASSUMES u is the instantiated action to be explained and atoms contains all non-instantiated formulas of the mentalstatecondition that will be instantiated using the substitution from u. 
		GoalActionNode goalNode=null;
		String edgeContent=" ";
		GoalActionNode actionNode;
		MentalStateConditionEdge edge;
		//create a subgoal/action node
		if (u.getAction() instanceof AdoptAction | u.getAction() instanceof AdoptOneAction)
			actionNode=createNode("goal "+parseUpdateActionContent(u.getAction()), parseUpdateActionContent(u.getAction()), false);
		else
			actionNode=createNode("action "+parseUpdateActionContent(u.getAction()), parseUpdateActionContent(u.getAction()), true);
		
		for (MentalAtom atom:atoms){
			
			if (atom.toString().contains("goal") | atom.toString().contains("a-goal"))
			{	//a goal atom is found, now create a goalaction node for explanation containing the instantiated goal 
				goalNode=createNode("goal "+atom.applySubst(u.getSubstitution()).getFormula().toString(), atom.applySubst(u.getSubstitution()).getFormula().toString(), false);
				//goalNode.setSelected(true);
				//goalNode.addSelectedTimeStamp(time);
			} else
			{ //create edge content with the non goal literals 
				edgeContent+=replaceTempWithX(atom.applySubst(u.getSubstitution()).getFormula().toString())+",";
			}
		}
		if (goalNode!=null){ //non-reactive rule
			edge=createEdge(edgeContent+goalNode.toString(), edgeContent.substring(0, edgeContent.length()-1), goalNode, actionNode, true);
		} else {//reactive rule
			edge=createEdge(edgeContent+"reactive", edgeContent.substring(0, edgeContent.length()-1), nodes.get("reaction"), actionNode, true);
		}
		edge.addEnabledTimeStamp(time);
	}
	
	public void createExplanationForPercept(Action a, Formula condition, int time){
		//ASSUMES  action is the instantiated action produced by a percept and condition is the instantiated condition 
		GoalActionNode actionNode;
		
		//create a subgoal/action node
		if (a instanceof AdoptAction | a instanceof AdoptOneAction)
			actionNode=createNode("goal "+parseUpdateActionContent(a), parseUpdateActionContent(a), false);
		else
			actionNode=createNode("action "+parseUpdateActionContent(a), parseUpdateActionContent(a), true);

		actionNode.setSelected(true);
		actionNode.addSelectedTimeStamp(time);
		createEdge(condition.toString()+" perception", condition.toString(), nodes.get("perception"), actionNode, true).addEnabledTimeStamp(time);
	}
	
	public String replaceTempWithX(String atom){
		int start=atom.indexOf("(_");
		if (start!=-1){
			int end=atom.indexOf(")", start);
			atom=atom.substring(0, start)+"(X)"+atom.subSequence(end+1, atom.length());
			return atom;
		} else
			return atom;
	}
	
	public String parseUpdateActionContent(Action a){
		//parse the raw goal toString output for an update_action into the pure literal
		//so that a goal in a-goal or adopt is always the same string 
		
		if (a instanceof AdoptAction)
			return ((AdoptAction)a).getGoal().toString();
		if (a instanceof AdoptOneAction)
			return ((AdoptOneAction)a).getGoal().toString();
		return a.toString();
	}
	
	public GoalActionNode createNode(String key, String content, boolean action){
		GoalActionNode node;
		if (!nodes.containsKey(key)){
			node= new Node(content, action, nodes.size());
			nodes.put(key, node);
		} else
			node=nodes.get(key);
		return node;
	}
	
	public MentalStateConditionEdge createEdge(String key, String content, GoalActionNode goal, GoalActionNode action, boolean isTrue){
		MentalStateConditionEdge edge;
		if (!edges.containsKey(key)){
			edge= new Edge(goal, action, content);
			edges.put(key, edge);
		} else
			edge=edges.get(key);
		edge.setTrue(isTrue);
		return edge;
	}
	
	public String toString(){
		String result="";
		result+="\nNodes:\n";
		for (GoalActionNode n: nodes.values())
			result+=n.toString()+"\n";
		result+="\nEdges:\n";
		for (MentalStateConditionEdge e: edges.values())
			result+=e.toString()+"\n";
		return result;
	}
	
	public String toDOT(){
		String dot;
		dot = "digraph G {\nrankdir=BT;\nnode [fontname=Courier, fontsize=8, label=\""+this.agent+"\"];\n";
		for (GoalActionNode node : nodes.values()) {
			dot += node.toDOT()+"\n";
		}
		for (MentalStateConditionEdge edge : edges.values()) {
			dot += edge.toDOT()+"\n";
		}
		dot += "}";
		return dot;
	}
	
	public void processDOT(String dot) {
	    String name="c:\\GOALExplanations\\GOALExplanation_"+agent+"_"+graphCounter;
	    String graphvizpath="c:\\graphviz\\";
	    
		File lastGraph = new File(name+".gif");
	    lastGraph.delete();
		graphCounter++;
		try {
        	File dotFile = new File(name+".dot");
        	PrintWriter pw = new PrintWriter(new FileWriter(dotFile),true);
        	pw.print(dot);
        	pw.close();
			Process p = Runtime.getRuntime().exec(graphvizpath+"\\bin\\dot -Tgif "+name+".dot"+" -o "+name+".gif");
        } catch (Exception ex) {
             System.out.println("Error creating explanantion from .dot format.");
        }
	}
	public void processDOT() {
		processDOT(this.toDOT());
	}
}
