package goal.tools;

import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.mas.MASRegistry;
import goal.parser.GOALLexer;
import goal.parser.GOALParser;
import goal.parser.GOALProgram;
import goal.parser.LinkedListTokenSource;
import goal.parser.LinkedListTokenStream;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.antlr.runtime.ANTLRReaderStream;


/**
 * general IO Management stuff.
 * CHECK Wouter 28jul09 shouldn't most functions here be static?
 * */
public class IOManager {
	
	// Class fields
	
	// Constructor
	public IOManager() {
		
	}

	// Class methods
	
	/**
	 * @author W.Pasman 9apr09. Would expect this to be somewhere in the "OS" but can't find it...
	 * @return concat of two paths. Absolute path starts with a '/', otherwise it's a relative path 
	 * Make sure that you convert windows '\' into the std java '/'
	 */
	static public String concatPaths(String path1, String path2) {
		if (path2.startsWith("/")) return path2; // absolute path
		if (path2.startsWith("./")) path2=path2.substring(2);
		if (path2.equals("") || path2.equals(".")) return path1;
		if (path1.endsWith("/")) path1=path1.substring(0, path1.length()-1); // drop '/'
		return path1+"/"+path2;
	}
	
	/** @return base directory that contains given file (full path to file needed). 
	 * @author W.Pasman*/
	static public String getDirectory(String fullpath)
	{
		// compute base path to be pre-pended to the specified goal filenames.
		// this basePath includes the '/' at the end.
		int indexofsep = fullpath.lastIndexOf('/');
		String basePath="";
		if (indexofsep>0) basePath=fullpath.substring(0,indexofsep+1);
		return basePath;
	}
	
	/** @return file name only and strips path */
	static public String getName(String fullpath) {
		int indexofsep = fullpath.lastIndexOf('/');
		if (indexofsep>0) return fullpath.substring(indexofsep+1);
		return fullpath;
	}
	/**
	 * @returns Hashtable of pairs <agentname, goalfilename> 
	 * Wouter: 18jun08: now throw  in case of failure. 
	 * @modified 24jun08: changed return type from MASRegistry to Hashtable,
	 * because the MASRegistry contains RUNNING agents only.
	 * */
	public BufferedReader loadFile(String pFilename) {
		try {
			return new BufferedReader(new FileReader(pFilename));
		} catch (Exception e) { new Warning("File "+pFilename+" not found.",e); return null; }
	}
	
	/** Wouter: modified 11mar09: returned registry now may contain no environment. 
	 * In that case, registry.getEnvironmentClassName() will return null */
	public MASRegistry loadMASFile(String pMASFilename) throws Exception {
	// Hashtable<String,String> loadMASFile(String pMASFilename) throws Exception {
		BufferedReader lBuffer = loadFile(pMASFilename);
		MASRegistry lRegistry;
		// Hashtable<String,String> theMAS = new Hashtable<String,String>();
		
		if (lBuffer == null)
			return null;
		
		lRegistry = new MASRegistry(pMASFilename);
		String basePath=lRegistry.getBasePath();

		
		// Ok now parse the contents
		// ASSUMPTION: Only lines of format "agent name : file name"
		// TODO: Use parser instead of dedicated code, and change setup mas file. See Mantis 187.
		String lLine = lBuffer.readLine();
		while (lLine != null) {
			if (!lLine.startsWith("%") && !lLine.equals("")) { // Ignore comments and empty lines
				// Remove layout characters at end of line
				while (lLine.endsWith("\r") || lLine.endsWith(" "))
					lLine = lLine.substring(0, lLine.length()-1);
				lLine = lLine.replace('\r', ' ');
				// Do not use replaceAll as it has problems with backslashes that occur in windows paths.
				String[] fields = lLine.split(":");
				if (fields.length!=2) throw new Exception("Not a mas file; expected one ':' but found "+lLine);

				if (fields[0].equals("environment")) {
					if (lRegistry.getEnvironmentClassName()!=null)
						throw new Exception("MAS file problem: duplicate environment definition");
					 // environment: classpath,classname
					String[] envinfo=fields[1].split(",");
					if (envinfo.length!=2) 
						throw new Exception("MAS file problem: environment field should have classpath,classname but found "+fields[1]);
					lRegistry.setEnvironment(envinfo[0], envinfo[1]);
				}
				else {
					String lAgentName = fields[0];
					String lEnvironment="";
					String lFilename = fields[1];
					if (fields[0].contains("@")) {
						String[] fields2=lAgentName.split("@");
						if (fields2.length!=2) throw new Exception("MAS file problem: encountered multiple '@' in agent name "+lAgentName);
						lAgentName=fields2[0];
						lEnvironment=fields2[1];
					}
					lRegistry.addAgentFilename(lAgentName, lEnvironment, basePath+lFilename);
				}
			}
			// Get next line.
			lLine = lBuffer.readLine();
		}
		lBuffer.close();
		return lRegistry; 
	}
		
	
	/** Added W.Pasman 12mar09 
	 * Creates new empty file of given name.
	 * Will overwrite old file if it already exists
	 * @throws exception if failed  */
	public static void CreateFile(String fullpath) throws Exception {
		File f=new File(fullpath);
		//if (f.exists()) {throw new Exception("file "+fullpath+" already exists");} 
		new FileWriter(f).close(); // create new empty file.
	}
		
		/*
		String lMASFileContent = new String();
		String lAgentname;
		String lFilename;
		Hashtable<String,String> theMAS = new Hashtable<String,String>();
		//MASRegistry lRegistry = new MASRegistry(pMASFilename);
		
		lMASFileContent = readFileAsString(pMASFilename);

		// Ok now parse the contents
		// TODO: Use parser instead of dedicated code, and change setup mas file. See Mantis 187.
		String[] lines = lMASFileContent.split("\n");
		for (String line : lines) {
			// remove layout characters at end of line
			while (line.endsWith("\r") || line.endsWith(" "))
				line=line.substring(0, line.length()-1);
			line = line.replace('\r', ' ');
			// Do not use replaceAll as it has problems with backslashes that occur in windows paths.
			if (!line.startsWith("%") && !line.equals("")) { // Ignore comments
				String[] fields = line.split(":");
				lAgentname = fields[0];
				lFilename = fields[1];
					
				theMAS.put(lAgentname, lFilename);
			}
		}
		return theMAS;
	}
	*/
	
	/*
	public MASRegistry loadMAS(MASRegistry pReg) throws Exception
	{
		HashMap<String, String> lFilenames = pReg.getFilenames();
		for (String lAgentname : lFilenames.keySet()) {
				pReg.addAgent(lAgentname, loadGOALAgent(lFilenames.get(lAgentname)));
		}
		return pReg;
	}
	*/
	
	/**
	 * @author Wouter 28jul09, this function was appearing at multiple places in the code. Fixed that.
	 * @param filename is full path of file. 
	 * @return short name for given filename. The short name can not be used to reconstruct the original name  
	 */
	public static String shortName(String filename) {
		int indexofsep = filename.lastIndexOf('/');
		String shortnm = filename;
		if (indexofsep > 0)
			shortnm = filename.substring(indexofsep+1);
		return shortnm;
	}
	
	/**
	 * @return new agent.
	 * @throws FileNotFoundException or RecognitionException
	 */
	public Agent loadGOALAgent(String pFileName, String agentName) throws Exception {
		// Create Agent
		System.out.println("Creating agent..."+new File(pFileName));
		//GOALSemantics lAgent = lParser.getHelper();
		//Agent lAgt = new Agent(lAgent.fAgentName, lAgent.fBBs, lAgent.fGBs,lActionRules ,lAgent.fOldActionSpec, lAgent.fActionSpec, debugger);

		// Read and Parse the Content of the Agent File
		Reader lFileReader = new FileReader(new File(pFileName));
		System.out.println("Parsing agent file...");
		ANTLRReaderStream lCharStream = new ANTLRReaderStream(lFileReader);

		GOALLexer lLexer = new GOALLexer(lCharStream);
		lLexer.setSourceName("file "+pFileName);
		LinkedListTokenSource lLinker = new LinkedListTokenSource(lLexer);
		LinkedListTokenStream lTokenStream = new LinkedListTokenStream(lLinker);
		GOALParser lParser = new GOALParser(lTokenStream);
		lParser.initialize("file "+pFileName);
		lParser.setInput(lLexer, lCharStream, lFileReader);
		GOALProgram program = lParser.program();
		
		// Report any errors and quit if any
		String lError = lParser.getFirstError();
		if (lError!=null) { 
			throw new Exception("Quiting agent startup due to error found during parsing."); // Do not print errors here; they have already been printed by parser.
		}

		Agent lAgt = new Agent(program, agentName); // will throw if failure occurs.
		System.out.println("Agent "+program.getAgentName()+" loaded successfully.");
		lFileReader.close();
		
		return lAgt;
		// horizon = lAgent.horizon;
	}
	
	/** get a class object from a specified class path 
	 * @author W.Pasman 28oct08*/
	public Object loadClass(final String ClassPath, final String ClassName) throws Exception {
		try {
			/* we wrap the entire run in a class loader that knows the right class path */
			return new MyClassLoader(ClassPath, ClassName).load();
		} 
		catch (Error e) {
			throw new Exception("Error occured while loading "+ClassName+" from classpath "+ClassPath+":"+e);
		}
	}

	/** IDE helper methods
	 * asks for filename. If this is a save-dialog, it will ask extra confirmation if file already exists.
	 @param openFile == true if file open, false if file save dialog. 
	 @param title  is the title for in the chooser's window title bar.
	 @returns null if cancelled.
	*/
	static String userdir = System.getProperty("user.dir")+"/GOALagents/"; /* directory where user located his files.*/
	
	public static String askFileName(JPanel parentpanel, boolean openFile, String title) {
		return askFileName(parentpanel,openFile,title, JFileChooser.FILES_ONLY,null,null);
	}

	 /** open file browser panel and ask user to pick a filename/directory.
	  * @author W.Pasman, moved here from the SimpleIDE 20apr09, to support GOAL-wide uniform browser.
	  * @param parentpanel is the panel to center this filebrowse panel on
	  * @param openFile should be true if you want open-file dialog, false if you want save dialog
	  * @param title is the title for the file browsesr panel 
	  * @param mode is FILES_ONLY or DIRECTORIES_ONLY or whatever you allow for selection.
	  * @param extension is the suggested extension. if not null and user entered filename without any extension,
	  * we add that extension. We recommend to leave this null for the "open-file" dialog. See trac 700
	  * @param suggestedname if not null the dialog will suggest a filename of the form suggestedname###.extension
	  * if openFile=true then an existing name is picked of that form, if openfile=false then a new name is picked.
	  * @return full path of selected file, or null if canceled.
	  */
	public static String askFileName(JPanel parentpanel, boolean openFile, String title, int mode, String extension,String suggestedname) {
		String filename=null;
		try {
			File dir=new File(userdir);
			String suggestion=null;
			if (suggestedname!=null) {
				if (openFile) suggestion=findExisting(dir,suggestedname,extension);
				else suggestion=findNonExisting(dir,suggestedname,extension);
			}
			JFileChooser chooser = new JFileChooser();
			chooser.setCurrentDirectory(dir);
			chooser.setDialogTitle(title);
			chooser.setFileSelectionMode(mode);
			if (suggestion!=null) chooser.setSelectedFile(new File(suggestion));
			int r;
			
			if (openFile)
				r = chooser.showOpenDialog(parentpanel);
			else
				r = chooser.showSaveDialog(parentpanel);
			
			if (r!=JFileChooser.APPROVE_OPTION) return null; // cancelled.

			File selected=chooser.getSelectedFile();
			filename = selected.getCanonicalPath();
			if (openFile && !selected.exists()) // Mantis 548: with Windows filebrowsers you can select non-existing files!
				throw new FileNotFoundException("file "+filename+" does not exist.");
			userdir = selected.getPath(); // store directory for future reference.
			//System.out.println("Selected "+filename);
			filename = filename.replace("\\", "/");
		} catch (Exception e) { new Warning("File selection failed.", e); return null; }
		
		if (extension!=null && !hasExtension(filename)) filename=filename+extension;
		if (!openFile && filename!=null && new File(filename).exists()) {
			int selection = JOptionPane.showConfirmDialog(parentpanel,
					"Overwrite existing file?",
					"Overwrite?", 
					JOptionPane.YES_NO_OPTION);
			if (selection != JOptionPane.YES_OPTION) filename=null;
		}
		
		return filename;
	}
	
	/** @return true if filename already has an extension (something of the form .XXXXXX with X alphanumeric chars)
	 */
	public static boolean hasExtension(String filename) {
		int i=filename.lastIndexOf('.');
		if (i==-1) return false;
		String maybeextension=filename.substring(i);
		return maybeextension.matches("\\.\\w+");
	}
	
	/** added Wouter 30jul09 trac 700 
	 * @returns a filename in given directory that starts with name and has extension, 
	 * or null if no such file was found. If dir is a file instead of path, the directory
	 * containing dir is used. */
	public static String findExisting(File dir, String name, String ext) {
		if (dir.isFile()) dir=dir.getParentFile(); 
		String[] children=dir.list();
		if (children==null) return null;
		for (String child: children) {
			if (child.startsWith(name) && child.endsWith(ext)) return child;
		}
		return null;
	}
	
	/** added Wouter 30jul09 trac 700 
	 * @returns a filename that starts with name and has extension, 
	 * and does not exist in given directory 
	 * If dir is a file instead of path, the directory
	 * containing dir is used.
	 * @throws Exception if no such filename can be found */
	public static String findNonExisting(File dir, String name, String ext) throws Exception {
		if (dir.isFile()) dir=dir.getParentFile(); 
		String[] chs=dir.list();
		if (chs==null) return name+ext; // no children at all... weird.... 
		ArrayList<String> children=new ArrayList<String>(Arrays.asList(chs));
		 // check of name+ext works straight away
		if (!children.contains(name+ext)) return (name+ext);
		 // no that did not work. Search an extra number to be added that works.
		for (int n=1; n<=1000; n++) {
			String newname=name+n+ext;
			if (!children.contains(newname)) return newname;
		}
		throw new Exception ("failed to make suggestion for new filename in this directory");
	}
}


/**
 * Class loader to load environment from custom jar files that were not necessarily in the class path
 * when GOAL was booted.
 * We use a URLClassLoader instead of a normal ClassLoader because the normal Classloader can not handle jars.
 * We seem to have luck: all classes loaded by this loader will also use this loader instead of the default loader.
 * People building their own environment might have to be aware of this.
 *
 * @author W.Pasman 28oct08
 */
class MyClassLoader extends URLClassLoader {
	String ClassPath, ClassName;
	
	/** 
	 * @param pClassPath is absolute path to the directory or jar file to be used.
	 * @param pClassName is the class name to be loaded. 
	 * pClassPath should be absolute -- start with '/' */
 	MyClassLoader(String pClassPath, String pClassName) {
		super(new URL[]{});
		ClassPath=pClassPath;
		ClassName=pClassName;
	}
	
 	/**
 	 * Wouter: at this point we convert the ClassPath to an URL
 	 * This is tricky: a trivial conversion to URL would be to add "jar:file://" in front and "!/" at the end for jars.
 	 * However, on Windows an absolute path starts with just a drive letter, eg "H:/file",
 	 * while the URL needs an additional "/" in front, so a correct URL would be "/H:/file".
 	 * To avoid system-dependent conversions we convert the ClassPath to a File and then toURL()
	 *
 	 * @throws ClassNotFOundException if class not found. 
 	 */
	public Object load() throws Exception {
		String filename=new File(ClassPath).toURL().toString();
		if (ClassPath.endsWith(".jar")) filename="jar:"+filename+"!/";
		URL u=new URL(filename);
		System.out.println("loading from classpath "+new File(u.getFile()));
		addURL(u);
		
		System.out.print("Searching [");
		for (URL s:getURLs()) { System.out.print(","+new File(s.getFile()) );  } // mantis 541 .
		
		System.out.println("]");
		Class c=loadClass(ClassName);
		try { 
			return c.newInstance();
		} catch (Error e) {
			throw new Exception("Class "+ClassName+" was found but it can not be instantiated. Maybe it depends on another class that could not be found: ",e);
		}
		
	}
	
	 static S urlToFile(URL url) {
		 return URLDecoder.decode(url.getFile(), System.getProperty("file.encoding"));
		 File f;
		 try {
		   f = new File(url.toURI());
		 } catch(URISyntaxException e) {
		   f = new File(url.getPath());
		 }
		 return f;
		 }
	 

	
}