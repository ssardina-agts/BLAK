package goal.tools.SimpleIDE;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JSplitPane;


public class IDEMainPanel extends JPanel {
	
	// Class fields
	private JSplitPane pane, tophalf;

	private JPanel fileProcessPanel;
	private FilePanel filePanel;
	private ProcessPanel processPanel;
	
	private JPanel editDebugPanel;
	private DebugPanel debugPanel;
	private EditPanel editPanel;
	
	private FeedbackPanel feedbackPanel;
	
	// Class constructor
	public IDEMainPanel(SimpleIDE theIDE) {
		CardLayout cl;
		
		setLayout(new BorderLayout());

		// add center pane
		fileProcessPanel = new JPanel(new CardLayout());
		filePanel = new FilePanel(theIDE);
		processPanel = new ProcessPanel(theIDE);
		fileProcessPanel.add(filePanel, "EDITVIEW");
		fileProcessPanel.add(processPanel, "DEBUGVIEW");
		cl = (CardLayout)fileProcessPanel.getLayout();
		cl.show(fileProcessPanel, "EDITVIEW");
		
		// OBSOLETE gepanel = new EditDebugTabPanel(theIDE);
		// below new code not using tabs...
		editDebugPanel = new JPanel(new CardLayout());
		editPanel = new EditPanel(theIDE);
		debugPanel = new DebugPanel(theIDE);
		editDebugPanel.add(editPanel, "EDITVIEW");
		editDebugPanel.add(debugPanel, "DEBUGVIEW");
		cl = (CardLayout)editDebugPanel.getLayout();
		cl.show(editDebugPanel, "EDITVIEW");

		tophalf = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, fileProcessPanel, editDebugPanel);
		tophalf.setOneTouchExpandable(true);
		tophalf.setContinuousLayout(true);
		tophalf.setMinimumSize(new Dimension(60,40));
		feedbackPanel = new FeedbackPanel(theIDE.getPlatformManager());
	    pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tophalf, feedbackPanel);

	    pane.setDividerLocation(IDEPrefPanel.getMainAreaHeight());

	    pane.setOneTouchExpandable(true);
		pane.setContinuousLayout(true);
		pane.setResizeWeight(1.0);
	    add(pane, BorderLayout.CENTER);
	}
	
	// Class methods
	public ProcessPanel getProcessPanel() {
		return processPanel;
	}
	
	public FeedbackPanel getFeedbackPanel() {
		return feedbackPanel;
	}
	
	public DebugPanel getDebugPanel() {
		return debugPanel;
	}
	
	public FilePanel getFilePanel() {
		return filePanel;
	}
	
	public EditPanel getEditPanel() {
		return editPanel;
	}
	
	public int getView() {
		if (editPanel.isVisible())
			return 0; // edit view
		else
			return 1; // debug view
	}
	
	public void switchView() { // switch to edit or debug view
		CardLayout cl = (CardLayout)editDebugPanel.getLayout();
		cl.next(editDebugPanel);
		cl = (CardLayout)fileProcessPanel.getLayout();
		cl.next(fileProcessPanel);
	}
	
	/**
	 * 
	 * @return the selected file in the file panel, or process in the process panel.
	 */
	public IDENode getSelectedNode() {
		if (getView()==0) // edit view
			return filePanel.getSelectedNode();
		else // process view
			return processPanel.getSelectedNode();
	}

	// Method closes tab in either edit or debug panel
	public void Close()  throws Exception {
		int view = getView();
		switch(view) {
		case 0: // edit view
			editPanel.Close();
		case 1: // debug view
			debugPanel.Close();
		}
	}
	
	/** Close all open panels and prepare for IDE shutdown */
	public void CloseAll() throws Exception {
		// relative sizes don't work, because the window is not visible at the moment we set the divider
		IDEPrefPanel.myPreferences.putInt("consolesize", pane.getDividerLocation());
		editPanel.CloseAll();
		debugPanel.CloseAll();
	}
	
	/** returns currently selected panel, null if none selected */
	public Component getCurrentPanel() {
		switch(getView()) {
		case 0: // edit view
			return editPanel.getActiveEditor();
		case 1: // debug view
			return debugPanel.getCurrentPanel();
		default:
			return null; // dunno what's selected but it's not a panel...
		}

	}

}
