/** Wouter: In eclipse, you may have to run this the goal system with
 * the Main.java window opened. If you have anything referring to an Applet open,
 *  Eclipse seems to start up in Applet mode causing everything to fail....
 *  
 *  Wouter 24mar09: seems that this is obsolete now. 
 *  SimpleIDE has been replacing this since long ago.
 */

package goal.tools;

import goal.core.agent.Agent;
import goal.core.env.blocksworld.BlocksWorldFrame;
import goal.core.env.wumpus.WumpusWorld;
import goal.tools.PlatformManager;
import goal.core.env.*;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Term;
import goal.core.kr.language.Var;
import goal.core.mentalstate.MentalState;
import goal.core.scheduler.*;
import goal.kr.language.swiprolog.SWIConstant;
import goal.kr.language.swiprolog.SWIPredicate;
import goal.kr.language.swiprolog.SWIVariable;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class Main {

	public static void main(String args[]) {
		try {
			Environment fEnv=null;
			Agent lAgent;
			String lFilename;
			
			System.out.println("\nStarting GOAL system...");
			// TODO: the following info COULD be put in a .mas file
			// and then loaded into the platform in one go.
			PlatformManager lGOALPlatform = new PlatformManager();
			
			/*****set configuration, also checking command line opts ******/
			lFilename=getOpt("f",args); // get filename, if available.
			
			if ((lFilename == null) || (!lFilename.endsWith(".mas"))) {
				lFilename="GOALagent/WumpusStuff/Wumpus.mas";
			}
			
			System.out.println("Loading "+lFilename);
			lGOALPlatform.loadMASfile(lFilename);

			ArrayList<Agent> lAllAgents=lGOALPlatform.getAgents();
					
			fEnv = new WumpusWorld();
			//fEnv = new BlocksWorldFrame(getInitialConfig(lAllAgents.get(0)));
			lGOALPlatform.setEnvironment(fEnv);

			Scheduler lScheduler = new WumpusScheduler(lAllAgents,fEnv);
			//Scheduler lScheduler = new BlocksWorldScheduler(lAllAgents,fEnv);
			lGOALPlatform.launchScheduler(lScheduler);

			// TODO Introspector has to be notified somehow if agent list changes.
			// currently we don't change the agent list.
			// TODO: Launch introspectors from platform manager only.
			// TODO: Obsolete: Introspector fIntrospector = new Introspector(lAllAgents,lGOALPlatform);

			lGOALPlatform.runMAS();
			if (fEnv!=null) { fEnv.close(); fEnv=null;}
			System.out.println("main loop FINISHED. GOAL quits now.");
			System.out.println("final statistics:");
			lAllAgents.get(0).showStatistics();
			System.out.println("\nTotalNrActions "+lScheduler.getTotalNumberOfActions());
			System.exit(0);
		} catch (Exception e) {
			System.out.println("Stopping with Failure: "+e);
			e.printStackTrace(); 
		}
	}

	/**
	 * Get option from command line,
	 * For instance if optname="f" we look for sequence "-f blabla" in the command line.
	 * blabla is then the value for option f.
	 * @return value for the option, or null if option not set.
	 */
	public static String getOpt(String optname,String args[]) {
		System.out.println("looking for option "+optname);
		for (int i=0; i<args.length-1; i+=2)
			if (args[i].equals("-"+optname)) return (args[i+1]);
		return null;
	}

	
	
	
	
}