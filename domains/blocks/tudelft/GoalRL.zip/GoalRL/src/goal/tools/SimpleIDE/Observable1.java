package goal.tools.SimpleIDE;

import java.util.Observable;

/**
 * @author W.Pasman
 * 
 * This class overrides the standard Observable in a trivial way:
 * only the setChanged is made public. 
 * 
 * You must call setChanged() otherwise notifyObservers will not do anything.
 * It's beyond me why the setChanged() is protected, that way other classes using an
 * observer can not set the required flag appropriately.....
 * */

public class Observable1 extends Observable {
	public void setChanged() { super.setChanged(); }
}
