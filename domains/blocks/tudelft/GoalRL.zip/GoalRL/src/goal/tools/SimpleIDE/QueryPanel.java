package goal.tools.SimpleIDE;

import goal.core.agent.Agent;
import goal.core.kr.language.Substitution;
import goal.core.mentalstate.MentalState;
import goal.core.program.MentalStateCond;
import goal.parser.GOALLexer;
import goal.parser.GOALParser;
import goal.parser.LinkedListTokenSource;
import goal.parser.LinkedListTokenStream;
import goal.tools.debugger.Debugger;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.StringReader;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JPanel;
//import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.antlr.runtime.ANTLRReaderStream;

/** @author W.Pasman
 * 4aug09: now using TextTrackingScrollPane to add clear button.
 */
class QueryPanel extends JPanel {
	JButton querybutton=new JButton("Query");
	JTextArea querytext=new JTextArea("Enter your query here");
	
	//JTextArea queryresulttext=new JTextArea("Query Results Appear here.");
	//JScrollPane queryresult=new JScrollPane(queryresulttext);
	TextTrackingScrollPane queryresult=new TextTrackingScrollPane("query results come here");
	JPanel querytop=new JPanel(); // query button and query input area

	Agent agent;
	
	/** @param  agt is Agent to contact in order to get the database and to handle queries.
	 * @param datatype is type of the database: BELIEFS, GOALS, MAILS or PERCEPTS */
	public QueryPanel(Agent agt) {
		//queryresulttext.setEditable(false);
		queryresult.setEditable(false);
		agent=agt;
		setLayout(new BorderLayout());
		
		querytext.addKeyListener(new java.awt.event.KeyAdapter() {
		    public void keyPressed(java.awt.event.KeyEvent evt) {
		        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
		        	 // check if query already complete.
		        	 // if so, do the query and consume the enter.
		        		evt.consume();
		        		doquery(); // TODO if query is expensive or even crashes, this locks up the IDE
		    }
		    } });
		
		
		querytop.setLayout(new BorderLayout());
		querytop.add(querybutton,BorderLayout.WEST);
		querytop.add(querytext,BorderLayout.CENTER);
				
		add(querytop,BorderLayout.NORTH);
		add(queryresult,BorderLayout.CENTER);
		
		querybutton.addActionListener(new ActionListener()
		{ public void actionPerformed(ActionEvent e) { doquery(); } }
		);
	}

	
	/** being called after you press the query button */
	public void doquery() {
		try {
			MentalState ms=agent.getMentalState();
			if (ms==null) throw new IllegalStateException("agent has not yet initialized its databases");
			MentalStateCond msq=parser(querytext.getText());
			Set<Substitution> result=ms.mscQuery(msq, new Debugger("beliefquery")); // use dummy debugger
			String resulttext="";
			if (result.isEmpty()) resulttext="No solutions";
			else { for (Substitution s: result) resulttext=resulttext+s+"\n"; }
			//queryresulttext.setText(resulttext);
			queryresult.setText(resulttext);
		}
		//catch (Exception e) { queryresulttext.setText("Query failed: "+e);}
		catch (Exception e) { queryresult.setText("Query failed: "+e);}
	}



	/** create an embedded GOAL parser that can parse the given string. */
	private GOALParser prepareGOALParser(String pString) {	
		GOALParser parser;
		try {
			ANTLRReaderStream charstream = new ANTLRReaderStream(new StringReader(pString));
			GOALLexer lLexer = new GOALLexer(charstream);
			lLexer.setSourceName(pString);
			LinkedListTokenSource linker = new LinkedListTokenSource(lLexer);
			LinkedListTokenStream tokenStream = new LinkedListTokenStream(linker);
			parser = new GOALParser(tokenStream);
			parser.initialize(pString);
			parser.setInput(lLexer, charstream,null); // no FileReader, we have stream from string.
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return parser;
	}
	
	/** @author W.Pasman.
	 * @throws exception if parse fails. 
	 * TODO seems to me that following functionality should be provided somewhere else...
	 * I now copied it from the IOManager  and made few modifications */
	public MentalStateCond parser(String mentalstatestring) throws Exception {
		GOALParser parser = prepareGOALParser(mentalstatestring);
		MentalStateCond msc=parser.mentalstatecond();
		String lError = parser.getFirstError();
		if (lError!=null) { 
			throw new Exception("Term "+mentalstatestring+" failed to parse as GOAL mental state condition:"+lError); // Do not print errors here; they have already been printed by parser.
		}
		return msc;
	}
	
}
