package goal.tools.SimpleIDE;

import goal.core.agent.Agent;
import goal.tools.MyDebugObserver;
import goal.tools.SimpleIDE.tab.CloseListener;
import goal.tools.SimpleIDE.tab.CloseTabbedPane;
import goal.tools.errorhandling.Warning;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.JPanel;

public class DebugPanel extends CloseTabbedPane implements LayoutChangeListener {
	
	// Class field
	IDEfunctionality myIDE;
	
	// Constructor
	public DebugPanel(IDEfunctionality theIDE) {
		myIDE = theIDE;
		
		addCloseListener(new CloseListener() {
			public void closeOperation(MouseEvent e, int TabIndex) {
				try {
					// CHECK: not sure if component that you close is actually selected,
					// otherwise we could just call ide.Close().
					Component c=getComponentAt(TabIndex);
					if (c instanceof IntrospectorPanel)
						myIDE.executeCommand(UserCmd.CLOSEINTROSPECTOR.toString(),((IntrospectorPanel)c).getAgentName());
					else
						myIDE.executeCommand(UserCmd.CLOSESNIFF.toString()); // if no introspector it must be the sniffer.
				}
				catch (Exception er) { new Warning("Close failed",er); }
			}
		});
	}

	
	public void SplitPositionChange(int newsplitposition, EventObject e) {
		if (IntrospectorPrefPanel.getCoupleQuerySize()) {
			
			for (int n=0; n<getComponentCount(); n++) {
				Component c=getComponent(n);
				if (c instanceof IntrospectorPanel) 
					((IntrospectorPanel)c).setDividerLocation(newsplitposition);
			}
		}
	}


	// Class methods
	// method shows introspectorpanel if available, otherwise creates one and shows it.
	public IntrospectorPanel showIntrospectorPanel(String agentName, MyDebugObserver debugObs) {
		IntrospectorPanel introspectorPanel;
		int index = indexOfTab(agentName);
		
		if (index==-1) { // create new introspector panel
			Agent lAgent = myIDE.getPlatformManager().getRegistry().getAgent(agentName);
			introspectorPanel = new IntrospectorPanel(lAgent, agentName, debugObs,this);
			//debugObs.setIntrospector(introspectorPanel); Wouter removed 27jul09, trac 696
			add(agentName, introspectorPanel);
		} else
			introspectorPanel = (IntrospectorPanel)getComponentAt(index);
		setSelectedComponent(introspectorPanel);
		return introspectorPanel;
	}

	/** just close the tab. Don't use unless you know what else has to be done.
	 * generally use the main ide Close or CloseProcess function. 
	 * 23apr09: now returns silently if no such introspector exists. */
	public void closeIntrospector(String pAgentName) throws Exception {
		int n=indexOfTab(pAgentName);
		if (n==-1) return; //no such tab. Silent return.
		IntrospectorPanel introspectorPanel = (IntrospectorPanel)getComponentAt(n);
		closeIntrospector(introspectorPanel);
	}
	
	public void closeIntrospector (IntrospectorPanel ip)  throws Exception {
		ip.Close();
		remove(ip);
	}

	public void addSnifferPanel(JPanel pSnifferPanel) {
		add("Sniffer", pSnifferPanel);
		setSelectedComponent(pSnifferPanel);
	}

	public void removeSnifferPanel(JPanel pSnifferPanel) {
		remove(pSnifferPanel);
	}
	
	/* Generic close command, closes the current tab.
	 * We have to re-route this apparently simple cal through the ide,
	 * because closing this tab may involve deleting the debug observer!
	 */
	public void Close() throws Exception { 
		Component c = getSelectedComponent();
		if (c == null) return;
		if (c instanceof IntrospectorPanel)
			myIDE.executeCommand(UserCmd.CLOSEINTROSPECTOR.toString(), ((IntrospectorPanel)c).getAgentName());
		else // if no introspector it must be the sniffer.
			myIDE.executeCommand(UserCmd.CLOSESNIFF.toString());
	}
	
	/** Close all debug panels and prepare for IDE shutdown */
	public void CloseAll() throws Exception {
		for (int i=0; i<getTabCount(); i++) {
			IntrospectorPanel ip = (IntrospectorPanel)getComponentAt(i);
			closeIntrospector(ip);
		}
	}
	
	public Component getCurrentPanel() {
		return getSelectedComponent();
	}
}
