package goal.tools.errorhandling;
import goal.tools.debugger.Debugger;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.prefs.Preferences;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class WarningPrefPanel extends JPanel implements ChangeListener 
{
	static Preferences myPreferences= Preferences.userNodeForPackage(WarningPrefPanel.class); // system wide store and better support than Properties()
	
	JCheckBox javadetails;
	JCheckBox stackdump;
	JSpinner spinner;
	
	public WarningPrefPanel() {
		javadetails=new JCheckBox("Add Java details to message");
		 stackdump=new JCheckBox("Add stackdump to messages");
		JPanel dblevelpanel=new JPanel(new BorderLayout());
		SpinnerNumberModel sm=new SpinnerNumberModel((int)Debugger.DEFAULT_LEVEL,1,50,1);
		dblevelpanel.add(new JLabel("Max. number of reporting the same error "),BorderLayout.CENTER);
		spinner=new JSpinner(sm);
		dblevelpanel.add(spinner,BorderLayout.WEST);

		init();
		setLayout(new GridLayout(0,1));
		add(new JLabel("Warning Message Settings"));
		add(javadetails); javadetails.addChangeListener(this);
		add(stackdump); stackdump.addChangeListener(this);
		add(dblevelpanel); spinner.addChangeListener(this);
	}
	
	/** copy settings from preferences to the check boxes */
	public void init() {
		javadetails.setSelected(myPreferences.getBoolean("javadetails",false)); // 2nd arg is the default value
		stackdump.setSelected(myPreferences.getBoolean("stackdump",false));
		spinner.setValue(myPreferences.getInt("suppresslevel", 2));
	}
	
	
	/** change most recent state */
	public void stateChanged(ChangeEvent e)  {
		
		myPreferences.putBoolean("javadetails", javadetails.isSelected());
		myPreferences.putBoolean("stackdump", stackdump.isSelected());
		myPreferences.putInt("suppresslevel", (Integer)spinner.getValue());
	}
	
	
}