package goal.tools.SimpleIDE;

import goal.tools.IOManager;
import goal.tools.SimpleIDE.tab.CloseListener;
import goal.tools.SimpleIDE.tab.CloseTabbedPane;
import goal.tools.errorhandling.Warning;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * @author W.Pasman 2008
 * EditPanel is the edit main area of the IDE, containing tabbed panes with active editors.
 */
class EditPanel extends JPanel {

	// Class fields
	JPanel thePanel;
	CloseTabbedPane fTabbedPane;
	IDEfunctionality myIDE;
	

	// Class constructor
	public EditPanel(IDEfunctionality theIDE) {
		myIDE=theIDE;
		setLayout(new BorderLayout());
	
		fTabbedPane = new CloseTabbedPane();
		fTabbedPane.addCloseListener(
			new CloseListener() {
				public void closeOperation(MouseEvent e, int overTabIndex) {
					try { 
						Close((TextEditorInterface)fTabbedPane.getComponentAt(overTabIndex));
						myIDE.setMenuItemsAndButtons();
					} catch (Exception ex) { new Warning ("Ignoring close of tab ",ex); }
				}
			}
		);
		add(fTabbedPane, BorderLayout.CENTER);
	}
	
	public void Save() throws Exception {
		getActiveEditor().Save();
		System.out.println("File saved.");
	}
	
	/** 
	 * assumes that confirmation for overwrite was already given if the file already exists
	 * */
	public void SaveAs(String pFilename) throws Exception {
		getActiveEditor().SaveAs(pFilename);
		 // change tab name to new name.
		fTabbedPane.setTitleAt(fTabbedPane.getSelectedIndex(), IOManager.shortName(pFilename));
		 // and change name in files panel.
		 // check multiple occurences, ask user if so.
		
		 // and show warning that user still has to edit the mas files.
		JOptionPane.showMessageDialog(this,"Remember that you have to edit\n" +
				" the MAS file manually\n" +
				"to match your new filename");
	}
	
	public void SaveAll() throws Exception {
		for (int i=0; i<fTabbedPane.getTabCount(); i++)
			((TextEditorInterface)fTabbedPane.getComponentAt(i)).Save();
		System.out.println("All files saved.");
	}

	boolean isDirty() {
		boolean dirty=false;
		for (int i=0; i<fTabbedPane.getTabCount(); i++) {
			 dirty=dirty | ((TextEditorInterface)fTabbedPane.getComponentAt(i)).isDirty();
		}
		return dirty;
	}
	
	/** will do nothing if given node not open in edit panel */
	public void Close(FileNode node) throws Exception { // editor for corresponding node is open, close it
		TextEditorInterface editor=getEditor(node);
		if (editor!=null) Close(getEditor(node));
		
		// Wouter: replaced 15apr09 with simpler version.
		//for (int i=0; i<fTabbedPane.getTabCount(); i++) {
		//	TextEditorInterface editor = ((TextEditorInterface)fTabbedPane.getComponentAt(i));
		//	
		//	if (fTabbedPane.getTitleAt(i).equals(node.getName()))
		//		Close(editor);
		//}
	}
	
	public void Close(TextEditorInterface editor) throws Exception {
		// we do not need to remove the observer (statusbar) as 
		// the observable will be removed when this object disappears.
		editor.Close();
		fTabbedPane.remove(editor);
	}
	
	public void Close() throws Exception {
		Close(getActiveEditor());
	}
	
	public void CloseAll() throws Exception {
		while (fTabbedPane.getTabCount()>0) {
			TextEditorInterface editor = ((TextEditorInterface)fTabbedPane.getComponentAt(0));
			fTabbedPane.setSelectedComponent(editor);
			Close(editor);
		}
	}

	public void Print() throws Exception {
		getActiveEditor().Print();
	}
	
	public void PageSetup() throws Exception {
		getActiveEditor().PageSetup();
	}

	/**
	 * 18jun08: 
	 * file dialog now part of SimpleIDE root. This just opens new tab with given name.
	 *	Opens a new tab in the editor, with last part of given filename.
	 *	@param filename=full path to file (should not be null), with '/' as separators. 
	 */
	public void editFile(String pFilename) {
		// check if already being edited.
		TextEditorInterface editor=getEditorPane(pFilename);
		if (editor!=null) {
			fTabbedPane.setSelectedComponent(editor);
			return;
		}
		try { // not open, open new editor.
			TextEditorInterface newEditor = new jEditTextEditor(pFilename); // TODO: should not (re)load file...
			fTabbedPane.add(IOManager.shortName(pFilename), newEditor);
			fTabbedPane.setSelectedComponent(newEditor);
			//connect the status bar
			newEditor.getObservable().addObserver(myIDE.getStatusBar());
		} catch (Exception e) {
			new Warning("Problem opening file '"+pFilename,e); 
		}
	}
	

	
	/** @return TextEditorInterface holding editor for given file, or null if no such editor */
	TextEditorInterface getEditorPane(String filename) {
		// check if already being edited.
		for (int i=0; i<fTabbedPane.getTabCount(); i++) {
			TextEditorInterface c=(TextEditorInterface)(fTabbedPane.getComponentAt(i));
			if (filename.equals(c.getFilename())) return c;
		}
		return null;
	}
	
	
	
	public void Undo() throws Exception { getActiveEditor().Undo(); }
	public void Redo() throws Exception  { getActiveEditor().Redo(); }
	public void Cut() throws Exception  { getActiveEditor().Cut(); }
	public void Copy() throws Exception  { getActiveEditor().Copy(); }
	public void Paste() throws Exception  { getActiveEditor().Paste(); }
	public void Find() throws Exception { getActiveEditor().SearchReplace(); }
	public void FindNext() throws Exception { getActiveEditor().SearchNext(); }
	public void GoToLine() throws Exception { 
		 /** see also org.gjt.sp.jedit.GUIUtilities.input and  org.gjt.sp.jedit.textarea.JEditTextArea. */
		String line = (String)JOptionPane.showInputDialog(this,
				"Line", "Go To Line",
				JOptionPane.QUESTION_MESSAGE);
		if(line == null) return;
		int lineNumber = Integer.parseInt(line) - 1;
		getActiveEditor().GoToLine(lineNumber); 
	}
	public void CompleteWord() throws Exception { getActiveEditor().AutoComplete(); }

	public TextEditorInterface getActiveEditor() {
		return (TextEditorInterface)fTabbedPane.getSelectedComponent();
	}
	
	/**@return TextEditorInterface for given node, or null if no editor open for that filenode */
	public TextEditorInterface getEditor(FileNode node) {
		for (int i=0; i<fTabbedPane.getTabCount(); i++) {
			TextEditorInterface editor = ((TextEditorInterface)fTabbedPane.getComponentAt(i));
			
			if (fTabbedPane.getTitleAt(i).equals(node.getName())) return editor;
		}
		return null;
	}
	
}



