package goal.tools.SimpleIDE;

import goal.tools.FileOrProcessNode;
import goal.tools.IDEfunctionality;
import goal.tools.errorhandling.Warning;

import java.awt.Component;
import java.awt.Container;

import javax.swing.JTree;
import javax.swing.Timer;
import javax.swing.tree.DefaultTreeCellEditor;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

// OBSOLETE Myrenderer does all the work. Editing nodes set to false for now.

/*
 * From DefaultTreeCellEditor:
 * Editing is started on a triple mouse click, or after a click, pause, click and a delay of 1200 miliseconds.
 * From http://www.javafaq.nu/java-books28.html:
 * 17.1.16            DefaultTreeCellEditor
 * class javax.swing.tree.DefaultTreeCellEditor
 * 
 * DefaultTreeCellEditor extends DefaultCellEditor, and is the default concrete implementation of the TreeCellEditor
 * interface. It uses a JTextField for editing a node's data (an instance of DefaultTreeCellEditor.DefaultTextField).
 * stopCellEditing() is called when ENTER is pressed in this text field.
 * An instance of DefaultTreeCellRenderer is needed to construct this editor, allowing renderer icons to remain
 * visible while editing (accomplished by embedding the editor in an instance of
 * DefaultTreeCellEditor.EditorContainer), and fires ChangeEvents when editing begins and ends. As expected, we can
 * add CellEditorListeners to intercept and process these events.
 * By default, editing starts (if it is enabled) when a cell is triple-clicked or a pause of 1200ms occurs between
 * two single mouse clicks (the latter is accomplished using an internal Timer). We can set the click count
 * requirement using the setClickCountToStart() method, or check for it directly by overriding isCellEditable().
 */

public class MyEditor extends DefaultTreeCellEditor {
	TreeCellRenderer therenderer;
	IDEfunctionality ide;
	
	public MyEditor(JTree tree, DefaultTreeCellRenderer renderer, IDEfunctionality theide) {
		super(tree,renderer,null); 
		ide=theide;
	}
	
	public Component getTreeCellEditorComponent(JTree tree, Object value,
		  boolean isSelected, boolean expanded, boolean leaf, int row) 
	{
		// Wouter: we return the normal tree render component instead of the
		// editor component. User cannot edit in the normal way and
		// the editor component will be shown elsewhere if necessary.
		//System.out.println("editor activated. object="+tree+","+lastPath+","+row);
		
		Open((FileNode)tree.getLastSelectedPathComponent());
		Component c=renderer.getTreeCellRendererComponent(tree,value,
			isSelected,expanded,leaf,row,true);
		((Container)c).removeAll();
		return c;
		//return new Container(); // do not re-render anything for editor.
	}	
	
	/** override startEditingTimer for faster doubleclick response. */
	protected void startEditingTimer() {
      if(timer == null) {
        timer = new Timer(200, this);
        timer.setRepeats(false);
      }
	timer.start();
	}
	
	public void Open(FileNode n) {
		try {
			switch (n.getType()) {
			case FileNode.GOALFILE:
			case FileNode.MASFILE:
			case FileNode.UNKNOWNFILE:
				ide.inspectFile((String)n.getFilename());
				break;
			case FileNode.GOALPROCESS:
				ide.inspectProcess((String)n.getFilename());
				break;
			default:
				System.out.println("can not open node of type "+n.getType());
			}
		}
		catch (Exception e) { new Warning("open failed:",e); }
	}
}
