package goal.tools.SimpleIDE;

import java.awt.BorderLayout;
import java.awt.Font;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class ConsoleTextPanel extends JPanel {
	TextTrackingScrollPane consoleoutput = new TextTrackingScrollPane("GOAL IDE GUI V1...\n");
	static final boolean REROUTE_CONSOLE_OUTPUT=IDEPrefPanel.getRememberRerouteConsole();

	public ConsoleTextPanel() {
		setLayout(new BorderLayout());
		// TODO set max number of rows, to prevent memory problems
		//consoletext.setRows(400);
		consoleoutput.setFont(new Font("Arial Narrow", Font.PLAIN, 12));
		
		 // no buttons, they look ugly and take way too much space.
		//JPanel ConsoleButtons=new JPanel(new FlowLayout());
		//ConsoleButtons.add(new JButton("clear console"));
		//add(ConsoleButtons,BorderLayout.NORTH);
		
		add(consoleoutput,BorderLayout.CENTER);
		        
				
		// re-route stdio and stderr
		if (REROUTE_CONSOLE_OUTPUT) {
			//PrintStream out=new PrintStream(new TextAreaOutputStream(consoleoutput.getTextArea(),consoleoutput.getVerticalScrollBar()));
			// added 'synchronized', 9apr9, attempting to solve mantis 533
			// that did not work. ... fixed with MyOutputStream that does not need synchronized
			PrintStream out=new PrintStream( new MyOutputStream(consoleoutput) );
			
			System.setOut(out);
			System.setErr(out);
		}
	}
	
	/*
	ImageIcon getIcon(String iconName) {
		return new ImageIcon(getClass().getClassLoader().getResource("goal/tools/SimpleIDE/icons/"+iconName));
	}
	 */
}


class MyOutputStream extends OutputStream {
	TextTrackingScrollPane consoleoutput;
	
	public MyOutputStream(TextTrackingScrollPane output) {
		consoleoutput=output;
	}
	
	static String linecache=""; // maybe messy if two threads print parallel. 

	public void write( int b ) throws IOException {
		linecache=linecache.concat(String.valueOf((char)b));
		if (b==10) { // newline, flush cache
			SwingUtilities.invokeLater(new Runnable() {
				private String toprint=new String(linecache);
				public void run() {
					consoleoutput.append( toprint );
				}
			});
			linecache="";
		}
	}
};
