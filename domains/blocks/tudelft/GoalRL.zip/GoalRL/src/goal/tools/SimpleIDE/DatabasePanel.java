package goal.tools.SimpleIDE;

import goal.core.agent.Agent;
import goal.core.mentalstate.BeliefBase;
import goal.core.mentalstate.GoalBase;
import goal.core.mentalstate.MentalState;
import goal.tools.errorhandling.Warning;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;


/**
 * Database panel including a query panel
 * remember to call Close() to stop internal timers after you're done with this panel.
 * This panel will directly call to the Agent for listings and queries.
 * @author W.Pasman
 */

class DatabasePanel extends JPanel implements ActionListener { //PropertyChangeListener removed - spit removed - trac 652
	// type of the database
	final static int BELIEFS=1;
	final static int GOALS=2;
	final static int MAILS=3;
	final static int PERCEPTS=4;
	final static int KNOWLEDGE=5;
	
	final static int REFRESH_PERIOD = 1000;
	
	Agent agent;
	int type;
	
	//LayoutChangeListener layoutlistener; // only one, maybe extend later.
	// removed 29jul09 trac 652 no split here anymore.
	
	JTextArea databasetext;
	JScrollPane databaseoutput;
	Timer refreshtimer = null;
	
	/** 
	 * @author W.Pasman
	 * @param  agt is Agent to contact in order to get the database and to handle queries.
	 * @param datatype is type of the database: BELIEFS, GOALS, MAILS or PERCEPTS 
	 * @param splitlistener is a class that listens to changes of the split position of
	 * @param autorefresh -- set to true to make panel refresh its contents
	 * @param initialtext is the intial text for the panel.
	 * the query area */
	public DatabasePanel(Agent agt, int datatype, boolean autorefresh, String initialtext) {
		agent=agt;
		type=datatype;
		setLayout(new BorderLayout());
		databasetext=new JTextArea(initialtext);
		databaseoutput=new JScrollPane(databasetext);
		

		databasetext.setEditable(false); // For now, set editable to false. NICETOHAVE: IDE in which this content can be edited as in e.g. eClipse.
		databasetext.setBackground(Color.white); // NICETOHAVE: This feature one day should be configurable :-)
		databasetext.setFont(new Font("Courier", Font.PLAIN, 12)); // NICETOHAVE: Add 'keyword/operator' highlighting 

		add(databaseoutput,BorderLayout.CENTER);

		if (autorefresh) {
			// set up timer for database-view refresh
			refreshtimer = new Timer(REFRESH_PERIOD,this) ;
			refreshtimer.setCoalesce(true); // if GUI can't keep up, reduce refresh events.
			refreshtimer.start();
		}
	}
	
	/** this is now called when the refresh timer goes off. See 
	 * http://java.sun.com/products/jfc/tsc/articles/threads/threads1.html
	 */
	public void actionPerformed(ActionEvent e) {
		refreshPanel();
	}
	
	/* removed trac 652 split removed from databasepanel.
	public void propertyChange(PropertyChangeEvent e) {
		layoutlistener.SplitPositionChange(splitpane.getDividerLocation(), e);
	}
	*/
	
	/*
	public void setDividerLocation(int splitpos) {
		if (splitpane.getDividerLocation()!=splitpos) { // prevent infinite recursion
			splitpane.setDividerLocation(splitpos);
		}
	}
	*/
	
	void Close() {
		//if (type==BELIEFS) {
		//	IntrospectorPrefPanel.myPreferences.putInt("querysize", splitpane.getDividerLocation());
		//}
		if (refreshtimer!=null) {
			refreshtimer.stop(); 
			refreshtimer=null; 
		}
	}


	
	/** Wouter jan09: NOTE this is really nasty code, we really should not be manipulating 
	 * Agent code from here.
	 * First, this is another thread, we risk thread safety issues (ConcurrentModificationExceptions)
	 * Second, IMHO accesss to agent private code should not be possible anyway
	 * Third, if this is executed in a timer thread instead of SWING we have multippe threads in the GUI,
	 * which is bad practice (http://java.sun.com/products/jfc/tsc/articles/threads/threads1.html)
	 */
	 
	void refreshPanel() {
		try {
			String text = new String();
			MentalState mentalstate = agent.getMentalState();
			if (mentalstate==null) return; // MS not yet initialized by agent.
			switch (type) {
			case BELIEFS:
				//refreshBeliefPanel(mentalstate);
				ArrayList<BeliefBase> beliefbases = mentalstate.getBeliefBase();
				// TODO: exclude mailbox/perceptbases.
				//for (BeliefBase beliefbase: beliefbases)
				//	text=text+beliefbase.getTheory();
				text=text+beliefbases.get(0).getTheory();
				/* ENABLE FOLLOWING TO ALSO GET VIEW OF REAL PROLOG DATABASE
				text=text+"\n----------------------\n";
				Formula[] forms=beliefbases.get(0).getLanguage().getInferenceEngine().getAllSentences(beliefbases.get(0).getDatabase());				
				for (int i=0; i<forms.length; i++) text=text+forms[i]+"\n";
				*/
				//mentalstate.getBeliefBase().get(0).getDatabase().showStatistics(); //DEBUG
				break;
			case GOALS:
				//refreshGoalPanel(mentalstate);
				ArrayList<GoalBase> goalbases = mentalstate.getGoalBase();
				for (GoalBase goalbase: goalbases)
					text=text+goalbase.getTheory().toStringSingleLine();
				break;
			case MAILS:
				//refreshMailPanel(mentalstate);
				text = mentalstate.getMailbox().getTheory().toString();
				break;
			case PERCEPTS:
				//refreshPerceptPanel(mentalstate);
				text = mentalstate.getPerceptBase().getTheory().toString();
				break;
			default: throw new Exception("unknown panel type "+type);
			}
			// WORKAROUND: refresh only if something really changed, to avoid flashing of panel text on Windows
			// TODO: create listeners instead.
			if (!databasetext.getText().equals(text))
				databasetext.setText(text);
		} catch (Exception e) { new Warning("AWT Refresh of panel delayed:",e); }
	}
	
}



