
/** 
 * IDEfunctionality describes functions that empower user's actions.
 * There need not be a 1-1 mapping of provided user menus/buttons and the 
 * functions provided here.
 * 
 * Several "external" (subpanel) programs call on the IDE,
 * For instance, the IDE has to open a file when you click on it in the FenPPanel.
 * Also a lot of functionality can be reached in multiple ways, eg via button, double clicking and menu
 * 
 * This interface lists all PUBLIC methods that need to be available in classes that are part of the IDE.
 */

package goal.tools.SimpleIDE;

import java.util.Observer;

import goal.tools.PlatformManager;

public interface IDEfunctionality {

	public PlatformManager getPlatformManager();
		
	 /** @returns selected file/process node, or null if nothing selected. */
	public IDENode getSelectedNode();
	public boolean debugViewEmpty();
	
	/** force refresh of menus and buttons */
 	public void setMenuItemsAndButtons();
	
 	/** Executes commands, mainly upon user request, e.g. by means of MENU, TOOLBAR, or double-clicking file/process tree.
 	 See enum type UserCmd for overview available commands. */
 	public void executeCommand(String pCommand);
 	 /** executeCommand with a parameter */
 	public void executeCommand(String pCommand, String parameter);
 	
 	/** @returns true if command enabled, false if not */
 	public boolean isEnabled(String Command);

 	/** @returns the status bar. See StatusBar.java */
 	public Observer getStatusBar();
}