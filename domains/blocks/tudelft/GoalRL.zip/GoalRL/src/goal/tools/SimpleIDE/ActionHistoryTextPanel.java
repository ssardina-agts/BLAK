package goal.tools.SimpleIDE;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JPanel;

public class ActionHistoryTextPanel extends JPanel {
	TextTrackingScrollPane consoleoutput = new TextTrackingScrollPane("Actions\n");
			
	public ActionHistoryTextPanel() {
		setLayout(new BorderLayout());
		// TODO set max number of rows, to prevent memory problems
		//consoletext.setRows(400);
		consoleoutput.setFont(new Font("Arial Narrow", Font.PLAIN, 12));

		add(consoleoutput,BorderLayout.CENTER);
		        		
	}

}
