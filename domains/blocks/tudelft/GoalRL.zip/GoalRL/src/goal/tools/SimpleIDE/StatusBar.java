package goal.tools.SimpleIDE;

import java.util.Observable;
import java.util.Observer;

import javax.swing.JTextArea;

/*
 * @author W.Pasman 8apr09
 * 
 * StatusBar is the row of text in the complete bottom of the IDE.
 * It is an Observer and hence should be subscribed with an Observable.
 * The observable should update us with text messages that are then shown in the bar.
 */

public class StatusBar extends JTextArea implements Observer {
	public StatusBar() {
		setEditable(false);
		setText("Status bar.");
	}
	
	/**
	 * The observable will call this. It should send only string object.
	 * When multiple observables are to be coupled to the status bar,
	 * this status bar might try to show them in a number of columns, one for each
	 * observable that is reporting to the status bar.
	 */
	public void update(Observable obs, Object o) {
		if (!(o instanceof String))
			throw new RuntimeException("Statusbar update only allowed with String objects");
		setText((String)o);
	}
}
