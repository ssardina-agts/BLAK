package goal.tools.SimpleIDE;

/**
*
* W.Pasman: took this code from internet.
* almost trivial, I dont think we need further permission
*
*/

import java.awt.event.AdjustmentListener;
import java.io.IOException;
import java.io.OutputStream;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import java.awt.event.AdjustmentEvent;
/**
* An output stream that writes its output to a javax.swing.JTextArea
* control.
*
* @author  W.Pasman
* @deprecated 3sept08 W.Pasman, added the minimal remaining functionality to the ConsoleTextPamel
*/
public class TextAreaOutputStream extends OutputStream {
    private JTextArea textControl;
    
    /**
     * Creates a new instance of TextAreaOutputStream which writes
     * to the specified instance of javax.swing.JTextArea control.
     *
     * @param control   A reference to the javax.swing.JTextArea
     *                  control to which the output must be redirected
     *                  to.
     */
    public TextAreaOutputStream( JTextArea control ) {
        textControl = control; 
 
        */
    }
    
    /**
     * Writes the specified byte as a character to the
     * javax.swing.JTextArea.
     *
     * @param   b   The byte to be written as character to the
     *              JTextArea.
     */
    public void write( int b ) throws IOException {
        // append the data as characters to the JTextArea control
        textControl.append( String.valueOf( ( char )b ) );
        
    }  
}