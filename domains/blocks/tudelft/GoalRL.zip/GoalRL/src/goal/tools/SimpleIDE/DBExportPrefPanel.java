package goal.tools.SimpleIDE;

import java.awt.GridLayout;
import java.awt.Insets;
import java.util.prefs.Preferences;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DBExportPrefPanel extends JPanel implements ChangeListener 
{
	static Preferences myPreferences= Preferences.userNodeForPackage(DBExportPrefPanel.class); // system wide store and better support than Properties()
	
	JCheckBox exportbeliefs;
	JCheckBox exportgoals;
	JRadioButton separatefiles;
	JCheckBox openaftersave;
	
	public DBExportPrefPanel() {
		exportbeliefs=new JCheckBox("Export Beliefbase");
		exportgoals=new JCheckBox("Export Goalbase");
		separatefiles=new JRadioButton("Export to separate files");
		separatefiles.setMargin(new Insets(0,30,0,0)); // make the button indent a bit
		openaftersave=new JCheckBox("Open after save");

		init();
		setLayout(new GridLayout(0,1));
		add(new JLabel("Database Export Options"));
		add(exportbeliefs); exportbeliefs.addChangeListener(this);
		add(exportgoals); exportgoals.addChangeListener(this);
		add(separatefiles); separatefiles.addChangeListener(this);
		add(new JSeparator());
		add(openaftersave); openaftersave.addChangeListener(this);
	}
	
	/** copy settings from preferences to the check boxes */
	public void init() {
		exportbeliefs.setSelected(getExportBeliefs()); // 2nd arg is the default value
		exportgoals.setSelected(getExportGoals());
		separatefiles.setSelected(getExportSeparateFiles());
		openaftersave.setSelected(getOpenAfterSave());
		
		separatefiles.setEnabled(exportbeliefs.isSelected() && exportgoals.isSelected() );
	}
	
	
	/** change most recent state */
	public void stateChanged(ChangeEvent e)  {
		myPreferences.putBoolean("exportbeliefs", exportbeliefs.isSelected());
		myPreferences.putBoolean("exportgoals", exportgoals.isSelected());
		myPreferences.putBoolean("separatefiles", separatefiles.isSelected());
		myPreferences.putBoolean("openaftersave", openaftersave.isSelected());
		
		separatefiles.setEnabled(exportbeliefs.isSelected() && exportgoals.isSelected() );
	}
	
	static boolean getExportBeliefs() {
		return myPreferences.getBoolean("exportbeliefs",true);  
	}

	static boolean getExportGoals() {
		return myPreferences.getBoolean("exportgoals",true);  
	}
	
	static boolean getExportSeparateFiles() {
		return myPreferences.getBoolean("separatefiles",true);  
	}
		
	
	static boolean getOpenAfterSave() {
		return myPreferences.getBoolean("openaftersave",false);
	}

}