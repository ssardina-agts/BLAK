package goal.tools;

import goal.tools.SimpleIDE.IntrospectorPanel;
import goal.tools.SimpleIDE.ProcessPanel;
import goal.tools.debugger.*;


// CHECK Class doesn't do more than connecting debuggers with introspectorpanels, right?
// Yes it reroutes the relevant info but it also couples agentName to observer.

/** This class collects info around my debug observers.
 * YOU still need to subscribe and unsubscribe it with the relevant debugger !!*/

public abstract class MyDebugObserver implements DebugObserver {
	
	// Class fields
	private String agentName;
	private Debugger debugger; 
	//private IntrospectorPanel introspectorPanel = null;
	//private ProcessPanel processPanel=null;

	// Constructor
	public MyDebugObserver(String pAgentName, Debugger pDebugger) {
		agentName = pAgentName; 
		debugger = pDebugger;
	}

	// Class methods
	public String getAgentName() {
		return agentName;
	}

	 // you need to talk with debugger to e.g. step and change debug levels.
	public Debugger getDebugger() {
		return debugger;
	}


	/*
	/** update is called whenever the debugger changed, eg when someone called step or when agent passed a bp 
	public void update(DebugInfo pInfo) {
		if (processPanel!=null)
			processPanel.update(pInfo);
	}

	
	public void setProcessPanel(ProcessPanel panel) {
		processPanel = panel;
	}
	
	public ProcessPanel getProcessPanel() {
		return processPanel;
	}
	*/
}
