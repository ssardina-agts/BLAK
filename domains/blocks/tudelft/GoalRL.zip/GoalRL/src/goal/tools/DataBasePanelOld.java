package goal.tools;

import java.awt.*;
import java.awt.event.*;

import goal.core.kr.language.*;
import goal.core.kr.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Timer;

import goal.core.kr.KRlanguage;
import java.util.Set;

import jpl.Query;
import goal.core.kr.Database;

import java.util.Timer;
import java.util.TimerTask;

import goal.tools.errorhandling.Warning;
import goal.core.agent.Agent;

/**
 * 
 * @author Wouter Pasman
 * Modified 12-3-2008: Koen Hindriks, Details of layout.
 * Modified 13..17-3-2008: W.Pasman numerous details of layout
 * 
*/


class DataBasePanelOld extends Panel {
	
	// Class fields
	//private Scrollbar hbar;
    //private Scrollbar vbar;
	private TextArea metatext;
	private TextArea fDBText;

	TextArea queryarea;
	Button querybutton;
	TextArea queryresultarea;
	Panel querypanel;
	public Choice fDBChoice;

	ArrayList<Database> databases;
	

	public DataBasePanelOld() {

		//databases=dbs;

		setLayout(new BorderLayout());
		fDBChoice = new Choice();
		// dont know the contents yet but have to add the combobox now.
		//for (Database lDB: fDataBases)	fDBChoice.add(lDB.getName());
		fDBChoice.addItemListener(new ItemListener() 
		{
			public void itemStateChanged   (ItemEvent e){	makePanel(); } 
			public Object getItem(int index) { 	return databases.get(index).getName(); } 
			public int getItemCount()	{ return databases.size();}
		} 
		
		);
		add("North",fDBChoice);
		
		fDBText = new TextArea("Database Contents",6,40);
		add("Center",fDBText);

		metatext = new TextArea("meta info about database",2,40);
		//add("South",metatext);
		
		querypanel=MakeQueryPanel();
		add("South",querypanel);	
		


		//dbUpdate();
    }

	public void setDatabases(ArrayList<Database> pDbs) {
		databases=pDbs;
		
		fDBChoice.removeAll();
		for (Database lDb: databases)
			fDBChoice.add(lDb.getName());
		
		fDBChoice.select(0);
		dbUpdate();	// refresh the window to show the contents.
	}

	public Panel MakeQueryPanel() {
		Panel panel=new Panel(new BorderLayout());
				
		queryarea=new TextArea("Enter_your_query_here",2,50);
		queryarea.setEditable(true);
		panel.add("Center",queryarea);
		
		querybutton = new Button("Query");
		querybutton.setFont(new Font("SansSerif", Font.BOLD, 12));
		querybutton.addActionListener(new ActionListener() 
			{ public void   actionPerformed(ActionEvent e)	{  doQuery(); } }
		);
		panel.add("East",querybutton);

		queryresultarea=new TextArea("Query Results Appear here.",4,55);
		panel.add("South",queryresultarea);
		return panel;
	}

	/** dbUpdate has to be called if a database change occurred */
	public boolean dbUpdate() {
		return makePanel();
	}

	/** load panel contents.
	 	returns true if update went OK, false if database seems obsolete (is empty) */
	private boolean makePanel() {
		int pIndex=fDBChoice.getSelectedIndex();
		if (pIndex==-1)
			metatext.setText("Please select a database.");
		else {
			String lText = new String();
			Formula[] lFormulas = null;

			try {
				Database lSelectedDB = databases.get(pIndex);
				KRlanguage lLangue = lSelectedDB.getLanguage();
				lFormulas = lLangue.getInferenceEngine().getAllSentences(lSelectedDB);
			} catch (Exception e) { lText="Retrieval of database content failed:"+e.getMessage(); }

			if (lText.equals("")) {
				for (Formula lForm: lFormulas)
					lText=lText+lForm+".\n";
			}
			
			if (!fDBText.getText().equals(lText))
			{
				//System.out.println("refreshing panel");
				
				fDBText.setText(lText);
				fDBText.setEditable(false); // For now, set editable to false. NICETOHAVE: IDE in which this content can be edited as in e.g. eClipse.
				fDBText.setBackground(Color.white); // NICETOHAVE: This feature one day should be configurable :-)
				fDBText.setFont(new Font("Courier", Font.PLAIN, 12)); // NICETOHAVE: Add 'keyword/operator' highlighting 
				//metatext.setText("Language: "+lLangue);
			}
			
			return !lText.equals("");
		}
		return true;
	}

	private void doQuery() {
		try	{
			queryresultarea.setText("**querying... please wait**");
			//int pIndex=fDBChoice.getSelectedIndex();
			// Wouter This is how this was supposed to be done....
			// Unfortunately there is a bug in foreignframe preventing us from doing it like this. 
			//Set<Substitution> result=fDataBases.get(pIndex).getLanguage().getInferenceEngine().rawquery("aap");
			String database = fDBChoice.getSelectedItem();

			// Wouter: THIS IS BAD.. DOING STRAIGHT PROLOG QUERY
			// also note, dirty hacks with true,... in order to cope with "not(X)",
			// which at head would give existence errors when sent through JPL.....
			
			String querytext = queryarea.getText();
			// HACK
			if (!querytext.endsWith(".")) {
				queryresultarea.setText("Query has to end with '.'");
				return;
			}
			querytext=querytext.substring(0, querytext.length()-1);
			Query query = new Query("true,"+database+":("+querytext+")");
			//Query query = new Query(queryarea.getText());
			Hashtable[] result = query.allSolutions();
			String text="";
			//for (Substitution s:result) text=text+s+"\n";
			if (result.length==0)
				text="Could not find any solutions.";
			else
				for (int n=0; n<result.length; n++) {
					//try { text=text+convert_lists_in_result(""+result[n])+ " >>"+result[n]+"\n"; }
					//catch (Exception e)
					//{ text=text+result[n]+" **"+e.getMessage()+"\n"; }
					text=text+result[n]+"\n";
				}
			queryresultarea.setText(text);
		} catch (Exception e) {queryresultarea.setText("Query failed: "+e);}
		dbUpdate();
	}

	public boolean action(Event evt, Object what) {
		//System.out.println("Database panel received action"+evt+what);
		makePanel();
		//if ("Query".equals(what)) { doQuery(); return true;}
		//return super.handleEvent(evt);
		return true;
	}
}
