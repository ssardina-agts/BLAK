package goal.tools.debugger;

/**
 * This is the "call-back" part of the debugger.
 * You can only perceive debug events with this observer.
 * Make direct calls to the debugger to control the debugger.
 * implement your own observer if you need one or override DefaultDebugObserver.
 * 
 * @author W.Pasman
 * @version 17jun08
 * @modified 20jun08: DebugObserver now is a pure interface
 * 
 */

public interface DebugObserver {
	 /** give this observer a unique name.
	  * This name is used also internally to compare DebugObservers! 
	  * duuh interfaces can not have constructors. Nevertheless this is what we want: */
	//public DebugObserver(String observername, Debugger dbg);
	
	/** This is called whenever a debug event of given level occurs. 
	IMPORTANT: this call is made by the thread that is being debugged.
	Make sure that you return immediately, not blocking on anything.
	If you want to block or step, that is done by calling Debugger.step() etc.
	*/
	public void update(DebugInfo info);
	
	public Debugger getDebugger();// {return theDebugger; }
}
