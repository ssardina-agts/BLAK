package goal.tools.SimpleIDE;

import goal.tools.IDEfunctionality;
import goal.tools.IntrospectorPanel;
import goal.tools.debugger.DebugObserver;
import goal.tools.errorhandling.Warning;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;


// Class is OBSOLETE

public class EditDebugTabPanel extends JPanel {
	
	// Class fields
	IDEfunctionality myIDE;
	
	public JTabbedPane fTabbedPane;
	public DebugPanel debugPanel;
	public EditPanel editPanel;
	public JPanel wrappingDebugPanel;

	boolean FixTabOrientation = !System.getProperty("os.name").toLowerCase().startsWith("mac");
	
	// Constructor
	public EditDebugTabPanel(IDEfunctionality theIDE) {
		myIDE = theIDE;
		
		//System.out.println("fixing tabs::"+FixTabOrientation);
		setLayout(new BorderLayout());
		fTabbedPane = new JTabbedPane();
		fTabbedPane.setTabPlacement(JTabbedPane.LEFT);
		
		// Runtime panel
		wrappingDebugPanel = new JPanel(new BorderLayout());
		wrappingDebugPanel.add(debugPanel = new DebugPanel(myIDE), BorderLayout.CENTER);

		// Edit panel
		editPanel = new EditPanel();
		
		if (FixTabOrientation) {
			// DOC: Windows and Linux cannot rotate tabs. So, we do it ourselves.
			fTabbedPane.addTab(null,
				new VerticalTextIcon("Debug",false), wrappingDebugPanel);
			fTabbedPane.addTab(null,new VerticalTextIcon("Edit",false),editPanel);
		} else {
			fTabbedPane.add("Runtime", wrappingDebugPanel);
			fTabbedPane.add("Edit", editPanel);
		}
		
		add(fTabbedPane, BorderLayout.CENTER);
	}
	
// Editor Panel methods
	public void SaveFile() throws Exception {
		CheckEditorIsActive();
		editPanel.Save();
	}
	
	public void SaveAs(String filename) throws Exception {
		CheckEditorIsActive();
		editPanel.SaveAs(filename);
	}

	public void SaveAll() throws Exception {
		editPanel.SaveAll();
	}
	
	public void OpenFile(String filename) {
		fTabbedPane.setSelectedComponent(editPanel);
		editPanel.editFile(filename);
	}
	
	public void Undo() throws Exception {
		CheckEditorIsActive();
		editPanel.Undo();
	}

	public void Redo() throws Exception {
		CheckEditorIsActive();
		editPanel.Redo();
	}

	public void Cut() throws Exception {
		CheckEditorIsActive();
		editPanel.Cut();
	}

	public void Copy() throws Exception {
		CheckEditorIsActive();
		editPanel.Copy();
	}

	public void Paste() throws Exception {
		CheckEditorIsActive();
		editPanel.Paste();
	}

// Debug Panel methods
	public IntrospectorPanel OpenProcess(String pAgentName, DebugObserver pDebugObs) throws Exception {
		fTabbedPane.setSelectedComponent(wrappingDebugPanel); 
		return debugPanel.showIntrospectorPanel(pAgentName, pDebugObs);
	}

	public void CloseIntrospector(String agentname) throws Exception {
		debugPanel.closeIntrospector(agentname);
	}
	
// Generic methods
	// user pressed close button of tab.
	public void Close() throws Exception {
		if (fTabbedPane.getSelectedComponent() == editPanel)
			editPanel.Close();
		else
			debugPanel.Close();
	}

	public void setPanel(int visiblePanel) {
		switch (visiblePanel) {
		case 0: // edit panel
			fTabbedPane.setSelectedComponent(editPanel);
			break;
		case 1: // debug panel
			fTabbedPane.setSelectedComponent(wrappingDebugPanel);
			break;
		default: new Warning("Unknown panel nr "+visiblePanel);
		}
	}
	
	public int visiblePanel() {
		if (fTabbedPane.getSelectedComponent() == editPanel)
			return 0; // edit panel
		else
			return 1; // debug panel
	}

	void CheckEditorIsActive() throws Exception {
		if (fTabbedPane.getSelectedComponent() != editPanel)
			throw new Exception("Please select file to save in the edit panel.");
			// CHECK: Is this exception message to the point?
	}

}
