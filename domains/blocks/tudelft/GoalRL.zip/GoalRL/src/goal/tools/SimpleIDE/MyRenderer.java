package goal.tools.SimpleIDE;

import goal.tools.SimpleIDE.FileNode;
import goal.tools.SimpleIDE.ProcessNode;

import java.awt.Color;
import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

/*
 * Custom renderer, to add our custom status icons before process nodes.
 */
public class MyRenderer extends DefaultTreeCellRenderer {
	
	public Component getTreeCellRendererComponent (JTree tree,
	        Object value, boolean sel, boolean expanded,
	        boolean leaf, int row, boolean hasFocus) 
	{
		if (!(value instanceof ProcessNode) && !(value instanceof FileNode))
			throw new RuntimeException("BUG: MyRenderer encountered node of unknown type?!?");
		
		String name;
		Icon icon;
		IDENode node = (IDENode)value; // type case node
		name = ""+node.getName();
		icon = node.getIcon();
		JLabel label = new JLabel(name);
		label.setIcon(icon);

		// HACK: should use colors of LAF, cyan looks ugly on OSX
		if (sel)
			label.setBackground(Color.cyan);
		else
			label.setBackground(Color.white);
		label.setOpaque(true); // default is transparent.
		return label;
	}
}
