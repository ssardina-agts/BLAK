package goal.tools;

public class PlatformEvent  {
	public enum EventType { AGENT_BORN,AGENT_DIED, AGENT_ASLEEP, AGENT_AWOKE, AGENT_STEPS };
	
	EventType event_type;
	String agent_name;
	
	PlatformEvent(EventType type,String name) {
		event_type=type;
		agent_name=name;
	}
	
	public EventType getEventType() { return event_type; }
	
	public String getAgentName() { return agent_name; }

	public String toString() { return "PlatformEvent["+event_type+","+agent_name+"]"; }
}