package goal.tools.SimpleIDE;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AboutBox extends JFrame {
	public AboutBox(Component parent) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        
        Package p=getClass().getPackage();
        String text="<html>\n<b>GOAL</b> Version "+p.getImplementationVersion()+"<br><br>"+
        "This software is developed by<br>" +
        "K.V.Hindriks and W.Pasman (@TUDelft.nl)<br>" +
        "Homepage: <a href=http://mmi.tudelft.nl/~koen/goal.html>http://mmi.tudelft.nl/~koen/goal.html</a><br>"+
        "</html>";
        add(new JLabel(text),BorderLayout.CENTER);

         // close button. Put it in its own panel to avoid very wide close button...
        JButton close=new JButton("Close");
        close.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt) { dispose(); }
        } );
        JPanel closepanel=new JPanel(new BorderLayout());
        closepanel.add(close,BorderLayout.EAST);
        add(closepanel,BorderLayout.SOUTH);
        pack();
        setVisible(true);
	}
}
