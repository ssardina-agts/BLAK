package goal.tools.SimpleIDE;

import javax.swing.Icon;

public interface IDENode {
	
	public String getName();
	
	public int getType();
	
	public Icon getIcon();

}
