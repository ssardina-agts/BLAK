package goal.tools.SimpleIDE;

import goal.core.agent.Agent;
import goal.core.kr.language.Formula;
import goal.tools.debugger.DebugObserver;
import goal.tools.debugger.Debugger;


import java.awt.BorderLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

//-----------------------introspector panels---------------------
 /*  This changelistener is used to re-layout other similar panels in case
 *  the user changes the layout (typically a drag of the split in the splitpane).
 * @author W.Pasman
 */
public class IntrospectorPanel extends JPanel implements PropertyChangeListener {

	//DebugMessagePanel debugmsgpanel;
	QueryPanel querypanel;
	
	String ouragentname;
	Agent agent;
	BGPAPanel tabs;
	JSplitPane pane; // the split pane
	LayoutChangeListener layoutlistener;
	
	public IntrospectorPanel(Agent a, String agentname,DebugObserver debugobserver, LayoutChangeListener lcl
			) {
		
		ouragentname=agentname;
		agent=a;
		layoutlistener=lcl;
		
		setLayout(new BorderLayout());
		
		tabs = new BGPAPanel(agent);
		//debugmsgpanel=new DebugMessagePanel(debugobserver);
		querypanel=new QueryPanel(a); // DatabasePanel.BELIEFS is a HACK
		pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tabs, querypanel);
	    pane.setDividerLocation(IntrospectorPrefPanel.getDBContentSize());

	    //pane.setDividerLocation(0.8);    
		pane.setResizeWeight(1.0);
	    pane.setOneTouchExpandable(true);
		pane.setContinuousLayout(true);
		pane.addPropertyChangeListener(this);
		
		add(pane,BorderLayout.CENTER);
	}
	
	public void propertyChange(PropertyChangeEvent evt) {
		layoutlistener.SplitPositionChange(pane.getDividerLocation(), evt);
	}
	
	
	/** new debug info arrived. This is the central callback function for DebugObservers. */
	//public void update(DebugInfo info) { debugmsgpanel.update(info); }
	
	
	public Debugger getDebugger() {
		throw new NullPointerException("Internal error. Introspector does not hold the real debugger.");
	}
	
	/** Correctly close the Introspector and  save settings. */
	public void Close() throws Exception { 
		IntrospectorPrefPanel.myPreferences.putInt("dbsize", pane.getDividerLocation());
		
		tabs.Close();	
	}
	
	public String getAgentName() { return ouragentname; }
	

	
	public void setDividerLocation(int loc) {
		// important, only set the location if it differs from the current one.
		// this is to prevent infinite recursion of change events
		if (pane.getDividerLocation()!=loc) pane.setDividerLocation(loc);
	}

}


class BGPAPanel extends JTabbedPane  { //implements LayoutChangeListener removed trac 652

	DatabasePanel beliefs, goals, mails, percepts,knowledge;
	String INITTEXT="Database contents will appear here";
	
	public BGPAPanel(Agent agent) {
		/* convert knowledge from array to nice string */
		ArrayList<Formula> kb=agent.getGOALProgram().getKnowledge();
		String kbtext="";
		for (Formula f: kb) kbtext+=f.toString()+"\n";

		
		beliefs = new DatabasePanel(agent,DatabasePanel.BELIEFS,true,INITTEXT);
		goals = new DatabasePanel(agent,DatabasePanel.GOALS,true,INITTEXT);
		mails = new DatabasePanel(agent,DatabasePanel.MAILS,true,INITTEXT);
		percepts = new DatabasePanel(agent,DatabasePanel.PERCEPTS,true,INITTEXT);
		knowledge=new DatabasePanel(agent,DatabasePanel.KNOWLEDGE,false,kbtext);
		
		add("Beliefs",beliefs);
		add("Goals",goals);
		add("Mails",mails);
		add("Percepts",percepts);
		add("Knowledge",knowledge);
	}
	
	public void Close() {
		beliefs.Close(); goals.Close(); mails.Close(); percepts.Close();
	}
	
}



