package goal.tools.SimpleIDE;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.swing.*;
import javax.swing.tree.*;

import goal.tools.SimpleIDE.IDEfunctionality;
import goal.tools.SimpleIDE.FileNode;
import goal.tools.errorhandling.Warning;
import java.lang.IllegalArgumentException;
import goal.tools.IOManager;

/**
 * The File Panel.
 * Double click or select and menu/edit to edit file.
 * 
 */

public class FilePanel extends JPanel {
	
	// Class fields
	private IDEfunctionality myIDE;
	
	private DefaultTreeModel treeModel; // we need treeModel to force re-rendering.
	private FileNode root;
	// final so that we can access it from the TreeSelectionListener
	final JTree fileTree;

	// Class constructor
	public FilePanel(IDEfunctionality theIDE) {
		myIDE = theIDE;
		// FIXME: why does panel not work if I add no nodes at all???
		root = new FileNode("", FileNode.ROOT, null);
		
		setLayout(new BorderLayout());
		
		treeModel = new DefaultTreeModel(root);
		fileTree = new JTree(treeModel);
		fileTree.setEditable(false); // TODO: 
		fileTree.setRootVisible(false);
		fileTree.setShowsRootHandles(true); // TODO: need to show root handle still to allow collapsing/expanding file hierarchy; need to add GOAL project nodes instead.
		MyRenderer renderer = new MyRenderer();
		fileTree.setCellRenderer(renderer);
		fileTree.addMouseListener(getMouseListener());
		// we want to use double click for editing instead of tree navi. ==> TODO: Use F2 to allow editing of file names;
		// process nodes cannot be edited.
		// so set ToggleClickCount to value that users will not use.
		fileTree.setToggleClickCount(9);// needed, see Mantis 303
		JScrollPane scrollingpane = new JScrollPane(fileTree);
		add(scrollingpane,BorderLayout.CENTER);
		
		add(new JLabel("Files                                "),BorderLayout.NORTH);
		// TODO: set initial size
		//add(fDebugButtonPanel,BorderLayout.SOUTH);
	}
	
	public DefaultTreeModel getTreeModel() { return treeModel; }
	
	/**
	 * @return selected node or root node if no node is selected.
	 */
	public FileNode getSelectedNode() {
		FileNode sel = (FileNode)fileTree.getLastSelectedPathComponent();
		if (sel==null)
			sel = (FileNode)fileTree.getModel().getRoot();
		return sel;
	}
	
	public void selectNode(FileNode node) {
		TreePath path = new TreePath(treeModel.getPathToRoot(node));
		fileTree.expandPath(path);
		fileTree.setSelectionPath(path);
	}
	
	/**
	 * @author Wouter 19mar09: mas file inserts mas, goal file insters goal into selected mas
	 * @param filePath is full path to selected file (.goal or .mas file). 
	 * @param node is selected node.
	 * @throws if node = null or if mas file already opened.
	 */
	public void insertFile(String filePath, FileNode node) throws Exception {
		String lFilename = filePath.substring(filePath.lastIndexOf('/')+1);

		// open it depending on the extension, and get the new selected mas file.
		if (filePath.endsWith(".mas"))
			node = insertMAS(filePath, lFilename);
		else
			if (filePath.endsWith(".goal"))
				insertGOALfile(filePath, lFilename, node);
			else
				throw new IllegalArgumentException("Expected .mas or .goal extension but found "+filePath);
				// TODO remove exception.
		selectNode(node);
	}

	void insertGOALfile(String filePath, String fileName, FileNode node) throws Exception {
		if (node.getType()==FileNode.GOALFILE) {
			node=(FileNode)node.getParent(); // this should be a MAS. But more checking can't do harm.
		}
		if (node.getType() != FileNode.MASFILE)
			throw new Exception("please select MAS in which to insert the goal file");
		// Wouter: exception if something unexpected happens.
		
		// Mantis 551: if already there and open in an editor then reload the file
		FileNode existing=null;
		for(int n=0; n<node.getChildCount(); n++) {
			FileNode fn = (FileNode)node.getChildAt(n);
			if (filePath.equals( fn.getFilename()))
				existing = fn;
		}
		
		if (existing!=null) {
			selectNode(existing);
			 // at this point can not see if user has the file open in the editor. 
			 // we handle this by just executing RELOAD and make it fail silently.
			myIDE.executeCommand(UserCmd.RELOAD.toString());
		} else
		{
			FileNode lNode = new FileNode(fileName, FileNode.GOALFILE, filePath);
			// DO NOT use node.add, it will not notify the GUI for re-rendering!
			treeModel.insertNodeInto(lNode, node, node.getChildCount());
		}
	}
	
	/** inserts new mas in the root. Expected is a .mas file but at this point we dont check that. 
	 * @param filePath is FULL filename with path. fileName is just a short name, typically the filename without the path.
	 * @return new mas node that was created. 
	 * @throws IllegalArgumentException if mas already open. */
	FileNode insertMAS(String filePath, String fileName) throws Exception {
		// TODO: See Mantis 271. Need to rethink IDE tree and insert GOAL projects at top level only.
		//check first if file already opened as mas (mantis 547).
		for (int n=0; n<root.getChildCount(); n++) {
			if ( ((FileNode)root.getChildAt(n)).getFilename().equals(filePath))
				throw new IllegalArgumentException("mas file "+filePath+" already open");
		}
		// First load mas file; throws exception if not a mas file (very basic check still!)
		myIDE.getPlatformManager().loadMASfile(filePath);
		
		FileNode masnode = new FileNode(fileName, FileNode.MASFILE, filePath);
		treeModel.insertNodeInto(masnode, root, root.getChildCount());
		
		
		/* compute base path to be pre-pended to the specified goal filenames.
		// this basePath includes the '/' at the end.
		// this overlaps with code in MASRegistry.getBasePath().
		int indexofsep = pFilename.lastIndexOf('/');
		String basePath="";
		if (indexofsep>0) basePath=pFilename.substring(0,indexofsep+1);
		*/
		
		// NOW: Add GOAL files as children to mas node. Get filenames from registry.
		// TODO: make both mas and associated GOAL files children of GOAL project (at same level); see mantis 271.
		// Don't duplicate files in the list, Mantis 511
		Set<String> filenames=new LinkedHashSet<String>();
		for (String lAgentFilename : myIDE.getPlatformManager().getRegistry().getFilenames().values()) {
			filenames.add(lAgentFilename);
		}
		for (String lAgentFilename : filenames) {
			FileNode lAgentNode =
				new FileNode(IOManager.shortName(lAgentFilename), FileNode.GOALFILE, lAgentFilename);
			treeModel.insertNodeInto(lAgentNode, masnode, masnode.getChildCount());
		}
		
		return masnode;
	}
	
	
	public void removeFileNode(FileNode node) { // root node cannot be removed, node must not be root node.
		treeModel.removeNodeFromParent(node);
		// child nodes also automatically removed
	}
	
	/**
	 * DOC needed
	 * @return
	 */
 	private MouseListener getMouseListener() { // See http://java.sun.com/j2se/1.4.2/docs/api/javax/swing/JTree.html for code below.
 		return new MouseAdapter() {
			public void mousePressed(MouseEvent event) {
				myIDE.setMenuItemsAndButtons();
		        TreePath selPath = fileTree.getPathForLocation(event.getX(), event.getY());
		        // TODO: since root handle is visible, we need to check for selPath=null; see TODO above.
		        if (selPath==null)
		        	return;
		        FileNode node = (FileNode)selPath.getLastPathComponent();
		        if (node != null) {
		        	// if(e.getClickCount() == 1) { // user simply selected node, menu/buttons do not need changing in edit view
		        	if (event.getClickCount() == 2) { // user double-clicked file node
		        		try { // CHECK: which method generates exception here??
		        			myIDE.executeCommand(UserCmd.EDIT.toString());
		        		} catch (Exception exception) { new Warning("EDIT failed",exception); } 
		        	}     	
		        }
			}
		};
 	}
 	
 	/**
 	 * rename all occurences of an old filename to a new name.
 	 * Ask user which ones to rename if multiple occurences.
 	 * assumption: we can not have multiple MAS files with same name.
 	 * therefore if we find duplicates it must be files INSIDE a MAS.
 	 * Returns silently without changing anything if user presses CANCEL.
 	 * See mantis 543
 	 * @param oldname is full filename to be renamed
 	 * @param newname is full new filename
 	 * @throws IllegalArgumentException if oldname does not occur in the FilePanel.
 	 * 
 	 */
 	public void Rename(String oldname, String newname) throws IllegalArgumentException {
 		FileNode node=root;
 		ArrayList<FileNode> affectednodes=new ArrayList<FileNode>();
 		while (node!=null) {
 			if (oldname.equals(node.getFilename())) {
 				affectednodes.add(node);
 			}
 			node=(FileNode)node.getNextNode();
 		}
 		
 		// filter affectednodes, if necessary
 		ArrayList<FileNode>nodestochange=Filter(affectednodes,oldname);
 		if (nodestochange==null) return; // cancelled
 		for (FileNode n: nodestochange) {
 			n.setName(IOManager.shortName(newname), newname);
 			treeModel.nodeChanged(n);
 		}
 	}
 	
 	/** Filter out nodes that are not selected by user. Support function for Rename. */
 	ArrayList<FileNode> Filter(ArrayList<FileNode> affectednodes, String oldname) 
 	{
 		switch (affectednodes.size()) {
 			case 0:
 				throw new IllegalArgumentException("node "+oldname+" does not occur in filespanel");
 			case 1:
 				break; // change the one node that has this name
 			default:
 				 // show requester which files to change.
				 // we can not dump an array of checkboxes into the showOptionDialog
				 // because it will show them next to each oter instead of below each other.
 				 // and because it does not show the OK and Cancel buttons. So we use ConfirmDialog isntead
 				JPanel choicespanel=new JPanel();
 				choicespanel.setLayout(new BoxLayout(choicespanel,BoxLayout.Y_AXIS));
 				choicespanel.add(new JLabel("There are multiple mas's using the renamed file.\n" +
 						"Please select which ones have to be renamed"));
 				ArrayList<JCheckBox> choices=new ArrayList<JCheckBox>();
 				for (FileNode n: affectednodes) 
 				{
 					JCheckBox checkbox=new JCheckBox(""+((FileNode)(n.getParent())).getFilename());
 					choices.add(checkbox);
 					choicespanel.add(checkbox);
 				}
 				
 				int choice=JOptionPane.showConfirmDialog(this,
 						choicespanel,
 						"Select files to rename",JOptionPane.OK_CANCEL_OPTION,
 						JOptionPane.QUESTION_MESSAGE);
 				if(choice==JOptionPane.CANCEL_OPTION) return null;
 				 // and finally copy the requested filenames to array
 				for (JCheckBox c: choices) {
 					if (!c.isSelected()) {
 						// remove choice from affectednodes
 						for (FileNode n: affectednodes) {
 							if (c.getText().equals(((FileNode)n.getParent()).getFilename()))
 							{
 								affectednodes.remove(n); break; 
 							}
 						}
 					}
 				}
 		}
 		return affectednodes;
 	}
 	
 	/** Wouter added 3aug09 trac 421*/
 	ArrayList<String> getMASs() {
 		ArrayList<String> mass=new ArrayList<String>();
		for (int n=0; n<root.getChildCount(); n++) {
			mass.add(((FileNode)(root.getChildAt(n))).getFilename());
		}
		return mass;
 	}

}