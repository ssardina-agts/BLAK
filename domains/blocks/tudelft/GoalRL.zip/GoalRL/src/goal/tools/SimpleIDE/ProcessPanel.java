package goal.tools.SimpleIDE;

import goal.tools.IOManager;
import goal.tools.PlatformEvent;
import goal.tools.errorhandling.Warning;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

public class ProcessPanel extends JPanel {
	
	// Class fields
	private IDEfunctionality myIDE;
	
	private DefaultTreeModel treeModel; // we need treeModel to force re-rendering.
	private ProcessNode fRoot;
	private ProcessNode MASNode; // the MAS node under the root.
	private final JTree processTree; // final so that we can access it from the TreeSelectionListener.

	// Constructor
	public ProcessPanel(IDEfunctionality theIDE) {
		myIDE = theIDE;
		
		myIDE.getPlatformManager().addObserver(new Observer() {
			public void update(Observable o, Object arg) {
				if (!(arg instanceof goal.tools.PlatformEvent))
					new Warning("Err.. expected Platform event but received "+arg);
				else {
				  handlePlatformEvent((PlatformEvent)arg);
				}
			}
		});
		
		
		// FIXME(WP): why does panel not work if I add no nodes at all???
		fRoot = new ProcessNode("", ProcessNode.ROOT, null, ProcessNode.ROOT);

		treeModel = new DefaultTreeModel(fRoot);
		processTree = new JTree(treeModel);

		// Define layout
		setLayout(new BorderLayout());
		// fTree.setEditable(true); ==> we do not want process nodes to be edited.
		processTree.setRootVisible(false);
		processTree.setShowsRootHandles(false); // prevent user from selecting root node (avoids null pointers in mouse listener)
		MyRenderer renderer = new MyRenderer();
		processTree.setCellRenderer(renderer);
		//processTree.setCellEditor(new MyEditor(processTree, renderer, theIDE));
		//processTree.addTreeSelectionListener(getTreeSelectionListener());
		processTree.addMouseListener(getMouseListener());
		processTree.setToggleClickCount(9); // needed, see Mantis 303


		JScrollPane scrollingpane = new JScrollPane(processTree);
		add(new JLabel("Processes"), BorderLayout.NORTH);
		add(scrollingpane, BorderLayout.CENTER);
	}
	
	
	/** handle a platform event -- agent alive or died.
	 * When one agent appears -> create entire MAS and set other agents to "killed".
	 * When agent is killed -> set that agent to "killed" */
	void handlePlatformEvent(PlatformEvent evt) {
		PlatformEvent.EventType type=evt.getEventType();
		//System.out.println("ProcessPanel: "+evt);
		String agt=evt.getAgentName();
		ProcessNode node=findNode(agt);

		int action=-1;
		
		switch (type) {
		case AGENT_BORN:
			 // First agent that reports being born usually is NOT the MAS or scheduler.
			 // but at that moment we do want to create the full tree including that MAS name.
			 // hence we need to access the registry to find out the MASFilename.
			// note that we moslty ignore AGENT_BORN actions, we just use the first one to
			// initialise the tree.
			if (debugViewEmpty()) {
				node=addMasProcesses(
						IOManager.shortName(myIDE.getPlatformManager().getRegistry().getMASFilename()));
			}
			action=ProcessNode.STEPPING;
			break;
		case AGENT_ASLEEP:
			action=ProcessNode.PAUSED;
			break;
		case AGENT_DIED:
			action=ProcessNode.KILLED; // TODO cleanup panel.
			break;
		case AGENT_AWOKE:
			action=ProcessNode.RUNNING;
			break;
		case AGENT_STEPS:
			if (node!=null && node.getStatus()==ProcessNode.RUNNING) {
				action=ProcessNode.PAUSED;
				// see discussion at trac 696 about effect of pressing
				// pause while agent is in run mode and how to show
				// this to the user.
			} else {
				action=ProcessNode.STEPPING;
			}
			break;
		default:
			new Warning("BUG: encountered unknown platform event type "+evt);
		}
		if (action!=-1 && node!=null) {
			node.setStatus(action);
			refreshProcessNode(node);
			myIDE.setMenuItemsAndButtons();
		}
		checkMASStatus(); // update MAS node - needed if any agent changes status.
	}
	
	// Class methods
	public boolean debugViewEmpty() {
		return (fRoot.getChildCount()==0);
	}
	
	// force rerendering tree
	private void refreshProcessNode(ProcessNode node) {
		final ProcessNode thenode=node;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				treeModel.nodeStructureChanged(thenode);
			}
		}
		);
	}

	// get currently selected node. Returns ROOT node if nothing selected.
	public ProcessNode getSelectedNode() {
		ProcessNode lSelected =(ProcessNode)processTree.getLastSelectedPathComponent();
		if (lSelected == null) {
			lSelected=(ProcessNode)processTree.getModel().getRoot();
			// Wouter: turned this warning off 16mar09, mantis 554, I dont see why this was here.
			//new Warning("BUG (Process Panel): there should always be a node selected in the Process Panel.");
		}
		return lSelected;
	}
	
	/** @return node in process panel with given agent name, or null if node not found */
	public ProcessNode findNode(String name) {
		ProcessNode mas, process, node = null;
		int i=0, j;
		
		// ASSUMPTION: In process panel only three levels: (1) (invisible) root node, (2) mas nodes, and (3) their children.
		while ((node==null) && i<fRoot.getChildCount()) {
			mas = (ProcessNode)fRoot.getChildAt(i);
			if (mas.getName().equals(name))
				node = mas;
			j = 0; // check children
			while ((node==null) && j<mas.getChildCount()) {
				process = (ProcessNode)mas.getChildAt(j);
				if (process.getName().equals(name))
					node = process;
				j+=1;
			}
			i+=1;
		}
		return node;
	}
	
	// select (first and only) node with name 'name'; ASSUMPTION: all names of mas and GOAL agent processes are unique. 
	public ProcessNode selectNode(String name) {
		ProcessNode node=findNode(name);
		if (node==null) {
			return null;
		}
		selectNode(node);
		return node;
	}
	
	public void selectNode(ProcessNode node) {
		TreePath path = new TreePath(treeModel.getPathToRoot(node));
		processTree.expandPath(path);
		processTree.setSelectionPath(path);
		myIDE.setMenuItemsAndButtons();
	}
	
	public ProcessNode addMasProcesses(String masName) {
		ProcessNode root;
		
		// TODO: Code still assumes a single registry, but with multiple GOAL projects there could be more than one.
		root = (ProcessNode)treeModel.getRoot();
		
		MASNode = new ProcessNode(masName, ProcessNode.MASFILE, "", ProcessNode.STEPPING); // TODO: add mas file path.
		treeModel.insertNodeInto(MASNode, root, root.getChildCount());
		//boolean isPaused = true, processPaused; removed, trac 696
		for (String agentName : myIDE.getPlatformManager().getRegistry().getFilenames().keySet()) {
			
			//processPaused = myIDE.getPlatformManager().getDebugObserver(agentName)!=null;
			ProcessNode node = new ProcessNode(agentName, ProcessNode.GOALPROCESS, "", ProcessNode.STEPPING );
			treeModel.insertNodeInto(node, MASNode, MASNode.getChildCount());
			selectNode(node); // force expansion of three.
			//isPaused = isPaused && processPaused;
		}
		//masNode.setStatus(isPaused ? ProcessNode.PAUSED : ProcessNode.RUNNING);
		//masNode.setStatus(ProcessNode.KILLED);
		return MASNode;
	}
	
	public void removeMas(ProcessNode mas) { // node must be node of type mas file
		for (int i=0; i<mas.getChildCount(); i++) {
			treeModel.removeNodeFromParent((ProcessNode)mas.getChildAt(i));
		}
		treeModel.removeNodeFromParent(mas);
		if (fRoot.getChildCount()!=0)
			selectNode((ProcessNode)fRoot.getChildAt(0));
	}
 	
 	private MouseListener getMouseListener() { // See http://java.sun.com/j2se/1.4.2/docs/api/javax/swing/JTree.html for code below.
 		return new MouseAdapter() {
			public void mousePressed(MouseEvent event) {
				myIDE.setMenuItemsAndButtons();
		        TreePath selPath = processTree.getPathForLocation(event.getX(), event.getY());
		        if (selPath==null) return; // nothing selected
		        ProcessNode node = (ProcessNode)selPath.getLastPathComponent();
		        if(node != null) {
		        	if(event.getClickCount() == 1) { // user selected node, update menu item and button status
		        		myIDE.setMenuItemsAndButtons();
		        	} else if (event.getClickCount() == 2) { // user double-clicked process node
		        		try { // CHECK: which method generates exception here??
		        			myIDE.executeCommand(UserCmd.DEBUG.toString());
		        		} catch (Exception exception) { new Warning("Debug of node failed",exception); } 
		        	}
		            // 	        	
		        }
			}
		};
 	}
 	
 	/** checks if all processes are running or STEPPING/PAUSED, and sets MAS to
 	 * either RUNNING or STEPPING in that case 
 	 * Fixed 28jul09, this was in the SimpleIDE and did not work properly due to trac 696 */
 	private void checkMASStatus() {
 		if (MASNode==null || MASNode.getChildCount()==0) return; // failsafe for during startup
		boolean sameStatus = true;
		int processStatus = getSimpleStatus((ProcessNode)MASNode.getChildAt(0));
		
		for (int i=0; i<MASNode.getChildCount(); i++)
			sameStatus = sameStatus && getSimpleStatus((ProcessNode)MASNode.getChildAt(i))==processStatus;
		if (sameStatus) {
			MASNode.setStatus(processStatus);
		}
 	}
 	
 	int getSimpleStatus(ProcessNode n) {
 		int status=n.getStatus();
 		if (status==ProcessNode.STEPPING) return ProcessNode.PAUSED;
 		return status;
 	}
 	
}