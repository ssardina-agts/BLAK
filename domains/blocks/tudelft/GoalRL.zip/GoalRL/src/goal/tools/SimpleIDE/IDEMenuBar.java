package goal.tools.SimpleIDE;

import goal.tools.debugger.Debugger;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.util.Hashtable;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;


class IDEMenuBar extends JMenuBar implements ActionListener {
	
	// Class field
	SimpleIDE myIDE;
	// menu items. We keep them to enable/disable them when necessary.
	JMenuItem newItem, openItem, saveItem, saveAsItem, saveAllItem, editItem, closeItem, removeItem, 
		printItem, pageSetupItem,quitItem;
	JMenuItem aboutItem, toBackItem, prefsItem, switchPanelItem;
	JMenuItem undoItem, redoItem, cutItem, copyItem, pasteItem;
	JMenuItem runItem, pauseItem, stepItem, backstepItem, setLevelItem, killItem,resetEnvItem, toggleLearning, explanation;
	JMenuItem sniffItem, stopSniffItem, clearSnifferItem, introspectorItem,exportItem;
	
	// table of all actions and associated menus. Used to en/disable them appropriately
	// createMenuItem will insert required info in this table as well.
	Hashtable<String,JMenuItem> allMenuItems=new Hashtable<String,JMenuItem>();
	
	// Constructor
	public IDEMenuBar(SimpleIDE theIDE) {
		myIDE = theIDE;
		boolean OSX=System.getProperty("os.name").equals("Mac OS X");

		JMenu goalMenu; // help menu on windows/linux
		goalMenu = new JMenu(OSX?"GOAL-IDE":"Help");
		createMenuItem(goalMenu, aboutItem = new JMenuItem("About GOAL IDE"), UserCmd.ABOUT.toString());
		goalMenu.addSeparator();
		createMenuItem(goalMenu, prefsItem = new JMenuItem("Preferences"), UserCmd.PREFERENCES.toString());
		goalMenu.addSeparator();
		createMenuItem(goalMenu, aboutItem = new JMenuItem("Memory Stats"), UserCmd.MEMSTATS.toString());
		createMenuItem(goalMenu,toBackItem = new JMenuItem("IDE to back"),UserCmd.TOBACK.toString());
		createMenuItem(goalMenu, switchPanelItem = new JMenuItem("Toggle Edit-Debug Mode"), UserCmd.SWITCHPANEL.toString(),'M');

		
		JMenu fileMenu = new JMenu("File");
		createMenuItem(fileMenu, newItem = new JMenuItem("New"), UserCmd.NEW.toString(), 'N');
		createMenuItem(fileMenu, openItem = new JMenuItem("Open"), UserCmd.OPEN.toString(), 'O');
		createMenuItem(fileMenu, saveItem = new JMenuItem("Save"), UserCmd.SAVE.toString(), 'S');
		createMenuItem(fileMenu, saveAsItem = new JMenuItem("Save As"), UserCmd.SAVEAS.toString());
		createMenuItem(fileMenu, saveAllItem = new JMenuItem("Save All"), UserCmd.SAVEALL.toString(), 'S', InputEvent.SHIFT_MASK);
		fileMenu.addSeparator();
		createMenuItem(fileMenu, editItem = new JMenuItem("Edit"), UserCmd.EDIT.toString());
		createMenuItem(fileMenu, closeItem = new JMenuItem("Close"), UserCmd.CLOSE.toString(), 'W');
		createMenuItem(fileMenu, removeItem = new JMenuItem("Remove File"), UserCmd.CLOSEANDREMOVE.toString());
		fileMenu.addSeparator();
		createMenuItem(fileMenu, printItem = new JMenuItem("Print"), UserCmd.PRINT.toString(), 'P');	
		createMenuItem(fileMenu, pageSetupItem = new JMenuItem("Page Setup"), UserCmd.PAGESETUP.toString());	

		
		JMenu editMenu = new JMenu("Edit");
		editMenu.addSeparator();
		createMenuItem(editMenu, undoItem = new JMenuItem("Undo"), UserCmd.UNDO.toString(), 'Z');
		createMenuItem(editMenu, redoItem = new JMenuItem("Redo"), UserCmd.REDO.toString(), 'Z', InputEvent.SHIFT_MASK);
		editMenu.addSeparator();
		createMenuItem(editMenu, cutItem = new JMenuItem("Cut"), UserCmd.CUT.toString(), 'X');
		createMenuItem(editMenu, copyItem = new JMenuItem("Copy"), UserCmd.COPY.toString(), 'C');
		createMenuItem(editMenu, pasteItem = new JMenuItem("Paste"), UserCmd.PASTE.toString(), 'V');
		editMenu.addSeparator();
		createMenuItem(editMenu, pasteItem = new JMenuItem("Find/Replace"), UserCmd.FIND.toString(), 'F');
		createMenuItem(editMenu, pasteItem = new JMenuItem("Find Again"), UserCmd.FINDNEXT.toString(), 'G');
		createMenuItem(editMenu, pasteItem = new JMenuItem("Go To Line"), UserCmd.GOTOLINE.toString(), 'L');
		editMenu.addSeparator();
		createMenuItem(editMenu, pasteItem = new JMenuItem("Auto Complete Word"), UserCmd.COMPLETEWORD.toString(), 'B');

		
		JMenu runMenu = new JMenu("Run");
		createMenuItem(runMenu, runItem = new JMenuItem("Run"), UserCmd.RUN.toString(), 'R');
		createMenuItem(runMenu, pauseItem = new JMenuItem("Pause"), UserCmd.PAUSE.toString(), 'P');
		createMenuItem(runMenu, stepItem = new JMenuItem("Step forward"), UserCmd.STEP.toString(), 'T');
		createMenuItem(runMenu, backstepItem = new JMenuItem("Step back"), UserCmd.BACKSTEP.toString(), 'T',InputEvent.SHIFT_MASK);
		createMenuItem(runMenu, killItem = new JMenuItem("Kill"), UserCmd.KILL.toString());
		createMenuItem(runMenu, setLevelItem = new JMenuItem("Set Debug Level..."), UserCmd.ASKDEBUGLEVEL.toString());
		runMenu.addSeparator();
		createMenuItem(runMenu, resetEnvItem = new JMenuItem("Reset Environment"), UserCmd.RESETENV.toString());
		createMenuItem(runMenu, toggleLearning = new JMenuItem("Toggle Learning"), UserCmd.TOGGLELEARNING.toString());
		createMenuItem(runMenu, explanation = new JMenuItem("Generate explanations"), UserCmd.EXPLANATION.toString());
		
		
		
		
		JMenu debugMenu = new JMenu("Debug");
		createMenuItem(debugMenu, introspectorItem = new JMenuItem("Open Introspector"), UserCmd.DEBUG.toString(), 'D');
		// Initially, no mas has been loaded nor launched and all items are disabled
		// TODO: when we use GOAL project configuration files which might be automatically be reloaded after closing IDE, run button should be available but all others not.
		createMenuItem(debugMenu, exportItem = new JMenuItem("Export DB Contents"), UserCmd.EXPORTDB.toString());
		

		JMenu sniffMenu = new JMenu("Sniffer");
		createMenuItem(sniffMenu, sniffItem = new JMenuItem("Sniff Agent"), UserCmd.SNIFF.toString());
		createMenuItem(sniffMenu, stopSniffItem = new JMenuItem("Stop Sniff"), UserCmd.STOPSNIFF.toString());
		createMenuItem(sniffMenu, clearSnifferItem = new JMenuItem("Clear Canvas"), UserCmd.CLEARSNIFF.toString());
		// Initially, no mas has been launched and sniff items are disabled
		sniffItem.setEnabled(false);
		stopSniffItem.setEnabled(false);
		clearSnifferItem.setEnabled(false);
		
		// items that have system-dependent place in the menus 
		if (OSX) {
			goalMenu.addSeparator();
			createMenuItem(goalMenu, quitItem = new JMenuItem("Quit"), UserCmd.QUIT.toString(), 'Q');
		}
		else {
			fileMenu.addSeparator();
			createMenuItem(fileMenu, quitItem = new JMenuItem("Quit"), UserCmd.QUIT.toString(), 'Q');
		}

		// finally insert the menus in the (system-dependent) order.		
		if (OSX) add(goalMenu); // else we add it at the end as help menu.
		add(fileMenu);
		add(editMenu);
		add(runMenu);
		add(debugMenu);
		add(sniffMenu);
		if (!OSX) add(goalMenu); // help menu in that case 

		
		setMenuItems(0, new FileNode("",FileNode.ROOT,"")); // make menu items avaialble in line with edit view initially
	}
	
	// Class methods
	void createMenuItem(JMenu menu, JMenuItem menuItem, String action) {
		createMenuItem(menu, menuItem, action, '\0');
	}
	
	void createMenuItem(JMenu menu, JMenuItem menuItem, String action, char shortcut) {
		createMenuItem(menu, menuItem, action, shortcut, 0);
	}
	
	/** @param pShortcut = 'X' where X is your shortcut character, or '\0' if no shortcut. */
	void createMenuItem(JMenu menu, JMenuItem menuItem, String action, char shortcut, int mask) {
		
		menuItem.setActionCommand(action);
		menuItem.addActionListener(this);
		
		// Set mask for keystroke
		int fullmask;
		// On OSX we need apple-X for the menu shortcuts, on other platforms ctrl-X.
		if ( System.getProperty("os.name").toLowerCase().indexOf("mac os x") > -1 )
			fullmask = InputEvent.META_MASK | mask;
		else
			fullmask = InputEvent.CTRL_MASK | mask;
		
		if (shortcut!='\0') {
			mask=mask | InputEvent.META_MASK;
		 	menuItem.setAccelerator(KeyStroke.getKeyStroke(shortcut, fullmask));
			// CHECK: Meta mask is option key on OSX, and I hope alt key on Windows. 
		}
		
		menu.add(menuItem);
		allMenuItems.put(action,menuItem);
	}

	public void actionPerformed(ActionEvent pEvent) { // handle menu event
		myIDE.executeCommand(pEvent.getActionCommand());
	}
	
	public void setMenuItems(int view, IDENode node) {
		for (String action:allMenuItems.keySet()) {
			JMenuItem menu=allMenuItems.get(action);
			menu.setEnabled(myIDE.isEnabled(action));
		}
	}
	
	
}


