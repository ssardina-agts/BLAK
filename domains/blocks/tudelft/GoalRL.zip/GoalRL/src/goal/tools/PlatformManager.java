/** 
 * Platform Manager starts up the GOAL system, loads agents etc.
 * 
 * See http://jade.tilab.com/doc/api/index.html for JADE documentation. TODO move this comment to 'middleware handling' part
 * 
 * @author W.Pasman // CHECK How many authors do we have?
 * 
 */

package goal.tools;

// CHECK Can we reduce references to core even further?? See below.
import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.mas.MASRegistry;
import goal.core.scheduler.GenericScheduler;

// TODO: platform manager should not have references to Formula.
import goal.core.kr.language.Formula;

import goal.tools.PlatformEvent.EventType;
import goal.tools.debugger.DebugInfo;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

// middleware infrastructure
import goal.middleware.jade.JadeGoalAgent;
import goal.middleware.jade.JadeScheduler;

import jade.BootProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Observable;

/**
 * 
 * @author K.Hindriks
 * 
 * Platform manager is central access point to mas registry, IO manager and middleware (JADE).
 * Mainly used to launch a mas, including environment and schedulers.
 * 
 * Wouter: modified 20jul09.
 * 
 * The PM keeps the debug observers, because we need debug observers to put the agent into step mode.
 *  
 * TODO: Platform manager should actually be able to manage multiple GOAL projects (as in Eclipse, where it is
 * possible to launch multiple projects at the same time). Elements of a GOAL project needed at runtime need to
 * be stored in mas registry. This means that environment, schedulers and container should be part of the registry
 * instead of fields of the platformmanager class. Correspondingly, the platformmanager should be able to manage
 * a list or set of mas registries, one associated with each available GOAL project. 
 * Note that the platformmanager does not need multiple instances of the IOManager.
 * 
 * 23jul09 Wouter: PlatformManager now extends Observable (see trac 696).
 * Inspired by Jade (PlatformController.Listener) the PM sends platformEvent objects to its listeners.
 * @since 27jul09: PM now merges JADE platform events with DebugObserver platform events (Agent.SLEEPS etc)
 * 
 */

public class PlatformManager extends Observable implements jade.wrapper.PlatformController.Listener {
		
	// Class fields
	private MASRegistry fReg = null;
	private Environment fEnv = null;
	private GenericScheduler fGOALScheduler = null;
	
	// middleware (used to implement inter-agent communication)
	private JadeScheduler fJADEScheduler = null;
	private AgentContainer fJADEContainer = null;
	private AgentController fSchedulerController=null;
	
    // GOAL system tools
	private IOManager fIOMngr = new IOManager();
	// DebugObservers are created here in order to be able to start agents in PAUSED mode.
	private ArrayList<MyDebugObserver> debugObservers = new ArrayList<MyDebugObserver>(); 
	
	// Constructor
	public PlatformManager() throws Exception {
		// HACK: Setup JADE agent container
		System.out.println("GOAL is starting up the JADE system.");
		BootProfileImpl profile = new BootProfileImpl();
		System.out.println(profile.toString());
		Runtime.instance().setCloseVM(true);
		fJADEContainer = Runtime.instance().createMainContainer(profile);
		
		fJADEContainer.addPlatformListener(this); // may throw ControllerException.
	}

	// TODO: Move this below to 'middleware handling'
	/** JADE PM to GOAL PM conversion code */
	public void bornAgent(jade.wrapper.PlatformEvent anEvent) { 
		notifyOurObservers(EventType.AGENT_BORN,anEvent);
	}
	public void deadAgent(jade.wrapper.PlatformEvent anEvent) { 
		notifyOurObservers(EventType.AGENT_DIED,anEvent);
	}
	public void killedPlatform(jade.wrapper.PlatformEvent anEvent) { }
	public void resumedPlatform(jade.wrapper.PlatformEvent anEvent) { }
	public void startedPlatform(jade.wrapper.PlatformEvent anEvent) { }
	public void suspendedPlatform(jade.wrapper.PlatformEvent anEvent) { }	
	
	void notifyOurObservers(EventType type, jade.wrapper.PlatformEvent evt) {
		setChanged();
		String agentname=evt.getAgentGUID(); // returns names as "elevator2@urk.twi:1099/JADE"
		agentname=agentname.substring(0,agentname.indexOf("@"));
		notifyObservers(new PlatformEvent(type,agentname));
	}
	
	/**
	 * Launches the multi-agent system masName if no other multi-agent system is running.
	 * @param masName is the full path to the mas file.
	 */
	public void launchMAS(String masName) throws Exception {
		
		// STEP 1: Check if mas is already running. If so, return.
		if (fReg.getStatus()) {
			throw new Exception("BUG (PlatformManager): Multi-agent system "+masName+" is already running. menu item and button should have been disabled.");
		}
		try { // Wouter: do correct cleanup in case of failure, see Mantis 528
			fReg.setStatus(true);
			
			// STEP 2: (Re)load mas file into Registry. mas file is a recipe for launching the mas.
			// TODO: locate mas registry with corresponding masName; currently we only have one, so it works.

			 // Wouter: removed following ADHOC, need fixing see Mantis 528
			 // fReg.KillMAS(); // ADHOC: first, clean up running JADE agents if any, ...
			fReg = fIOMngr.loadMASFile(masName);
			
			// STEP 3: Launch multi-agent system. Registry contains recipe for launching multi-agent system.
			// do this before launching scheduler and environment, which may need these agents
			for (String lAgentName : fReg.getAgentNames())
				launchGOALAgent(lAgentName);
			
			// STEP 4: Initialize and launch environment.
			if (fEnv == null && fReg.getEnvironmentClassPath()!=null) {
				// Added W.Pasman 11mar09: check that the mas requires environment anyway.
				// ADHOC: currently do this only if environment has not yet been started.
				//fReg.setEnvironment("wumpusenv.jar", "wumpusenv.WumpusWorld"); //Wouter TODO put this in the MAS file.
				//fReg.setEnvironment("..", "wumpusenv.WumpusWorld"); //Wouter TODO put this in the MAS file.
				/*
				 * TODO: What actually needs to happen here is:
				 * Step i: check if environment is running.
				 * Step iia: if not, launch it and register agents at environment
				 * Step iib: if so, check if all agents in registry have been registered at environment. Add any that are missing, remove any that are no longer present in registry.
				 * Step iii: check if GOAL scheduler is running. If not, launch it.
				 * Step iv: check if all agents in registry have been registered by JADE scheduler. Add any that are missing, remove any that are no longer present in registry.
				 * TODO: This requires additional functionality in the environment interface, i.e. to subscribe and unsubscribe agents with environment.
				 * TODO: Upon user changes to the mas file, cleanup must be done. E.g. user renames agent, etc
				 */
				System.out.println("Launching environment..."); // Now something tricky, see Mantis 540
				String goaldir=System.getProperty("user.dir")+"/";
				String fullenvpath=PMPrefPanel.getEnvBasePath(goaldir,IOManager.getDirectory(masName));
				fullenvpath=IOManager.concatPaths(fullenvpath,fReg.getEnvironmentClassPath());
				
				Object env=fIOMngr.loadClass(fullenvpath, fReg.getEnvironmentClassName());
				if (!(env instanceof Environment))
					throw new InstantiationException("Object "+fReg.getEnvironmentClassName()+" is not an instance of an Environment");
				fEnv=(Environment)env;
			}
				
			// STEP 5: Initialize and launch scheduler(s). Requires environment since scheduler informs environment which actions should be performed.
			launchScheduler(fEnv);
		} catch (Exception e) {
			// in case of exception, close down the MAS and cleanup.
			killMAS(masName);
			throw new Exception("Launch of MAS failed: ",e);	
		}
	}
	
	public void launchGOALAgent(String pAgentName) throws Exception {
		// TODO: Obtain recipe for launching this particular agent from Registry. I.e. nr of instances, include files, etc.
		
		// A GOAL agent  agent every time MAS is launched since user may e.g. have changed the GOAL file that is
		// associated with the agent name in the mas file in the mean time, or may have changed the GOAL file itself.

		if (!fReg.containsAgent(pAgentName)) {
			// Agent is not yet present in registry, initializing runtime environment, mas is just launched by user.
			// Otherwise only JADE controller needs to be restarted.
			fReg.addAgent(pAgentName, fIOMngr.loadGOALAgent(fReg.getFilename(pAgentName), pAgentName));
			// launch agents in PAUSED mode
			MyDebugObserver observer = getOrCreateDebugObserver(pAgentName);
			 // Now we put the debugger into STEP mode. We can not directly put the agent into HALT mode
			 // because the agent runs in another thread and because 
			 // being in HALT mode means that the thread called a Debugger.bp() function that did not return.
			 // to get the agent really in HALT mode means we have to RUN the agent.
			 // the call to launchJadeAgent() below will run the agent into the first bp.
			observer.getDebugger().step(observer);
		} else {
			System.out.println("Restarting GOAL process.");
		}
		if (fReg.containsController(pAgentName)) { // agent controller already exists ?!?
			new Warning("JADE controller with name "+pAgentName+" already exists. Cannot launch it a second time.");
			return;
		}
		launchJadeAgent(pAgentName, fReg.getAgent(pAgentName));
	}

	/**
	 * Starts a new GOAL agent in JADE and runs up to first bp
	 * @param pAgentName is the name that the agent is supposed to have.
	 * @param pAgent is the GOAL agent to be started.
	 * @author W.Pasman
	 */
	private void launchJadeAgent(String pAgentName, Agent pAgent) {
		try {
			System.out.println("Launching GOAL-JADE agent: "+pAgentName);
			AgentController lController =
				fJADEContainer.acceptNewAgent(pAgent.getName(), new JadeGoalAgent(pAgent));
			lController.start(); // Start the JADE agent. This will call the agent's startup() call
			 // which will run up to the first (level 1) bp() and halt there 
			fReg.addController(pAgentName, lController);
		} catch (Exception e) {
			new Warning("Platformmanager encountered error while starting agent "+pAgentName,e);
		}
	}
	
	/** 
	 * Kills an agent process in the registry.
	 * Agents are not actually removed, to make it possible to restart the agent at a later time.
	 */
	public void killAgent(String agentName) throws Exception {
		removeObserver(getDebugObserver(agentName));
		fReg.killAgent(agentName);
	}
	
	/**
	 * Removes all observers, and kills environment, scheduler, MAS and agents in MAS.
	 */
	public void killMAS(String masName) throws Exception {
		// if called from the SimpleIDE, usually all observers have been removed already,
		// because the associated introspector tabs were closed first.
		// we re-do it here, because the PM may have debug observers open without associated introspectors in the IDE.
		while (!debugObservers.isEmpty())
			removeObserver(debugObservers.get(0));
		killScheduler();
		killEnvironment();
		fReg.KillMAS();
		fReg.setStatus(false); // Wouter: added 30jun08 mantis 528
	}
	
	/** 
	 * Quits and kills the scheduler. 
	 * @author W.Pasman
	 */
	public void killScheduler() throws Exception {
		if (fSchedulerController != null) {
			fSchedulerController.kill();
			fSchedulerController=null;
		}
		fJADEScheduler=null;
		fGOALScheduler=null;	
	}

	/** 
	 * Invokes the close() method of the environment interface.
	 */
	public void killEnvironment() throws Exception {
		if (fEnv!=null) {
			fEnv.close();
			fEnv=null;
		}
	}

	public void setRegistry(MASRegistry pReg) {
		fReg = pReg;
	}
	
	public MASRegistry getRegistry() {
		return fReg;
	}
	
	public void addAgentfile(String pAgentname, String pAgentfilename) {
		// TODO
	}
	
	public ArrayList<Agent> getAgents() {
		return fReg.getAgents();
	}
	
	/**
	 * Reset the agent. This means resetting its databases.
	 * May throw if reset fails.
	 * Resets the random seed stored in ActionSelectionEngine.
	 * TODO: How do we clear a 'set seed'??
	 * 
	 * WARNING: DO NOT CALL debugger during reset
	 * 
	 */
	public void reset(String pAgentName) throws Exception {
		// FIXME: load(); ==> method moved to IOManager
		// FIXME: resetRandomSeed();  ==> method moved to ActionSelectionEngine
		new Warning("Agent has [NOT] been reset.");
	}

	/** 
	 * Sets a GOAL scheduler to be used as scheduler.
	 * Creates a JADE-GOAL scheduler and places it in the MAS and runs it.
	 */
	public void launchScheduler(Environment pEnv) {
		System.out.println("Launching scheduler...");
		
		fGOALScheduler = new GenericScheduler(pEnv,fReg);
		
		fJADEScheduler = new JadeScheduler(null, fGOALScheduler);

		try{		
			fSchedulerController=getMainContainer().acceptNewAgent("Scheduler", fJADEScheduler);
			fSchedulerController.start();
		} catch (Exception e) { new Warning("Problem with adding scheduler to JADE registry.",e); }
	}

/**
 * IO Handling
 */
	public IOManager getIOMngr() {
		return fIOMngr;
	}

	public void loadMASfile(String pFilename) throws Exception {
		fReg = fIOMngr.loadMASFile(pFilename);
	}

	/** 
	 * @author W.Pasman jan09.
	 * Export database contents of given agent to given filename 
	 * @throws exception if error occurs, e.g. agent not exists, file can not be created, etc.
	 * @param addkb set to true to include knowledge base in export
	 * @param addbeliefs set to true to include belief base in export
 	 * @param addgoals set to true to include goal base in export
	 */
	public void exportDB(String agentName, String filename, boolean addkb, boolean addbeliefs, boolean addgoals) throws Exception {
		String ms = mentalStateToString(agentName, addkb, addbeliefs, addgoals);
		ms = ms.replaceAll("\n",".\n"); // TODO: move this to method mentalStateToString. CHECK this is weird, why is there no "." terminating these prolog sentences?
		FileWriter fw = new FileWriter(filename);
		fw.write(ms);
		fw.close();
	}
	
	/**
	 * @author W.Pasman jan09.
	 * Returns (parts of a) mental state of agent as a string.
	 * @modified Wouter 30jul09: you can now select which parts are exported.
	 * Note that mailbox and percept base are considered a part of the belief base.
	 * @param addkb set to true to include knowledge base in export
	 * @param addbeliefs set to true to include belief base in export
 	 * @param addgoals set to true to include goal base in export
	 * @throws Exception if error occurs, eg agent not exists or its database is not yet ready.
	 */
	public String mentalStateToString(String agentName, boolean addkb, boolean addbeliefs, boolean addgoals) throws Exception {
		String text="";
		Agent agt = fReg.getAgent(agentName);
		// see also DatabasePanel.java but here we get all belief bases instead of just first one.
		if (agt.getMentalState()==null) // this can happen if we screw up some init code so keep the check.
			throw new IllegalStateException("Agent "+agentName+" has not yet initialised its databases");
		
		// CHECK: is this exception actually possible? Would seem that something is wrong with user interface in that case...
		if (agt==null)
			throw new IllegalArgumentException("Agent "+agentName+" is not running");

		if (addkb) {
			// first convert the KB to string.
			text+="% ----- Knowledge -----\n";
			ArrayList<Formula> formulas = agt.getGOALProgram().getKnowledge();
			for (Formula formula : formulas)
				text +=formula+"\n";
		}
		text=text+agt.getMentalState().toString(addbeliefs, addgoals);

		return text;
	}

/**
 * DEBUGGER Handling
 */
	/** 
	 * @return observer for given agent name, or null if not found.
	 */
	public MyDebugObserver getDebugObserver(String agentName) {
		for (MyDebugObserver debugObserver : debugObservers)
			if (debugObserver.getAgentName().equals(agentName))
				return debugObserver;
		return null;
	}
	
	/**
	 * @return observer for given agent name and create one if not yet exists.
	 */
	public MyDebugObserver getOrCreateDebugObserver(String agentName) {
		MyDebugObserver observer = getDebugObserver(agentName); 
		if (observer==null) { // HACK ASSUMPTION: there is a one-to-one correspondence between observers and agents
				//  Wouter: THIS ASSUMPTION IS INCORRECT. But will do as long as we are in single-UI mode.
			Debugger theAgentDebugger = fReg.getAgent(agentName).getDebugger();
			 // EFFICIENCY ISSUE. Routing debug messages first to PM and then 
			 // to panel is very inefficient. We need to think about fix. See trac 696
			observer = new MyDebugObserver(agentName, theAgentDebugger) {
				public void update(DebugInfo info) {
					// if agent goes asleep or awakes, inform the agents.
					switch (info.getInfoType()) {
					case AGENT_HALTED: // TODO: can we change this to AGENT_PAUSED? Can we change duplicates to single label; AGENT_HALTED and AGENT_ASLEEP, AGENT_STEPPING and AGENT_STEPS.
						setChanged();
						notifyObservers(new PlatformEvent(EventType.AGENT_ASLEEP,info.getAgentName()));
						break;
					case AGENT_RUNNING:
						setChanged();
						notifyObservers(new PlatformEvent(EventType.AGENT_AWOKE,info.getAgentName()));
						break;
					case AGENT_STEPPING:
						setChanged();
						notifyObservers(new PlatformEvent(EventType.AGENT_STEPS,info.getAgentName()));
						break;
					}					
				}
			};
			debugObservers.add(observer);
			theAgentDebugger.subscribe(observer);
		}
		return observer;
 	}
	
	public void removeObserver(MyDebugObserver observer) {
		if (observer!=null) {
			observer.getDebugger().unsubscribe(observer);
			debugObservers.remove(observer);
		}
	}
	
	/** 
	 * @return all existing debug observers.
	 */
	public ArrayList<MyDebugObserver> getDebugObservers() {
		return debugObservers;
	}
	
	/**
	 * Sets a global debug level that applies to stepping for all agents
	 */
	public void setDebugLevel(int level) {
		for (MyDebugObserver obs:debugObservers) {
			obs.getDebugger().setLevel(obs, level);
		}
	}

	
/**
 * MIDDLEWARE Handling
 */
	public AgentContainer getMainContainer() { 
		return fJADEContainer;
	}
	
	/**
	 * Scheduler is another agent in the JADE MAS, but not a GOAL-JADE agent.
	 */
	public JadeScheduler getScheduler() {
		return fJADEScheduler;
	}
	

/**
 * ENVIRONMENT Handling
 */
	public void resetEnvironment() throws Exception {
		// DOC: This method is implemented only if the environment facilitates a reset by third party software.
		if (fEnv == null)
			throw new Exception("No environment is available");
		fEnv.reset();
	}
	public void regenerateEnvironment() throws Exception {
		// DOC: This method is implemented only if the environment facilitates a reset by third party software.
		if (fEnv == null)
			throw new Exception("No environment is available");
		try {fEnv.reGenerate();
		} catch (AbstractMethodError e){
			throw new Exception("Regenerate not implemented.");
		}
	}
	
}