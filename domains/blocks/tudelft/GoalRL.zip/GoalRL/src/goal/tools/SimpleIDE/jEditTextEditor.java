package goal.tools.SimpleIDE;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import javax.swing.JOptionPane;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import org.gjt.sp.jedit.Mode;
import org.gjt.sp.jedit.ViewSubstitute;
import org.gjt.sp.jedit.jEdit;
import org.gjt.sp.jedit.buffer.JEditBuffer;
import org.gjt.sp.jedit.searchstandalone.SearchAndReplace;
import org.gjt.sp.jedit.searchstandalone.SearchDialog;
import org.gjt.sp.jedit.syntax.ModeProvider;
import org.gjt.sp.jedit.textarea.StandaloneTextArea;
import org.gjt.sp.jedit.textarea.TextArea;
import org.gjt.sp.jedit.Registers;
import org.gjt.sp.jedit.guistandalone.CompleteWord;
//import org.gjt.sp.jedit.print.BufferPrinter1_4;


/**
 * This is some glue code to comply a jEdit pane with a TextEditorInterface.
 * see also org/gjt/sp/jedit/actions.xml in the jEdit code.
 * @author W.Pasman
 */
public class jEditTextEditor extends TextEditorInterface {

	ViewSubstitute view;
	
	/** it is allowed to give null as filename, in which case we open empty editor */
    public jEditTextEditor (String pFilename) throws Exception {
    	super(pFilename);
    	
    	view=new ViewSubstitute();

		jEdit.initSystemProperties();
		
		TextArea text = StandaloneTextArea.createTextArea(view); // this creates stand-alone textarea.
		view.setTextArea(text);
		
		Mode mode; // the mode of this file
		// TODO use the catalog to guess the filetype.
		
		if (pFilename.endsWith(".mas")) {
			mode = new Mode("mas"); 
			mode.setProperty("file","modes/mas.xml");
			ModeProvider.instance.addMode(mode);
		} else if (pFilename.endsWith(".pl")) {
			mode = new Mode("prolog"); 
			mode.setProperty("file","modes/prolog.xml");
			ModeProvider.instance.addMode(mode);

		}else {
			Mode prologmode = new Mode("prolog");  
			prologmode.setProperty("file","modes/prolog.xml");
			ModeProvider.instance.addMode(prologmode);
		
			mode = new Mode("goal");
			mode.setProperty("file","modes/goal.xml");
			ModeProvider.instance.addMode(mode);
		}
		if (pFilename!=null) text.getBuffer().insert(0, ReadFile(pFilename));
		text.getBuffer().setDirty(false); // not dirty, we now match the file.
		text.getBuffer().setMode(mode);
		GoToLine(0); // otherwise we would get at the last line (mantis 523), as result of the insert.

		setLayout(new BorderLayout());
		add(text, BorderLayout.CENTER);
		
		setupObserver(text);
    }
    
	public void Save() throws Exception {
		SaveAs(filename); // use the initial filename.
	}
	
	public void SaveAs(String newfilename) throws Exception {
		JEditBuffer buffer=view.getBuffer();
		WriteFile(newfilename,buffer.getText(0,buffer.getLength()));
		view.getBuffer().setDirty(false);
		filename=newfilename;
	}
	
	public boolean isDirty() { return view.getBuffer().isDirty(); }

	public void Undo() throws Exception { view.getBuffer().undo(view.getTextArea()); }
	
	public void Redo() throws Exception { view.getBuffer().redo(view.getTextArea());}

	public void Cut() throws Exception { Registers.cut(view.getTextArea(),'$'); }
	
	public void Copy() throws Exception { Registers.copy(view.getTextArea(),'$'); } 

	public void Paste() throws Exception { Registers.paste(view.getTextArea(),'$',false); } 
	
	public void SearchReplace() throws Exception {  
		SearchDialog.showSearchDialog(view,view.getTextArea().getSelectedText(),SearchDialog.CURRENT_BUFFER);
	}

	public void SearchNext() throws Exception { 
		SearchAndReplace.find(view);
	}
	
	public void GoToLine(int lineNumber) throws Exception {
		view.getTextArea().setCaretPosition(view.getBuffer().getLineStartOffset(lineNumber));
	}
	
	public void AutoComplete() throws Exception { 
		CompleteWord.completeWord(view);
	}

	/** read file into a String.
	 * CHECK: we dropped all save functionality from jEdit: autosave, special character 
	 * support, etc. The save routines in jEdit are extensive and intricately linked
	 * with View, Buffer (which is NOT the JEditBuffer) etc. 
	 * However all it takes to do a basic load and save is a few lines of code as below. 
	 */
	public static String ReadFile(String filename) throws Exception {
		String filecontents="";
		//System.out.println("reading file "+filename);
	    
      //use buffering, reading one line at a time
      //FileReader always assumes default encoding is OK!
      BufferedReader input =  new BufferedReader(new FileReader(filename));
        /*
        * readLine is a bit quirky :
        * it returns the content of a line MINUS the newline.
        * it returns null only for the END of the stream.
        * it returns an empty String if two newlines appear in a row.
        */
      String line;
      while ((  line = input.readLine()) != null){
          filecontents=filecontents+line+"\n";
      }
	  input.close();
	  return filecontents;
	}
	
	/** write a string into a file */
	public static void WriteFile(String filename, String contents) throws Exception {
	    FileWriter fstream = new FileWriter(filename);
	    BufferedWriter out = new BufferedWriter(fstream);
	    out.write(contents);
	    out.close();
	}
	
	public void Close() throws Exception {
		if (view.getBuffer().isDirty()) {
			int choice = JOptionPane.showConfirmDialog(this,
					"Save changes before closing?", "Save File Before Close?",
					JOptionPane.YES_NO_CANCEL_OPTION);
			switch(choice) {
			case JOptionPane.YES_OPTION: Save();break;
			case JOptionPane.NO_OPTION: break;
			case JOptionPane.CANCEL_OPTION: throw new Exception("Close cancelled by user");
			default: throw new Exception("Choice pane returned unknown choice: "+choice);
			
			}	
		}
	}
	
	/** check if file was changed, and if so ask user if he wants to reload 
	 * changes can happen in two ways
	 * 1. user edited in this editor
	 * 2. someone replaced the file in the FS */
	public void Reload() throws Exception {
		int choice = JOptionPane.showConfirmDialog(this,
				"Do you want to reload "+filename, "Reload?",
				JOptionPane.YES_NO_CANCEL_OPTION); // Wouter: CANCEL=NO in this case.
		if (choice!=JOptionPane.YES_OPTION) return;
		// OK, confirmation received. reload.
		// No need to check time etc, just reload.

		view.getBuffer().insert(0, ReadFile(filename));
		view.getBuffer().setDirty(false); // not dirty, we now match the file.
		GoToLine(0); // otherwise we would get at the last line (mantis 523), as result of the insert.
	}
	
	public void Print() throws Exception { 
		ModifiedBufferPrinter1_4.print(view,view.getBuffer(),false); 
	}

	public void PageSetup() throws Exception { 
		ModifiedBufferPrinter1_4.pageSetup(null); // we dont have a view but from source code inspection we dont need it anyway 

	}

	// set up the editor's observer.
	public void setupObserver(final TextArea text) {
		text.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent evt) {
				//System.out.println("evt"+evt+" "+text.getCaretPosition());
				// Check org.gjt.sp.jedit.gui.statusbar.java line 306ev
                int caretPosition = text.getCaretPosition();
                int currLine = text.getCaretLine();

                // there must be a better way of fixing this...
                // the problem is that this method can sometimes
                // be called as a result of a text area scroll
                // event, in which case the caret position has
                // not been updated yet.
                if(currLine >= text.getBuffer().getLineCount())
                        return; // hopefully another caret update will come?

                int start = text.getLineStartOffset(currLine);
                int dot = caretPosition - start;

                // see above
                if(dot < 0)
                        return;
                String status=(currLine+1)+","+(dot+1);
                observable.setChanged();
                observable.notifyObservers(status);
			}
		});
		
	}
}
	