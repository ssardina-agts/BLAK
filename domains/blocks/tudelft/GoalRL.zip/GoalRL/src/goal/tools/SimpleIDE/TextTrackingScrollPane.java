package goal.tools.SimpleIDE;

import goal.tools.errorhandling.Warning;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.Utilities;

/**
 * This class creates a text area that can be scrolled, 
 * but if you move the scroll bar close to the bottom it wil stick there,
 * following new text entering the area.
 * @author W.Pasman 3sept08
 * 
 * I really would like to extend the JTextArea here too but Java does not allow....
 * This causes a lot of redundant copies of JTextArea functions inside this class....
 */
public class TextTrackingScrollPane extends JScrollPane implements ActionListener {
	
	JTextArea textarea;
	JScrollBar vscrollbar;
	boolean track_bottom=true;
	private int max_lines;
	

	public TextTrackingScrollPane(String initial_text) {
		this(initial_text,IntrospectorPrefPanel.getMaxLines());
	}
	/**
	 * @param max is the maxlines number of lines in the area. Oldest lines will be erased when 
	 * you append beyond this limit. Must be at least 10.
	 */
	public TextTrackingScrollPane(String initial_text, int maxlines) {
		if (maxlines<=10) throw new IllegalArgumentException("max number of lines must be at least 10");
		max_lines=maxlines;
		textarea=new JTextArea(initial_text);
		textarea.setEditable(false);
		setViewportView(textarea);
	    vscrollbar=getVerticalScrollBar(); 
	    vscrollbar.addAdjustmentListener(new AdjustmentListener() {
	    	public void adjustmentValueChanged(AdjustmentEvent e) {
	    		
	    		if (vscrollbar.getValueIsAdjusting()) { // this is true when dragging
	    			 // note, extra brackets are needed, bug or strange behaviour of compiler??
	    			track_bottom=((vscrollbar.getValue()+vscrollbar.getVisibleAmount())>vscrollbar.getMaximum()-16);
	    		} else {
	    			if(track_bottom) {
	    				vscrollbar.setValue(vscrollbar.getMaximum()); 
	    				//textarea.setCaretPosition(textarea.getDocument().getLength());
	    			}
	    		}
	    	}
	    });
	    
		JPopupMenu popup=new JPopupMenu();
        JMenuItem menuItem = new JMenuItem("Clear");
        menuItem.addActionListener(this);
        popup.add(menuItem);
	    
        textarea.addMouseListener(new PopupListener(popup));
	}
	
	/** disabled 6aug09, to avoid people calling append directly on textarea
	 *  */
    //public JTextArea getTextArea() { return textarea; }

    public void setMaxLines(int max) {
    	max_lines=max;
    }
    
    public void setText( String t) {
    	textarea.setText(t);
    }
    
    public void setEditable( boolean b) {
    	textarea.setEditable(b);
    }
    
    public void setFont(Font f) {
    	super.setFont(f); // stupid, JScrollbar also has a setfont() call... we intended here to support the
    	 // textarea.setFont.... but textarea may not yet exist at this point....
    	if (textarea!=null) textarea.setFont(f);
    }
    
    public void append(String text) {
		textarea.append(text);
		int rowEnd;
	 	while (textarea.getLineCount()>max_lines) {
			// erase number of lines from the top...
	 		try {
	 			rowEnd=Utilities.getRowEnd(textarea, 1);
	 		}
	 		catch (BadLocationException e) {
	 			new Warning("internal error",e);
	 			return;
	 		}
	 		textarea.replaceRange(null,0,rowEnd); // delete row.
		}
    }
    
    public void actionPerformed(ActionEvent e) {
    	String action = ((JMenuItem)e.getSource()).getText();
        // REMOVE System.out.println(action + "\n");
        if (action.equals("Clear")) {
        	textarea.setText("");
        }
    }
}


 // handle right-mouse clicks to show the popup menu.
class PopupListener extends MouseAdapter {
    JPopupMenu popup;

    PopupListener(JPopupMenu popupMenu) {
        popup = popupMenu;
    }

    public void mousePressed(MouseEvent e) {
        maybeShowPopup(e);
    }

    public void mouseReleased(MouseEvent e) {
        maybeShowPopup(e);
    }

    private void maybeShowPopup(MouseEvent e) {
        if (e.isPopupTrigger()) {
            popup.show(e.getComponent(),
                       e.getX(), e.getY());
        }
    }
}
