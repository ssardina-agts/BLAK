package goal.tools.debugger;

import goal.tools.debugger.DebugInfo.InfoType;
import goal.tools.errorhandling.Warning;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.prefs.Preferences;

/** 
 * @author W.Pasman june 2008
 * debug info handler.
 * The main job is to decouple the debug info generation from the handler
 * that is probably inside the thread of the debugger window.
 * Can reroute debug info to all apps that want it.
 * I think this is thread safe. Multithreading and parallel debugging already supported.
 * 
 * add a DebugObserver to get default debug message handling.
 * just create a Debugger where you need it. It will join with the existing debugger.
 * 
 * Important: always call bp() BEFORE the action takes place, so that debugger indicates what
 * the system is going to do. This enables the user to see what happens BEFORE the problem occurs,
 * as the system may behave erratically AFTER the error occured and post-mortem analysis is much
 * harder than seeing that what was promised is not actually done.
 * 
 * GENERAL NOTES ON DEBUG LEVELS-- NOT UPTO DATE!!! We now go up to level 10.
 * Level 1: on perception-action cycle, on the perception part just before the action.
 * Level 2: action performed
 * Level 3: actions enabled, and queries involved to check that; achieved goals
 * Level 4: raw queries involved in determining achieved goals; rules with IF satisfied and holding precond.
 * Level 5: raw queries involving determining which rules have satisfied preconditions
 * 
 * 
 * version 1 (before 13june2008): enter() and exit(int level) are used to control debug levels.
 * version 2 13jun08:  db(type,message,level) replaces Info(level,message).
 * 					dropped currentLevel. new TYPE of debug events.
 * 					added per-observer debug level.
 * 					sorting of messages now happens at the debugger instead of debugobserver.
 * version3 17jun08: implemented message queue and wait mechanism in debugger.
 * 
 * There may be multiple users connected to the system, each using his own debugger.
 * Obviously people will have to synchronise to avoid confusion, 
 * the debugger will run only if every observer agrees to run.
 * This may pose some extra GUI issues....
 * 
 * The Debugger runs in the AGENT's thread.
 * An agent can be in HALT, RUN and STEP mode.
 * You can request RUN or STEP mode via the step and run function.
 * Such requests will be checked at the next break point of the agent.
 * If agent reaches breakpoint with observer in STEP mode and at sufficient level, 
 * agent will be HALTed
 * 
 * An subscribed observer "hits" a breakpoint whenever a breakpoint
 * with sufficient level is encountered. Multiple observers can hit at the same time.
 * If you have multiple hits, 
 * the agent will continue only if ALL commanders are out of HALT mode,
 * and running halts whenever one or more observers hit a breakpoint.
 * 
 * You get an observer out of halt mode by requesting RUN or STEP for that observer.
 * 
 * We currently do not use a standard Observer/Observable pattern because agents may not be interested in all events,
 * depending on the debug settings.
 */


public class Debugger {
	
	String agent_name=null; // every debugger is coupled to unique agent. This name should be unique id of agt.

	public static final Integer DEFAULT_LEVEL=2; // Default: DOC which info is provided here?.

	private Thread theThreadUnderDebug; // Currently set automatically to the thread creating this object.

	 /** all subscribed observers */
	ArrayList<DebugObserver> myObservers = new ArrayList<DebugObserver>();
	
	 /** Debug level for each observer.
	    observer is interested in all messages at or below this level.
	 	level 0 is top level, higher levels are more detail/bottom level*/
	Hashtable<DebugObserver,Integer> levels=new Hashtable<DebugObserver,Integer>();
	
	
	 /** run mode for each observer. We halt immediately every time we sent a debug message
	  * to an observer in the STEP mode. */
	Hashtable<DebugObserver,Integer> modes=new Hashtable<DebugObserver,Integer>();
	 // run modes for an agent.
	public final static int HALT=1; // agent is NOW stopped
	public final static int STEP=2; // agent will stop at next breakpoint of requested level
	public final static int RUN=3;  // agent will run until further notice.	
	
	
	public Debugger(String name) { 
		agent_name=name;
		theThreadUnderDebug=Thread.currentThread(); 
	}

	 /** bp informs the debugger that the thread under debug has reached a breakpoint. 
	  * this should be called only by the agent, never by an external thread 
	  * This call may block if there are observers in step mode at this level.
	  * It unblocks only after all these observers agreed to continue. 
	  * IMPORTANT: do NOT place bp inside a synchronized block if you want to support multithreading.
	  * */
	public void bp(String type,String msg,int level) 
	{
		// determine the info type: if we will halt, use InfoType.AGENT_SLEEPS else use the BP
		
		ArrayList<DebugObserver> interested=getInterestedObs(level);
		if (interested.isEmpty()) return; 

		// update sleepmode: put the notified observers that were in STEP mode to HALT mode.
		for (DebugObserver obs: interested) { 
			if (modes.get(obs)==STEP) modes.put(obs, HALT); 
		}		
		
		
		boolean cont=canContinue();
		// TODO check that thread is authorized to call this. Not working as it was.
		//if (Thread.currentThread()!=theThreadUnderDebug)
		//	throw new AccessControlException("thread that calls debugger.bp has to own the debugger");
		DebugInfo info = new DebugInfo(cont?DebugInfo.InfoType.BP:DebugInfo.InfoType.AGENT_HALTED,agent_name,type,level,msg);
		broadcastInfo(myObservers,info); // notify all observers?
		 // CHECK the problem is, only the ones that actually halted can ask the process to continue.

		
		if (!cont) { // wait for agent wakeup and notify observers of that event too
			try { waitForContinue(); }
			catch (InterruptedException e) 
			{  new Warning("breakpoint was forced to continue due to InterruptedException. Agent is killed!",e);
				throw new ThreadDeath();
			}
			updateListeners();
		}
	}

	
	ArrayList<DebugObserver> getInterestedObs(int level) {
		ArrayList<DebugObserver> interested=new ArrayList<DebugObserver>();

		for (DebugObserver obs: myObservers) {
			if (level <= levels.get(obs)) 
			{
				interested.add(obs);
			}
		}

		return interested;
	}

	
	/*
	 * Check all observers and inform those interested.
	 * We determine here which are interested to save lots of messages.
	 * @returns all observers that received the message
	 */
	private synchronized void broadcastInfo(ArrayList<DebugObserver> who, DebugInfo info) {		
		for (DebugObserver obs: who) obs.update(info);
	}
	
	 /** Wait until all observers are out of HALT mode 
	  * @param observers is list of observers that should request continuation 
	  * @throws InterruptedException if someone interrupts the debugger
	  * synchronized is needed to avoid IllegalMonitorStateException on wait() call.
	  * */
	private synchronized void waitForContinue() throws InterruptedException
	{
		while (!canContinue()) wait();
	}
	
	
	/** check that all observers are out of the HALT mode. */
	private synchronized boolean canContinue()
	{
		for (DebugObserver obs:myObservers)
		{
			if (modes.get(obs)==HALT) return false;
		}
		return true;
	}

	 /** update ALL listeners about latest state of debugger/agent running status.
	  * The info field will not contain a text message.
	  * This is needed both when agent hits a breakpoint and when someone 
	  * calls one of the functions controlling debugging eg 'step' or 'run' */
	void updateListeners() {
		 // are we now running or stepping?
		boolean stepping=false;
		for (DebugObserver obs: myObservers) { 
			if (modes.get(obs)==STEP) stepping=true; 
		}	
		DebugInfo info=new DebugInfo(stepping?DebugInfo.InfoType.AGENT_STEPPING:DebugInfo.InfoType.AGENT_RUNNING, 
				agent_name, null, 0, null);
		broadcastInfo(myObservers,info);
	}
	
	
	 /* ************** FUNCTIONS TO CONTROL DEBUGGING **************** */

	/** These functions are called by DebugObservers to control the debugging process */
	
	/** Set the level of the messages you want to receive.
		Higher means more  and more detailed messages*/
	// TODO check that 'synchronized' means that levels is not used by anyone else.
	public synchronized void setLevel(DebugObserver obs,int level) { levels.put(obs, level); }

	/** subscribe. Subscribing twice has no effect (TODO check that) 
	 * BTW you can change to STEP mode before running the agent,
	 * by talking to the debugger before asking Jade to run the agent. 
	 * (that is in version 223) 
	 * Default subscription puts the debug at the DEFAULT_LEVEL.
	 * PERFORMANCE HIT: Adding a debug observer will give an agent (and entire system)
	 * a serious performance hit.
	 * Therefore if you are not interested in debug events, please remove your observer
	 * from the subscribe list.
	 * */
	public synchronized void subscribe(DebugObserver obs) {
		myObservers.add(obs);
		levels.put(obs,DEFAULT_LEVEL);
		modes.put(obs, RUN);
	}

	 /** Call this to put agent in step mode. This will continue the agent until 
	  * it hits the next breakpoint with sufficient high level,
	  * (that is, if no other debugger also halted it) */
	public synchronized void step(DebugObserver obs)
	{
		modes.put(obs,STEP);
		notify();
		updateListeners();
	}
	
	public synchronized void run(DebugObserver obs)
	{
		modes.put(obs,RUN);
		notify();
		updateListeners();
	}	
	
	public synchronized void unsubscribe(DebugObserver obs) {
		myObservers.remove(obs);
		levels.remove(obs);
		notify();
		updateListeners();
	}
	
	/** get current run mode for given observer. null if observer unknown */
	public int getRunMode(DebugObserver obs)
	{ return modes.get(obs); }

}


