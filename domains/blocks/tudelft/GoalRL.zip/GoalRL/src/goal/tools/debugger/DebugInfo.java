package goal.tools.debugger;

/**
 * 
 * This class is used to store info about a single debugging event
 * @author W.Pasman june 2008
 * 
 */

public class DebugInfo {
	/** BP: agent passed a breakpoint. 
	 * AGENT_HALTED: agent stopped at a breakpoint
	 * AGENT_STEPPING: agent is now running but in STEP mode 
	 * AGENT_RUNNING: agent is now running and not in STEP mode */
	public enum InfoType {BP, AGENT_HALTED, AGENT_STEPPING, AGENT_RUNNING};

	
	// Class fields
	InfoType infotype;
	String agent_name;
	public int level;	// level of the debug event
	String location;
	String message;		// message of the debug event
	
	
	// Class constructor
	/** @param type is InfoType: BP, Halted, Stepping, Running
	 * @param name is name of agent that is under debug control
	 * @param loc is the location of the breakpoint
	 * @param lev is the debug level at which the breakpoint occured
	 * @param msg is the message associated with the breakpoint.
	 * 
	 * The loc, lev and msg fields may be empty if only the InfoType changes 
	 */
	public DebugInfo(InfoType type, String name, String loc, int lev, String msg) {
		level=lev; agent_name=name; location=loc; message=msg; infotype=type;
	}

	public InfoType getInfoType() { return infotype; }
	
	public String getAgentName() { return agent_name; }
	
	public String getMessage() { return message; }
	
	// Class method
	// Format debug info
	public String toString () {
		return "["+agent_name+","+location+","+level+ "] "+message;
	}
	
	public void setInfoType(InfoType t) { infotype=t; } 
}