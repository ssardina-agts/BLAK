package goal.tools.SimpleIDE;


import goal.tools.PlatformManager;
import goal.tools.debugger.DebugInfo;
import goal.tools.debugger.DebugObserver;
import goal.tools.debugger.Debugger;

import java.awt.BorderLayout;
import java.awt.Font;
import java.rmi.AlreadyBoundException;

import javax.swing.JPanel;


/** shows Debug Trace Text and a level number input field.
 * Note that this panel uses a debug observer separate from the PlatformManager  */
public class DebugTextPanel extends JPanel implements DebugObserver {
	PlatformManager platformmgr;
	Debugger agentdebugger;
	String agentname=null; // null if agent is dead.
	TextTrackingScrollPane thetextarea;
	
	public DebugTextPanel(PlatformManager pm) {
		setLayout(new BorderLayout());
		thetextarea=new TextTrackingScrollPane("");
		 // figure out: limit max #rows in panel
		platformmgr=pm;
		
		thetextarea.setFont(new Font("Arial Narrow", Font.PLAIN, 12));
		add(thetextarea,BorderLayout.CENTER);


	}
	
	/**
	 * @throws exception if agent already bound to a debugger */
	public void agentBorn(String newagentname) throws AlreadyBoundException {
		if (agentname!=null) throw new AlreadyBoundException("DebugTextPanel for "+agentname+" is already bound");
		agentname=newagentname;
		agentdebugger=platformmgr.getRegistry().getAgent(agentname).getDebugger();
		agentdebugger.subscribe(this);
		agentdebugger.run(this); // we only want to get reports so we say run.
	}

	public void agentDied() {
		thetextarea.append("**********agent died**********\n");

		agentdebugger.unsubscribe(this);
		agentname=null;
	}
	
	public void update(DebugInfo info) {
		if (info.getMessage()==null) return; // do not print non-messages.
		thetextarea.append(info+"\n");
	}

	public Debugger getDebugger() { return agentdebugger; }
	
	/** call this before closing the panel so that we unsubscribe properly */
	public void Close() {
		agentDied();
	}
	
	public void setDebugLevel(int level) {
		agentdebugger.setLevel(this, level);
	}

}