package goal.tools.SimpleIDE;

import java.io.File;
import java.sql.Time;
import java.util.Date;
import java.util.Observer;
import java.util.Observable;

import javax.swing.JPanel;

/**
 * @author W.Pasman 25jun08
 * This really should be an interface, except that an interface
 * can not extend a JPanel...
 * It could be an abstract class but then partial implementations
 * would have to do all the throw Exception() stuff for non-implemented parts.
 * 
 * Wouter: I prefer a java interface over a XML construct, 
 * because this way we can plug different interfaces without
 * having to change XML files, and we can even use different
 * implementations of the interface at the same time. 
 * 
 * 
 */
class TextEditorInterface extends JPanel {
	
	String filename;
	long loadingtime; // the time that the file was opened. If no file, this is the time the editor opened.
	
	int serial=1;
	Observable1 observable=new Observable1(); 
		// this is the object handling observations of the editor.
		// modify it by adjusting the observable object to your needs.
	
	/** it is allowed to give null as filename, in which case 
	 * a new filename is generated  and an empty window is supposed to be opened.
	 * We do not provide a TextEditorInterface() constructor,
	 * to remind you that we really expect the filename to start with. */
	TextEditorInterface(String newfilename) throws Exception
	{
		if (newfilename==null) {
			filename="Untitled-"+serial++;
		} else {
			filename=newfilename;
		}
		File f=new File(filename);
		if (f.exists()) loadingtime=f.lastModified();
		else loadingtime=(new Date()).getTime();
	}
	
	public void Save() throws Exception { throw new Exception("not implemented"); }
	
	/** saveas should save file under new name and adopt the new filename for future save. 
	 * IDE will switch the panel's name to the new name */
	public void SaveAs(String filename) throws Exception { throw new Exception("not implemented"); }
	
	/** Warning. This closes the file but does not close the panel. */
	public void Close() throws Exception {}

	 /** @return true if file was edited and not yet saved.*/
	public boolean isDirty() { return true; }

	public String getFilename() { return filename; }
	
	public void Undo() throws Exception { throw new Exception("not implemented"); }
	
	public void Redo() throws Exception { throw new Exception("not implemented"); }

	public void Cut() throws Exception { throw new Exception("not implemented"); }
	
	public void Copy() throws Exception { throw new Exception("not implemented"); }

	public void Paste() throws Exception { throw new Exception("not implemented"); }
	
	public void SearchReplace() throws Exception { throw new Exception("not implemented"); }
	
	public void SearchNext() throws Exception { throw new Exception("not implemented"); }
	
	public void GoToLine(int linenr) throws Exception { throw new Exception("not implemented"); }
	
	public void AutoComplete() throws Exception { throw new Exception("not implemented"); }
	
	/** Reload is used to load the current version from disk. */
	public void Reload() throws Exception { throw new Exception("not implemented"); }

	public void Print() throws Exception { throw new Exception("not implemented"); }

	public void PageSetup() throws Exception { throw new Exception("not implemented"); }

	 /** Use this to observe this editor object. Default it does nothing. 
	  * It is ment to inform an enclosing application about the status of the editor,
	  * for instance the caret position, so that the enclosing editor can show
	  * this information at a uniform place */
	public Observable1 getObservable() { return observable; }
}
