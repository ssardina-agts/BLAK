package goal.tools.SimpleIDE;

import javax.swing.*;
import javax.swing.tree.*;
import java.lang.RuntimeException;

/**
 * Data structure for file node in file panel which stores info related to the nodes in the tree,
 * and contains associated icon pictures to indicate file type in file panel.
 *
*/
public class FileNode extends DefaultMutableTreeNode implements IDENode {
	
	// Class fields
	String name; // short display name of agent, process, file, whatever.
	String filename; // full path to file
	private int type = ROOT;
	
	/** various values for type */
	public static final int ROOT=0;
	public static final int GOALFILE=10;
	public static final int MASFILE=11;
	public static final int UNKNOWNFILE=12;


	 // the icons, they are in principle static final but we load them once with the getIcon() from the class constructor
	static ImageIcon root,goalfile,masfile,otherfile,runningprocess,pausedprocess;
	
	ImageIcon getIcon(String iconName) {
		return new ImageIcon(getClass().getClassLoader().getResource("goal/tools/SimpleIDE/icons/"+iconName));
	}
	

	/** @param nm is "view" name, i.e. the string made visible in edit view
	 * @param tp is type
	 * @pFilename is additional details, depending on type of node.
	 * should be String (full path name to file) for files
	 * and Agent for a process.
	 */
	public FileNode(String nm, int tp, String pFilename) { 
		name = nm; 
		type = tp; 
		filename = pFilename;
		if (root==null) root=getIcon("run.gif");
		if (goalfile==null) goalfile=getIcon("goalfile.gif");
		if (masfile==null) masfile=getIcon("goalfile.gif");
		if (otherfile==null) otherfile=getIcon("typelessfile.gif");
		if (runningprocess==null) runningprocess=getIcon("runningprocess.gif");
		if (pausedprocess==null) pausedprocess=getIcon("pausedprocess.gif");
	}
	
	 /** set a new name */
	public void setName(String nm, String filen) {
		name=nm;
		filename=filen;
	}

	// Class methods
	public String getName() {
		return name;
	}
	
	public String getFilename() {
		return filename;
	}
	
	
	public int getType() {
		return type;
	}
	
	public ImageIcon getIcon() {
		switch (type) {
		case ROOT:
			return root;
		case GOALFILE:
			return goalfile;
		case MASFILE:
			return masfile;
		case UNKNOWNFILE:
			return otherfile;
		default:
			throw new RuntimeException("Internal error, Unknown type of filenode: "+type);
		}
	}
	
	public String toString() {
		return "Filenode["+name+","+typeToString(type)+"]";
	}

	public String typeToString(int t) {
		switch (type) {
		case ROOT:
			return "ROOT";
		case GOALFILE:
			return "GOALFILE";
		case MASFILE:
			return "MASFILE";
		case UNKNOWNFILE:
			return "UNKNOWNFILE";
		default: return "NOT SET";
		}
	}

}
