package goal.tools.SimpleIDE;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.prefs.Preferences;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/** @author W.Pasman 24mar09
 * This panel stores the IDE preferences and provides a GUI to edit them. */

public class IDEPrefPanel extends JPanel implements ChangeListener 
{
	static Preferences myPreferences= Preferences.userNodeForPackage(IDEPrefPanel.class); // system wide store and better support than Properties()
	
	JCheckBox rememberwinsize;
	JTextArea winsize; // copy of "winwidth" and "winheight" as in the current preferences.
	JCheckBox rememberconsolesize; 
	JTextArea consolesize;
	JCheckBox showtoolbar;
	JCheckBox rerouteconsole;
	static final int TOOLBARHEIGHT=100; // estimated toolbar height... see Mantis 598..
	JLabel openMAStext;
	JTextField openMASs; // MASs that were open at time of last close
	JCheckBox reopenMASs; // re-open MASs that were open last time?
	

	public IDEPrefPanel() {
		rememberwinsize=new JCheckBox("Remember main window size");
		winsize=new JTextArea("      width="+myPreferences.getInt("winwidth", 800)+
				" height="+myPreferences.getInt("winheight", 600));
		winsize.setEditable(false);
		rememberconsolesize=new JCheckBox("Remember console size");
		consolesize=new JTextArea("      current pos:"+myPreferences.getInt("consolesize", myPreferences.getInt("winheight", 600)*7/10));
		consolesize.setEditable(false);
		showtoolbar=new JCheckBox("Show toolbar");
		rerouteconsole=new JCheckBox("Show console output in IDE's console (changes take effect after restart of GOAL)");

		openMAStext=new JLabel("MASs that were open at last start-up");
		openMASs=new JTextField("");
		openMASs.setEditable(false);
		reopenMASs=new JCheckBox("Re-open MASs at start-up");
		
		init();
		setLayout(new GridLayout(0,1));
		add(new JLabel("GUI Settings"));
		add(rememberwinsize); rememberwinsize.addChangeListener(this);
		add(winsize); 
		add(rememberconsolesize); rememberconsolesize.addChangeListener(this);
		add(consolesize);
		add(rerouteconsole); rerouteconsole.addChangeListener(this);
		add(new JSeparator());
		add(openMAStext);
		add(openMASs);
		add(reopenMASs); reopenMASs.addChangeListener(this);
		
	}
	
	/** copy settings from preferences to the check boxes */
	public void init() {
		rememberwinsize.setSelected(getRememberWinSize()); // 2nd arg is the default value
		rememberconsolesize.setSelected(getRememberConsoleSize());
		rerouteconsole.setSelected(getRememberRerouteConsole());
		openMASs.setText(getMASs().toString());
		reopenMASs.setSelected(getReopenMASs());
	}
	
	
	/** change most recent state */
	public void stateChanged(ChangeEvent e)  {
		
		myPreferences.putBoolean("rememberwinsize", rememberwinsize.isSelected());
		myPreferences.putBoolean("rememberconsolesize", rememberconsolesize.isSelected());
		myPreferences.putBoolean("rerouteconsole", rerouteconsole.isSelected());
		myPreferences.putBoolean("reopenmass", reopenMASs.isSelected());
	}

	 /** @returns the total height of the IDE window. */
	public static int getWinHeight() {
		int height=600;
		if (getRememberWinSize()) {
			height=IDEPrefPanel.myPreferences.getInt("winheight", 600);
		}
		return height;
	}
	
	public static int getWinWidth() {
		int width=800;
		if (getRememberWinSize()) {
			width=IDEPrefPanel.myPreferences.getInt("winwidth", width);
		}
		return width;
	}
	
	 /** @returns the height of the main area above the console, which is also the split position of the jsplitpane. */
	public static int getMainAreaHeight() {
		return getWinHeight()-TOOLBARHEIGHT-getConsoleAreaHeight();
	}
	
	public static int getConsoleAreaHeight() {
		int height=120; // the default size. 
		if (getRememberConsoleSize()) {
			height= myPreferences.getInt("consolesize", height);
		}
		return height;			
	}
	
	 /** @return  true when user wants us to remember winsize */
	public static boolean getRememberWinSize() {
		return myPreferences.getBoolean("rememberwinsize",true);
	}
	
	 /** @return  true when user wants us to remember console size */
	public static boolean getRememberConsoleSize() {
		return myPreferences.getBoolean("rememberconsolesize",true);
	}
	
	 /** @return  true when user wants us to reroute console output (System.out.println) to the GOAL console */
	public static boolean getRememberRerouteConsole() {
		return myPreferences.getBoolean("rerouteconsole",true);
	}
	
	public static boolean getReopenMASs() {
		return myPreferences.getBoolean("reopenmass",true); 
	}
	
	/** @return MASs that were open at last close. filenames should not contain comma. */
	public static ArrayList<String> getMASs() {
		String mass= myPreferences.get("lastusedmass", "[]");
		if (mass.length()<2) mass="[]"; // if user hacked prefs, this might happen?
		mass=mass.substring(1, mass.length()-1); // drop []
		ArrayList<String> maslist=new ArrayList<String>();
		if (mass.equals("")) return maslist; // catch bug in split....
		for (String mas: mass.split(",")) maslist.add(mas.trim()); // trim, split doesnot do that.
		return maslist;
	}
	
	/** save list of MASs to be used at next startup. filenames should not contain comma.*/
	public static void setMASs(ArrayList<String> mases) {
		myPreferences.put("lastusedmass", mases.toString());
	}
}