package goal.tools.SimpleIDE;

import javax.swing.*;
import javax.swing.tree.*;
import java.lang.RuntimeException;

/* Internal data structure for process nodes.
 * This class only stores info about nodes in a process tree, and contains some useful tools like icon pictures.
 * 
 * A process node may contain either the name of the mas file being executed or a GOAL agent process.
 * 
 * Wouter: BUG in DefaultMutableTreeNode: toString geeft altijd null?!?!?!
 * Dus altijd overriden als je hier niet in wil trappen....
 *
 */

public class ProcessNode extends DefaultMutableTreeNode implements IDENode {
	
	// Class fields
	private String name; // Short name for display of process name or mas file.
	private String details = null; // Only used for mas file node to give full path for to this file? not used at all?
	private int type = ROOT;
	private int status;
	
	// various values for type
	public static final int ROOT=0;
	//public static final int GOALFILE=10;
	public static final int MASFILE=11;
	//public static final int UNKNOWNFILE=12;
	public static final int GOALPROCESS=20;
	//public static final int UNKNOWNPROCESS=21;	
	public static final int ENVIRONMENTPROCESS=22;
	
	// types for status
	public static final int RUNNING=1;
	public static final int STEPPING=5; // added 27jul09 to reflect stepping process. 
	public static final int PAUSED=2;
	public static final int KILLED=3;
	public static final int UNKNOWN=4;

	
	static ImageIcon root,masfile,runningprocess,pausedprocess,killedprocess,steppingprocess;

	ImageIcon getIcon(String iconName) {
		return new ImageIcon(getClass().getClassLoader().getResource("goal/tools/SimpleIDE/icons/"+iconName));
	}

	
	// Constructor
	/** @param pName is 'screen' name
	 * @param pType is type
	 * @det is additional details, depending on type of node.
	 * should be String (full path name to file) for files and Agent for a process.
	 */
	public ProcessNode(String pName, int pType, String pDetails, int pStatus) {
		name = pName;
		type = pType;
		details = pDetails;
		status = pStatus;
		
		if (root==null) root=getIcon("run.gif");
		if (masfile==null) masfile=getIcon("goalfile.gif");
		if (runningprocess==null) runningprocess=getIcon("runningprocess.gif");
		if (steppingprocess==null) steppingprocess=getIcon("steppingprocess.gif");

		if (pausedprocess==null) pausedprocess=getIcon("pausedprocess.gif");
		if (killedprocess==null) killedprocess=getIcon("killedprocess.gif");
	}
	
	public String getName() {
		return name;
	}
	
	// DOC: process nodes do not have ref to filename; this caused more problems for me than that it helped
	//public String getDetails() {
	//	return details;
	//}
	
	public int getType() {
		return type;
	}
	
	
	public int getStatus() {
		return status;
	}
	
	public ImageIcon getIcon() {
		switch (type) {
		case ROOT: return root;
		case MASFILE: //return masfile;
		case GOALPROCESS:
			switch (status) {
			case PAUSED: return pausedprocess;
			case RUNNING: return runningprocess;
			case STEPPING: return steppingprocess;
			case KILLED: return killedprocess;
			default: return runningprocess;
			}
		case ENVIRONMENTPROCESS:
			return runningprocess;
		default:
			throw new RuntimeException("Internal error, Unknown type of process node: "+type);
		}
	}
	
	public String typeToString(int t) {
		switch (type) {
		case ROOT: return "ROOT";
		case MASFILE: return "MASFILE";
		case GOALPROCESS: return "GOALPROCESS";
		default: return "NOT SET";
		}
	}
	
	// @param s must be either RUNNING, PAUSED or KILLED.
	public void setStatus(int s) {
		status=s;
	}
	
	public String statusToString(int s) {
		switch (status) {
		case PAUSED: return "PAUSED";
		case RUNNING: return "RUNNING";
		case KILLED: return "KILLED";
		default: return "NOT SET";
		}
	}
	
	public String toString() {
		return "Process Node["+name+","+typeToString(type)+","+statusToString(status)+"]";
	}
}
