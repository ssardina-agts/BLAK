/** Wouter: See http://www.jroller.com/santhosh/date/20050617 */
package goal.tools.SimpleIDE;


import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.EventListener;
import java.util.EventObject;

/**
 * @author W.Pasman 27mar09
 * GUI layout change events are passed through callbacks of SplitPositionChange
 * 
 * We can not use PropertyChangeListener directly for the following reason:
 * In some cases, eg with the DatabasePanel, we want to route splitpos events
 * from multiple DatabasePanels to a single listener.
 * However that listener needs the split position which requires a call to 
 * jsplitpane.getDividerLocation(). Overriding each database panel propertyChangeListener would
 * be quite some code. This LayoutChangeListener provides the needed info straight away.
 * I called it LayoutChangeListener as in the future other layout change events may be 
 * routed through this listener.
 * 
 * We might consider making the panels listeners as well, and 
 * pass resize information in the other direction as well.  
 */
public interface LayoutChangeListener extends EventListener
{ 
	public void SplitPositionChange(int newsplitposition, EventObject e);
}