package goal.tools.SimpleIDE;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.prefs.Preferences;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/** @author W.Pasman 24mar09
 * This panel stores the Introspector preferences and provides a GUI to edit them. 
 */

public class IntrospectorPrefPanel extends JPanel implements ChangeListener 
{
	static Preferences myPreferences= Preferences.userNodeForPackage(IntrospectorPrefPanel.class); // system wide store and better support than Properties()
	
	JCheckBox rememberdbsize;
	JTextArea dbsize; 
	//JCheckBox rememberquerysize;
	//JTextArea querysize; 
	//JCheckBox coupledebugoutputsize;
	JCheckBox couplequerysize;
	JSpinner spinner;

	public IntrospectorPrefPanel() {
		// Wouter removed 29jul09 trac652
		//rememberdebugsize=new JCheckBox("Remember Debug outputarea size (last closed introspector)");
		//debugsize=new JTextArea("      current size:"+getDBaseAreaSize());		
		rememberdbsize=new JCheckBox("Remember database view size (last closed introspector)");
		dbsize=new JTextArea("      current size:"+getDBContentSize());		
		//coupledebugoutputsize=new JCheckBox("Single size of debug ouput area");
		couplequerysize=new JCheckBox("Single size of query area");

		JPanel maxlinespanel=new JPanel(new BorderLayout());
		SpinnerNumberModel sm=new SpinnerNumberModel(1000,100,2000,100);
		maxlinespanel.add(new JLabel("Max. number of lines in output area "),BorderLayout.CENTER);
		spinner=new JSpinner(sm);
		maxlinespanel.add(spinner,BorderLayout.WEST);

		init();
		setLayout(new GridLayout(0,1));
		add(new JLabel("Introspector Settings"));
		add(rememberdbsize); rememberdbsize.addChangeListener(this);
		add(dbsize);
		//add(rememberquerysize); rememberquerysize.addChangeListener(this);
		//add(querysize);
		//add(coupledebugoutputsize); coupledebugoutputsize.addChangeListener(this);
		add(couplequerysize); couplequerysize.addChangeListener(this);
		add(maxlinespanel); spinner.addChangeListener(this);
	}
	
	/** copy settings from preferences to the check boxes */
	public void init() {
		rememberdbsize.setSelected(getRememberDBSize()); // 2nd arg is the default value
		//rememberquerysize.setSelected(getRememberQuerySize());
		//coupledebugoutputsize.setSelected(getCoupleDebugOutputSize());
		couplequerysize.setSelected(getCoupleQuerySize());
		//spinner.setValue(getMaxLines());
	}
	
	
	/** change most recent state */
	public void stateChanged(ChangeEvent e)  {
		myPreferences.putBoolean("rememberdbsize", rememberdbsize.isSelected());
		//myPreferences.putBoolean("rememberquerysize", rememberquerysize.isSelected());
		//myPreferences.putBoolean("coupledebugoutputsize",coupledebugoutputsize.isSelected());
		myPreferences.putBoolean("couplequerysize",couplequerysize.isSelected());
		myPreferences.putInt("maxlines", (Integer)spinner.getValue());
	}

	public static int getMaxLines() {
		return myPreferences.getInt("maxlines", 100);
	}
	
	/** @return height of database area size
	 * which is also the position of the split of the jsplitpane 
	 * renamed trac 652 Wouter 29jul09*/
	public static int getDBContentSize() {
		int height=IDEPrefPanel.getMainAreaHeight()*7/10; // default
		if (getRememberDBSize()) {
			height=myPreferences.getInt("dbsize", height);
		}
		return height;
	}
	
	/** @return size or database content area (the part up to the query area, aka
	 * the split position of the jsplitpane
	 * removed Wouter 29jul09 trac 652
	public static int getDBContentSize() {
		int height=getDBaseAreaSize()*8/10; // default
		if (myPreferences.getBoolean("rememberquerysize", true)) {
			height=myPreferences.getInt("querysize", height);
		}
		return height;
	}
	*/
	
	public static boolean getRememberDBSize() {
		return myPreferences.getBoolean("rememberdbsize",true);
	}
	
	/*
	public static boolean getRememberQuerySize() {
		return myPreferences.getBoolean("rememberquerysize",true);
	}
	
	public static boolean getCoupleDebugOutputSize() {
		return myPreferences.getBoolean("coupledebugoutputsize", true);
	}
	*/
	public static boolean getCoupleQuerySize() {
		return myPreferences.getBoolean("couplequerysize", true);
	}
	
}