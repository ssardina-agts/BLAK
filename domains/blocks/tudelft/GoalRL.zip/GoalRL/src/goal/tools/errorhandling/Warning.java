package goal.tools.errorhandling;

import goal.tools.errorhandling.WarningPrefPanel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.prefs.Preferences;

import javax.swing.JCheckBox;


/** 
 * Warning objects handle warning messages. These objects also count how many times a particular type of message
 * has been issued already.
 * You can ask for a stack dump as well.
 * This class is identical to the Warning class in the GOAL system since 5sept08 W.Pasman
 * @author W.Pasman
 * @version 2 4mar09: uses preferences for all settings. 
 */

public class Warning {
	
	
	
	protected class MyWarningException extends Exception {}
	
	// Class fields
	static Hashtable<String,Integer>
		pPreviousMessages = new Hashtable<String,Integer>();   // Hashtable key = warning message, corresponding value = #repetitions.

	/**
	 * Default warning: Print warning message at most 5 times. Stack trace is not printed.
	 */
	public Warning(String warning) {
		makeWarning(warning, new MyWarningException());
	}
	
	/** if you set showstack to true, stack dump will be made for location where WARNING occurs.
	 * The location of the error will be reported as the code location where this warning is placed. 
	 * Note that this is not useful if you are converting an exception into a warning. In that case,
	 * you better use Warning(warning, Exception).
	 * @param warning is the message to be shown
	 * @param showstack is true if you want to show a stack dump as well
	 * @param suppressat is the maximum number of this warning you want to appear 
	 * @deprecated 4mar09: we now set suppression and showstack via the preferences */
	public Warning(String warning, boolean showstack, int suppressat) {
		makeWarning(warning, new MyWarningException());
	}
	
	public Warning(String pWarning, Exception err) {
		makeWarning(pWarning,err);
	}
	
	/** if you set showstack to true, stack dump will be made for location where WARNING occurs. 
	 * Note that this is not useful if you are converting an exception into a warning. In that case,
	 * you better use Warning(warning, Exception) 
	 * @param warning is the message to be shown
	 * @param err is the exception that caused the rise of this warning. this will be used
	 * to inform the user about where the problem occured.
	 * @param showstack is true if you want to show a stack dump as well
	 * @param suppressat is the maximum number of this warning you want to appear 
	 * @deprecated 4mar09: now we set showstack and suppression via preferences.
	 */
	public Warning(String pWarning, Exception err, boolean pShowStack,int pSuppressAt) {
		makeWarning(pWarning,err);
	}
	
	// Class methods
	/**
	 * Add warning to static hashtable used to keep track of all warnings issued so far.
	 * Only show warning if message has not appeared more than 'fSuppressAt' times.
	 * @param e is exception that caused the problem. Use null to avoid stack dump. 
	 */
	public void makeWarning(String pWarning, Exception e) {
		
		 // read prefs with every warning. That is expensive but warnings should not occur too often
		Preferences myPreferences= Preferences.userNodeForPackage(WarningPrefPanel.class); // system wide store and better support than Properties()
		boolean showJavaDetails=myPreferences.getBoolean("javadetails",false); // 2nd arg is the default value
		boolean showStackdump=myPreferences.getBoolean("stackdump",false);	
		int suppressionLevel=myPreferences.getInt("suppresslevel", 5);
		
		
		Object lWarnings = pPreviousMessages.get(pWarning);

		if (lWarnings==null) {
			pPreviousMessages.put(pWarning, 0);
			lWarnings=0;
		}
		
		int lNrOfWarnings = (Integer)(pPreviousMessages.get(pWarning))+1;
		// Update nr of warning occurrences in hashtable
		pPreviousMessages.put(pWarning, lNrOfWarnings);
		
		if ((Integer)lWarnings > suppressionLevel) return;

		// Print message
		System.out.print("WARNING: "+pWarning+". "+e.getMessage()+"\n");
		if (showJavaDetails && !(e instanceof MyWarningException) ) 
			System.out.print(e);

		
		
		if (showStackdump )
		{
			System.out.println(". Stack dump:\n"+getFullStackDumpInfo(e));
		} else if (showJavaDetails) {
			ArrayList<StackTraceElement> stackelts=getTopStack(e);
			if (!(stackelts.isEmpty())) System.out.print(" at "+stackelts.get(0));
			else System.out.print(" at empty stack point?\n");
		}
		System.out.println();
		
		if ((Integer)lWarnings == suppressionLevel)
		{
			System.out.print("New occurrences of this warning will not be shown anymore.\n");
			return; 
		}
	}

	/** Wouter 30jun09: 
	 * @return string with stack dump info for exception 
	 * recursively calls itself to gather causes as well*/
	public String getFullStackDumpInfo(Throwable e) {
		String stack="";

		ArrayList<StackTraceElement> stackelts=getTopStack(e);
		for (StackTraceElement elt:stackelts) stack=stack+elt+"\n";
		
		 // now add info about the cause if there is one
		Throwable cause=e.getCause();
		if (cause!=null) {
			stack=stack+"-----which was caused by a deeper exception:"+cause+"-----\n"+
			getFullStackDumpInfo(cause);
		}
		
		return stack;
	}

	 /** @return the elements in the stack, but only the top cause and only those having a java line number */
	public ArrayList<StackTraceElement> getTopStack(Throwable e) {
		ArrayList<StackTraceElement> elts=new ArrayList<StackTraceElement>(Arrays.asList(e.getStackTrace()));
		ArrayList<StackTraceElement> tmp = new ArrayList<StackTraceElement>(elts);
		if (e instanceof MyWarningException) {
			tmp.remove(0); // remove the warning itself from the trace.
		}
		// now remove up to the first line that shows a real source file location as MentalState.java:22
		while((!tmp.isEmpty())&&(tmp.get(0).toString().indexOf(':')==-1)) tmp.remove(0);
		if(tmp.isEmpty())   tmp=elts;
		return tmp;
	}

}