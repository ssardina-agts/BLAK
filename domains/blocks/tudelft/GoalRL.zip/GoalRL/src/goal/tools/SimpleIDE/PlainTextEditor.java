/**
 * @author W.Pasman
 * This is a heavily hacked example from the sun website.
 */

package goal.tools.SimpleIDE;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.util.ArrayList;

import java.util.Hashtable;

import javax.swing.text.*;
import javax.swing.undo.*;



/**
 * This was a formatted text editor, 
 * but I removed all format options and menu items.
 * @author W.Pasman
 */
public class PlainTextEditor extends TextEditorInterface {
	
	// Class fields
    JTextPane textPane;
    DefaultStyledDocument lsd;
    //JTextArea changeLog;
    Hashtable actions;
    // String newline = System.getProperty("line.separator");
    String newline = "\n"; // CHECK Doesn't JAVA take care of this automatically, and select right '\n' for each platform?
    // static final int MAX_CHARACTERS = 300; W.Pasman: removed limit (and the checks).

    //undo helpers
    protected UndoAction undoAction;
    protected RedoAction redoAction;
    protected UndoManager undo = new UndoManager();

    // Class constructor
    public PlainTextEditor (String pFilename) throws Exception {
    	super(pFilename);
        //Some initial setup
        lsd = new DefaultStyledDocument();
        undoAction = new UndoAction();
        redoAction = new RedoAction();

        //Create the text pane and configure it
        textPane = new JTextPane(lsd)	// All right! No 60's jokes.
        {
        	// W.Pasman: turn off line wrap. Bit obscure, not in the manuals but it works
        	public boolean getScrollableTracksViewportWidth() { return false; }
        };
        textPane.setCaretPosition(0);
        textPane.setMargin(new Insets(5,5,5,5));
        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        //Create the status area
        JPanel statusPane = new JPanel(new GridLayout(1, 1));
        CaretListenerLabel caretListenerLabel = new CaretListenerLabel("Caret Status");
        statusPane.add(caretListenerLabel);

        //Add the components to the frame 
		setLayout(new BorderLayout());
		add(scrollPane);
        add(statusPane, BorderLayout.SOUTH);

        //Set up the menu bar
        createActionTable(textPane);
        initDocument(filename);
        
        //Start watching for undoable edits and caret changes
        lsd.addUndoableEditListener(new MyUndoableEditListener());
        textPane.addCaretListener(caretListenerLabel);
        //lsd.addDocumentListener(new MyDocumentListener());
    }

    // Class methods
    void initDocument(String pFilename) throws Exception {	
    	SimpleAttributeSet lAttribute = new SimpleAttributeSet();
    	StyleConstants.setFontFamily(lAttribute, "monospaced");
    	StyleConstants.setFontSize(lAttribute, 12);
    	
    	// Wouter: default tabs are rediculously wide at 10 characters. Lower this 
    	// Create one of each type of tab stop. 
    	// 200 tab stops (for total of 4000 pixels wide) seems sufficient in all cases.
        ArrayList<TabStop> list = new ArrayList<TabStop>();
        for (int tabnr=1; tabnr<200; tabnr++) {
        	TabStop tstop=new TabStop(tabnr*20, TabStop.ALIGN_LEFT,TabStop.LEAD_NONE);
        	list.add(tstop);
        }
        TabStop[] tstops = (TabStop[])list.toArray(new TabStop[0]);
        TabSet tabs = new TabSet(tstops);
        Style style = textPane.getLogicalStyle();
        StyleConstants.setTabSet(style, tabs);
        textPane.setLogicalStyle(style);
        
        // Create a left-aligned tab stop at 100 pixels from the left margin
        float pos = 100;
        int align = TabStop.ALIGN_LEFT;
        int leader = TabStop.LEAD_NONE;
        TabStop tstop = new TabStop(pos, align, leader);
        list.add(tstop);
        
        
        
		// Load file into the editor
		if (pFilename != null) {
			BufferedReader lBuffer = new BufferedReader(new FileReader(pFilename));
			String lString = lBuffer.readLine();
			while (lString != null) {
				lsd.insertString(lsd.getLength(), lString+newline, lAttribute); 
				lString = lBuffer.readLine();
			}
			lBuffer.close();
		}
		else
			lsd.insertString(lsd.getLength(), "Type your text here...", lAttribute);
    }

    //This listens for and reports caret movements.
    protected class CaretListenerLabel extends JLabel implements CaretListener {
        public CaretListenerLabel (String label) {
            super(label);
        }
        public void caretUpdate(CaretEvent e) {
            //Get the location in the text
            int dot = e.getDot();
            int mark = e.getMark();
            setText("Line " + getLineNumber());
        }
    }
    
    int getLineNumber()
    {
    	int lineNumber = 1;
    	String text=textPane.getText();
    	int caret=textPane.getCaretPosition();

    	for (int i=0; i<caret; i++) 
    		if (text.startsWith(newline,i)) lineNumber++;
    	return(lineNumber);
    }

    //This one listens for edits that can be undone.
    protected class MyUndoableEditListener implements UndoableEditListener {
        public void undoableEditHappened(UndoableEditEvent e) {
            //Remember the edit and update the menus
            undo.addEdit(e.getEdit());
            undoAction.updateUndoState();
            redoAction.updateRedoState();
        }
    }

    //The following two methods allow us to find an
    //action provided by the editor kit by its name.
    private void createActionTable(JTextComponent textComponent) {
        actions = new Hashtable();
        Action[] actionsArray = textComponent.getActions();
        for (int i = 0; i < actionsArray.length; i++) {
            Action a = actionsArray[i];
            actions.put(a.getValue(Action.NAME), a);
        }
    }

    private Action getActionByName(String name) {
        return (Action)(actions.get(name));
    }

    class UndoAction extends AbstractAction {
        public UndoAction() {
            super("Undo");
            setEnabled(false);
        }
          
        public void actionPerformed(ActionEvent e) {
            try {
                undo.undo();
            } catch (CannotUndoException ex) {
                System.out.println("Unable to undo: " + ex);
                ex.printStackTrace();
            }
            updateUndoState();
            redoAction.updateRedoState();
        }
          
        protected void updateUndoState() {
            if (undo.canUndo()) {
                setEnabled(true);
                putValue(Action.NAME, undo.getUndoPresentationName());
            } else {
                setEnabled(false);
                putValue(Action.NAME, "Undo");
            }
        }      
    }    

    class RedoAction extends AbstractAction {
        public RedoAction() {
            super("Redo");
            setEnabled(false);
        }

        public void actionPerformed(ActionEvent e) {
            try {
                undo.redo();
            } catch (CannotRedoException ex) {
                System.out.println("Unable to redo: " + ex);
                ex.printStackTrace();
            }
            updateRedoState();
            undoAction.updateUndoState();
        }

        protected void updateRedoState() {
            if (undo.canRedo()) {
                setEnabled(true);
                putValue(Action.NAME, undo.getRedoPresentationName());
            } else {
                setEnabled(false);
                putValue(Action.NAME, "Redo");
            }
        }
    }    

    public void Undo() { undo.undo(); }
    public void Redo() { undo.redo(); }
    
    public void Save() throws Exception {
		FileWriter writer=new FileWriter(filename);
		writer.write(textPane.getText());
		writer.close();
    }
	
	public void SaveAs(String fn) throws Exception { filename=fn; Save(); };
	
	/** Warning. This closes the file but does not close the panel. */
	public void Close() throws Exception { 
		// TODO: check whether file actually changed.
		int n=JOptionPane.showConfirmDialog(this,"Save file "+filename+"?",
			"Save before closing?",JOptionPane.YES_NO_OPTION);
		if (n==0) Save();
	}

	public String getFilename() { return filename; }
	public void Cut() throws Exception  { textPane.cut(); }
	public void Copy() throws Exception { textPane.copy(); }
	public void Paste() throws Exception { textPane.paste();}
	
	
}



