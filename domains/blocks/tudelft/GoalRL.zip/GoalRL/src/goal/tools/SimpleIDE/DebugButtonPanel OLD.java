package goal.tools.SimpleIDE;

import goal.tools.SimpleIDE.FileNode;
import goal.tools.SimpleIDE.IDEfunctionality;
import goal.tools.SimpleIDE.ProcessNode;
import goal.tools.errorhandling.Warning;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

// OBSOLETE ==> handled by toolbar now

public class DebugButtonPanel extends JPanel {
	private ImageIcon runicon=new ImageIcon("icons/run.gif");
	private ImageIcon stepicon=new ImageIcon("icons/step.gif");
	private ImageIcon backstepicon=new ImageIcon("icons/backstep.gif");
	private ImageIcon killicon=new ImageIcon("icons/kill.gif");
	private ImageIcon pauseicon=new ImageIcon("icons/pause.gif");
	
	private JButton runbutton=new JButton(runicon);
	private JButton stepbutton=new JButton(stepicon);
	private JButton backstepbutton=new JButton(backstepicon);
	private JButton killbutton=new JButton(killicon);
	private IDEfunctionality myide;
	
	public DebugButtonPanel(IDEfunctionality ide) {
		myide=ide;
		setLayout(new BorderLayout());
		JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEADING));
		
		buttons.add(runbutton);
		buttons.add(stepbutton);
		buttons.add(backstepbutton);
		buttons.add(killbutton);
	
		add(buttons,BorderLayout.CENTER);
	

		runbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				try { 
					if (runbutton.getIcon()==runicon)
						myide.runOrPause(myide.getSelection()); 
					else
						myide.stepNode((ProcessNode)myide.getSelection());
						// CHECK maybe crank up the debug level to get really in step mode?
				}
				catch (Exception err) { new Warning("Run/Step failed:",err); }
			}
		} );
		
		// W.Pasman: The step and pause buttons are not properly reflecting the underlying debugger
		// because there is pause and step button while underlying debugger has a 'step mode' and
		// a 'run mode' only. IMHO this is a user interface issue. 
		stepbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				try { myide.stepNode((ProcessNode)myide.getSelection()); }
				catch (Exception err) { new Warning("Step failed:",err); }
			}
		});
		backstepbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				try { myide.BackStep((ProcessNode)myide.getSelection()); }
				catch (Exception err) { new Warning("Step failed:",err); }
			}
		});
		killbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				try { myide.Kill((ProcessNode)myide.getSelection()); }
				catch (Exception err) { new Warning("Kill failed:",err); }
			}
		});
	}


	/** Update the debug run, step, backstep and kill buttons
		according to the currently selected node in the jTree */
	public void SetButtonState(FileNode node) {		
		switch (node.getType()) {
		case FileNode.GOALPROCESS:
			stepbutton.setEnabled(true);
			backstepbutton.setEnabled(true);
			if (node.getStatus()==FileNode.RUNNING)
				runbutton.setIcon(pauseicon);
			else
				runbutton.setIcon(runicon);
			break;
		case FileNode.MASFILE:
			stepbutton.setEnabled(false);
			backstepbutton.setEnabled(false);
			if (node.getStatus()==FileNode.RUNNING)
				runbutton.setIcon(pauseicon);
			else
				runbutton.setIcon(runicon);
			break;
		default:
			runbutton.setIcon(runicon);
			stepbutton.setEnabled(false);
			backstepbutton.setEnabled(false);
		}
			
	}

	/** Update the debug run, step, backstep and kill buttons
	according to the currently selected node in the jTree */
	public void SetButtonState(ProcessNode pNode) {
	switch (pNode.getType()) {
	case ProcessNode.GOALPROCESS:
		stepbutton.setEnabled(true);
		backstepbutton.setEnabled(true);
		if (pNode.getStatus() == ProcessNode.RUNNING)
			runbutton.setIcon(pauseicon);
		else
			runbutton.setIcon(runicon);
		break;
	case ProcessNode.MASFILE:
		stepbutton.setEnabled(false);
		backstepbutton.setEnabled(false);
		if (pNode.getStatus() == ProcessNode.RUNNING)
			runbutton.setIcon(pauseicon);
		else
			runbutton.setIcon(runicon);
		break;
	default:
		runbutton.setIcon(runicon);
		stepbutton.setEnabled(false);
		backstepbutton.setEnabled(false);
	}
		
}
	
}
