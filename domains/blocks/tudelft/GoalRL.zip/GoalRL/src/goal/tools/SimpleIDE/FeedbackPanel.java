package goal.tools.SimpleIDE;

import goal.tools.PlatformEvent;
import goal.tools.PlatformManager;
import goal.tools.SimpleIDE.tab.CloseListener;
import goal.tools.SimpleIDE.tab.CloseTabbedPane;
import goal.tools.errorhandling.Warning;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.util.Observable;
import java.util.Observer;

/**
 * FeedbackPanel is the lower area holding the Console and other feedback items.
 * 28jul09: it subscribes with the PM in order to show the messages sent by 
 * the various agents.
 * 
 * We handle the re-routing of the text messages here right away,
 * because 
 */
public class FeedbackPanel extends CloseTabbedPane  {
	PlatformManager platformmgr;
	
	/** uses PM to subscribe to agent debug streams */
	public FeedbackPanel(PlatformManager pm) {
		platformmgr=pm;
		
		add("Console",new ConsoleTextPanel());
		add("Actions",new ActionHistoryTextPanel());
		
		pm.addObserver(new Observer() {
			public void update(Observable o, Object arg) {
				if (!(arg instanceof goal.tools.PlatformEvent))
					new Warning("Err.. expected Platform event but received "+arg);
				else {
				  handlePlatformEvent((PlatformEvent)arg);
				}
			}
		});
		
		addCloseListener(
				new CloseListener() {
					public void closeOperation(MouseEvent e, int overTabIndex) {
						try { 
							Component c=getComponentAt(overTabIndex);
							if (c instanceof DebugTextPanel) {
								((DebugTextPanel)c).Close();
								remove(overTabIndex);
							}
						} catch (Exception ex) { new Warning ("Ignoring close of tab ",ex); }
					}
				}
			);
		
	}
	



	 /** print the message to the right tab. Make a tab if it's not there. */
	void handlePlatformEvent(PlatformEvent evt) {
		//PlatformEvent.EventType type=evt.getEventType();
		String agentname=evt.getAgentName();
		 // ignore non-goal agents in the platform (eg sniffer-related stuff).. trac 713 
		if (!platformmgr.getRegistry().containsAgent(agentname)) return;
		switch (evt.getEventType()) {
		case AGENT_DIED:
			DebugTextPanel p=getOrCreatePanel(agentname);
			p.agentDied();
			remove(p);
			break;
		case AGENT_BORN:
			try {
			  getOrCreatePanel(agentname).agentBorn(agentname);
			  
			} catch (Exception e) {
				new Warning("can not open debug trace panel",e);
			}
			break;
		default:
			//System.out.println("Feedback panel ignoring event "+evt+"\n");
		}
	}
	
	public DebugTextPanel getOrCreatePanel(String panelname) {
		int i=indexOfTab(panelname);
		DebugTextPanel textpanel;
		if (i==-1) { // does not exist, make it
			textpanel=new DebugTextPanel(platformmgr);
			add(panelname, textpanel);
		} else {
			textpanel=(DebugTextPanel)getComponentAt(i);
			// CHECK what if somehow the name of existing other panel like "Console" or "Actions"
			// would be assigned to an agent?
			// is that possible at all?
		}
		return textpanel;
	}
	
	/** set global debug level for all debug tracer windows */
	public void setDebugLevel(int level) {
		for (Component c: getComponents()) {
			if (c instanceof DebugTextPanel) ((DebugTextPanel)c).setDebugLevel(level);
		}
	}
	
	/*
	public void addText(String panelname,String text) {
		DebugTextPanel textpanel=getOrCreatePanel(panelname);
		//System.out.println("Feedback: "+text);
		JTextArea textarea=textpanel.getTextArea();
		textarea.append(text);
	}
	*/
	
	
	
}

