

package goal.tools.SimpleIDE;

import goal.tools.PlatformManager;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

import java.awt.BorderLayout;

/** interface to sniffer 
 * This is an abstract class and not an interface, to enforce a SnifferInterface to provide a JPanel
 * @author W.Pasman 24mor09 */
public class SnifferImp extends SnifferInterface {
	
	// both following fields always either both initialized or null
	private AgentController snifferController = null;
	private goal.tools.sniffer.Sniffer JADEsniffer=null;

	
	 /** init. We need the PM to convert agent names into proper middleware agent names. Maybe to be fixed */
	SnifferImp(PlatformManager pm) { 
		super(pm);
		// create and return the panel
		try {
			if (JADEsniffer==null) {
	 			JADEsniffer = new goal.tools.sniffer.Sniffer();
	 			snifferController =
	 				platformManager.getMainContainer().acceptNewAgent("one sniffer", JADEsniffer);
	 			snifferController.start();
	 			
	 			setLayout(new BorderLayout());
	 			add(JADEsniffer.getMessagePanel(), BorderLayout.CENTER);
			}
		} catch (StaleProxyException e) {
			// convert to RuntimeException, init is not allowed to throw normal exception.
			throw new RuntimeException("Trouble creating Sniffer",e);
		}
	}
	
	 /** add an agent to sniff
	  * @param agentname is the name of the agent. 
	  * The PM will be called to turn the agent name into a platform dependent middleware agent name*/
	public void Sniff(String agentname) throws Exception {
 	 		JADEsniffer.doSniff(agentname+"@"+platformManager.getMainContainer().getName());
 	 	}

	
	 /** stop sniffing an agent. Returns silently if agent is not sniffed at this moment */
	public void stopSniff(String agentName) throws Exception {
 		JADEsniffer.doNotSniff(agentName+"@"+platformManager.getMainContainer().getName());
 	}
	
	/** close the entire sniffer panel. Dispose your handle to this SnifferImp immediately after
	 * you called this. 
	 * @throws  StaleProxyException if ???
	 */
	public void closeSniff() throws Exception {
 				snifferController.kill();
	}
	
	/** clear the sniff canvas */
	public void clearCanvas() {
		if (JADEsniffer==null) return; 
		JADEsniffer.ClearCanvas();
	}




 
 	
}