package goal.tools;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.prefs.Preferences;

import goal.tools.IOManager;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/** @author W.Pasman 24mar09
 * This panel stores the IDE preferences and provides a GUI to edit them. */

public class PMPrefPanel extends JPanel implements ActionListener 
{
	static Preferences myPreferences= Preferences.userNodeForPackage(PMPrefPanel.class); // system wide store and better support than Properties()
	
	
	JTextField absolutedir;
	JLabel envdirexplanation;
	
	JRadioButton useGoalButton;
	JRadioButton useMASButton;
	JRadioButton useAbsoluteButton;
	JButton browseButton;
	
	public PMPrefPanel() {
		
		absolutedir=new JTextField("/");
		absolutedir.setEditable(false);
		envdirexplanation=new JLabel("Use this base path for the environment:");
		useGoalButton=new JRadioButton("environments directory inside GOAL install directory");
		useMASButton=new JRadioButton("directory containing the MAS file");
		useAbsoluteButton=new JRadioButton("Specific absolute path");
		browseButton=new JButton("Browse...");
		final PMPrefPanel thispanel=this;
		browseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newname=IOManager.askFileName(thispanel, true,"select base path for environment",JFileChooser.DIRECTORIES_ONLY,null,null);
				if (newname!=null) {
					absolutedir.setText(newname);
					useAbsoluteButton.setSelected(true);
					thispanel.actionPerformed(null);
				}
			}
		});
		
		JPanel pathpanel=new JPanel(new BorderLayout());
		pathpanel.add(useAbsoluteButton,BorderLayout.WEST);
		pathpanel.add(absolutedir,BorderLayout.CENTER);
		pathpanel.add(browseButton,BorderLayout.EAST);
	
		ButtonGroup envpath=new ButtonGroup();
		envpath.add(useGoalButton);
		envpath.add(useMASButton);
		envpath.add(useAbsoluteButton);

		init();
		setLayout(new GridLayout(0,1));
		add(new JLabel("MAS Settings"));
		add(envdirexplanation);
		add(useGoalButton); useGoalButton.addActionListener(this);
		add(useMASButton); useMASButton.addActionListener(this);
		add(pathpanel); useAbsoluteButton.addActionListener(this);
		
		
	}
	
	/** copy settings from preferences to the check boxes */
	public void init() {
		absolutedir.setText(myPreferences.get("absolutedir", "/"));
		useGoalButton.setSelected(myPreferences.getBoolean("useGoalDir", true));
		useMASButton.setSelected(myPreferences.getBoolean("useMASDir", false));
		useAbsoluteButton.setSelected(myPreferences.getBoolean("useAbsoluteDir", false));
	}
	
	
	/** change most recent state 
	 * actionEvent maybe null (if called from a browse action) */
	public void actionPerformed(ActionEvent e)  {
		myPreferences.put("absolutedir", absolutedir.getText());
		myPreferences.putBoolean("useGoalDir", useGoalButton.isSelected());
		myPreferences.putBoolean("useMASDir", useMASButton.isSelected());
		myPreferences.putBoolean("useAbsoluteDir", useAbsoluteButton.isSelected());
	}

	
	/**
	 * @param GoalDir is abs path to goal installation directory.
	 * @param MASDir is abs path to directory containing mas file.
	 * @return absolute path to directory supposedly containing environment   
	 */
	public static String getEnvBasePath(String GoalDir, String MASDir) {
		if (myPreferences.getBoolean("useGoalDir", true)) {
			return GoalDir+"environments/";
		}
		if (myPreferences.getBoolean("useMASDir", false)) {
			return MASDir; 
		}
		return myPreferences.get("absolutedir", "/");

	}
}