
package goal.tools.SimpleIDE;

import goal.tools.PlatformManager;

import javax.swing.JPanel;

/** interface to sniffer 
 * Wouter: Koen asked for further separation of sniffer stuff from the SimpleIDE so here you go.
 * This interface defines the required capabilities of a sniffer tool.
 * When we define a middleware layer this maybe will be integrated there.
 * But that depends on whether we require middleware to offer sniff functionality
 * This is an abstract class and not an interface, to enforce a SnifferInterface to provide a JPanel
 * @author W.Pasman 24mor09 */
public abstract class SnifferInterface extends JPanel {

	PlatformManager platformManager;
	 /** init. We need the PM to convert agent names into proper middleware agent names. Maybe to be fixed */
	SnifferInterface(PlatformManager pm) { 
		platformManager=pm;
	}
	
	 /** add an agent to sniff
	  * @param agentname is the name of the agent. */
	public abstract void Sniff(String agentname) throws Exception;
	
	 /** stop sniffing an agent. Returns silently if agent is not sniffed at this moment */
	public abstract void stopSniff(String agentname) throws Exception;
	
	/** close the entire sniffer panel. */
	public abstract void closeSniff() throws Exception;
	
	/** clear the sniff canvas. returns silently if no sniff panel open. */
	public abstract void clearCanvas();
}