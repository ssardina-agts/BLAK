package goal.tools.SimpleIDE;

import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author K.Hindriks
 * 
 * This class defines the toolbar of the GOAL IDE. It introduces buttons for most of the available user commands
 * defined in the enum class UserCmd. Event handling is taken care of by the class SimpleIDE.
 * 
 * See also: http://java.sun.com/docs/books/tutorial/uiswing/components/toolbar.html.
 */

public class ToolBar extends JToolBar implements ActionListener {
	
	// Class fields
	IDEfunctionality myIDE;
	// Buttons
	private JButton newButton, openButton, saveButton, saveAsButton, saveAllButton, editButton;
	private JButton undoButton, redoButton, cutButton, copyButton, pasteButton;
	private JButton runOrPauseButton, stepButton, backstepButton, killButton;
	private JButton debugButton, sniffButton, envResetButton, switchPanelButton;
	
	ImageIcon runIcon,pauseIcon; // fix for Mantis 552 Wouter 17mar09
	
	SpinnerNumberModel sm=new SpinnerNumberModel((int)Debugger.DEFAULT_LEVEL,0,10,1);
	final JSpinner debuglevelspinner=new JSpinner(sm);
	
	// table of all actions and associated menus. Used to en/disable them appropriately
	// createMenuItem will insert required info in this table as well.
	Hashtable<String,JButton> allButtons=new Hashtable<String,JButton>();

	
	// Constructor
	public ToolBar(IDEfunctionality theIDE) {
		myIDE = theIDE;
		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		setName("GOAL IDE ToolBar");
        addButtons();
	}
	
	// Class methods
	protected void addButtons() {
		// File buttons
		add(newButton = makeButton("new16.gif", UserCmd.NEW.toString(), "Open new file"));
		add(openButton = makeButton("open16.gif", UserCmd.OPEN.toString(), "Open file"));
	    add(saveButton = makeButton("save16.gif", UserCmd.SAVE.toString(), "Save file"));
	    add(saveAsButton = makeButton("saveas16.gif", UserCmd.SAVEAS.toString(), "Save as..."));
	    add(saveAllButton = makeButton("saveall16.gif", UserCmd.SAVEALL.toString(), "Save all files"));
	    add(editButton = makeButton("edit16.gif", UserCmd.EDIT.toString(), "Edit file"));
	    addSeparator();
	    // Edit buttons
	    add(undoButton = makeButton("undo16.gif", UserCmd.UNDO.toString(), "Undo"));
	    add(redoButton = makeButton("redo16.gif", UserCmd.REDO.toString(), "Redo"));
	    add(cutButton = makeButton("cut16.gif", UserCmd.CUT.toString(), "Cut"));
	    add(copyButton = makeButton("copy16.gif", UserCmd.COPY.toString(), "Copy"));
	    add(pasteButton = makeButton("paste16.gif", UserCmd.PASTE.toString(), "Paste"));
	    addSeparator();
	    // Run buttons
	    add(runOrPauseButton = makeButton("run.gif", UserCmd.RUN.toString(), "Launch agent (system)")); // change to pause when agent (system) is running
	    runOrPauseButton.setIcon(runIcon=getIcon("run.gif")); // we use run annd step Icon to avoid FS overhead during switching. See mantis 552
	    pauseIcon=getIcon("pause.gif");
	    
	    //add(makeButton("pause.gif", UserCmd.PAUSE.toString(), "Pause agent (system)"));
	    add(stepButton = makeButton("step.gif", UserCmd.STEP.toString(), "Step forward"));
		// debug level -- spinner
		debuglevelspinner.setMaximumSize(new Dimension(50,30));
		add(debuglevelspinner,"Select the debug level");
		debuglevelspinner.addChangeListener(
				new ChangeListener() {
					public void stateChanged(ChangeEvent e)
					{ 
						myIDE.executeCommand(UserCmd.SETDEBUGLEVEL.toString(),debuglevelspinner.getValue().toString());
					}
					
			});
		//spinner.setEnabled(false);

		add(backstepButton = makeButton("backstep.gif", UserCmd.BACKSTEP.toString(), "Not yet implemented"));
	    backstepButton.setEnabled(false); // TODO: still needs to be implemented.
	    add(killButton = makeButton("kill.gif", UserCmd.KILL.toString(), "Kill agent (system)")); // TODO: Resize kill button...
	    addSeparator();
	    // Debug button
	    add(debugButton = makeButton("debug_exc.png", UserCmd.DEBUG.toString(), "Launch introspector"));
	    add(sniffButton = makeButton("snifferjade.gif", UserCmd.SNIFF.toString(), "Launch sniffer")); // change tool tip text to "Add agent to sniffer" when sniffer has been launched?
	    // TODO: Add clear sniff button
	    addSeparator(); addSeparator();
	    // Environment reset button
	    add(envResetButton = makeButton("application16rotated.gif", UserCmd.RESETENV.toString(), "Reset environment"));
	    // alignment
	    add(Box.createHorizontalGlue());
	    addSeparator();
	    // Edit/debug switch button
	    switchPanelButton = new JButton("Debug"); // change text to "  Edit  " when pressed
	    switchPanelButton.setActionCommand(UserCmd.SWITCHPANEL.toString());
	    switchPanelButton.setToolTipText("Goto debug window"); // change text to "Goto edit window" when pressed
	    switchPanelButton.addActionListener(this);
	    allButtons.put(UserCmd.SWITCHPANEL.toString(), switchPanelButton);
	    add(switchPanelButton);
	    
	    setToolBarButtons(0, new FileNode("",FileNode.ROOT,"")); // make buttons avaialble in line with edit view initially
	}
	
	
	ImageIcon getIcon(String iconName) {
		return new ImageIcon(getClass().getClassLoader().getResource("goal/tools/SimpleIDE/icons/"+iconName));
	}
	
	// Class methods
	protected JButton makeButton(String iconName, String actionCommand, String toolTipText) {
		JButton button = new JButton();
		
		button.setIcon(getIcon(iconName));
		button.setActionCommand(actionCommand);
		button.setToolTipText(toolTipText);
		button.addActionListener(this);
		button.setPreferredSize(new Dimension(20,24));
		allButtons.put(actionCommand,button);
		return button;
	}
	
	public void actionPerformed(ActionEvent pEvent) { // handle toolbar event
		String lCommand = pEvent.getActionCommand();
		/* removed pseudoaction RUNPAUSE W.Pasman 14may09 see mantis 558
		if (lCommand.equals(UserCmd.RUNPAUSE)) {
			if (runButton.getIcon()==runIcon)
				lCommand = UserCmd.RUN.toString();
			else
				lCommand = UserCmd.PAUSE.toString();
		}
		*/

		myIDE.executeCommand(lCommand);
	}
	
	public void switchPanel(int view, IDENode node) {
		switch(view) {
		case 0: // edit view; set to "Goto debug panel" button
			switchPanelButton.setText("Debug");
			switchPanelButton.setToolTipText("Goto debug window");
			break;
		case 1: // debug view; set to "Goto edit panel" button
			switchPanelButton.setText("  Edit  ");
			switchPanelButton.setToolTipText("Goto edit window");
			break;
		default:
			new Warning("BUG: view unknown in ToolBar.");
		}
		setToolBarButtons(view, node);
	}
	
	public void setToolBarButtons(int view, IDENode node) {
		for (String action: allButtons.keySet()) {
			JButton button=allButtons.get(action);
			/* removed pseudoaction RUNPAUSE W.Pasman 14may09 see mantis 558
			if (action.equals(UserCmd.RUNPAUSE)) {
				// special button, always enabled but changes appearance 
				if (myIDE.isEnabled(UserCmd.RUN.toString())) {
					runButton.setIcon(runIcon); 
					runButton.setEnabled(true);
				}
				else
					if (myIDE.isEnabled(UserCmd.PAUSE.toString())) {
						runButton.setIcon(pauseIcon);
						runButton.setEnabled(true);
					}
					else runButton.setEnabled(false);
				continue;
			}
			*/
			
			 // check the runOrPauseButton. It can contain RUN or PAUSE command. 
			 // If RUN disabled, try PAUSE. If pause also disabled, set to disabled
			if (button==runOrPauseButton) {
				if (myIDE.isEnabled(UserCmd.RUN.toString())) {
					runOrPauseButton.setIcon(runIcon);
					runOrPauseButton.setActionCommand(UserCmd.RUN.toString());
					runOrPauseButton.setEnabled(true);
				}
				else if (myIDE.isEnabled(UserCmd.PAUSE.toString())) {
					runOrPauseButton.setIcon(pauseIcon);
					runOrPauseButton.setActionCommand(UserCmd.PAUSE.toString());
					runOrPauseButton.setEnabled(true);
				}
				else runOrPauseButton.setEnabled(false);
				continue;
			}	
			debuglevelspinner.setEnabled(myIDE.isEnabled(UserCmd.ASKDEBUGLEVEL.toString()));
			button.setEnabled(myIDE.isEnabled(action));
		}
	}
	
	String getDebugLevel() {
		return debuglevelspinner.getValue().toString();
	}
	
}
