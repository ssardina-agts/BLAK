package goal.kr.implementations.swiprolog;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.Set;

import jpl.Query;
import foreignframe.ForeignFrame;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Term;
import goal.core.kr.language.Substitution.Binding;
import goal.kr.language.prolog.VariableTerm;
import goal.tools.debugger.Debugger;
import goal.tools.errorhandling.Warning;

/**
 * To place a query, you should always use a SWIQuery.rawquery()
 * This ensures that the bugfix (avoiding memory leaks) is used.
 * 
 * This object is to be unique, so that synchronization works as expected.
 * Therefore we use the singleton design pattern
 * BUT NOTE this object is NEVER instantiated, we don't needd any instantiation as it contains code only
 * 
 * IF you use SWIQuery, make sure to call FreeEngine when you're done.
 * Not doing that will cause loss of 100Mb of memory.
 * 
 * @author W.Pasman 20jan09
 * 
 */

public final class SWIQuery  { 
	
	/** you can not make instantiations, this is a singleton. Use SWIQuery.rawquery*/
	private SWIQuery() { }
	
	/**
	 * 	singletons can not be copied.
	 * @deprecated on purpose, to make it immediately obvious that you should not even try this.
	 */
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
	
	static ForeignFrame foreignframe=null; // any call to rawquery will instantiate it and load bugfix.
	
	/**
	 * rawquery is a raw call to SWIprolog but does some extra
	 * to avoid memory leaks in prolog and error handling.
	 * returns a set of substitutions, empty set if there are no solutions,
	 * and an empty substitution if there is a solution without need to substitute variables.
	 * BUG? Wouter: why does this give only "dynamic at/1" at all times in wumpusworld?
	 * even with swidb0:listing, user:listing and swidb1:listing???
	 * 
	 * @moddified 24jun08 after a modification in the readMAS to have mas nodes in the JTree of the SimpleIDE
	 * represent their own mas info, I get sucking CPU problem and crashing rawqueries.
	 * Probably a query is failing but how to find which?
	 * 
	 */
	public static Set<Substitution> rawquery(String pQueryString, Debugger debugger) throws Exception {
		debugger.bp("RQ", "Doing database query: "+pQueryString, 9);
		Hashtable[] lSolutions=synchronizedRawquery(pQueryString);
		Set<Substitution> lSubst = new LinkedHashSet<Substitution>();
		for ( int i=0;  i < lSolutions.length; i++)
			lSubst.add(mapSWISolutionToSubst(lSolutions[i]));
		
		debugger.bp("RQ", "Query Result="+lSubst, 10);
		return lSubst;
	}


	/**
	 * You can use this if you need the JPL Hashtable[] result directly
	 * @throws if problem with foreighframe. Maybe we should also throw if query fails?
	 */
	public  static synchronized Hashtable[] synchronizedRawquery(String pQueryString) throws Exception {		
		//CHECK why do we init foreignframe if it is not used according to useforeignframe?
		if (foreignframe==null) foreignframe=new ForeignFrame(); // load it if first time call
		Hashtable[] lSolutions = new Hashtable[0];
		boolean useforeignframe = true; // stupid, can't this be just a constant?
		
		if (useforeignframe)
			foreignframe.open();
		try {
			//System.out.println("querying "+pQueryString);
			
			Query query = new Query(pQueryString);
			lSolutions = query.allSolutions();

			// DEBUG
			//Query query1 = new Query("statistics");
			//query1.allSolutions();
		} catch (Exception e) {
			// Check if existence_error has occurred; if so, generate warning.
			String mess = e.getMessage();
			int i = mess.indexOf("existence_error(procedure, ");
			if (i!=-1) { 
				 // JPL existence error. ASSUMES modules are queried.
				int start=i+29;
				int end = mess.indexOf(")",start); // should be there
				String lWarning = "query "+pQueryString+" failed: not implemented predicate: "+
					mess.substring(start, end).replace(',','/');
				
				/* Wouter: disabled (somwehere 2008) because this code failed sometimes 
				String lWarning = "query "+pQueryString+" failed in ";
				while (e.getMessage().charAt(i)!=':') i++;
				int j = i++; while (e.getMessage().charAt(j)!=',') j++;
				lWarning += e.getMessage().substring(i+1,j)+": not implemented predicate ";
				i = j; while (e.getMessage().charAt(i)!='/') i++;
				j = i++; while (e.getMessage().charAt(j)!=',') j++;
				lWarning += e.getMessage().substring(i+1,j)+"/";
				i = j; while (e.getMessage().charAt(i)==' ') i++;
				j = i++; while (e.getMessage().charAt(j)!=')') j++;
				lWarning += e.getMessage().substring(i+1,j)+".";
				*/
				
				new Warning(lWarning,e);
			} else
				new Warning("query "+pQueryString +" failed",e);
		}
		catch (Error e) { 
			 // JPL can also throw Errors, eg out of stack space.
			 // wrap error in an exception, our warning class can't eat errors right now.
			new Warning("query "+pQueryString +" threw an error",new Exception(e));
		}
		if (useforeignframe)
			foreignframe.close();
		return lSolutions;
	}
	

	
	/** @returns a solution substitition from JPL converted into */
	public static Substitution mapSWISolutionToSubst(Hashtable pSolution) {
		Substitution lSubst = new Substitution(new LinkedHashSet<Binding>());
		
		Enumeration<String> lKeys = pSolution.keys();
		while (lKeys.hasMoreElements()) {
			String lKey = new String();
			try {
				lKey = (String)(lKeys.nextElement());
			} 
			catch (ClassCastException e) {
				new Warning("Internal error: JPL did not return expected string-type key",e);
			}
			
			SWIVariable lVar = null;
			try {
				lVar = new SWIVariable(new VariableTerm(lKey.toString())); // ASSUMPTION: can reconstruct variable name from keys in hash table
			} catch (Exception e) {
				new Warning("Internal error: SWI var failure:",e);
			}
			Term lTerm = null;
			try {
				lTerm = SWIPrologLanguage.getInstance().mapJPLTerm2SWITerm((jpl.Term)pSolution.get(lKey));
			} catch (Exception e) {
				new Warning("Internal error: Problem converting term "+pSolution.get(lKey),e);
			}
			lSubst.addBinding(lSubst.new Binding(lVar, lTerm));
			// put(new GenericPrologInterface.Variable(key),JPLTermToGenericTerm(value));
		}
		return lSubst;
	}
	
	/**
	 * Added W.Pasman 9feb2009 to free up all resources associated with 
	 * an inference engine. Make sure that you call this from every thread that did one or more SWIQuery calls
	 * Fixed 23apr09: you can now also call this if you did not do any SWIQuery calls yet.
	 */
	public static void FreeEngine() throws Exception {
		if (foreignframe!=null) {
			foreignframe.destroyEngine();
		}
	}
}