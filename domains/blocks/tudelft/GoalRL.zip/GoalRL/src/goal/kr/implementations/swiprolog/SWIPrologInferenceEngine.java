package goal.kr.implementations.swiprolog;

/**
 * 
 * @author Koen Hindriks.
 * Modified and extended source code originally written by Wouter Pasman.
 * 
 */

import goal.core.kr.Database;
import goal.core.kr.InferenceEngine;
import goal.core.kr.KRlanguage;
import goal.core.kr.language.Expression;
import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Substitution;
import goal.tools.debugger.Debugger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;


public class SWIPrologInferenceEngine implements InferenceEngine {
	
	// Class fields
	private String fName;
	
	/**set properties as you need. Check the constructor function for possibilities.*/
	public Properties PropertiesF; 
	
	// Class constructor
	public SWIPrologInferenceEngine(String pName) {
		fName = new String(pName);
		PropertiesF = new Properties();
		PropertiesF.setProperty("EnableJPLQueryBugFix","true"); // default.
	}
	
	// Class methods
	public String getName() {
		return fName;
	}
	
	public Set<Substitution> query(QueryExpression pQuery, Database pDB, Debugger debugger) throws Exception {	
		String query;
		if(pQuery instanceof SWILiteral) {
			//  CHECK: this check was performed based on assumption that JPL does not work properly when the name of
			// the database is put in front of a negation. Apparently, it does work when negation occurs in conjunction
			// and put "true," in front of it, but not if we have a plain literal? 
			if (((SWILiteral)pQuery).getSign())
				query = pDB.getName()+": "+pQuery;
			else
				query = "not("+ pDB.getName()+": "+((SWILiteral)pQuery).getPredicate()+")";
		} else if (pQuery instanceof SWIQueryExpression) { // Predicate isa QueryExpression
			query="true,"+pDB.getName()+": ("+((SWIQueryExpression)pQuery).getTerm()+")";
		}
		else throw new IllegalArgumentException("SWI engine can not handle query expression of type "+pQuery.getClass());
		
		return SWIQuery.rawquery(query, debugger);
	}
	
	
	public Set<Substitution> rawquery(String query,Debugger debugger) throws Exception {
		return SWIQuery.rawquery(query, debugger);
	}

	/*
	 * Wouter: below old version of the code. So silly that I replaced it entirely.
	 * CHECK Thanks, I guess...
	 * 
	public Set<Substitution> query(QueryExpression pQuery,  Database pDB) throws Exception {	
		// A database is implemented in SWI Prolog as a module (context) which has the same name as the database itself.
		// ASSUMPTION: pQuery is a single literal or a conjunction of literals.
		ArrayList<SWIFormula> lLits = new ArrayList<SWIFormula>();
		if (pQuery instanceof SWIPredicate || pQuery instanceof SWILiteral)
			lLits.add((SWIFormula)pQuery);
		//else if (pQuery instanceof SWIConjunction) {
		//	lLits = ((SWIConjunction)pQuery).getFormulas();
		//} 
		else throw new Exception("Expected one or more literals. Got "+pQuery.toString());
		//DT: the following query does no work:
		//String lQueryString = pDB.getName()+":("+lLits.get(0).toString()+")";
		//JPL allows the name of the database before the predicate only CHECK
		String lQueryString;
		if((lLits.get(0)) instanceof SWILiteral) {
			if(((SWILiteral)(lLits.get(0))).getSign())
				lQueryString = pDB.getName()+": "+lLits.get(0).toString()+"";
			else
				lQueryString = "not("+ pDB.getName()+": "+((SWILiteral)(lLits.get(0))).getPredicate().toString()+")";
		} else {
			lQueryString = pDB.getName()+":("+lLits.get(0).toString()+")";
		}
		for (int i=1; i<lLits.size(); i++)
			lQueryString += ","+ pDB.getName()+":("+lLits.get(i).toString()+")";
			// toString adds 'not(..)' if necessary. 
		
		//Wouter: note, we could have written the entire conversion as something like
		// "true,swidb0:("+llIts.toString()+")"
		// the "true," is needed to avoid jpl problem with querys starting with "swidb0:"

		return rawquery(lQueryString,pDB.getDebugger());
	}
	*/
	

	
	/**
	 * A trick is used to implement the method 'getAllSentences'. By performing the query below, a file  is obtained
	 * with the listing of all Prolog formulas in database pDB.
	 * open('cat',write,Stream,[]),with_output_to(Stream,listing),close(Stream).
	 * Note: /tmp has to be writable.
	 * 
	 * Debug hint: use watch expression (and hack the dynamic0 into database you need )
	 * (new Query("tmp_file('tmp',X),open(X,write,Stream,[]),with_output_to(Stream,"+"dynamic0:listing),close(Stream)")).allSolutions()
	 * 
	 * @return array of strings, each holding one database item.
	 * 
	*/
	public synchronized SWIFormula[] getAllSentences(Database pDB) throws Exception {
	
		Hashtable[] lSolutions;
		
		// Save all sentences present in the SWI Prolog database (module) to a temp file.
		// Wouter: it's weird but asking "listing" straight away dumps not the full listing to the screen
		// but only "dynamic at/1". To file, everything works as it should????
		lSolutions = SWIQuery.synchronizedRawquery("tmp_file('tmp',X),open(X,write,Stream,[]),with_output_to(Stream,"+pDB.getName()+":listing),close(Stream).");
		
		if (lSolutions.length == 0) 
			throw new Exception("Listing query failed, without detailed report...");

		Object lName = lSolutions[0].get("X");
		
		String lFilename;
		lFilename = lName.toString();
		//System.out.println("Saved database "+pDB.getName()+" to temporary file "+lFilename+".");
		lFilename=lFilename.substring(1,lFilename.length()-1); //cut the enclosing quotes.
		
		String lLine;
        ArrayList<String> lRules = new ArrayList<String>();
		File lListingfile=new File(lFilename);
		FileReader lFileReader=new FileReader(lListingfile);
		BufferedReader lBufferReader=new BufferedReader(lFileReader);

		String lCurrentRule = new String();
		while((lLine=lBufferReader.readLine())!=null){
			if(lLine.contains(":- dynamic")) // Wouter: we really should keep them but parser crashes currently on "dynamic wumpus/1"
			{
				//System.out.println(lLine);
				continue;
			}
			lCurrentRule = lCurrentRule+lLine;
			if (lCurrentRule.length()>0 && lCurrentRule.charAt(lCurrentRule.length()-1)=='.' )
			{
				lRules.add(lCurrentRule+" "); //Wouter 16jul08: clauses need WHITESPACE at end.
				lCurrentRule="";		
			}
		}

		SWIFormula[] lAllFormulas = new SWIFormula[lRules.size()];
		
		KRlanguage lLangue = SWIPrologLanguage.getInstance();
		for (int i=0; i<lRules.size(); i++) {
			Expression lExpr = lLangue.parser(lRules.get(i));
			if (lExpr!=null)
				lAllFormulas[i] = new SWIFormula(lExpr);
			else
				throw new Exception("Unable to parse formula "+lRules.get(i)+"retrieved from database.");
		}

		lBufferReader.close();
		lListingfile.delete(); // Wouter: for debugging turn this off.
		
		return lAllFormulas;
	}
}
