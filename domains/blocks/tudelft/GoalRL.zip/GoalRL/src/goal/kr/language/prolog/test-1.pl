-1.
between(-1,1,X).
-(3+2).
not((true,true)).
