package goal.kr.implementations.swiprolog;

import goal.core.kr.language.Var;
import goal.kr.language.prolog.VariableTerm;

/**
 * Wouter: we need this because Substitution needs it. 
 * Otherwise these are just strings containing the var name.
 *
 */

public class SWIVariable extends SWIExpression implements Var {
	
	public int hashCode() { return 1; }
		
	public SWIVariable(VariableTerm t) { super(t); }
	
	public SWIVariable(String name) { super(new VariableTerm(name)); }
	
	public String getVarName() { return ((VariableTerm)this.getTerm()).getName(); }
	
	public Var clone() { return (Var) new SWIVariable((VariableTerm)getTerm()); }
	
	public boolean equals(Object o) {
		if (!(o instanceof SWIVariable)) return false;
		return getVarName().equals( ((SWIVariable)o).getVarName());
	}
	
	public SWITerm getSimilar() {
		String varname="_"+this.getTerm().getName();
		return new SWITerm(new VariableTerm(varname));
	}
}

/*
  	private String fName;
	
	// Constructor
	public SWIVariable(String pName) throws Exception
	{
		super(new VariableTerm(pName));
		if (pName==null)
		 	throw new Exception("Variable name not specified.");
		if (Character.isUpperCase(pName.charAt(0)) || pName.charAt(0)=='_') {
			fName = new String(pName);
		}
		else
			throw new Exception("Variable "+fName+" must start with an uppercase character or '_'.");
	}
	
	// Class methods
	public SWIVariable clone() {
		try {
			return new SWIVariable(new String(this.fName));
		} catch (Exception e) {
			return null;
		}
	}
	
	public boolean isClosed() {
		return false;
	}
	
	public boolean equals(Object pExpr) { 
		if (pExpr instanceof SWIVariable) {
			return (fName.equals(((SWIVariable)pExpr).getName())); 
		} else
			return false;
	}
	
	public Set<Var> getFreeVar() {
		Set<Var> lVars = new LinkedHashSet<Var>();
		lVars.add(this);
		return lVars;
	}

	public String getName() {
		return fName;
	}
	
	public String toString() {
		return fName;
	}


	public Expression applySubst(Substitution pSubst) {
		if (pSubst.get(this)!=null) {
			return pSubst.get(this).clone();
		} else
			return this;
	}

	public KRlanguage getLanguage() {
		return SWIPrologLanguage.getInstance();
	}

	public boolean isVar() {
		return true;
	}
	
	public boolean isAnonymous()
	{
		return fName.equals("_");
	}

	public Substitution mgu(Expression pExpr) {
		if (!(pExpr instanceof Term) || pExpr.getFreeVar().contains(this)) {
			return null;
		} else
			return new Substitution((Var)this,(Term)pExpr);
	}
}
 */