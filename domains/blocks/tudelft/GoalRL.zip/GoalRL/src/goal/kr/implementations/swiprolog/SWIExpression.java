package goal.kr.implementations.swiprolog;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Hashtable;

import goal.core.kr.KRlanguage;
import goal.core.kr.language.*;

import goal.kr.language.prolog.*;
import goal.tools.errorhandling.Warning;
import goal.kr.language.prolog.PrologTerm;

/**
 * 
 * SWIPredicate is glue code between the GOAL Expression and the prolog PrologTerm.
 * Converts GOAL Expression to a SWI expression, do the computation, and convert result back to GOAL.
 * 
 * @author W.Pasman 9jul08.
 * 
 * I'm trying to keep the functionality out of the PrologTerm code.
 * That results in a number of "instanceof" checks inside this implementation...
 */

public class SWIExpression implements Expression {

	// Class fields
	private PrologTerm term; // the term behind this predicate.
	
	/**
	@param   term the prolog term behind the predicate.
	@throws Exception not a good predicate. 
	 */
	
	public SWIExpression(Expression e) {
		if (!(e instanceof SWIExpression))
			throw new ClassCastException("SWI glue layer can currently not handle expression "+e+" of type "+e.getClass());
		term = ((SWIExpression)e).getTerm().clone();
	}
	
	public SWIExpression(PrologTerm t) {
		if (t==null)
			throw new NullPointerException("null argument to initialize SWIExpression");
		term = t.clone(); 
	}

	 /** @returns String explaining why this is not a predicate, or null if it is a predicate . */
	public String isPredicate() {
		if (term==null)
			return "null term is no good predicate";
		if (term instanceof VariableTerm)
			return "variable is no predicate";
		//TODO check headers, mathematical functions are not predicates.
		return null;
	}
	
	public boolean isLiteral() {
	// Keep things simple:
	// literal is BasicTerm or
	// FuncTerm with main operator that is not built-in, or equal to 'not'.
		if (term instanceof VariableTerm)
			return false;
		if (term instanceof BasicTerm)
			return true;
		if (term instanceof FuncTerm) {
			FuncTerm temp = (FuncTerm)term;
			if (temp.getName().equals("not"))
				return true;
			else
				return !prologBuiltin(temp.getName());
		}
		return false;
	}
	
	public String toString() { return ""+term; }
	
	public Expression clone() {
		return new SWIExpression(term.clone()); // note this does not clone the term itself. is that needed? YES...
	}

	public boolean isClosed() { return getFreeVar().isEmpty(); }

	public boolean isQuery(String pStr) {
		return true; //TODO. Does it make sense anyway?
	}
	
	/*
	public boolean equals(Object o) {
		if (!(o instanceof SWIExpression)) return false;
		return term.equals(((SWIExpression)o).getTerm());
	}
	*/
	

	/** Wouter: what makes this tricky is that Substitution is a generic GOAL object 
	 * and we have to convert it back to SWI prolog terms */
	public SWIExpression applySubst(Substitution s) {
		 /* Convert GOAL Substitution into SWI Prolog substitution (a plain hashtable) */
		Hashtable<String,PrologTerm> substis=new Hashtable<String,PrologTerm> ();
		for ( Substitution.Binding b: s.getBindings())
		{
			/*GOAL*/Term term=b.getTerm();
			if (!(term instanceof SWIExpression))
				throw new RuntimeException("Term "+term+" is not a SWIExpression, conversion not implemented");
			substis.put( b.getVar().getVarName(),((SWIExpression)term).getTerm());
		}
		return new SWIExpression(applySubst(term,substis));
	}

		/** 
		 * This version of applySubst works in Prolog land.
		 * returns new substitution, with the given substi applied to this 
		 * Hashtable is set of <varname,term> values to be substituted. 
		 * PROBABLY BUG: if PrologTerm contains other vars, these should be substituted as well?
		 * DOC: KH 28Jul08: I am not sure what you mean, but applying a substitution just replaces
		 * those variables that occur both in term as well as in substitution...
		 * @throws IllegalArgument if given term is of unknown type. TODO make throws explicit?
		 * */
	public PrologTerm applySubst(PrologTerm term, Hashtable<String,PrologTerm> substitution) {
		
		if (term instanceof BasicTerm)
			return term;
		if (term instanceof VariableTerm) {
			PrologTerm instantiation = substitution.get(((VariableTerm)term).getName());
			if (instantiation!=null)
				return instantiation;
			else
				return term;
		}
		if (term instanceof FuncTerm) {
			FuncTerm ft = (FuncTerm)term;
			ArrayList<PrologTerm> instantiatedArgs = new ArrayList<PrologTerm>();
			for (PrologTerm arg: ft.getArguments())
				instantiatedArgs.add(applySubst(arg, substitution));
			return new FuncTerm(ft.getName(), instantiatedArgs);
		}

		throw new IllegalArgumentException("PrologTerm "+term+" has unknown type");
	}

	/** @returns null, if getFreeVar() fails. CHECK Koen please check: I think this should be a throw */
	public Set<Var> getFreeVar()  {
		try { return getFreeVar(term);}
		catch (Exception e) {new Warning("term "+term+" seems to contain vars that are incompatible with GOAL",e); }
		return null;
	}

	
	/** version with an argument, allowing recursive calling
	 * May throw, if term contains variables that are incompatible with GOAL. */
	public Set<Var> getFreeVar(PrologTerm t) {
		Set<Var> lVarSet = new LinkedHashSet<Var>();

		if (t instanceof VariableTerm) { lVarSet.add(new SWIVariable((VariableTerm)t));}
		else if (t instanceof FuncTerm)
		{
			for (PrologTerm arg: ((FuncTerm) t).getArguments() )
				lVarSet.addAll(getFreeVar(arg));
		}
		// else it must be the BasicTerm which does nothing.

		return lVarSet;
	}

	public KRlanguage getLanguage() {
		return SWIPrologLanguage.getInstance();
	}

	public boolean isVar() {
		return false;
	}
	
	public PrologTerm getTerm() { return term; }

	public Substitution mgu(Expression e) {
		if (!(e instanceof SWIExpression)) return null; // CHECK: need to support other languages?
		return mgu(term,((SWIExpression)e).getTerm());
	}
	
	/* compute mgu of two prolog terms */
	public Substitution mgu(PrologTerm t1,PrologTerm t2) {
		if (t1 instanceof BasicTerm) 
			{ if (t1.equals(t2)) return new Substitution(); else return null; }
		if (t1 instanceof VariableTerm) {
			 // check that this is actually a working substi has to be checked
			 // higher up in the mgu hierarchy (see FuncTerm code below).
			Var v=new SWIVariable((VariableTerm)t1);
			if ((t2 instanceof VariableTerm) || !getFreeVar(t2).contains(v))
				return new Substitution(v,new SWITerm(t2));
			else
				return null;
		}
		if (t1 instanceof FuncTerm) {
			if (!(t2 instanceof FuncTerm)) return null;
			FuncTerm f1=(FuncTerm)t1;
			FuncTerm f2=(FuncTerm)t2;
			if (! f1.getName().equals(f2.getName())) return null;
			ArrayList<PrologTerm> args1=f1.getArguments();
			ArrayList<PrologTerm> args2=f2.getArguments();
			if (args1.size()!=args2.size()) return null;
			
			 // functions with same number of args. Match all the args and merge results.
			Substitution subs=new Substitution();
			for (int i=0; i<args1.size(); i++)
			{
				subs = subs.combine(mgu(args1.get(i),args2.get(i)));
				if (subs==null) break;
			}
			return subs;
		}
		throw new IllegalArgumentException("PrologTerm "+term+" has unknown type");
	}
	
	public boolean prologBuiltin(String operator) {
		// DOC: This list is far from complete! TODO: Extend this list to increase coverage.
		final Hashtable<String,Integer> operators = new Hashtable<String,Integer>();
		
		// copied from class FuncTerm
		operators.put(":/1", 50);
		operators.put("@/1",100); 
		operators.put("-/1",200); 
		operators.put("\\/1",200);
		operators.put("**/2",200);
		operators.put("^/2",200);
		operators.put("*/2",400);
		operators.put("//2",400);
		operators.put("///2",400);
		operators.put("rem/2",400);
		operators.put("mod/2",400);
		operators.put("<</2",400);
		operators.put(">>/2",400);
		operators.put("+/2",500);
		operators.put("-/2",500);
		operators.put("/\\/2",500);
		operators.put("\\//2",500);
		operators.put("is/2",700);
		operators.put("=:=/2",700);
		operators.put("=\\=/2",700);
		operators.put("</2",700);
		operators.put("=</2",700);
		operators.put(">/2",700);
		operators.put(">=/2",700); 
		operators.put("=../2",700); 
		operators.put("==/2",700); 
		operators.put("\\==/2",700); 
		operators.put("@<2",700); 
		operators.put("@=</2",700); 
		operators.put("@>/2",700); 
		operators.put("@>=/2",700); 
		operators.put("=/2",700); 
		operators.put("=\\=/2",700); 
		operators.put(",/2",1000); 
		operators.put("->/2",1050); 
		operators.put(";/2",1100); 
		operators.put(":-/1",1200); 
		operators.put("?-/1",1200); 
		operators.put(":-/2",1200);
		operators.put("-->/2",1200);
		// added; prio not really important here
		operators.put("dynamic/1",0);
		operators.put("assert/1",0);
		operators.put("retract/1",0);
		operators.put("not/1",0);
		// check
		return operators.containsKey(operator);
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((term == null) ? 0 : term.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final SWIExpression other = (SWIExpression) obj;
		if (term == null) {
			if (other.term != null)
				return false;
		} else if (!term.equals(other.term))
			return false;
		return true;
	}
	
}
 