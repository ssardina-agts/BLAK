package goal.kr.implementations.swiprolog;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

import org.antlr.runtime.ANTLRReaderStream;

import goal.core.kr.Database;
import goal.core.kr.InferenceEngine;
import goal.core.kr.KRlanguage;
import goal.core.kr.Theory;
import goal.core.kr.UpdateEngine;
import goal.core.kr.language.*;
import goal.kr.language.prolog.*;
import goal.parser.LinkedListTokenSource;
import goal.parser.LinkedListTokenStream;

/**
 * 
 * @author Koen Hindriks
 * @modified 10jul08 W.Pasman
 *
 */

public class SWIPrologLanguage implements KRlanguage{
	
	// Wouter: modified 13jan09: in the ElevatorEnv we want to refer to SWIPrologLanguage without
	// immediately requiring SWI Prolog and ForeignFrame in the class path.
	// Therefore we need access to the name without instantiating the SWIPrologLanguage.
	// TODO: Use KRLANGUAGES.SWIProlog instead!
	public static String fName = KRLANGUAGES.SWIProlog.toString();
	
	private static SWIPrologLanguage fInstance=null; // use this for Singleton Design Pattern
	private SWIPrologInferenceEngine fInfEngine;
	private SWIPrologUpdateEngine fUpdEngine;
	private ArrayList<SWIPrologDatabase> fSWIDbs;
	
	// Constructor
	public SWIPrologLanguage() {
		fSWIDbs = new ArrayList<SWIPrologDatabase>();
		fInfEngine = new SWIPrologInferenceEngine("SWIPrologInferenceEngine");
		fUpdEngine = new SWIPrologUpdateEngine("SWIPrologUpdateEngine");
		// See http://www.swi-prolog.org/packages/jpl/release_notes.html for explanation
		// why Don't Tell Me Mode needs to be false. Setting this mode to false ensures
		// that variables with initial '_' are treated as regular variables.
		jpl.JPL.setDTMMode(false);
	}
	
	// Class methods
	/** @deprecated 13jan09 W.Pasman: now just read SWIPrologLanguage.fName. See also mantis 476*/
	public String getName() {
		return fName;
	}
	
	public static SWIPrologLanguage getInstance() {
		if (fInstance==null) {
			fInstance = new SWIPrologLanguage();
		}
		return fInstance;
	}
	
	public boolean equals(Object pLangue) {
		if (this == pLangue)
			return true;
		else return false;
	}
	
	
	/** 
	 * The method 'parser' takes a string a returns an expression object that
	 * correspondsin to the grammar category associated with a language.
	 * @param pStr A string.
	 * @return An 'Expression' object if string pStr is part of the language,
	 * otherwise 'null'.
	 */
	private PrologParser prepareEmbeddedParser(String pString) {	
		PrologParser parser;
		try {
			ANTLRReaderStream charstream = new ANTLRReaderStream(new StringReader(pString));
			PrologLexer lLexer = new PrologLexer(charstream);
			lLexer.setSourceName(pString);
			LinkedListTokenSource linker = new LinkedListTokenSource(lLexer);
			LinkedListTokenStream tokenStream = new LinkedListTokenStream(linker);
			parser = new PrologParser(tokenStream);
			parser.setSourceName(pString);
			parser.setInput(lLexer, charstream);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return parser;
	}
	
	/** @author W.Pasman. Parses expression WITHOUT dot at the end. 
	 * @returns SWIExpression 
	 * @throws Wouter 23sept: now throws proper message if problem occurs, 
	 * instead of returning null.  */
	public SWIExpression parser(String pStr) throws Exception {
		PrologParser parser = prepareEmbeddedParser(pStr);
		PrologTerm term=parser.clause(); // Wouter 16jul08: was 'term1200' but we need to eat the '.<WHITESP>' at the end as well.
		if (term==null) throw new RuntimeException(parser.lasterror); // Wouter: rethrow the parser error.... TODO not yet complete... how to get full text??
		return new SWIExpression(term);
	}
	
	/**
	 * 
	 * @author W.Pasman. 
	 * 
	 */
	public Term mapJPLTerm2SWITerm(jpl.Term pTerm) throws Exception {
		return new SWITerm(mapJPLTerm2PrologTerm(pTerm));
	}
	
	public PrologTerm mapJPLTerm2PrologTerm(jpl.Term pTerm)	throws Exception {
		if (pTerm.isAtom())  // Constant, or empty list...
			return new BasicTerm(pTerm.toString()); //Wouter, was BasicTerm(pTerm.name()), see mantis 694

		if (pTerm.isCompound()) { // Function term, or list...
			ArrayList<PrologTerm> args = new ArrayList<PrologTerm>();
			
			for (int i=0; i<pTerm.arity(); i++)	{
				// JPL starts counting at 1 instead of 0... Use 'i+1'!
				args.add(mapJPLTerm2PrologTerm(pTerm.arg(i+1)));
			}

			return new FuncTerm(pTerm.name(),args);
		}

		if (pTerm.isFloat())
			return new BasicTerm(""+pTerm.doubleValue());

		if (pTerm.isInteger())
			return new BasicTerm(""+pTerm.intValue());

		if (pTerm.isVariable())
			return new BasicTerm(pTerm.name());

		// Run out of options... Throw exception.
		throw new IllegalArgumentException("SWI term "+pTerm.toString()+" has unknown type "+pTerm.type());
	}
	
	public Database makeDatabase(String name, Theory theory) throws Exception {
		SWIPrologDatabase database = new SWIPrologDatabase(name, theory);
		fSWIDbs.add(database);
		return database;
	}

	/**
	 * The method 'getInferernceEngine' returns the associated inference engine of the
	 * knowledge representation (KR) language. An API for a language should always
	 * supply an inference engine, otherwise the GOAL programming language will not be
	 * able to operate with the KR language.
	 * @return The inference engine that is associated with the language, if no
	 * inference engine is available an exception should be thrown.
	 */
	public InferenceEngine getInferenceEngine() {
		return fInfEngine;
	}
	
	/**
	 * The method 'getUpdateEngine' returns the associated update engine of the
	 * knowledge representation (KR) language. An API for a language only needs to
	 * supply an update engine with a language if the language is used to specify the
	 * POSTconditions of actions of agents, or one of the actions 'insert' or 'delete'
	 * are used in an agent program to insert/delete sentences from the language.
	 * (Note that this can be verified at parse time.)
	 * @return The inference engine that is associated with the language, if no
	 * inference engine is available an exception should be thrown.
	 */
	public UpdateEngine getUpdateEngine() {
		return fUpdEngine;
	}
	
}
