package goal.kr.implementations.swiprolog;

import java.util.LinkedHashSet;

import goal.core.kr.Database;
import goal.core.kr.KRlanguage;
import goal.core.kr.Theory;
import goal.core.kr.language.Formula;
import goal.tools.errorhandling.Warning;
import java.util.Hashtable;


/**
 * Each database can be viewed as a set of sentences, i.e. closed formula.
 * An API implementation of the Database interface needs to comply with
 * this set-theoretic view of a database and come with a set of associated
 * set-theoretic methods such as defined in the UpdateEngine interface. 
 * 
 * @author Koen Hindriks
 * 
 */

public class SWIPrologDatabase implements Database {

	// Class fields
	private String name; // SWI-Prolog module name
	private Theory theory; // set of formulae part of database
	static int uniqueNumberCounter=0; // to generate new database names.

	static LinkedHashSet<SWIPredicate> dynamicpredicates=new LinkedHashSet<SWIPredicate>(); // CHECK: OBSOLETE we don't need this?

	// Constructor
	public SWIPrologDatabase(String name, Theory theory) throws Exception {
		if (name.equals(""))
			name = "swidb";
		this.name = new String(name+uniqueNumberCounter);
		uniqueNumberCounter++;
		
		this.theory = new Theory(); // the theory is added to this.theory by the expand method below.
		
		SWIQuery.synchronizedRawquery(name+":true");
		
		for (String formula : theory.getFormulae())
			getLanguage().getUpdateEngine().expand(new SWIFormula(getLanguage().parser(formula+". ")), this);
	}

	// Class methods
	public String getName() {
		return name;
	}
	
	public Theory getTheory() {
		return theory;
	}
	
	public void add(Theory theory) { // ASSUMES theory is consistent with this.theory.
		try {
			for (String formula : theory.getFormulae())
				getLanguage().getUpdateEngine().expand(new SWIFormula(getLanguage().parser(formula+". ")), this);
			this.theory.add(theory);
		}
		catch (Exception e) { new Warning("add failed:",e); }
	}
	
	public String toString() {
		return "<"+name+">";
	}
	
	/**
	 * Initialise database. Perform whatever operations are necessary to setup a new database.
	 */
	public Database initialise() {
		return this;
	}
	
	/**
	 * Appends the contents of a database from a prolog file and import it into the database. This
	 * method is typically used directly after initialisation to add content to a database.
	 * But can also be used to handle #include etc.
	 * @param pFilename The name of the file.
	 */
	// TODO: we need to use parser here to also load content from file into theory.
	public void loadFromFile(String pFilename) throws Exception {	
		// Create JPL query object. Load file into module name 'fName'. 
		// Wouter: I found that loading requires a strange construct.
		// First, the manual seems not to document loading a file into a module.
		// when in the SWI prolog command prompt, what works is module:consult('filename')
		// but this seems not to work through the JPL interface.
		//  with the JPL interface, the following seems to work though:
		// consult(module:'filename')
		Hashtable[] res=SWIQuery.synchronizedRawquery("consult("+name+":'"+pFilename+"')");
		if (res==null || res.length==0)
			throw new Exception("Load failed for unknown reason.");
		else System.out.println("Succesfully loaded file: "+pFilename);
	}
	
	/**
	 * Each database consists of sentences from a UNIQUE language.
	 * @return the knowledge representation language associated with the database.  
	 */
	public KRlanguage getLanguage() {
		return SWIPrologLanguage.getInstance();
	}
	
	public void showStatistics() {
		try { SWIQuery.synchronizedRawquery("statistics"); }
		catch (Exception e) { new Warning("can't get stats: ",e); }
	}
	
	/**
	 * copy contents (all predicates) from another database to this database.
	 * WARNING SWI specific.
	 * @author W.Pasman 9jan07
	 * @param sourcedb the database to copy the contents from
	 */
	public void copycontentsfrom(SWIPrologDatabase sourcedb) throws Exception {
		 // CHECK OBSOLETE? first copy the predicates that were declared dynamic
		for (SWIPredicate p:sourcedb.getDynamicPredicates()) addDynamicPredicate(p);
		
		 // and copy the contents using one smart query.
		String source = sourcedb.getName();
		String target = name;
		String findone = "("+source+":current_predicate(Predicate, Head),"+
			"not(predicate_property("+source+":Head,built_in)),"+
			"not(predicate_property("+source+":Head,foreign)),"+
			"not(predicate_property("+source+":Head,imported_from(_))),"+
			"clause("+source+":Head,Body),"+
			target+":assert(Head:-Body))";
		Hashtable[] sol=SWIQuery.synchronizedRawquery("findall(1,"+findone+",R).");
		if (sol==null || sol.length==0)
			throw new Exception("copycontents from "+source+" to "+target+" failed for unknown reason.");
	}

	/** return a clone of this database
	 * @author W.Pasman
	 */
	public SWIPrologDatabase clone() { // clone does not allow throwing...
		SWIPrologDatabase db=null;
		try { 
			db = new SWIPrologDatabase("", this.theory);
			db.copycontentsfrom(this);
		} catch (Exception e) {
			new Warning("clone fails",e);
		}
		return db;
	}
	
	/**
	 * @author W.Pasman
	 * removes all predicates from database. CHECK: Only predicates? Why not all clauses?
	 * WARNING. This is not implementable fully in SWI prolog.
	 * You can reset a database to free up some memory, but do not re-use the database.
	 * However, it will NOT reset the dynamic declarations.
	 * This is a bug, but nevertheless..  So if you
	 * ever declared predicate P to be dynamic it will still be dynamic
	 * after calling clear
	 * Workaround: after resetting do not re-use this database but make new one.
	 * In most cases you want to keep the dynamic declarations anyway
	 */
	public void eraseContent() {
		String deleteone="(" +name+":current_predicate(Predicate, Head)," +
				"not(predicate_property(" +name+":Head,built_in))," +
				"not(predicate_property(" +name+":Head,foreign))," +
				"not(predicate_property(" +name+":Head,imported_from(_)))," +
				"retractall(" +name+":Head)).";
		try { SWIQuery.synchronizedRawquery(deleteone); }
		catch (Exception e) { new Warning("eraseContent failed:",e); }
		theory.clear();
	}

	// CHECK methods below OBSOLETE?
	public void addDynamicPredicate(SWIPredicate p) {	
		if (dynamicpredicates.contains(p)) return;
		
		dynamicpredicates.add(p);
		try { SWIQuery.synchronizedRawquery("true,"+name+":"+p); }
		catch (Exception e) { new Warning("dynamic declaration "+p+" failed for database "+name,e); }
	}
		
	public LinkedHashSet<SWIPredicate> getDynamicPredicates() { return dynamicpredicates; }
}
