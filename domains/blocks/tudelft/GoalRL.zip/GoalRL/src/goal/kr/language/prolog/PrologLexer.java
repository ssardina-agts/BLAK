// $ANTLR 3.0.1 Prolog.g 2008-12-09 09:01:59

    package goal.kr.language.prolog;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class PrologLexer extends Lexer {
    public static final int REST_OF_FLOAT=10;
    public static final int T29=29;
    public static final int ENDTOKEN=4;
    public static final int NUMBER=6;
    public static final int T36=36;
    public static final int T58=58;
    public static final int T35=35;
    public static final int T61=61;
    public static final int T45=45;
    public static final int T34=34;
    public static final int T64=64;
    public static final int WHITESPACECHAR=17;
    public static final int T25=25;
    public static final int T37=37;
    public static final int T26=26;
    public static final int T32=32;
    public static final int T51=51;
    public static final int SYMBOLIC_CONTROL_CHAR=21;
    public static final int T46=46;
    public static final int DIGIT=16;
    public static final int T38=38;
    public static final int T41=41;
    public static final int T24=24;
    public static final int HEXADECIMALCONSTANT=13;
    public static final int T69=69;
    public static final int T39=39;
    public static final int T62=62;
    public static final int T44=44;
    public static final int T55=55;
    public static final int T68=68;
    public static final int T33=33;
    public static final int T50=50;
    public static final int CHAR=19;
    public static final int STRING=8;
    public static final int ALPHACHAR=15;
    public static final int T43=43;
    public static final int T28=28;
    public static final int T42=42;
    public static final int T66=66;
    public static final int T40=40;
    public static final int COMMENT=22;
    public static final int T63=63;
    public static final int T57=57;
    public static final int OCTALCONSTANT=12;
    public static final int T65=65;
    public static final int BINARYCONSTANT=11;
    public static final int T56=56;
    public static final int WHITESPACE=23;
    public static final int INTEGERCONSTANT=9;
    public static final int T59=59;
    public static final int T48=48;
    public static final int EXPONENT=14;
    public static final int ESCAPE_SEQUENCE=18;
    public static final int T54=54;
    public static final int VARIABLE=5;
    public static final int EOF=-1;
    public static final int T67=67;
    public static final int T47=47;
    public static final int META_CHAR=20;
    public static final int Tokens=70;
    public static final int T53=53;
    public static final int T60=60;
    public static final int T31=31;
    public static final int T49=49;
    public static final int T27=27;
    public static final int T52=52;
    public static final int NAME=7;
    public static final int T30=30;

    	String sourcename;
    	public String lasterror=null; //  non-null if error occured. 
    	 // Wouter: made public 23sept08, so that GOAL can recover error if null term comes back.
    	 // null term comes back because Prolog parser will try to recover (which then fails again..).

    	public void setSourceName(String name) { sourcename=name; }

    	@Override 
    	public String getErrorHeader(RecognitionException e) {
    		lasterror="Prolog lexer error, "+sourcename+" line "+e.line+", position "+e.charPositionInLine;
    		return lasterror;
    	}

    public PrologLexer() {;} 
    public PrologLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "Prolog.g"; }

    // $ANTLR start T24
    public final void mT24() throws RecognitionException {
        try {
            int _type = T24;
            // Prolog.g:20:5: ( ':-' )
            // Prolog.g:20:7: ':-'
            {
            match(":-"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T24

    // $ANTLR start T25
    public final void mT25() throws RecognitionException {
        try {
            int _type = T25;
            // Prolog.g:21:5: ( ',' )
            // Prolog.g:21:7: ','
            {
            match(','); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T25

    // $ANTLR start T26
    public final void mT26() throws RecognitionException {
        try {
            int _type = T26;
            // Prolog.g:22:5: ( '[' )
            // Prolog.g:22:7: '['
            {
            match('['); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T26

    // $ANTLR start T27
    public final void mT27() throws RecognitionException {
        try {
            int _type = T27;
            // Prolog.g:23:5: ( ']' )
            // Prolog.g:23:7: ']'
            {
            match(']'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T27

    // $ANTLR start T28
    public final void mT28() throws RecognitionException {
        try {
            int _type = T28;
            // Prolog.g:24:5: ( '|' )
            // Prolog.g:24:7: '|'
            {
            match('|'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T28

    // $ANTLR start T29
    public final void mT29() throws RecognitionException {
        try {
            int _type = T29;
            // Prolog.g:25:5: ( '-->' )
            // Prolog.g:25:7: '-->'
            {
            match("-->"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T29

    // $ANTLR start T30
    public final void mT30() throws RecognitionException {
        try {
            int _type = T30;
            // Prolog.g:26:5: ( ';' )
            // Prolog.g:26:7: ';'
            {
            match(';'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T30

    // $ANTLR start T31
    public final void mT31() throws RecognitionException {
        try {
            int _type = T31;
            // Prolog.g:27:5: ( '->' )
            // Prolog.g:27:7: '->'
            {
            match("->"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T31

    // $ANTLR start T32
    public final void mT32() throws RecognitionException {
        try {
            int _type = T32;
            // Prolog.g:28:5: ( '=' )
            // Prolog.g:28:7: '='
            {
            match('='); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T32

    // $ANTLR start T33
    public final void mT33() throws RecognitionException {
        try {
            int _type = T33;
            // Prolog.g:29:5: ( '\\\\=' )
            // Prolog.g:29:7: '\\\\='
            {
            match("\\="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T33

    // $ANTLR start T34
    public final void mT34() throws RecognitionException {
        try {
            int _type = T34;
            // Prolog.g:30:5: ( '==' )
            // Prolog.g:30:7: '=='
            {
            match("=="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T34

    // $ANTLR start T35
    public final void mT35() throws RecognitionException {
        try {
            int _type = T35;
            // Prolog.g:31:5: ( '\\\\==' )
            // Prolog.g:31:7: '\\\\=='
            {
            match("\\=="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T35

    // $ANTLR start T36
    public final void mT36() throws RecognitionException {
        try {
            int _type = T36;
            // Prolog.g:32:5: ( '@<' )
            // Prolog.g:32:7: '@<'
            {
            match("@<"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T36

    // $ANTLR start T37
    public final void mT37() throws RecognitionException {
        try {
            int _type = T37;
            // Prolog.g:33:5: ( '@=<' )
            // Prolog.g:33:7: '@=<'
            {
            match("@=<"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T37

    // $ANTLR start T38
    public final void mT38() throws RecognitionException {
        try {
            int _type = T38;
            // Prolog.g:34:5: ( '@>' )
            // Prolog.g:34:7: '@>'
            {
            match("@>"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T38

    // $ANTLR start T39
    public final void mT39() throws RecognitionException {
        try {
            int _type = T39;
            // Prolog.g:35:5: ( '@>=' )
            // Prolog.g:35:7: '@>='
            {
            match("@>="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T39

    // $ANTLR start T40
    public final void mT40() throws RecognitionException {
        try {
            int _type = T40;
            // Prolog.g:36:5: ( '=..' )
            // Prolog.g:36:7: '=..'
            {
            match("=.."); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T40

    // $ANTLR start T41
    public final void mT41() throws RecognitionException {
        try {
            int _type = T41;
            // Prolog.g:37:5: ( 'is' )
            // Prolog.g:37:7: 'is'
            {
            match("is"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T41

    // $ANTLR start T42
    public final void mT42() throws RecognitionException {
        try {
            int _type = T42;
            // Prolog.g:38:5: ( '=:=' )
            // Prolog.g:38:7: '=:='
            {
            match("=:="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T42

    // $ANTLR start T43
    public final void mT43() throws RecognitionException {
        try {
            int _type = T43;
            // Prolog.g:39:5: ( '=\\\\=' )
            // Prolog.g:39:7: '=\\\\='
            {
            match("=\\="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T43

    // $ANTLR start T44
    public final void mT44() throws RecognitionException {
        try {
            int _type = T44;
            // Prolog.g:40:5: ( '<' )
            // Prolog.g:40:7: '<'
            {
            match('<'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T44

    // $ANTLR start T45
    public final void mT45() throws RecognitionException {
        try {
            int _type = T45;
            // Prolog.g:41:5: ( '=<' )
            // Prolog.g:41:7: '=<'
            {
            match("=<"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T45

    // $ANTLR start T46
    public final void mT46() throws RecognitionException {
        try {
            int _type = T46;
            // Prolog.g:42:5: ( '>' )
            // Prolog.g:42:7: '>'
            {
            match('>'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T46

    // $ANTLR start T47
    public final void mT47() throws RecognitionException {
        try {
            int _type = T47;
            // Prolog.g:43:5: ( '>=' )
            // Prolog.g:43:7: '>='
            {
            match(">="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T47

    // $ANTLR start T48
    public final void mT48() throws RecognitionException {
        try {
            int _type = T48;
            // Prolog.g:44:5: ( '+' )
            // Prolog.g:44:7: '+'
            {
            match('+'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T48

    // $ANTLR start T49
    public final void mT49() throws RecognitionException {
        try {
            int _type = T49;
            // Prolog.g:45:5: ( '/\\\\' )
            // Prolog.g:45:7: '/\\\\'
            {
            match("/\\"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T49

    // $ANTLR start T50
    public final void mT50() throws RecognitionException {
        try {
            int _type = T50;
            // Prolog.g:46:5: ( '\\\\/' )
            // Prolog.g:46:7: '\\\\/'
            {
            match("\\/"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T50

    // $ANTLR start T51
    public final void mT51() throws RecognitionException {
        try {
            int _type = T51;
            // Prolog.g:47:5: ( '*' )
            // Prolog.g:47:7: '*'
            {
            match('*'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T51

    // $ANTLR start T52
    public final void mT52() throws RecognitionException {
        try {
            int _type = T52;
            // Prolog.g:48:5: ( '/' )
            // Prolog.g:48:7: '/'
            {
            match('/'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T52

    // $ANTLR start T53
    public final void mT53() throws RecognitionException {
        try {
            int _type = T53;
            // Prolog.g:49:5: ( '//' )
            // Prolog.g:49:7: '//'
            {
            match("//"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T53

    // $ANTLR start T54
    public final void mT54() throws RecognitionException {
        try {
            int _type = T54;
            // Prolog.g:50:5: ( 'rem' )
            // Prolog.g:50:7: 'rem'
            {
            match("rem"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T54

    // $ANTLR start T55
    public final void mT55() throws RecognitionException {
        try {
            int _type = T55;
            // Prolog.g:51:5: ( 'mod' )
            // Prolog.g:51:7: 'mod'
            {
            match("mod"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T55

    // $ANTLR start T56
    public final void mT56() throws RecognitionException {
        try {
            int _type = T56;
            // Prolog.g:52:5: ( '<<' )
            // Prolog.g:52:7: '<<'
            {
            match("<<"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T56

    // $ANTLR start T57
    public final void mT57() throws RecognitionException {
        try {
            int _type = T57;
            // Prolog.g:53:5: ( '>>' )
            // Prolog.g:53:7: '>>'
            {
            match(">>"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T57

    // $ANTLR start T58
    public final void mT58() throws RecognitionException {
        try {
            int _type = T58;
            // Prolog.g:54:5: ( '**' )
            // Prolog.g:54:7: '**'
            {
            match("**"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T58

    // $ANTLR start T59
    public final void mT59() throws RecognitionException {
        try {
            int _type = T59;
            // Prolog.g:55:5: ( '^' )
            // Prolog.g:55:7: '^'
            {
            match('^'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T59

    // $ANTLR start T60
    public final void mT60() throws RecognitionException {
        try {
            int _type = T60;
            // Prolog.g:56:5: ( '(' )
            // Prolog.g:56:7: '('
            {
            match('('); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T60

    // $ANTLR start T61
    public final void mT61() throws RecognitionException {
        try {
            int _type = T61;
            // Prolog.g:57:5: ( ')' )
            // Prolog.g:57:7: ')'
            {
            match(')'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T61

    // $ANTLR start T62
    public final void mT62() throws RecognitionException {
        try {
            int _type = T62;
            // Prolog.g:58:5: ( '{' )
            // Prolog.g:58:7: '{'
            {
            match('{'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T62

    // $ANTLR start T63
    public final void mT63() throws RecognitionException {
        try {
            int _type = T63;
            // Prolog.g:59:5: ( '}' )
            // Prolog.g:59:7: '}'
            {
            match('}'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T63

    // $ANTLR start T64
    public final void mT64() throws RecognitionException {
        try {
            int _type = T64;
            // Prolog.g:60:5: ( ':' )
            // Prolog.g:60:7: ':'
            {
            match(':'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T64

    // $ANTLR start T65
    public final void mT65() throws RecognitionException {
        try {
            int _type = T65;
            // Prolog.g:61:5: ( '@' )
            // Prolog.g:61:7: '@'
            {
            match('@'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T65

    // $ANTLR start T66
    public final void mT66() throws RecognitionException {
        try {
            int _type = T66;
            // Prolog.g:62:5: ( '-' )
            // Prolog.g:62:7: '-'
            {
            match('-'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T66

    // $ANTLR start T67
    public final void mT67() throws RecognitionException {
        try {
            int _type = T67;
            // Prolog.g:63:5: ( '\\\\' )
            // Prolog.g:63:7: '\\\\'
            {
            match('\\'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T67

    // $ANTLR start T68
    public final void mT68() throws RecognitionException {
        try {
            int _type = T68;
            // Prolog.g:64:5: ( '\\\\+' )
            // Prolog.g:64:7: '\\\\+'
            {
            match("\\+"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T68

    // $ANTLR start T69
    public final void mT69() throws RecognitionException {
        try {
            int _type = T69;
            // Prolog.g:65:5: ( '?-' )
            // Prolog.g:65:7: '?-'
            {
            match("?-"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T69

    // $ANTLR start NUMBER
    public final void mNUMBER() throws RecognitionException {
        try {
            int _type = NUMBER;
            // Prolog.g:251:2: ( INTEGERCONSTANT ( REST_OF_FLOAT )? | BINARYCONSTANT | OCTALCONSTANT | HEXADECIMALCONSTANT )
            int alt2=4;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='0') ) {
                switch ( input.LA(2) ) {
                case 'b':
                    {
                    alt2=2;
                    }
                    break;
                case 'x':
                    {
                    alt2=4;
                    }
                    break;
                case 'o':
                    {
                    alt2=3;
                    }
                    break;
                default:
                    alt2=1;}

            }
            else if ( ((LA2_0>='1' && LA2_0<='9')) ) {
                alt2=1;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("249:1: NUMBER : ( INTEGERCONSTANT ( REST_OF_FLOAT )? | BINARYCONSTANT | OCTALCONSTANT | HEXADECIMALCONSTANT );", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // Prolog.g:258:3: INTEGERCONSTANT ( REST_OF_FLOAT )?
                    {
                    mINTEGERCONSTANT(); 
                     if (input.LA(1)!='.' || input.LA(2)<'0' || input.LA(2)>'9') break; 
                    // Prolog.g:258:90: ( REST_OF_FLOAT )?
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( (LA1_0=='.') ) {
                        alt1=1;
                    }
                    switch (alt1) {
                        case 1 :
                            // Prolog.g:258:90: REST_OF_FLOAT
                            {
                            mREST_OF_FLOAT(); 

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // Prolog.g:259:4: BINARYCONSTANT
                    {
                    mBINARYCONSTANT(); 

                    }
                    break;
                case 3 :
                    // Prolog.g:260:4: OCTALCONSTANT
                    {
                    mOCTALCONSTANT(); 

                    }
                    break;
                case 4 :
                    // Prolog.g:261:4: HEXADECIMALCONSTANT
                    {
                    mHEXADECIMALCONSTANT(); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NUMBER

    // $ANTLR start REST_OF_FLOAT
    public final void mREST_OF_FLOAT() throws RecognitionException {
        try {
            // Prolog.g:265:2: ( '.' INTEGERCONSTANT ( EXPONENT )? )
            // Prolog.g:265:5: '.' INTEGERCONSTANT ( EXPONENT )?
            {
            match('.'); 
            mINTEGERCONSTANT(); 
            // Prolog.g:265:25: ( EXPONENT )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0=='E'||LA3_0=='e') ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // Prolog.g:265:25: EXPONENT
                    {
                    mEXPONENT(); 

                    }
                    break;

            }


            }

        }
        finally {
        }
    }
    // $ANTLR end REST_OF_FLOAT

    // $ANTLR start EXPONENT
    public final void mEXPONENT() throws RecognitionException {
        try {
            // Prolog.g:269:2: ( ( 'e' | 'E' ) ( '+' | '-' )? INTEGERCONSTANT )
            // Prolog.g:269:5: ( 'e' | 'E' ) ( '+' | '-' )? INTEGERCONSTANT
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // Prolog.g:269:17: ( '+' | '-' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='+'||LA4_0=='-') ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // Prolog.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recover(mse);    throw mse;
                    }


                    }
                    break;

            }

            mINTEGERCONSTANT(); 

            }

        }
        finally {
        }
    }
    // $ANTLR end EXPONENT

    // $ANTLR start NAME
    public final void mNAME() throws RecognitionException {
        try {
            int _type = NAME;
            // Prolog.g:274:2: ( ( 'a' .. 'z' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* | '!' )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( ((LA6_0>='a' && LA6_0<='z')) ) {
                alt6=1;
            }
            else if ( (LA6_0=='!') ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("273:1: NAME : ( ( 'a' .. 'z' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* | '!' );", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // Prolog.g:274:4: ( 'a' .. 'z' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
                    {
                    // Prolog.g:274:4: ( 'a' .. 'z' )
                    // Prolog.g:274:5: 'a' .. 'z'
                    {
                    matchRange('a','z'); 

                    }

                    // Prolog.g:274:15: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0>='0' && LA5_0<='9')||(LA5_0>='A' && LA5_0<='Z')||LA5_0=='_'||(LA5_0>='a' && LA5_0<='z')) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // Prolog.g:
                    	    {
                    	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);


                    }
                    break;
                case 2 :
                    // Prolog.g:275:4: '!'
                    {
                    match('!'); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NAME

    // $ANTLR start VARIABLE
    public final void mVARIABLE() throws RecognitionException {
        try {
            int _type = VARIABLE;
            // Prolog.g:279:2: ( ( 'A' .. 'Z' | '_' ) ( ALPHACHAR | DIGIT | '_' )* )
            // Prolog.g:279:4: ( 'A' .. 'Z' | '_' ) ( ALPHACHAR | DIGIT | '_' )*
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // Prolog.g:279:21: ( ALPHACHAR | DIGIT | '_' )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>='0' && LA7_0<='9')||(LA7_0>='A' && LA7_0<='Z')||LA7_0=='_'||(LA7_0>='a' && LA7_0<='z')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // Prolog.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end VARIABLE

    // $ANTLR start INTEGERCONSTANT
    public final void mINTEGERCONSTANT() throws RecognitionException {
        try {
            // Prolog.g:284:2: ( ( DIGIT )+ )
            // Prolog.g:284:7: ( DIGIT )+
            {
            // Prolog.g:284:7: ( DIGIT )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // Prolog.g:284:8: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end INTEGERCONSTANT

    // $ANTLR start BINARYCONSTANT
    public final void mBINARYCONSTANT() throws RecognitionException {
        try {
            // Prolog.g:288:2: ( '0b' ( '0' | '1' )+ )
            // Prolog.g:288:4: '0b' ( '0' | '1' )+
            {
            match("0b"); 

            // Prolog.g:288:9: ( '0' | '1' )+
            int cnt9=0;
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>='0' && LA9_0<='1')) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // Prolog.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='1') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end BINARYCONSTANT

    // $ANTLR start OCTALCONSTANT
    public final void mOCTALCONSTANT() throws RecognitionException {
        try {
            // Prolog.g:292:2: ( '0o' ( '0' .. '7' )+ )
            // Prolog.g:292:4: '0o' ( '0' .. '7' )+
            {
            match("0o"); 

            // Prolog.g:292:9: ( '0' .. '7' )+
            int cnt10=0;
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( ((LA10_0>='0' && LA10_0<='7')) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // Prolog.g:292:10: '0' .. '7'
            	    {
            	    matchRange('0','7'); 

            	    }
            	    break;

            	default :
            	    if ( cnt10 >= 1 ) break loop10;
                        EarlyExitException eee =
                            new EarlyExitException(10, input);
                        throw eee;
                }
                cnt10++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end OCTALCONSTANT

    // $ANTLR start HEXADECIMALCONSTANT
    public final void mHEXADECIMALCONSTANT() throws RecognitionException {
        try {
            // Prolog.g:296:2: ( '0x' ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )+ )
            // Prolog.g:296:4: '0x' ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )+
            {
            match("0x"); 

            // Prolog.g:296:9: ( '0' .. '9' | 'a' .. 'f' | 'A' .. 'F' )+
            int cnt11=0;
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>='0' && LA11_0<='9')||(LA11_0>='A' && LA11_0<='F')||(LA11_0>='a' && LA11_0<='f')) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // Prolog.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt11 >= 1 ) break loop11;
                        EarlyExitException eee =
                            new EarlyExitException(11, input);
                        throw eee;
                }
                cnt11++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end HEXADECIMALCONSTANT

    // $ANTLR start CHAR
    public final void mCHAR() throws RecognitionException {
        try {
            // Prolog.g:300:2: ( ALPHACHAR | DIGIT | '_' | '#' | '$' | '&' | '*' | '+' | '-' | '.' | '/' | ':' | '<' | '=' | '>' | '?' | '@' | '^' | '~' | '!' | '(' | ')' | ',' | ';' | '[' | ']' | '{' | '}' | '|' | '%' | WHITESPACECHAR | '\\\\' | ESCAPE_SEQUENCE )
            int alt12=33;
            switch ( input.LA(1) ) {
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case 'a':
            case 'b':
            case 'c':
            case 'd':
            case 'e':
            case 'f':
            case 'g':
            case 'h':
            case 'i':
            case 'j':
            case 'k':
            case 'l':
            case 'm':
            case 'n':
            case 'o':
            case 'p':
            case 'q':
            case 'r':
            case 's':
            case 't':
            case 'u':
            case 'v':
            case 'w':
            case 'x':
            case 'y':
            case 'z':
                {
                alt12=1;
                }
                break;
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                {
                alt12=2;
                }
                break;
            case '_':
                {
                alt12=3;
                }
                break;
            case '#':
                {
                alt12=4;
                }
                break;
            case '$':
                {
                alt12=5;
                }
                break;
            case '&':
                {
                alt12=6;
                }
                break;
            case '*':
                {
                alt12=7;
                }
                break;
            case '+':
                {
                alt12=8;
                }
                break;
            case '-':
                {
                alt12=9;
                }
                break;
            case '.':
                {
                alt12=10;
                }
                break;
            case '/':
                {
                alt12=11;
                }
                break;
            case ':':
                {
                alt12=12;
                }
                break;
            case '<':
                {
                alt12=13;
                }
                break;
            case '=':
                {
                alt12=14;
                }
                break;
            case '>':
                {
                alt12=15;
                }
                break;
            case '?':
                {
                alt12=16;
                }
                break;
            case '@':
                {
                alt12=17;
                }
                break;
            case '^':
                {
                alt12=18;
                }
                break;
            case '~':
                {
                alt12=19;
                }
                break;
            case '!':
                {
                alt12=20;
                }
                break;
            case '(':
                {
                alt12=21;
                }
                break;
            case ')':
                {
                alt12=22;
                }
                break;
            case ',':
                {
                alt12=23;
                }
                break;
            case ';':
                {
                alt12=24;
                }
                break;
            case '[':
                {
                alt12=25;
                }
                break;
            case ']':
                {
                alt12=26;
                }
                break;
            case '{':
                {
                alt12=27;
                }
                break;
            case '}':
                {
                alt12=28;
                }
                break;
            case '|':
                {
                alt12=29;
                }
                break;
            case '%':
                {
                alt12=30;
                }
                break;
            case '\t':
            case '\n':
            case '\f':
            case '\r':
            case ' ':
                {
                alt12=31;
                }
                break;
            case '\\':
                {
                int LA12_32 = input.LA(2);

                if ( (LA12_32=='\"'||LA12_32=='\''||LA12_32=='\\'||(LA12_32>='`' && LA12_32<='b')||LA12_32=='f'||LA12_32=='n'||LA12_32=='r'||LA12_32=='t'||LA12_32=='v'||LA12_32=='x') ) {
                    alt12=33;
                }
                else {
                    alt12=32;}
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("299:10: fragment CHAR : ( ALPHACHAR | DIGIT | '_' | '#' | '$' | '&' | '*' | '+' | '-' | '.' | '/' | ':' | '<' | '=' | '>' | '?' | '@' | '^' | '~' | '!' | '(' | ')' | ',' | ';' | '[' | ']' | '{' | '}' | '|' | '%' | WHITESPACECHAR | '\\\\' | ESCAPE_SEQUENCE );", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // Prolog.g:300:4: ALPHACHAR
                    {
                    mALPHACHAR(); 

                    }
                    break;
                case 2 :
                    // Prolog.g:300:16: DIGIT
                    {
                    mDIGIT(); 

                    }
                    break;
                case 3 :
                    // Prolog.g:300:24: '_'
                    {
                    match('_'); 

                    }
                    break;
                case 4 :
                    // Prolog.g:301:4: '#'
                    {
                    match('#'); 

                    }
                    break;
                case 5 :
                    // Prolog.g:301:10: '$'
                    {
                    match('$'); 

                    }
                    break;
                case 6 :
                    // Prolog.g:301:16: '&'
                    {
                    match('&'); 

                    }
                    break;
                case 7 :
                    // Prolog.g:301:22: '*'
                    {
                    match('*'); 

                    }
                    break;
                case 8 :
                    // Prolog.g:301:28: '+'
                    {
                    match('+'); 

                    }
                    break;
                case 9 :
                    // Prolog.g:301:34: '-'
                    {
                    match('-'); 

                    }
                    break;
                case 10 :
                    // Prolog.g:301:40: '.'
                    {
                    match('.'); 

                    }
                    break;
                case 11 :
                    // Prolog.g:301:46: '/'
                    {
                    match('/'); 

                    }
                    break;
                case 12 :
                    // Prolog.g:301:52: ':'
                    {
                    match(':'); 

                    }
                    break;
                case 13 :
                    // Prolog.g:301:58: '<'
                    {
                    match('<'); 

                    }
                    break;
                case 14 :
                    // Prolog.g:301:64: '='
                    {
                    match('='); 

                    }
                    break;
                case 15 :
                    // Prolog.g:301:70: '>'
                    {
                    match('>'); 

                    }
                    break;
                case 16 :
                    // Prolog.g:301:76: '?'
                    {
                    match('?'); 

                    }
                    break;
                case 17 :
                    // Prolog.g:301:82: '@'
                    {
                    match('@'); 

                    }
                    break;
                case 18 :
                    // Prolog.g:301:88: '^'
                    {
                    match('^'); 

                    }
                    break;
                case 19 :
                    // Prolog.g:301:94: '~'
                    {
                    match('~'); 

                    }
                    break;
                case 20 :
                    // Prolog.g:302:4: '!'
                    {
                    match('!'); 

                    }
                    break;
                case 21 :
                    // Prolog.g:302:10: '('
                    {
                    match('('); 

                    }
                    break;
                case 22 :
                    // Prolog.g:302:16: ')'
                    {
                    match(')'); 

                    }
                    break;
                case 23 :
                    // Prolog.g:302:22: ','
                    {
                    match(','); 

                    }
                    break;
                case 24 :
                    // Prolog.g:302:28: ';'
                    {
                    match(';'); 

                    }
                    break;
                case 25 :
                    // Prolog.g:302:34: '['
                    {
                    match('['); 

                    }
                    break;
                case 26 :
                    // Prolog.g:302:40: ']'
                    {
                    match(']'); 

                    }
                    break;
                case 27 :
                    // Prolog.g:302:46: '{'
                    {
                    match('{'); 

                    }
                    break;
                case 28 :
                    // Prolog.g:302:52: '}'
                    {
                    match('}'); 

                    }
                    break;
                case 29 :
                    // Prolog.g:302:58: '|'
                    {
                    match('|'); 

                    }
                    break;
                case 30 :
                    // Prolog.g:302:64: '%'
                    {
                    match('%'); 

                    }
                    break;
                case 31 :
                    // Prolog.g:303:5: WHITESPACECHAR
                    {
                    mWHITESPACECHAR(); 

                    }
                    break;
                case 32 :
                    // Prolog.g:304:4: '\\\\'
                    {
                    match('\\'); 

                    }
                    break;
                case 33 :
                    // Prolog.g:305:4: ESCAPE_SEQUENCE
                    {
                    mESCAPE_SEQUENCE(); 

                    }
                    break;

            }
        }
        finally {
        }
    }
    // $ANTLR end CHAR

    // $ANTLR start ALPHACHAR
    public final void mALPHACHAR() throws RecognitionException {
        try {
            // Prolog.g:309:2: ( 'A' .. 'Z' | 'a' .. 'z' )
            // Prolog.g:
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

        }
        finally {
        }
    }
    // $ANTLR end ALPHACHAR

    // $ANTLR start DIGIT
    public final void mDIGIT() throws RecognitionException {
        try {
            // Prolog.g:313:2: ( '0' .. '9' )
            // Prolog.g:313:7: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end DIGIT

    // $ANTLR start STRING
    public final void mSTRING() throws RecognitionException {
        try {
            int _type = STRING;
            // Prolog.g:317:2: ( '\\'' ( CHAR | '\\'\\'' | '\"' )* '\\'' | '\"' ( CHAR | '\"\"' | '\\'' )* '\"' )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0=='\'') ) {
                alt15=1;
            }
            else if ( (LA15_0=='\"') ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("316:1: STRING : ( '\\'' ( CHAR | '\\'\\'' | '\"' )* '\\'' | '\"' ( CHAR | '\"\"' | '\\'' )* '\"' );", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // Prolog.g:317:4: '\\'' ( CHAR | '\\'\\'' | '\"' )* '\\''
                    {
                    match('\''); 
                    // Prolog.g:317:9: ( CHAR | '\\'\\'' | '\"' )*
                    loop13:
                    do {
                        int alt13=4;
                        switch ( input.LA(1) ) {
                        case '\'':
                            {
                            int LA13_1 = input.LA(2);

                            if ( (LA13_1=='\'') ) {
                                alt13=2;
                            }


                            }
                            break;
                        case '\t':
                        case '\n':
                        case '\f':
                        case '\r':
                        case ' ':
                        case '!':
                        case '#':
                        case '$':
                        case '%':
                        case '&':
                        case '(':
                        case ')':
                        case '*':
                        case '+':
                        case ',':
                        case '-':
                        case '.':
                        case '/':
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                        case ':':
                        case ';':
                        case '<':
                        case '=':
                        case '>':
                        case '?':
                        case '@':
                        case 'A':
                        case 'B':
                        case 'C':
                        case 'D':
                        case 'E':
                        case 'F':
                        case 'G':
                        case 'H':
                        case 'I':
                        case 'J':
                        case 'K':
                        case 'L':
                        case 'M':
                        case 'N':
                        case 'O':
                        case 'P':
                        case 'Q':
                        case 'R':
                        case 'S':
                        case 'T':
                        case 'U':
                        case 'V':
                        case 'W':
                        case 'X':
                        case 'Y':
                        case 'Z':
                        case '[':
                        case '\\':
                        case ']':
                        case '^':
                        case '_':
                        case 'a':
                        case 'b':
                        case 'c':
                        case 'd':
                        case 'e':
                        case 'f':
                        case 'g':
                        case 'h':
                        case 'i':
                        case 'j':
                        case 'k':
                        case 'l':
                        case 'm':
                        case 'n':
                        case 'o':
                        case 'p':
                        case 'q':
                        case 'r':
                        case 's':
                        case 't':
                        case 'u':
                        case 'v':
                        case 'w':
                        case 'x':
                        case 'y':
                        case 'z':
                        case '{':
                        case '|':
                        case '}':
                        case '~':
                            {
                            alt13=1;
                            }
                            break;
                        case '\"':
                            {
                            alt13=3;
                            }
                            break;

                        }

                        switch (alt13) {
                    	case 1 :
                    	    // Prolog.g:317:10: CHAR
                    	    {
                    	    mCHAR(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // Prolog.g:317:17: '\\'\\''
                    	    {
                    	    match("\'\'"); 


                    	    }
                    	    break;
                    	case 3 :
                    	    // Prolog.g:317:26: '\"'
                    	    {
                    	    match('\"'); 

                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;
                case 2 :
                    // Prolog.g:318:4: '\"' ( CHAR | '\"\"' | '\\'' )* '\"'
                    {
                    match('\"'); 
                    // Prolog.g:318:8: ( CHAR | '\"\"' | '\\'' )*
                    loop14:
                    do {
                        int alt14=4;
                        switch ( input.LA(1) ) {
                        case '\"':
                            {
                            int LA14_1 = input.LA(2);

                            if ( (LA14_1=='\"') ) {
                                alt14=2;
                            }


                            }
                            break;
                        case '\t':
                        case '\n':
                        case '\f':
                        case '\r':
                        case ' ':
                        case '!':
                        case '#':
                        case '$':
                        case '%':
                        case '&':
                        case '(':
                        case ')':
                        case '*':
                        case '+':
                        case ',':
                        case '-':
                        case '.':
                        case '/':
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                        case ':':
                        case ';':
                        case '<':
                        case '=':
                        case '>':
                        case '?':
                        case '@':
                        case 'A':
                        case 'B':
                        case 'C':
                        case 'D':
                        case 'E':
                        case 'F':
                        case 'G':
                        case 'H':
                        case 'I':
                        case 'J':
                        case 'K':
                        case 'L':
                        case 'M':
                        case 'N':
                        case 'O':
                        case 'P':
                        case 'Q':
                        case 'R':
                        case 'S':
                        case 'T':
                        case 'U':
                        case 'V':
                        case 'W':
                        case 'X':
                        case 'Y':
                        case 'Z':
                        case '[':
                        case '\\':
                        case ']':
                        case '^':
                        case '_':
                        case 'a':
                        case 'b':
                        case 'c':
                        case 'd':
                        case 'e':
                        case 'f':
                        case 'g':
                        case 'h':
                        case 'i':
                        case 'j':
                        case 'k':
                        case 'l':
                        case 'm':
                        case 'n':
                        case 'o':
                        case 'p':
                        case 'q':
                        case 'r':
                        case 's':
                        case 't':
                        case 'u':
                        case 'v':
                        case 'w':
                        case 'x':
                        case 'y':
                        case 'z':
                        case '{':
                        case '|':
                        case '}':
                        case '~':
                            {
                            alt14=1;
                            }
                            break;
                        case '\'':
                            {
                            alt14=3;
                            }
                            break;

                        }

                        switch (alt14) {
                    	case 1 :
                    	    // Prolog.g:318:9: CHAR
                    	    {
                    	    mCHAR(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // Prolog.g:318:16: '\"\"'
                    	    {
                    	    match("\"\""); 


                    	    }
                    	    break;
                    	case 3 :
                    	    // Prolog.g:318:23: '\\''
                    	    {
                    	    match('\''); 

                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end STRING

    // $ANTLR start ESCAPE_SEQUENCE
    public final void mESCAPE_SEQUENCE() throws RecognitionException {
        try {
            // Prolog.g:322:25: ( '\\\\' ( META_CHAR | SYMBOLIC_CONTROL_CHAR ) )
            // Prolog.g:322:27: '\\\\' ( META_CHAR | SYMBOLIC_CONTROL_CHAR )
            {
            match('\\'); 
            if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||(input.LA(1)>='`' && input.LA(1)<='b')||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t'||input.LA(1)=='v'||input.LA(1)=='x' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

        }
        finally {
        }
    }
    // $ANTLR end ESCAPE_SEQUENCE

    // $ANTLR start META_CHAR
    public final void mMETA_CHAR() throws RecognitionException {
        try {
            // Prolog.g:324:19: ( '\\\\' | '\\'' | '\"' | '`' )
            // Prolog.g:
            {
            if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='`' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

        }
        finally {
        }
    }
    // $ANTLR end META_CHAR

    // $ANTLR start SYMBOLIC_CONTROL_CHAR
    public final void mSYMBOLIC_CONTROL_CHAR() throws RecognitionException {
        try {
            // Prolog.g:326:31: ( 'a' | 'b' | 'f' | 'n' | 'r' | 't' | 'v' | 'x' )
            // Prolog.g:
            {
            if ( (input.LA(1)>='a' && input.LA(1)<='b')||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t'||input.LA(1)=='v'||input.LA(1)=='x' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

        }
        finally {
        }
    }
    // $ANTLR end SYMBOLIC_CONTROL_CHAR

    // $ANTLR start ENDTOKEN
    public final void mENDTOKEN() throws RecognitionException {
        try {
            int _type = ENDTOKEN;
            // Prolog.g:330:2: ( '.' WHITESPACECHAR )
            // Prolog.g:330:4: '.' WHITESPACECHAR
            {
            match('.'); 
            mWHITESPACECHAR(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end ENDTOKEN

    // $ANTLR start COMMENT
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            // Prolog.g:338:10: ( '%' (~ ( '\\n' | '\\r' ) )* | '/*' ( options {greedy=false; } : . )* '*/' )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0=='%') ) {
                alt18=1;
            }
            else if ( (LA18_0=='/') ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("338:1: COMMENT : ( '%' (~ ( '\\n' | '\\r' ) )* | '/*' ( options {greedy=false; } : . )* '*/' );", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // Prolog.g:338:13: '%' (~ ( '\\n' | '\\r' ) )*
                    {
                    match('%'); 
                    // Prolog.g:338:16: (~ ( '\\n' | '\\r' ) )*
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( ((LA16_0>='\u0000' && LA16_0<='\t')||(LA16_0>='\u000B' && LA16_0<='\f')||(LA16_0>='\u000E' && LA16_0<='\uFFFE')) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // Prolog.g:338:17: ~ ( '\\n' | '\\r' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop16;
                        }
                    } while (true);

                     skip(); 

                    }
                    break;
                case 2 :
                    // Prolog.g:339:5: '/*' ( options {greedy=false; } : . )* '*/'
                    {
                    match("/*"); 

                    // Prolog.g:339:10: ( options {greedy=false; } : . )*
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0=='*') ) {
                            int LA17_1 = input.LA(2);

                            if ( (LA17_1=='/') ) {
                                alt17=2;
                            }
                            else if ( ((LA17_1>='\u0000' && LA17_1<='.')||(LA17_1>='0' && LA17_1<='\uFFFE')) ) {
                                alt17=1;
                            }


                        }
                        else if ( ((LA17_0>='\u0000' && LA17_0<=')')||(LA17_0>='+' && LA17_0<='\uFFFE')) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // Prolog.g:339:39: .
                    	    {
                    	    matchAny(); 

                    	    }
                    	    break;

                    	default :
                    	    break loop17;
                        }
                    } while (true);

                    match("*/"); 

                     skip(); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end COMMENT

    // $ANTLR start WHITESPACE
    public final void mWHITESPACE() throws RecognitionException {
        try {
            int _type = WHITESPACE;
            // Prolog.g:344:12: ( ( WHITESPACECHAR )+ )
            // Prolog.g:344:14: ( WHITESPACECHAR )+
            {
            // Prolog.g:344:14: ( WHITESPACECHAR )+
            int cnt19=0;
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( ((LA19_0>='\t' && LA19_0<='\n')||(LA19_0>='\f' && LA19_0<='\r')||LA19_0==' ') ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // Prolog.g:344:14: WHITESPACECHAR
            	    {
            	    mWHITESPACECHAR(); 

            	    }
            	    break;

            	default :
            	    if ( cnt19 >= 1 ) break loop19;
                        EarlyExitException eee =
                            new EarlyExitException(19, input);
                        throw eee;
                }
                cnt19++;
            } while (true);

             skip(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end WHITESPACE

    // $ANTLR start WHITESPACECHAR
    public final void mWHITESPACECHAR() throws RecognitionException {
        try {
            // Prolog.g:348:24: ( ( ' ' | '\\t' | '\\f' | '\\r' | '\\n' ) )
            // Prolog.g:348:26: ( ' ' | '\\t' | '\\f' | '\\r' | '\\n' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

        }
        finally {
        }
    }
    // $ANTLR end WHITESPACECHAR

    public void mTokens() throws RecognitionException {
        // Prolog.g:1:8: ( T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | T35 | T36 | T37 | T38 | T39 | T40 | T41 | T42 | T43 | T44 | T45 | T46 | T47 | T48 | T49 | T50 | T51 | T52 | T53 | T54 | T55 | T56 | T57 | T58 | T59 | T60 | T61 | T62 | T63 | T64 | T65 | T66 | T67 | T68 | T69 | NUMBER | NAME | VARIABLE | STRING | ENDTOKEN | COMMENT | WHITESPACE )
        int alt20=53;
        switch ( input.LA(1) ) {
        case ':':
            {
            int LA20_1 = input.LA(2);

            if ( (LA20_1=='-') ) {
                alt20=1;
            }
            else {
                alt20=41;}
            }
            break;
        case ',':
            {
            alt20=2;
            }
            break;
        case '[':
            {
            alt20=3;
            }
            break;
        case ']':
            {
            alt20=4;
            }
            break;
        case '|':
            {
            alt20=5;
            }
            break;
        case '-':
            {
            switch ( input.LA(2) ) {
            case '-':
                {
                alt20=6;
                }
                break;
            case '>':
                {
                alt20=8;
                }
                break;
            default:
                alt20=43;}

            }
            break;
        case ';':
            {
            alt20=7;
            }
            break;
        case '=':
            {
            switch ( input.LA(2) ) {
            case '\\':
                {
                alt20=20;
                }
                break;
            case '=':
                {
                alt20=11;
                }
                break;
            case '.':
                {
                alt20=17;
                }
                break;
            case '<':
                {
                alt20=22;
                }
                break;
            case ':':
                {
                alt20=19;
                }
                break;
            default:
                alt20=9;}

            }
            break;
        case '\\':
            {
            switch ( input.LA(2) ) {
            case '=':
                {
                int LA20_43 = input.LA(3);

                if ( (LA20_43=='=') ) {
                    alt20=12;
                }
                else {
                    alt20=10;}
                }
                break;
            case '+':
                {
                alt20=45;
                }
                break;
            case '/':
                {
                alt20=27;
                }
                break;
            default:
                alt20=44;}

            }
            break;
        case '@':
            {
            switch ( input.LA(2) ) {
            case '>':
                {
                int LA20_47 = input.LA(3);

                if ( (LA20_47=='=') ) {
                    alt20=16;
                }
                else {
                    alt20=15;}
                }
                break;
            case '=':
                {
                alt20=14;
                }
                break;
            case '<':
                {
                alt20=13;
                }
                break;
            default:
                alt20=42;}

            }
            break;
        case 'i':
            {
            int LA20_11 = input.LA(2);

            if ( (LA20_11=='s') ) {
                int LA20_51 = input.LA(3);

                if ( ((LA20_51>='0' && LA20_51<='9')||(LA20_51>='A' && LA20_51<='Z')||LA20_51=='_'||(LA20_51>='a' && LA20_51<='z')) ) {
                    alt20=48;
                }
                else {
                    alt20=18;}
            }
            else {
                alt20=48;}
            }
            break;
        case '<':
            {
            int LA20_12 = input.LA(2);

            if ( (LA20_12=='<') ) {
                alt20=33;
            }
            else {
                alt20=21;}
            }
            break;
        case '>':
            {
            switch ( input.LA(2) ) {
            case '>':
                {
                alt20=34;
                }
                break;
            case '=':
                {
                alt20=24;
                }
                break;
            default:
                alt20=23;}

            }
            break;
        case '+':
            {
            alt20=25;
            }
            break;
        case '/':
            {
            switch ( input.LA(2) ) {
            case '/':
                {
                alt20=30;
                }
                break;
            case '\\':
                {
                alt20=26;
                }
                break;
            case '*':
                {
                alt20=52;
                }
                break;
            default:
                alt20=29;}

            }
            break;
        case '*':
            {
            int LA20_16 = input.LA(2);

            if ( (LA20_16=='*') ) {
                alt20=35;
            }
            else {
                alt20=28;}
            }
            break;
        case 'r':
            {
            int LA20_17 = input.LA(2);

            if ( (LA20_17=='e') ) {
                int LA20_62 = input.LA(3);

                if ( (LA20_62=='m') ) {
                    int LA20_69 = input.LA(4);

                    if ( ((LA20_69>='0' && LA20_69<='9')||(LA20_69>='A' && LA20_69<='Z')||LA20_69=='_'||(LA20_69>='a' && LA20_69<='z')) ) {
                        alt20=48;
                    }
                    else {
                        alt20=31;}
                }
                else {
                    alt20=48;}
            }
            else {
                alt20=48;}
            }
            break;
        case 'm':
            {
            int LA20_18 = input.LA(2);

            if ( (LA20_18=='o') ) {
                int LA20_63 = input.LA(3);

                if ( (LA20_63=='d') ) {
                    int LA20_70 = input.LA(4);

                    if ( ((LA20_70>='0' && LA20_70<='9')||(LA20_70>='A' && LA20_70<='Z')||LA20_70=='_'||(LA20_70>='a' && LA20_70<='z')) ) {
                        alt20=48;
                    }
                    else {
                        alt20=32;}
                }
                else {
                    alt20=48;}
            }
            else {
                alt20=48;}
            }
            break;
        case '^':
            {
            alt20=36;
            }
            break;
        case '(':
            {
            alt20=37;
            }
            break;
        case ')':
            {
            alt20=38;
            }
            break;
        case '{':
            {
            alt20=39;
            }
            break;
        case '}':
            {
            alt20=40;
            }
            break;
        case '?':
            {
            alt20=46;
            }
            break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            {
            alt20=47;
            }
            break;
        case '!':
        case 'a':
        case 'b':
        case 'c':
        case 'd':
        case 'e':
        case 'f':
        case 'g':
        case 'h':
        case 'j':
        case 'k':
        case 'l':
        case 'n':
        case 'o':
        case 'p':
        case 'q':
        case 's':
        case 't':
        case 'u':
        case 'v':
        case 'w':
        case 'x':
        case 'y':
        case 'z':
            {
            alt20=48;
            }
            break;
        case 'A':
        case 'B':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
        case 'G':
        case 'H':
        case 'I':
        case 'J':
        case 'K':
        case 'L':
        case 'M':
        case 'N':
        case 'O':
        case 'P':
        case 'Q':
        case 'R':
        case 'S':
        case 'T':
        case 'U':
        case 'V':
        case 'W':
        case 'X':
        case 'Y':
        case 'Z':
        case '_':
            {
            alt20=49;
            }
            break;
        case '\"':
        case '\'':
            {
            alt20=50;
            }
            break;
        case '.':
            {
            alt20=51;
            }
            break;
        case '%':
            {
            alt20=52;
            }
            break;
        case '\t':
        case '\n':
        case '\f':
        case '\r':
        case ' ':
            {
            alt20=53;
            }
            break;
        default:
            NoViableAltException nvae =
                new NoViableAltException("1:1: Tokens : ( T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | T35 | T36 | T37 | T38 | T39 | T40 | T41 | T42 | T43 | T44 | T45 | T46 | T47 | T48 | T49 | T50 | T51 | T52 | T53 | T54 | T55 | T56 | T57 | T58 | T59 | T60 | T61 | T62 | T63 | T64 | T65 | T66 | T67 | T68 | T69 | NUMBER | NAME | VARIABLE | STRING | ENDTOKEN | COMMENT | WHITESPACE );", 20, 0, input);

            throw nvae;
        }

        switch (alt20) {
            case 1 :
                // Prolog.g:1:10: T24
                {
                mT24(); 

                }
                break;
            case 2 :
                // Prolog.g:1:14: T25
                {
                mT25(); 

                }
                break;
            case 3 :
                // Prolog.g:1:18: T26
                {
                mT26(); 

                }
                break;
            case 4 :
                // Prolog.g:1:22: T27
                {
                mT27(); 

                }
                break;
            case 5 :
                // Prolog.g:1:26: T28
                {
                mT28(); 

                }
                break;
            case 6 :
                // Prolog.g:1:30: T29
                {
                mT29(); 

                }
                break;
            case 7 :
                // Prolog.g:1:34: T30
                {
                mT30(); 

                }
                break;
            case 8 :
                // Prolog.g:1:38: T31
                {
                mT31(); 

                }
                break;
            case 9 :
                // Prolog.g:1:42: T32
                {
                mT32(); 

                }
                break;
            case 10 :
                // Prolog.g:1:46: T33
                {
                mT33(); 

                }
                break;
            case 11 :
                // Prolog.g:1:50: T34
                {
                mT34(); 

                }
                break;
            case 12 :
                // Prolog.g:1:54: T35
                {
                mT35(); 

                }
                break;
            case 13 :
                // Prolog.g:1:58: T36
                {
                mT36(); 

                }
                break;
            case 14 :
                // Prolog.g:1:62: T37
                {
                mT37(); 

                }
                break;
            case 15 :
                // Prolog.g:1:66: T38
                {
                mT38(); 

                }
                break;
            case 16 :
                // Prolog.g:1:70: T39
                {
                mT39(); 

                }
                break;
            case 17 :
                // Prolog.g:1:74: T40
                {
                mT40(); 

                }
                break;
            case 18 :
                // Prolog.g:1:78: T41
                {
                mT41(); 

                }
                break;
            case 19 :
                // Prolog.g:1:82: T42
                {
                mT42(); 

                }
                break;
            case 20 :
                // Prolog.g:1:86: T43
                {
                mT43(); 

                }
                break;
            case 21 :
                // Prolog.g:1:90: T44
                {
                mT44(); 

                }
                break;
            case 22 :
                // Prolog.g:1:94: T45
                {
                mT45(); 

                }
                break;
            case 23 :
                // Prolog.g:1:98: T46
                {
                mT46(); 

                }
                break;
            case 24 :
                // Prolog.g:1:102: T47
                {
                mT47(); 

                }
                break;
            case 25 :
                // Prolog.g:1:106: T48
                {
                mT48(); 

                }
                break;
            case 26 :
                // Prolog.g:1:110: T49
                {
                mT49(); 

                }
                break;
            case 27 :
                // Prolog.g:1:114: T50
                {
                mT50(); 

                }
                break;
            case 28 :
                // Prolog.g:1:118: T51
                {
                mT51(); 

                }
                break;
            case 29 :
                // Prolog.g:1:122: T52
                {
                mT52(); 

                }
                break;
            case 30 :
                // Prolog.g:1:126: T53
                {
                mT53(); 

                }
                break;
            case 31 :
                // Prolog.g:1:130: T54
                {
                mT54(); 

                }
                break;
            case 32 :
                // Prolog.g:1:134: T55
                {
                mT55(); 

                }
                break;
            case 33 :
                // Prolog.g:1:138: T56
                {
                mT56(); 

                }
                break;
            case 34 :
                // Prolog.g:1:142: T57
                {
                mT57(); 

                }
                break;
            case 35 :
                // Prolog.g:1:146: T58
                {
                mT58(); 

                }
                break;
            case 36 :
                // Prolog.g:1:150: T59
                {
                mT59(); 

                }
                break;
            case 37 :
                // Prolog.g:1:154: T60
                {
                mT60(); 

                }
                break;
            case 38 :
                // Prolog.g:1:158: T61
                {
                mT61(); 

                }
                break;
            case 39 :
                // Prolog.g:1:162: T62
                {
                mT62(); 

                }
                break;
            case 40 :
                // Prolog.g:1:166: T63
                {
                mT63(); 

                }
                break;
            case 41 :
                // Prolog.g:1:170: T64
                {
                mT64(); 

                }
                break;
            case 42 :
                // Prolog.g:1:174: T65
                {
                mT65(); 

                }
                break;
            case 43 :
                // Prolog.g:1:178: T66
                {
                mT66(); 

                }
                break;
            case 44 :
                // Prolog.g:1:182: T67
                {
                mT67(); 

                }
                break;
            case 45 :
                // Prolog.g:1:186: T68
                {
                mT68(); 

                }
                break;
            case 46 :
                // Prolog.g:1:190: T69
                {
                mT69(); 

                }
                break;
            case 47 :
                // Prolog.g:1:194: NUMBER
                {
                mNUMBER(); 

                }
                break;
            case 48 :
                // Prolog.g:1:201: NAME
                {
                mNAME(); 

                }
                break;
            case 49 :
                // Prolog.g:1:206: VARIABLE
                {
                mVARIABLE(); 

                }
                break;
            case 50 :
                // Prolog.g:1:215: STRING
                {
                mSTRING(); 

                }
                break;
            case 51 :
                // Prolog.g:1:222: ENDTOKEN
                {
                mENDTOKEN(); 

                }
                break;
            case 52 :
                // Prolog.g:1:231: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 53 :
                // Prolog.g:1:239: WHITESPACE
                {
                mWHITESPACE(); 

                }
                break;

        }

    }


 

}