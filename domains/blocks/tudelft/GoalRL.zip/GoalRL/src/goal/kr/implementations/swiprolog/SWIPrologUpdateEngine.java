package goal.kr.implementations.swiprolog;

import java.util.ArrayList;

import java.util.Hashtable;


import goal.core.kr.Database;
import goal.core.kr.UpdateEngine;
import goal.core.kr.language.*;
import goal.tools.errorhandling.Warning;
import goal.kr.language.prolog.*;


/**
 * 
 * @author Koen Hindriks
 *
 */

public class SWIPrologUpdateEngine implements UpdateEngine {
	
	// Class fields
	private String name;
	
	// Class constructor
	public SWIPrologUpdateEngine(String name) {
		this.name = name;
	}
	
	// Class methods
	public String getName() {
		return name;
	}
	
	/**
	 * The following methods are used to transform the contents of a database
	 * by additing or removing information from it. The method names correspond
	 * to the commonly used names of belief revision operators in the AGM framework,
	 * to suggest their intended semantics.
	 */
	
	/** ASSUMES that the Application Programming Interface (API) that implements this UpdateEngine interface
	 * needs to ensure that Formula form is 'closed'!
	 */

	/**
	 * In addition to the common AGM revision operators, a method 'delete' must be provided to remove a
	 * sentence from a database in the set-theoretical sense. That is, the sentence to be deleted is removed
	 * from the database viewed as a set of sentences. After deletion it still may be the case that the
	 * sentence is entailed by the database, but it should no longer be contained explicitly in the database.
	 * @param formula The sentence (a closed formula) to be removed.
	 * @param database The database from which the sentence is removed.
	 * @return A boolean value 'true' upon successful removal of the sentence from the database, otherwise
	 * 'false'. The method should also return 'false' if the sentence is not an element from the database
	 * viewed as a set.
	 */
	public boolean delete(Formula formula, Database database) {
		// ASSUMES that both delete and contract remove simple, ground positive literals.
		try {
			return contract(formula, database);
		} catch (Exception e) { new Warning("delete of formula "+formula+" failed",e); return false; }
	}
	
	/** 
	 * The method 'contract' removes a sentence from a database. After applying the method the sentence that
	 * is removed should no longer follow from the database.
	 * @param formula The sentence to be removed.
	 * @param database The database from which the sentence is removed.
	 * @return A boolean value 'true' upon successful removal of the sentence from the database, otherwise 'false'.
	 * Wouter: HUH, returns ALWAYS true.
	 */
	public boolean contract(Formula formula, Database database) throws Exception {
		//if (!(pForm instanceof SWIPredicate) && !(pForm instanceof SWILiteral && ((SWILiteral)pForm).getSign())) {
		if (!((SWIExpression)formula).isLiteral())
			new Warning("Retracted non-atomic formula: "+formula.toString()+".");
		if (!(formula.isClosed()))
			 new Warning("Retracted formula "+formula.toString()+" with variables.");
		// Wouter trac 730 changed retractall into retract 7sept09
		SWIQuery.synchronizedRawquery("retract("+database.getName()+":"+formula.toString()+")");
		database.getTheory().remove(formula); // keep theory in sync with SWI-Prolog database
		return true;
	}
	
	/**
	 * The method 'expand' simply adds a sentence to a database in the set-theoretical sense.
	 * As a result, the database will entail the added formula, but also may become logically
	 * inconsistent. The method always succeeds.
	 * @param pFormula The sentence to be added.
	 * @param database The database to which the sentence has been added.
	 * @return A boolean value 'true' upon successful addition of the sentence, otherwise 'false'.
	 * Wouter: it also returns false if the database did not change...
	 * @throws jpl.PrologException if illegal query is done.  
	 */
	public boolean expand(Formula formula, Database database) {
		boolean result = false;
		// ASSUMES that a formula is in conjunctive normal form and does not contain disjunctions nor negated atoms as conjuncts.
		ArrayList<PrologTerm> conjuncts = UnzipConjunction(((SWIFormula)formula).getTerm());
		
		for(PrologTerm conjunct : conjuncts) {
			if (!database.getTheory().contains(new SWIFormula(conjunct))) { // avoid duplication of clauses in database
				result = addPrologTerm(conjunct, (SWIPrologDatabase)database);
			if (result)
				database.getTheory().add(new SWIFormula(conjunct)); // keep theory in sync with SWI-Prolog database
			}
		}
		return result;
	}
	
	/** The method 'revise' also adds a sentence to a database but at the same time other sentences
	 * are removed if this is needed to ensure that the resulting database is consistent. The resulting
	 * database entails the added sentence if the method was successful in removing all conflicting data.
	 * @param formula The sentence to be added.
	 * @param database The database that is to be revised with the sentence.
	 * @return A boolean value 'true' upon successful revision of the database with the sentence, otherwise 'false'.
	 */
	public boolean revise(Formula formula, Database database) {
		// Currently, expand and revise are defined as identical functions. TODO: Revise ;-)
		return expand(formula, database);
	}
	
	/** The method 'update' updates a database with a sentence after some changes have occurred due to actions the
	 * agent performed or other events that changed the agent's environment. The 'update' method is similar to the
	 * 'revision' method in that it removes other sentences if this is needed to ensure that the resulting database
	 * is consistent. The resulting database entails the added sentence if the method was successful in
	 * removing all conflicting data. The 'update' method may be identical to the 'revise' operator (and will be
	 * in many simplified settings) but does not need to be the same.
	 * 
	 * Wouter: pForm generally is of the form aap,not(beer),kat,not(dark).
	 * This is handled as follows: the top level conjunction is split into parts
	 * A negative literal will result in a retract, a positive literal in an addition to the database(s).
	 * @param formula The sentence to be added.
	 * @param database The database that is to be revised with the sentence.
	 * @return A boolean value 'true' upon successful revision of the database with the sentence, otherwise 'false'.
	 * 
	 * @modified W.Pasman 17jul08: SWIConjunction does not exist anymore.
	 * now accepts general SWIExpression instead of SWILiteral conjunction.
	 */
	public boolean update(Formula formula, Database database) {
		boolean result = true;
		
		// First, check sort of formulas in pForm. Only literals can be handled. // TODO: Extend also for Predicates!
		if (!(formula instanceof SWIFormula)) { 
			new Warning("only SWIFormulas can be handled, but encountered "+formula+" of type "+formula.getClass());
			return false;
		}
		ArrayList<PrologTerm> conjuncts = UnzipConjunction(((SWIFormula)formula).getTerm());

		/** DOC: ASSUMES that the formula to update with is a conjunction of literals.
		 * In order to update a database with a conjunction of positive and negative literals we need to
		 * (minimally) ensure that the atoms denoted by the positive literals are entailed by the database
		 * after the update and the (negated) atoms denoted by the negative literals are no longer entailed
		 * after the update.
		 * Although it is not quite clear what to do when the formula to update with is inconsistent (i.e. contains
		 * occurrences of the same atom that are and are not negated) the code below ensures that in this case the
		 * positive information is incorporated and entailed after the update. 
		 */		
		// First, remove items from database.
		Formula atom;
		for (PrologTerm conjunct : conjuncts)
			if (conjunct instanceof FuncTerm && ((FuncTerm)conjunct).getName().equals("not")) {
				atom = new SWIFormula(((FuncTerm)conjunct).getArguments().get(0));
				try {
					boolean res=contract(atom, database);
					result = result && res;
					// Wouter: modified 1oct08: ALWAYS do all expands, also if one expand does not change the dbase. Mantis 376
					database.getTheory().remove(atom); // keep theory in sync with SWI-Prolog database
				} catch (Exception e) { new Warning("Problem while contracting "+atom,e); }
			}
		// Second, add items to database. TODO inconsistent exception throwing; contract does, expand doesn't...
		for (PrologTerm conjunct : conjuncts)
			if ((conjunct instanceof BasicTerm) || (conjunct instanceof FuncTerm && !((FuncTerm)conjunct).getName().equals("not"))) {
				atom = new SWIFormula(conjunct);
				boolean res=expand(atom, database); 
				// Wouter: modified 1oct08: ALWAYS do all expands, also if one expand does not change the dbase. Mantis 376
				result = result && res;
				database.getTheory().add(atom); // keep theory in sync with SWI-Prolog database
			}
		return result;
	}
	
	/*
	 * original code
	public boolean update(Expression pForm, Database pBase) {
		// ASSUMES that updates on databases are performed only with (lists of) literals.
		ArrayList<SWILiteral> lLiterals = new ArrayList<SWILiteral>();
		boolean lResult = true;
		
		// First, check sort of formulas in pForm. Only literals can be handled. // TODO: Extend also for Predicates!
		if (pForm instanceof SWILiteral)
			lLiterals.add((SWILiteral)pForm);
		else
			if (pForm instanceof SWIConjunction) {
				for (SWIFormula lForm : ((SWIConjunction)pForm).getFormulas()) {
					if (lForm instanceof SWILiteral)
						lLiterals.add((SWILiteral)lForm);
					else
						System.out.println("Cannot update database with formula: "+lForm.toString()+". Only literals allowed.");
				}
			} else
				System.out.println("Cannot update database with formula: "+pForm.toString()+". Only literals allowed.");
		
		// Second, update the database. The literal list lLiterals is a combination of an add/delete list, with the
		// negative literals on the list to be removed and the positive literals on the list to be added. Note that
		// this "operational" meaning does conflict with the logical, i.e. in case both an atom and its negation occur
		// in the list. It is better programming practice to make sure that this does never occur, but the SWI update
		// method below only supports the "operational" reading of pForm as an add/delete list.

		// First, remove items from database.
		for (SWILiteral lLit : lLiterals) {
			try {
				if (!lLit.getSign()) lResult = lResult && contract(lLit.getPredicate(),pBase);
			} catch (Exception e) {}
		}
		// Second, add items to database.
		for (SWILiteral lLit : lLiterals) {
			if (lLit.getSign()) lResult = lResult && expand(lLit,pBase);
		}
		return lResult;
	}
	 */
	
	// ASSUMES formula is an atom (fact).
	public boolean insert(String formula, Database database)  {
		//CHECK maybe we can do a few basic checks like whether there are variables in the string?
		if (!database.getTheory().getFormulae().contains(formula)) {
			database.getTheory().getFormulae().add(formula);
			String q="assert("+database.getName()+":"+formula+")";
			Hashtable[] res=null;
			try { res=SWIQuery.synchronizedRawquery(q); }
			catch (Exception e) { new Warning("insert failed",e); }
			return (res==null);
		}
		else
			return false;
	}
	
	/** add prolog term to the database.
	 * @return Wouter:false only if error occurs (warning was printed then to the console). 
	 * IMHO this should be changed into throwing if an error occurs. */
	public boolean addPrologTerm(PrologTerm term, SWIPrologDatabase db) {
		String q="";

		// check for special heads. 
		if (term instanceof FuncTerm) { // CHECK why this check? Should be functerm, or not?
			FuncTerm ft=(FuncTerm)term;
			ArrayList<PrologTerm> args=ft.getArguments();

			String name=ft.getName();
			if (name.equals("not")) {
				new Warning("Cannot add negative literal "+term+" to SWI Prolog database.");
				return false;
			} else if (name.equals(",")) { // conjunction of prolog terms. All need to be checked!
				for(PrologTerm t:args) 
					if (addPrologTerm(t,db)!=true) return false; // cancel when failure occurs. TODO handle with exceptions.
				return true;
			} else if (name.equals("dynamic")) {
				if (args.size()!=1)
					new Warning("Illegal predicate dynamic/"+args.size());
				db.addDynamicPredicate(new SWIPredicate(term));
				q="true,"+db.getName()+":("+term+")";
			} else if (name.equals("assert") || name.equals("retract")) {
				q="true,"+db.getName()+":("+term+")";
			} else q="assert("+db.getName()+":("+term+"))"; // extra brackets: paramlist of assert/1 is prio1000 and term maybe 1200.
		} else if (term instanceof BasicTerm)
			q="assert("+db.getName()+":("+term+"))"; // extra brackets: paramlist of assert/1 is prio1000 and term maybe 1200.
		else if (term instanceof VariableTerm)
			new Warning("Variable "+term+"can not be asserted into database");
		else throw new IllegalArgumentException("Term"+term+" of unknown type "+term.getClass());

		try { 
			Hashtable[] res=SWIQuery.synchronizedRawquery(q); 
			if (res==null) {
				new Warning("Insertion of predicate "+term+" failed without clear reason. query='"+q+"'");
				return false;
			}
		}
		catch (Exception e) { throw new RuntimeException("Query "+q+" failed",e); }

		// DEBUG:
		/*
		System.out.println("TEST!@#!! LISTING NOW:");
		lQuery = new Query("swidb0:listing");
		if (lQuery.allSolutions()==null)
			System.out.println("listing failed without clear reason.");
		*/
		return true;
	}
		
	 /**@returns list of all terms in the conjunction.
	  * If given PrologTerm is not a conjunction but just one item, returns list with only that item. */
	public ArrayList<PrologTerm> UnzipConjunction(PrologTerm t) {
		ArrayList<PrologTerm> terms=new ArrayList<PrologTerm>();
		if (t instanceof FuncTerm && ((FuncTerm)t).getName().equals(",")) {
			ArrayList<PrologTerm> args=((FuncTerm)t).getArguments();
			terms.add(args.get(0));
			terms.addAll(UnzipConjunction(args.get(1)));
		} else
			terms.add(t);
		return terms;
	}

}
