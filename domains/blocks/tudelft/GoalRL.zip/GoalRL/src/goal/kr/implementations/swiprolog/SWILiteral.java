package goal.kr.implementations.swiprolog;

import java.util.Set;

import goal.core.kr.KRlanguage;
import goal.core.kr.language.Expression;
import goal.core.kr.language.Formula;
import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Substitution;
import goal.core.kr.language.Term;
import goal.core.kr.language.Var;
import goal.kr.implementations.swiprolog.SWIPrologLanguage;
import goal.kr.language.prolog.PrologTerm;

/**
 * Wouter: jul08: Literal is an object needed to place a prolog Query. It is either a Predicate or not(Predicate).
 * From discussion with Koen I understand that this is to handle STRIPS like notations,
 * where not(actionspec) should indicate that actionspec has to be *retracted* 
 * 
 * Wouter: 15jul08. After discussion with Koen I propose to "sharpen" the definition of this object, as follows.
 * It is a predicate used in the (pre???? and) post condition of action specifications.
 * Also the head of the predicate can NOT be a predicate but only an user-defined atom (so not "sin" but "aap" is OK).
 * One exception: it can be not(predicate1) with predicate1 having the predicate restrictions above.
 * The meaning of that construct with not is that predicate1 is to be retracted. 
 * 
 * Why is there no 'Literal' in the GOAL language definition?
 * 
 * @author Koen Hindriks.
 * 
 * @modified W.Pasman 10jul08. 
 */

public class SWILiteral implements  QueryExpression, Formula {
	
	// Class fields
	private SWIPredicate fPredicate;
	private boolean fSign;   // if fSign is true than the literal is negated, i.e. not(predicate)
	
	// Class constructor
	public SWILiteral(PrologTerm t, boolean pSign) {
			fPredicate = new SWIPredicate(t);
			fSign = pSign;
	}
	
	/* Default constructor for positive literal */
	//public SWILiteral(PrologTerm t) { new SWILiteral(t,false); }

	public SWIPredicate getPredicate() {
		return fPredicate;
	}
	
	public boolean getSign() {
		return fSign;
	}
		
	public String toString() { 
		String lResult = fPredicate.toString();
		if (!fSign)
			lResult = "not("+lResult+")";
		return lResult;
	}
	
	public SWILiteral clone() {
		return new SWILiteral(fPredicate.getTerm(), fSign);
	}
	
	public boolean isClosed() {
		return fPredicate.isClosed();
	}

	public Formula applySubst(Substitution pSubst) {
		PrologTerm t=((SWIExpression)fPredicate.applySubst(pSubst)).getTerm();
		return new SWILiteral(t,fSign);
	}

	public boolean equals(Object pExpr) {
		if (pExpr instanceof SWILiteral)
			return fPredicate.equals(((SWILiteral)pExpr).getPredicate()) &&
				fSign==((SWILiteral)pExpr).getSign();
		else
			return false;
	}

	public Set<Var> getFreeVar() {
		return fPredicate.getFreeVar();
	}

	public KRlanguage getLanguage() {
		return SWIPrologLanguage.getInstance();
	}

	public boolean isVar() {
		return false;
	}

	public Substitution mgu(Expression pExpr) {
		if (pExpr instanceof SWILiteral)
			if (fSign==((SWILiteral)pExpr).getSign())
				return fPredicate.mgu(((SWILiteral)pExpr).getPredicate());
		return null;
	}

}
 