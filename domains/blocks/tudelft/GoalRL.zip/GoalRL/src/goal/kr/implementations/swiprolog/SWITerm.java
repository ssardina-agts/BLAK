package goal.kr.implementations.swiprolog;


import goal.core.kr.language.*;
import goal.kr.language.prolog.PrologTerm;


public class SWITerm extends SWIExpression implements Term { 
	
	 // Following annoys me. We have to create new SWIFormula object but it is in fact
	 // just a clone of the SWIExpression....
	public SWITerm(Expression e) { 
		super(e); 
	}

	public SWITerm(PrologTerm t) { 
		super(t); 
	}
	
	public Expression clone() {
		return new SWITerm(this);
	}
}