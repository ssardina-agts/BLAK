package goal.kr.language.prolog;

import java.util.ArrayList;
import java.util.Hashtable;

/** FuncTerm always has at least 1 argument.
	we have special function "." for list constructor 
	@author W.Pasman 8jul08 */
	
public class FuncTerm implements PrologTerm {
	
	String name;
	ArrayList<PrologTerm> arguments = new ArrayList<PrologTerm>();
		
	static Hashtable<String,Integer> operatorprios=new Hashtable<String,Integer>();
	static Hashtable<String,Integer> operatorspecs=new Hashtable<String,Integer>();
	
	// CHECK: 09Mar04KH: '\=' not in list? 'not'?
	static {
	operatorprios.put(":/1",50); operatorspecs.put(":/1",XFX);
	operatorprios.put("@/1",100); operatorspecs.put("@/1",XFX);
	operatorprios.put("-/1",200); operatorspecs.put("-/1",FY);
	operatorprios.put("\\/1",200); operatorspecs.put("\\/1",FY);
	operatorprios.put("**/2",200); operatorspecs.put("**/2",XFX);
	operatorprios.put("^/2",200); operatorspecs.put("^/2",XFY);
	operatorprios.put("*/2",400); operatorspecs.put("*/2",YFX);
	operatorprios.put("//2",400);  operatorspecs.put("//2",YFX);
	operatorprios.put("///2",400); operatorspecs.put("///2",YFX);
	operatorprios.put("rem/2",400); operatorspecs.put("rem/2",YFX);
	operatorprios.put("mod/2",400); operatorspecs.put("mod/2",YFX);
	operatorprios.put("<</2",400); operatorspecs.put("<</2",YFX);
	operatorprios.put(">>/2",400); operatorspecs.put(">>/2",YFX);
	operatorprios.put("+/2",500); operatorspecs.put("+/2",YFX);
	operatorprios.put("-/2",500); operatorspecs.put("-/2",YFX);
	operatorprios.put("/\\/2",500); operatorspecs.put("/\\/2",YFX);
	operatorprios.put("\\//2",500); operatorspecs.put("\\//2",YFX);
	operatorprios.put("is/2",700); operatorspecs.put("is/2",XFX);
	operatorprios.put("=:=/2",700); operatorspecs.put("=:=/2",XFX);
	operatorprios.put("=\\=/2",700); operatorspecs.put("=\\=/2",XFX);
	operatorprios.put("</2",700); operatorspecs.put("</2",XFX);
	operatorprios.put("=</2",700); operatorspecs.put("=</2",XFX);
	operatorprios.put(">/2",700); operatorspecs.put(">/2",XFX);
	operatorprios.put(">=/2",700); operatorspecs.put(">=/2",XFX);
	operatorprios.put("=../2",700); operatorspecs.put("=../2",XFX);
	operatorprios.put("==/2",700); operatorspecs.put("==/2",XFX);
	operatorprios.put("\\==/2",700); operatorspecs.put("\\==/2",XFX);
	operatorprios.put("@<2",700); operatorspecs.put("@/2",XFX);
	operatorprios.put("@=</2",700); operatorspecs.put("@=</2",XFX);
	operatorprios.put("@>/2",700); operatorspecs.put("@>/2",XFX);
	operatorprios.put("@>=/2",700); operatorspecs.put("@>=/2",XFX);
	operatorprios.put("=/2",700); operatorspecs.put("=/2",XFX);
	operatorprios.put("=\\=/2",700); operatorspecs.put("=\\=/2",XFX);
	operatorprios.put(",/2",1000); operatorspecs.put(",/2",XFY);
	operatorprios.put("->/2",1050); operatorspecs.put("->/2",XFY);
	operatorprios.put(";/2",1100); operatorspecs.put(";/2",XFY);
	operatorprios.put(":-/1",1200); operatorspecs.put(":-/1",FX);
	operatorprios.put("?-/1",1200); operatorspecs.put("?-/1",FX);
	operatorprios.put(":-/2",1200); operatorspecs.put(":-/2",XFX);
	operatorprios.put("-->/2",1200); operatorspecs.put("-->/2",XFX);
	};
	
	public FuncTerm(String fname, PrologTerm arg) { name=fname; putArg(arg); }
	public FuncTerm(String fname, PrologTerm a1, PrologTerm a2) { name=fname; putArg(a1); putArg(a2); }			
	public FuncTerm(String fname, ArrayList<PrologTerm> args) { name=fname; arguments=args;}
	public void putArg(PrologTerm arg) { arguments.add(arg); }	
	
	public String toString() {
		// TODO is there a smarter way to do the bracketing?
		// I guess so but then we need to determine actual priorities of subtrees.
		switch (GetSpec()) { // is this an operator?
		case FX:
		case FY:
			if (arguments.size()==1) 
				{
					if (name.equals("-")) return name+MaybeBracketed(0); // SWI bug workaround. Mantis 280
					return name+" "+MaybeBracketed(0); 
				}
				// "-" is tight binding in which case the extra brackets are not needed
				// but the :- is not tight binding so there we need brackets.
			break; // else go for default functional notation
		case XFX:
		case XFY:
		case YFX:
			if (arguments.size()==2) 
				return MaybeBracketed(0)+" "+name+" "+MaybeBracketed(1);
			break;
		case XF:
			// Wouter: I have never seen postfix. Just guessing how it would look like
			if (arguments.size()==1) return MaybeBracketed(0)+" "+name+" ";
			break;
		}
		
		// default: print in functional notation (canonical form)
		// note that FuncTerms always have at least 1 argument.
		 // special treatment of lists.
		if (name.equals(".") && arguments.size()==2) 
			return "["+arguments.get(0)+arguments.get(1).ListToString()+"]";
		
		String s=name+"("+MaybeBracketedArgument(0);
		for (int i=1; i<arguments.size(); i++) s=s+","+MaybeBracketedArgument(i);
		s=s+")";
		return s;
	}
	
	 // remember, this converts the TAIL of a list to a string.
	 // and we already know it's a function, not a BasicTerm.
	public String ListToString() { 
		if (name.equals(".")) 
			return ","+arguments.get(0)+arguments.get(1).ListToString(); // seems going well
		return "|"+this; // uh oh, bad ending, non-cons object within a cons construct.
	}
	
	/** arguments inside a predicate are priority 1000. All args higher than that must have been bracketed */
	public String MaybeBracketedArgument(int argumentnumber)
	{
		PrologTerm arg=arguments.get(argumentnumber);
		if (arg==null) throw new RuntimeException("argument "+argumentnumber+" of term "+name+" is null");
		int argprio=arg.GetPriority();
		if (argprio>=1000) //prio of ','. If we encounter a ","(..) inside arglist we also need brackets.
			return "("+arg+")";
		return ""+arg;
	}
	
	/** for operators: Convert argument to string and maybe place brackets around it,
	    if the term has a principal functor whose prio is so high that the term could not be re-input correctly
		see ISO p.45 part h 2. 
		argumentnumber should be 0 or 1.
		*/
	public String MaybeBracketed(int argumentnumber) {
		PrologTerm arg=arguments.get(argumentnumber);
		if (arg==null) throw new RuntimeException("argument "+argumentnumber+" of term "+name+" is null");
		int argprio=arg.GetPriority();
		int ourprio=GetPriority();
		
		if (argprio>ourprio) return "("+arg+")";
		if (argprio==ourprio) {
			// let's say we have an xfy operator here. The y side can have equal prio by default,
			// and that side can be printed without brackets.
			// but if the x side has same prio that's only possible if there were brackets.
			//System.out.println("getting spec of "+name+"/"+arguments.size()+"="+GetSpec());
			//System.out.println("prio of arg "+argumentnumber+" "+arg+" = "+argprio);
			Integer spec=GetSpec();
			if (spec==null) return ""+arg; // no spec, no op.
			switch ((int)spec) {
			case FX:  // args without Y need brackets anyway
			case XF:
			case XFX: 
				return "("+arg+")";
			case YFX: 
				if (argumentnumber==1) return "("+arg+")"; 
				break;
			case XFY: 
				if (argumentnumber==0) return "("+arg+")"; 
				break;
			}
		}
		return ""+arg;
	}
	
	public int GetPriority()
	{	//System.out.println("getting prio of "+name+"/"+arguments.size());
		//System.out.println("="+operatorprios.get(name+"/"+arguments.size()));
		Integer prio=operatorprios.get(name+"/"+arguments.size());
		if (prio==null) return 0;
		return prio;
	}

	public int GetSpec() {
		Integer spec=operatorspecs.get(name+"/"+arguments.size()); 
		if (spec==null) return NOT_OPERATOR;
		return spec;
	}
	
	public String getName() { return name ; }
	public ArrayList<PrologTerm> getArguments() { return arguments; }

	/*
	public boolean equals(Object o) {
		if (!(o instanceof FuncTerm)) return false;
		FuncTerm ft=(FuncTerm)o;
		if (!name.equals(ft.getName())) return false;
		
		ArrayList<PrologTerm> args = ft.getArguments();
		if (arguments.size()!=args.size()) return false;
		for (int i=0; i<arguments.size(); i++)
			if (!arguments.get(i).equals(args.get(i))) return false;
		return true;
	}
	*/
	
	public PrologTerm clone() {
		ArrayList<PrologTerm> args = new ArrayList<PrologTerm>();
		for(PrologTerm term : arguments)
			args.add(term.clone());
		return new FuncTerm(name, args);
	}
	
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((arguments == null) ? 0 : arguments.hashCode());
		result = PRIME * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final FuncTerm other = (FuncTerm) obj;
		if (arguments == null) {
			if (other.arguments != null)
				return false;
		} else if (!arguments.equals(other.arguments))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
}