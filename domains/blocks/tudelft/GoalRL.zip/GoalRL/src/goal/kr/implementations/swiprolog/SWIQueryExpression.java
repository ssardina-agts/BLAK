package goal.kr.implementations.swiprolog;


import goal.core.kr.language.*;


public class SWIQueryExpression extends SWIExpression implements QueryExpression { 
	
	// Following annoys me. We have to create new SWIFormula object but it is in fact
	// just a clone of the SWIExpression....
	public SWIQueryExpression(SWIExpression e) {
		super(e.getTerm());
	}
	
	public SWIQueryExpression applySubst(Substitution s) {
		return new SWIQueryExpression(super.applySubst(s));
	}
	
	public Expression clone() {
		return new SWIQueryExpression(this);
	}
}