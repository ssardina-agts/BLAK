package goal.kr.implementations.swiprolog;

import goal.kr.language.prolog.PrologTerm;
import goal.core.kr.language.QueryExpression;
import goal.core.kr.language.Term;
import goal.core.kr.language.Formula;

public class SWIPredicate extends SWIFormula implements QueryExpression, Formula
{
	 /* Wouter: this used to be called with a name and an array of Term objects. 
	  * That was mixing up levels I think. */
	public SWIPredicate(PrologTerm t) {
		super(t);
	}
	
}
