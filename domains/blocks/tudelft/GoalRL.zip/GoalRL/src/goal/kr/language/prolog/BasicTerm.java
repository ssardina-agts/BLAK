package goal.kr.language.prolog;

/** 
 * This represents basic terms: strings, integers, floats, [].
 * Everything is stored as String.
 * String are stored including the quotes (' or ").
 * special basic term [] is the empty list 
 * @author W.Pasman*/
public class BasicTerm implements PrologTerm {
	
	String term;
	
	public BasicTerm(String t) { term=t; }
	
	// Class methods
	public String getName() { return term; }
	
	public String toString() { return term; }
	
	public String ListToString() {
		if (term.equals("[]")) return ""; // end of list reached happily
		return "|"+term; // the bad ending, list is not a list after all....
	}
	
	public int GetPriority() { return 0; }
	public int GetSpec() { return NOT_OPERATOR; }
	public String getText() { return term; }
	
	public boolean equals(Object o) {
		if (!(o instanceof BasicTerm)) return false;
		return term.equals(((BasicTerm) o).getText());
	}
	
	public PrologTerm clone() {
		return new BasicTerm(term);
	}

}