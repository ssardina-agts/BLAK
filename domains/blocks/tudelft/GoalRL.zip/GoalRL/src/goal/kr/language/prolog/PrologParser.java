// $ANTLR 3.0.1 Prolog.g 2008-12-09 09:01:58

    package goal.kr.language.prolog;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class PrologParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ENDTOKEN", "VARIABLE", "NUMBER", "NAME", "STRING", "INTEGERCONSTANT", "REST_OF_FLOAT", "BINARYCONSTANT", "OCTALCONSTANT", "HEXADECIMALCONSTANT", "EXPONENT", "ALPHACHAR", "DIGIT", "WHITESPACECHAR", "ESCAPE_SEQUENCE", "CHAR", "META_CHAR", "SYMBOLIC_CONTROL_CHAR", "COMMENT", "WHITESPACE", "':-'", "','", "'['", "']'", "'|'", "'-->'", "';'", "'->'", "'='", "'\\\\='", "'=='", "'\\\\=='", "'@<'", "'@=<'", "'@>'", "'@>='", "'=..'", "'is'", "'=:='", "'=\\\\='", "'<'", "'=<'", "'>'", "'>='", "'+'", "'/\\\\'", "'\\\\/'", "'*'", "'/'", "'//'", "'rem'", "'mod'", "'<<'", "'>>'", "'**'", "'^'", "'('", "')'", "'{'", "'}'", "':'", "'@'", "'-'", "'\\\\'", "'\\\\+'", "'?-'"
    };
    public static final int REST_OF_FLOAT=10;
    public static final int ENDTOKEN=4;
    public static final int NUMBER=6;
    public static final int CHAR=19;
    public static final int STRING=8;
    public static final int ALPHACHAR=15;
    public static final int COMMENT=22;
    public static final int OCTALCONSTANT=12;
    public static final int BINARYCONSTANT=11;
    public static final int WHITESPACE=23;
    public static final int WHITESPACECHAR=17;
    public static final int INTEGERCONSTANT=9;
    public static final int EXPONENT=14;
    public static final int ESCAPE_SEQUENCE=18;
    public static final int VARIABLE=5;
    public static final int EOF=-1;
    public static final int META_CHAR=20;
    public static final int SYMBOLIC_CONTROL_CHAR=21;
    public static final int DIGIT=16;
    public static final int NAME=7;
    public static final int HEXADECIMALCONSTANT=13;

        public PrologParser(TokenStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "Prolog.g"; }


    	private PrologLexer lexer;
    	private CharStream cs;

    	// Wouter: extend error message
    	String sourcename;
    	public String lasterror=null;
    	
    	public void setSourceName(String name) { sourcename=name; }

    	@Override
    	public String getErrorHeader(RecognitionException e) {
    		lasterror= "Prolog parse error: "+sourcename+" line "+e.line+":"+e.charPositionInLine;
    		return lasterror;
    	}

    	// disable standard error handling by ANTLR; be strict ;; taken from David Holroyd E4X island grammar
    	// TODO: Implement more advanced error handling. One idea would be to be strict wrt embedded language and
    	// return control to outer grammar parser upon an error, but, in case the outer grammar cannot continue
    	// parsing without errors either, consume one CHARACTER (+ additionally all 'white characters'), and return
    	// control to the embedded grammar again...
    	protected void mismatch(IntStream input, int ttype, BitSet follow)
    		throws RecognitionException
    	{ throw new MismatchedTokenException(ttype, input); }

    	public void setInput(PrologLexer lexer, CharStream cs) {
    		this.lexer = lexer;
    		this.cs = cs;
    	}



    // $ANTLR start prologtext
    // Prolog.g:86:1: prologtext returns [ArrayList<PrologTerm> txt] : ( (t= directive | t= clause ) )* ;
    public final ArrayList<PrologTerm> prologtext() throws RecognitionException {
        ArrayList<PrologTerm> txt = null;

        PrologTerm t = null;


        try {
            // Prolog.g:87:2: ( ( (t= directive | t= clause ) )* )
            // Prolog.g:87:6: ( (t= directive | t= clause ) )*
            {
             txt=new ArrayList<PrologTerm>(); 
            // Prolog.g:88:3: ( (t= directive | t= clause ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=VARIABLE && LA2_0<=STRING)||LA2_0==24||LA2_0==26||(LA2_0>=29 && LA2_0<=60)||LA2_0==62||(LA2_0>=66 && LA2_0<=69)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // Prolog.g:88:5: (t= directive | t= clause )
            	    {
            	    // Prolog.g:88:5: (t= directive | t= clause )
            	    int alt1=2;
            	    int LA1_0 = input.LA(1);

            	    if ( (LA1_0==24) ) {
            	        alt1=1;
            	    }
            	    else if ( ((LA1_0>=VARIABLE && LA1_0<=STRING)||LA1_0==26||(LA1_0>=29 && LA1_0<=60)||LA1_0==62||(LA1_0>=66 && LA1_0<=69)) ) {
            	        alt1=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("88:5: (t= directive | t= clause )", 1, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt1) {
            	        case 1 :
            	            // Prolog.g:88:6: t= directive
            	            {
            	            pushFollow(FOLLOW_directive_in_prologtext81);
            	            t=directive();
            	            _fsp--;


            	            }
            	            break;
            	        case 2 :
            	            // Prolog.g:88:20: t= clause
            	            {
            	            pushFollow(FOLLOW_clause_in_prologtext87);
            	            t=clause();
            	            _fsp--;


            	            }
            	            break;

            	    }

            	    txt.add(t);

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return txt;
    }
    // $ANTLR end prologtext


    // $ANTLR start directive
    // Prolog.g:92:1: directive returns [PrologTerm term] : ':-' t= term1200 ENDTOKEN ;
    public final PrologTerm directive() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t = null;


        try {
            // Prolog.g:93:2: ( ':-' t= term1200 ENDTOKEN )
            // Prolog.g:93:4: ':-' t= term1200 ENDTOKEN
            {
            match(input,24,FOLLOW_24_in_directive115); 
            pushFollow(FOLLOW_term1200_in_directive119);
            t=term1200();
            _fsp--;

            match(input,ENDTOKEN,FOLLOW_ENDTOKEN_in_directive121); 
            term=new FuncTerm(":-",t);

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end directive


    // $ANTLR start clause
    // Prolog.g:96:1: clause returns [PrologTerm term] : t= term1200 ENDTOKEN ;
    public final PrologTerm clause() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t = null;


        try {
            // Prolog.g:97:2: (t= term1200 ENDTOKEN )
            // Prolog.g:97:4: t= term1200 ENDTOKEN
            {
            pushFollow(FOLLOW_term1200_in_clause142);
            t=term1200();
            _fsp--;

            match(input,ENDTOKEN,FOLLOW_ENDTOKEN_in_clause144); 
             term=t; 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end clause


    // $ANTLR start arglist
    // Prolog.g:101:1: arglist returns [ArrayList<PrologTerm> args] : e= expression ( ',' m= arglist )? ;
    public final ArrayList<PrologTerm> arglist() throws RecognitionException {
        ArrayList<PrologTerm> args = null;

        PrologTerm e = null;

        ArrayList<PrologTerm> m = null;


        try {
            // Prolog.g:102:2: (e= expression ( ',' m= arglist )? )
            // Prolog.g:102:6: e= expression ( ',' m= arglist )?
            {
            ArrayList<PrologTerm> as=new ArrayList<PrologTerm>(); 
            pushFollow(FOLLOW_expression_in_arglist172);
            e=expression();
            _fsp--;

            as.add(e);
            // Prolog.g:103:29: ( ',' m= arglist )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==25) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // Prolog.g:103:30: ',' m= arglist
                    {
                    match(input,25,FOLLOW_25_in_arglist177); 
                    pushFollow(FOLLOW_arglist_in_arglist181);
                    m=arglist();
                    _fsp--;

                     as.addAll(m); 

                    }
                    break;

            }

             args=as; 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return args;
    }
    // $ANTLR end arglist


    // $ANTLR start expression
    // Prolog.g:107:1: expression returns [PrologTerm term] : t= term900 ;
    public final PrologTerm expression() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t = null;


        try {
            // Prolog.g:108:2: (t= term900 )
            // Prolog.g:108:4: t= term900
            {
            pushFollow(FOLLOW_term900_in_expression211);
            t=term900();
            _fsp--;

            term=t;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end expression


    // $ANTLR start listterm
    // Prolog.g:111:1: listterm returns [PrologTerm term] : '[' (i= items )? ']' ;
    public final PrologTerm listterm() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm i = null;


        try {
            // Prolog.g:112:2: ( '[' (i= items )? ']' )
            // Prolog.g:112:4: '[' (i= items )? ']'
            {
            match(input,26,FOLLOW_26_in_listterm229); 
            // Prolog.g:112:9: (i= items )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=VARIABLE && LA4_0<=STRING)||LA4_0==26||(LA4_0>=29 && LA4_0<=60)||LA4_0==62||(LA4_0>=66 && LA4_0<=68)) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // Prolog.g:112:9: i= items
                    {
                    pushFollow(FOLLOW_items_in_listterm233);
                    i=items();
                    _fsp--;


                    }
                    break;

            }

            match(input,27,FOLLOW_27_in_listterm236); 
             if (i==null) term=new BasicTerm("[]"); else term=i; 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end listterm


    // $ANTLR start items
    // Prolog.g:115:1: items returns [PrologTerm term] : l= expression ( ( ',' r= items ) | ( '|' (r= listterm | (r1= VARIABLE ) ) ) )? ;
    public final PrologTerm items() throws RecognitionException {
        PrologTerm term = null;

        Token r1=null;
        PrologTerm l = null;

        PrologTerm r = null;


        try {
            // Prolog.g:116:2: (l= expression ( ( ',' r= items ) | ( '|' (r= listterm | (r1= VARIABLE ) ) ) )? )
            // Prolog.g:116:4: l= expression ( ( ',' r= items ) | ( '|' (r= listterm | (r1= VARIABLE ) ) ) )?
            {
            pushFollow(FOLLOW_expression_in_items257);
            l=expression();
            _fsp--;

            term=new FuncTerm(".",l); 
            // Prolog.g:117:3: ( ( ',' r= items ) | ( '|' (r= listterm | (r1= VARIABLE ) ) ) )?
            int alt6=3;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==25) ) {
                alt6=1;
            }
            else if ( (LA6_0==28) ) {
                alt6=2;
            }
            switch (alt6) {
                case 1 :
                    // Prolog.g:117:5: ( ',' r= items )
                    {
                    // Prolog.g:117:5: ( ',' r= items )
                    // Prolog.g:117:6: ',' r= items
                    {
                    match(input,25,FOLLOW_25_in_items266); 
                    pushFollow(FOLLOW_items_in_items270);
                    r=items();
                    _fsp--;


                    }


                    }
                    break;
                case 2 :
                    // Prolog.g:117:21: ( '|' (r= listterm | (r1= VARIABLE ) ) )
                    {
                    // Prolog.g:117:21: ( '|' (r= listterm | (r1= VARIABLE ) ) )
                    // Prolog.g:117:22: '|' (r= listterm | (r1= VARIABLE ) )
                    {
                    match(input,28,FOLLOW_28_in_items276); 
                    // Prolog.g:117:26: (r= listterm | (r1= VARIABLE ) )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==26) ) {
                        alt5=1;
                    }
                    else if ( (LA5_0==VARIABLE) ) {
                        alt5=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("117:26: (r= listterm | (r1= VARIABLE ) )", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // Prolog.g:117:27: r= listterm
                            {
                            pushFollow(FOLLOW_listterm_in_items281);
                            r=listterm();
                            _fsp--;


                            }
                            break;
                        case 2 :
                            // Prolog.g:117:40: (r1= VARIABLE )
                            {
                            // Prolog.g:117:40: (r1= VARIABLE )
                            // Prolog.g:117:41: r1= VARIABLE
                            {
                            r1=(Token)input.LT(1);
                            match(input,VARIABLE,FOLLOW_VARIABLE_in_items288); 
                            r=new VariableTerm(r1.getText());

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }

             	if (r==null) term=new FuncTerm(".",l,new BasicTerm("[]"));
            			else term=new FuncTerm(".",l,r); 
            		

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end items


    // $ANTLR start prefixoperator
    // Prolog.g:123:1: prefixoperator returns [PrologTerm term] : f= ( '-->' | ';' | '->' | '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' | '+' | '/\\\\' | '\\\\/' | '*' | '/' | '//' | 'rem' | 'mod' | '<<' | '>>' | '**' | '^' ) '(' e1= expression ',' e2= expression ')' ;
    public final PrologTerm prefixoperator() throws RecognitionException {
        PrologTerm term = null;

        Token f=null;
        PrologTerm e1 = null;

        PrologTerm e2 = null;


        try {
            // Prolog.g:128:2: (f= ( '-->' | ';' | '->' | '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' | '+' | '/\\\\' | '\\\\/' | '*' | '/' | '//' | 'rem' | 'mod' | '<<' | '>>' | '**' | '^' ) '(' e1= expression ',' e2= expression ')' )
            // Prolog.g:128:4: f= ( '-->' | ';' | '->' | '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' | '+' | '/\\\\' | '\\\\/' | '*' | '/' | '//' | 'rem' | 'mod' | '<<' | '>>' | '**' | '^' ) '(' e1= expression ',' e2= expression ')'
            {
            f=(Token)input.LT(1);
            if ( (input.LA(1)>=29 && input.LA(1)<=59) ) {
                input.consume();
                errorRecovery=false;
            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_prefixoperator329);    throw mse;
            }

            match(input,60,FOLLOW_60_in_prefixoperator459); 
            pushFollow(FOLLOW_expression_in_prefixoperator463);
            e1=expression();
            _fsp--;

            match(input,25,FOLLOW_25_in_prefixoperator465); 
            pushFollow(FOLLOW_expression_in_prefixoperator469);
            e2=expression();
            _fsp--;

            match(input,61,FOLLOW_61_in_prefixoperator471); 
             term=new FuncTerm(f.getText(),e1,e2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end prefixoperator


    // $ANTLR start term0
    // Prolog.g:140:1: term0 returns [PrologTerm term] : (tk= NUMBER | tk= NAME ( '(' a= arglist ')' )? | tk= VARIABLE | tk= STRING | '(' t= term1200 ')' | '{' t= term1200 '}' | t= listterm | t= prefixoperator );
    public final PrologTerm term0() throws RecognitionException {
        PrologTerm term = null;

        Token tk=null;
        ArrayList<PrologTerm> a = null;

        PrologTerm t = null;


        try {
            // Prolog.g:141:2: (tk= NUMBER | tk= NAME ( '(' a= arglist ')' )? | tk= VARIABLE | tk= STRING | '(' t= term1200 ')' | '{' t= term1200 '}' | t= listterm | t= prefixoperator )
            int alt8=8;
            switch ( input.LA(1) ) {
            case NUMBER:
                {
                alt8=1;
                }
                break;
            case NAME:
                {
                alt8=2;
                }
                break;
            case VARIABLE:
                {
                alt8=3;
                }
                break;
            case STRING:
                {
                alt8=4;
                }
                break;
            case 60:
                {
                alt8=5;
                }
                break;
            case 62:
                {
                alt8=6;
                }
                break;
            case 26:
                {
                alt8=7;
                }
                break;
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
                {
                alt8=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("140:1: term0 returns [PrologTerm term] : (tk= NUMBER | tk= NAME ( '(' a= arglist ')' )? | tk= VARIABLE | tk= STRING | '(' t= term1200 ')' | '{' t= term1200 '}' | t= listterm | t= prefixoperator );", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // Prolog.g:141:4: tk= NUMBER
                    {
                    tk=(Token)input.LT(1);
                    match(input,NUMBER,FOLLOW_NUMBER_in_term0495); 
                     term=new BasicTerm(tk.getText()); 

                    }
                    break;
                case 2 :
                    // Prolog.g:145:4: tk= NAME ( '(' a= arglist ')' )?
                    {
                    tk=(Token)input.LT(1);
                    match(input,NAME,FOLLOW_NAME_in_term0514); 
                    // Prolog.g:145:12: ( '(' a= arglist ')' )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==60) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // Prolog.g:145:14: '(' a= arglist ')'
                            {
                            match(input,60,FOLLOW_60_in_term0518); 
                            pushFollow(FOLLOW_arglist_in_term0522);
                            a=arglist();
                            _fsp--;

                            match(input,61,FOLLOW_61_in_term0524); 

                            }
                            break;

                    }

                    	if (a==null) term=new BasicTerm(tk.getText()); 
                    				else { term=new FuncTerm(tk.getText(),a); } 
                    			

                    }
                    break;
                case 3 :
                    // Prolog.g:149:4: tk= VARIABLE
                    {
                    tk=(Token)input.LT(1);
                    match(input,VARIABLE,FOLLOW_VARIABLE_in_term0542); 
                     term=new VariableTerm(tk.getText()); 

                    }
                    break;
                case 4 :
                    // Prolog.g:151:4: tk= STRING
                    {
                    tk=(Token)input.LT(1);
                    match(input,STRING,FOLLOW_STRING_in_term0557); 
                     term=new BasicTerm(tk.getText()); 

                    }
                    break;
                case 5 :
                    // Prolog.g:153:4: '(' t= term1200 ')'
                    {
                    match(input,60,FOLLOW_60_in_term0572); 
                    pushFollow(FOLLOW_term1200_in_term0576);
                    t=term1200();
                    _fsp--;

                    match(input,61,FOLLOW_61_in_term0578); 
                    term=t; 

                    }
                    break;
                case 6 :
                    // Prolog.g:155:4: '{' t= term1200 '}'
                    {
                    match(input,62,FOLLOW_62_in_term0590); 
                    pushFollow(FOLLOW_term1200_in_term0594);
                    t=term1200();
                    _fsp--;

                    match(input,63,FOLLOW_63_in_term0596); 
                     term=new FuncTerm("{}",t); 

                    }
                    break;
                case 7 :
                    // Prolog.g:157:4: t= listterm
                    {
                    pushFollow(FOLLOW_listterm_in_term0611);
                    t=listterm();
                    _fsp--;

                    term=t; 

                    }
                    break;
                case 8 :
                    // Prolog.g:159:4: t= prefixoperator
                    {
                    pushFollow(FOLLOW_prefixoperator_in_term0625);
                    t=prefixoperator();
                    _fsp--;

                    term=t; 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term0


    // $ANTLR start term50
    // Prolog.g:163:1: term50 returns [PrologTerm term] : t1= term0 ( ':' t2= term0 )? ;
    public final PrologTerm term50() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:164:2: (t1= term0 ( ':' t2= term0 )? )
            // Prolog.g:164:4: t1= term0 ( ':' t2= term0 )?
            {
            pushFollow(FOLLOW_term0_in_term50648);
            t1=term0();
            _fsp--;

            // Prolog.g:164:13: ( ':' t2= term0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==64) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // Prolog.g:164:14: ':' t2= term0
                    {
                    match(input,64,FOLLOW_64_in_term50651); 
                    pushFollow(FOLLOW_term0_in_term50655);
                    t2=term0();
                    _fsp--;


                    }
                    break;

            }

            	if (t2==null) term=t1; else term=new FuncTerm(":",t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term50


    // $ANTLR start term100
    // Prolog.g:168:1: term100 returns [PrologTerm term] : t1= term50 ( '@' t2= term50 )? ;
    public final PrologTerm term100() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:169:2: (t1= term50 ( '@' t2= term50 )? )
            // Prolog.g:169:4: t1= term50 ( '@' t2= term50 )?
            {
            pushFollow(FOLLOW_term50_in_term100680);
            t1=term50();
            _fsp--;

            // Prolog.g:169:14: ( '@' t2= term50 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==65) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // Prolog.g:169:15: '@' t2= term50
                    {
                    match(input,65,FOLLOW_65_in_term100683); 
                    pushFollow(FOLLOW_term50_in_term100687);
                    t2=term50();
                    _fsp--;


                    }
                    break;

            }

            	if (t2==null) term=t1; 	else term=new FuncTerm("@",t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term100


    // $ANTLR start term200
    // Prolog.g:173:1: term200 returns [PrologTerm term] : ( (op= '-' | op= '\\\\' ) t= term200 | t1= term100 ( (op= '^' t2= term200 ) | (op= '**' t2= term100 ) )? );
    public final PrologTerm term200() throws RecognitionException {
        PrologTerm term = null;

        Token op=null;
        PrologTerm t = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:174:2: ( (op= '-' | op= '\\\\' ) t= term200 | t1= term100 ( (op= '^' t2= term200 ) | (op= '**' t2= term100 ) )? )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=66 && LA13_0<=67)) ) {
                alt13=1;
            }
            else if ( ((LA13_0>=VARIABLE && LA13_0<=STRING)||LA13_0==26||(LA13_0>=29 && LA13_0<=60)||LA13_0==62) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("173:1: term200 returns [PrologTerm term] : ( (op= '-' | op= '\\\\' ) t= term200 | t1= term100 ( (op= '^' t2= term200 ) | (op= '**' t2= term100 ) )? );", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // Prolog.g:174:4: (op= '-' | op= '\\\\' ) t= term200
                    {
                    // Prolog.g:174:4: (op= '-' | op= '\\\\' )
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==66) ) {
                        alt11=1;
                    }
                    else if ( (LA11_0==67) ) {
                        alt11=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("174:4: (op= '-' | op= '\\\\' )", 11, 0, input);

                        throw nvae;
                    }
                    switch (alt11) {
                        case 1 :
                            // Prolog.g:174:5: op= '-'
                            {
                            op=(Token)input.LT(1);
                            match(input,66,FOLLOW_66_in_term200713); 

                            }
                            break;
                        case 2 :
                            // Prolog.g:174:14: op= '\\\\'
                            {
                            op=(Token)input.LT(1);
                            match(input,67,FOLLOW_67_in_term200719); 

                            }
                            break;

                    }

                    pushFollow(FOLLOW_term200_in_term200725);
                    t=term200();
                    _fsp--;

                     term=new FuncTerm(op.getText(),t); 

                    }
                    break;
                case 2 :
                    // Prolog.g:176:4: t1= term100 ( (op= '^' t2= term200 ) | (op= '**' t2= term100 ) )?
                    {
                    pushFollow(FOLLOW_term100_in_term200738);
                    t1=term100();
                    _fsp--;

                    // Prolog.g:176:15: ( (op= '^' t2= term200 ) | (op= '**' t2= term100 ) )?
                    int alt12=3;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==59) ) {
                        alt12=1;
                    }
                    else if ( (LA12_0==58) ) {
                        alt12=2;
                    }
                    switch (alt12) {
                        case 1 :
                            // Prolog.g:176:17: (op= '^' t2= term200 )
                            {
                            // Prolog.g:176:17: (op= '^' t2= term200 )
                            // Prolog.g:176:18: op= '^' t2= term200
                            {
                            op=(Token)input.LT(1);
                            match(input,59,FOLLOW_59_in_term200745); 
                            pushFollow(FOLLOW_term200_in_term200749);
                            t2=term200();
                            _fsp--;


                            }


                            }
                            break;
                        case 2 :
                            // Prolog.g:176:39: (op= '**' t2= term100 )
                            {
                            // Prolog.g:176:39: (op= '**' t2= term100 )
                            // Prolog.g:176:40: op= '**' t2= term100
                            {
                            op=(Token)input.LT(1);
                            match(input,58,FOLLOW_58_in_term200757); 
                            pushFollow(FOLLOW_term100_in_term200761);
                            t2=term100();
                            _fsp--;


                            }


                            }
                            break;

                    }

                    	if (t2==null) term=t1; 	else term=new FuncTerm(op.getText(),t1,t2);
                    			

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term200


    // $ANTLR start term400
    // Prolog.g:181:1: term400 returns [PrologTerm term] : t= term200 ( (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' ) t1= term200 )* ;
    public final PrologTerm term400() throws RecognitionException {
        PrologTerm term = null;

        Token op=null;
        PrologTerm t = null;

        PrologTerm t1 = null;


        try {
            // Prolog.g:182:2: (t= term200 ( (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' ) t1= term200 )* )
            // Prolog.g:182:4: t= term200 ( (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' ) t1= term200 )*
            {
            pushFollow(FOLLOW_term200_in_term400788);
            t=term200();
            _fsp--;

            // Prolog.g:183:3: ( (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' ) t1= term200 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=51 && LA15_0<=57)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // Prolog.g:184:4: (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' ) t1= term200
            	    {
            	    // Prolog.g:184:4: (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' )
            	    int alt14=7;
            	    switch ( input.LA(1) ) {
            	    case 51:
            	        {
            	        alt14=1;
            	        }
            	        break;
            	    case 52:
            	        {
            	        alt14=2;
            	        }
            	        break;
            	    case 53:
            	        {
            	        alt14=3;
            	        }
            	        break;
            	    case 54:
            	        {
            	        alt14=4;
            	        }
            	        break;
            	    case 55:
            	        {
            	        alt14=5;
            	        }
            	        break;
            	    case 56:
            	        {
            	        alt14=6;
            	        }
            	        break;
            	    case 57:
            	        {
            	        alt14=7;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("184:4: (op= '*' | op= '/' | op= '//' | op= 'rem' | op= 'mod' | op= '<<' | op= '>>' )", 14, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt14) {
            	        case 1 :
            	            // Prolog.g:184:5: op= '*'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,51,FOLLOW_51_in_term400800); 

            	            }
            	            break;
            	        case 2 :
            	            // Prolog.g:184:15: op= '/'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,52,FOLLOW_52_in_term400807); 

            	            }
            	            break;
            	        case 3 :
            	            // Prolog.g:184:24: op= '//'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,53,FOLLOW_53_in_term400813); 

            	            }
            	            break;
            	        case 4 :
            	            // Prolog.g:184:34: op= 'rem'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,54,FOLLOW_54_in_term400819); 

            	            }
            	            break;
            	        case 5 :
            	            // Prolog.g:184:45: op= 'mod'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,55,FOLLOW_55_in_term400825); 

            	            }
            	            break;
            	        case 6 :
            	            // Prolog.g:184:56: op= '<<'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,56,FOLLOW_56_in_term400831); 

            	            }
            	            break;
            	        case 7 :
            	            // Prolog.g:184:66: op= '>>'
            	            {
            	            op=(Token)input.LT(1);
            	            match(input,57,FOLLOW_57_in_term400837); 

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_term200_in_term400846);
            	    t1=term200();
            	    _fsp--;

            	     t=new FuncTerm(op.getText(),t,t1); 

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             term=t; 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term400


    // $ANTLR start term500
    // Prolog.g:192:1: term500 returns [PrologTerm term] : t= term400 (op= ( '+' | '-' | '/\\\\' | '\\\\/' ) t1= term400 )* ;
    public final PrologTerm term500() throws RecognitionException {
        PrologTerm term = null;

        Token op=null;
        PrologTerm t = null;

        PrologTerm t1 = null;


        try {
            // Prolog.g:193:2: (t= term400 (op= ( '+' | '-' | '/\\\\' | '\\\\/' ) t1= term400 )* )
            // Prolog.g:193:4: t= term400 (op= ( '+' | '-' | '/\\\\' | '\\\\/' ) t1= term400 )*
            {
            pushFollow(FOLLOW_term400_in_term500880);
            t=term400();
            _fsp--;

            // Prolog.g:194:3: (op= ( '+' | '-' | '/\\\\' | '\\\\/' ) t1= term400 )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=48 && LA16_0<=50)||LA16_0==66) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // Prolog.g:195:4: op= ( '+' | '-' | '/\\\\' | '\\\\/' ) t1= term400
            	    {
            	    op=(Token)input.LT(1);
            	    if ( (input.LA(1)>=48 && input.LA(1)<=50)||input.LA(1)==66 ) {
            	        input.consume();
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_term500891);    throw mse;
            	    }

            	    pushFollow(FOLLOW_term400_in_term500913);
            	    t1=term400();
            	    _fsp--;

            	     t=new FuncTerm(op.getText(),t,t1); 

            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

             term=t; 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term500


    // $ANTLR start term700
    // Prolog.g:202:1: term700 returns [PrologTerm term] : t1= term500 (op= ( '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' ) t2= term500 )? ;
    public final PrologTerm term700() throws RecognitionException {
        PrologTerm term = null;

        Token op=null;
        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:203:2: (t1= term500 (op= ( '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' ) t2= term500 )? )
            // Prolog.g:203:4: t1= term500 (op= ( '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' ) t2= term500 )?
            {
            pushFollow(FOLLOW_term500_in_term700946);
            t1=term500();
            _fsp--;

            // Prolog.g:203:15: (op= ( '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' ) t2= term500 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( ((LA17_0>=32 && LA17_0<=47)) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // Prolog.g:204:4: op= ( '=' | '\\\\=' | '==' | '\\\\==' | '@<' | '@=<' | '@>' | '@>=' | '=..' | 'is' | '=:=' | '=\\\\=' | '<' | '=<' | '>' | '>=' ) t2= term500
                    {
                    op=(Token)input.LT(1);
                    if ( (input.LA(1)>=32 && input.LA(1)<=47) ) {
                        input.consume();
                        errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_term700956);    throw mse;
                    }

                    pushFollow(FOLLOW_term500_in_term7001031);
                    t2=term500();
                    _fsp--;


                    }
                    break;

            }

             if (t2==null) term=t1; else term=new FuncTerm(op.getText(),t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term700


    // $ANTLR start term900
    // Prolog.g:210:1: term900 returns [PrologTerm term] : (t= term700 | '\\\\+' t= term900 );
    public final PrologTerm term900() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t = null;


        try {
            // Prolog.g:211:2: (t= term700 | '\\\\+' t= term900 )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=VARIABLE && LA18_0<=STRING)||LA18_0==26||(LA18_0>=29 && LA18_0<=60)||LA18_0==62||(LA18_0>=66 && LA18_0<=67)) ) {
                alt18=1;
            }
            else if ( (LA18_0==68) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("210:1: term900 returns [PrologTerm term] : (t= term700 | '\\\\+' t= term900 );", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // Prolog.g:211:4: t= term700
                    {
                    pushFollow(FOLLOW_term700_in_term9001058);
                    t=term700();
                    _fsp--;

                     term=t; 

                    }
                    break;
                case 2 :
                    // Prolog.g:213:4: '\\\\+' t= term900
                    {
                    match(input,68,FOLLOW_68_in_term9001069); 
                    pushFollow(FOLLOW_term900_in_term9001073);
                    t=term900();
                    _fsp--;

                     term=new FuncTerm("\\+",t);  

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term900


    // $ANTLR start term1000
    // Prolog.g:217:1: term1000 returns [PrologTerm term] : t1= term900 ( ',' t2= term1000 )? ;
    public final PrologTerm term1000() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:218:2: (t1= term900 ( ',' t2= term1000 )? )
            // Prolog.g:218:4: t1= term900 ( ',' t2= term1000 )?
            {
            pushFollow(FOLLOW_term900_in_term10001096);
            t1=term900();
            _fsp--;

            // Prolog.g:218:15: ( ',' t2= term1000 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==25) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // Prolog.g:218:16: ',' t2= term1000
                    {
                    match(input,25,FOLLOW_25_in_term10001099); 
                    pushFollow(FOLLOW_term1000_in_term10001103);
                    t2=term1000();
                    _fsp--;


                    }
                    break;

            }

             if (t2==null) term=t1; else term=new FuncTerm(",",t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term1000


    // $ANTLR start term1050
    // Prolog.g:222:1: term1050 returns [PrologTerm term] : t1= term1000 ( '->' t2= term1050 )? ;
    public final PrologTerm term1050() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:223:2: (t1= term1000 ( '->' t2= term1050 )? )
            // Prolog.g:223:4: t1= term1000 ( '->' t2= term1050 )?
            {
            pushFollow(FOLLOW_term1000_in_term10501127);
            t1=term1000();
            _fsp--;

            // Prolog.g:223:16: ( '->' t2= term1050 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==31) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // Prolog.g:223:17: '->' t2= term1050
                    {
                    match(input,31,FOLLOW_31_in_term10501130); 
                    pushFollow(FOLLOW_term1050_in_term10501134);
                    t2=term1050();
                    _fsp--;


                    }
                    break;

            }

             if (t2==null) term=t1; else term=new FuncTerm("->",t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term1050


    // $ANTLR start term1100
    // Prolog.g:227:1: term1100 returns [PrologTerm term] : t1= term1050 ( ';' t2= term1100 )? ;
    public final PrologTerm term1100() throws RecognitionException {
        PrologTerm term = null;

        PrologTerm t1 = null;

        PrologTerm t2 = null;


        try {
            // Prolog.g:228:2: (t1= term1050 ( ';' t2= term1100 )? )
            // Prolog.g:228:4: t1= term1050 ( ';' t2= term1100 )?
            {
            pushFollow(FOLLOW_term1050_in_term11001158);
            t1=term1050();
            _fsp--;

            // Prolog.g:228:16: ( ';' t2= term1100 )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==30) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // Prolog.g:228:17: ';' t2= term1100
                    {
                    match(input,30,FOLLOW_30_in_term11001161); 
                    pushFollow(FOLLOW_term1100_in_term11001165);
                    t2=term1100();
                    _fsp--;


                    }
                    break;

            }

             if (t2==null) term=t1; else term=new FuncTerm(";",t1,t2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term1100


    // $ANTLR start term1200
    // Prolog.g:232:1: term1200 returns [PrologTerm term] : (t1= term1100 ( (op= ':-' | op= '-->' ) t2= term1100 )? | '?-' t= term1100 );
    public final PrologTerm term1200() throws RecognitionException {
        PrologTerm term = null;

        Token op=null;
        PrologTerm t1 = null;

        PrologTerm t2 = null;

        PrologTerm t = null;


        try {
            // Prolog.g:233:2: (t1= term1100 ( (op= ':-' | op= '-->' ) t2= term1100 )? | '?-' t= term1100 )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( ((LA24_0>=VARIABLE && LA24_0<=STRING)||LA24_0==26||(LA24_0>=29 && LA24_0<=60)||LA24_0==62||(LA24_0>=66 && LA24_0<=68)) ) {
                alt24=1;
            }
            else if ( (LA24_0==69) ) {
                alt24=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("232:1: term1200 returns [PrologTerm term] : (t1= term1100 ( (op= ':-' | op= '-->' ) t2= term1100 )? | '?-' t= term1100 );", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // Prolog.g:233:4: t1= term1100 ( (op= ':-' | op= '-->' ) t2= term1100 )?
                    {
                    pushFollow(FOLLOW_term1100_in_term12001189);
                    t1=term1100();
                    _fsp--;

                    // Prolog.g:233:16: ( (op= ':-' | op= '-->' ) t2= term1100 )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==24||LA23_0==29) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // Prolog.g:233:18: (op= ':-' | op= '-->' ) t2= term1100
                            {
                            // Prolog.g:233:18: (op= ':-' | op= '-->' )
                            int alt22=2;
                            int LA22_0 = input.LA(1);

                            if ( (LA22_0==24) ) {
                                alt22=1;
                            }
                            else if ( (LA22_0==29) ) {
                                alt22=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("233:18: (op= ':-' | op= '-->' )", 22, 0, input);

                                throw nvae;
                            }
                            switch (alt22) {
                                case 1 :
                                    // Prolog.g:233:20: op= ':-'
                                    {
                                    op=(Token)input.LT(1);
                                    match(input,24,FOLLOW_24_in_term12001197); 

                                    }
                                    break;
                                case 2 :
                                    // Prolog.g:233:30: op= '-->'
                                    {
                                    op=(Token)input.LT(1);
                                    match(input,29,FOLLOW_29_in_term12001203); 

                                    }
                                    break;

                            }

                            pushFollow(FOLLOW_term1100_in_term12001208);
                            t2=term1100();
                            _fsp--;


                            }
                            break;

                    }

                     if (t2==null) term=t1; else term=new FuncTerm(op.getText(),t1,t2); 

                    }
                    break;
                case 2 :
                    // Prolog.g:235:4: '?-' t= term1100
                    {
                    match(input,69,FOLLOW_69_in_term12001220); 
                    pushFollow(FOLLOW_term1100_in_term12001224);
                    t=term1100();
                    _fsp--;

                     term=new FuncTerm("?-",t);  

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return term;
    }
    // $ANTLR end term1200


 

    public static final BitSet FOLLOW_directive_in_prologtext81 = new BitSet(new long[]{0x5FFFFFFFE50001E2L,0x000000000000003CL});
    public static final BitSet FOLLOW_clause_in_prologtext87 = new BitSet(new long[]{0x5FFFFFFFE50001E2L,0x000000000000003CL});
    public static final BitSet FOLLOW_24_in_directive115 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000003CL});
    public static final BitSet FOLLOW_term1200_in_directive119 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ENDTOKEN_in_directive121 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term1200_in_clause142 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ENDTOKEN_in_clause144 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_arglist172 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_arglist177 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_arglist_in_arglist181 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term900_in_expression211 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_listterm229 = new BitSet(new long[]{0x5FFFFFFFEC0001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_items_in_listterm233 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_listterm236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_items257 = new BitSet(new long[]{0x0000000012000002L});
    public static final BitSet FOLLOW_25_in_items266 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_items_in_items270 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_items276 = new BitSet(new long[]{0x0000000004000020L});
    public static final BitSet FOLLOW_listterm_in_items281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VARIABLE_in_items288 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_prefixoperator329 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_60_in_prefixoperator459 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_expression_in_prefixoperator463 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_25_in_prefixoperator465 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_expression_in_prefixoperator469 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_prefixoperator471 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_term0495 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_term0514 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_60_in_term0518 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_arglist_in_term0522 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_term0524 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VARIABLE_in_term0542 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_term0557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_60_in_term0572 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000003CL});
    public static final BitSet FOLLOW_term1200_in_term0576 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_term0578 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_62_in_term0590 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000003CL});
    public static final BitSet FOLLOW_term1200_in_term0594 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_63_in_term0596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_listterm_in_term0611 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_prefixoperator_in_term0625 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term0_in_term50648 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_64_in_term50651 = new BitSet(new long[]{0x5FFFFFFFE40001E0L});
    public static final BitSet FOLLOW_term0_in_term50655 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term50_in_term100680 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000002L});
    public static final BitSet FOLLOW_65_in_term100683 = new BitSet(new long[]{0x5FFFFFFFE40001E0L});
    public static final BitSet FOLLOW_term50_in_term100687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_66_in_term200713 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_67_in_term200719 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_term200_in_term200725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term100_in_term200738 = new BitSet(new long[]{0x0C00000000000002L});
    public static final BitSet FOLLOW_59_in_term200745 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_term200_in_term200749 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_58_in_term200757 = new BitSet(new long[]{0x5FFFFFFFE40001E0L});
    public static final BitSet FOLLOW_term100_in_term200761 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term200_in_term400788 = new BitSet(new long[]{0x03F8000000000002L});
    public static final BitSet FOLLOW_51_in_term400800 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_52_in_term400807 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_53_in_term400813 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_54_in_term400819 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_55_in_term400825 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_56_in_term400831 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_57_in_term400837 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_term200_in_term400846 = new BitSet(new long[]{0x03F8000000000002L});
    public static final BitSet FOLLOW_term400_in_term500880 = new BitSet(new long[]{0x0007000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_set_in_term500891 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_term400_in_term500913 = new BitSet(new long[]{0x0007000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_term500_in_term700946 = new BitSet(new long[]{0x0000FFFF00000002L});
    public static final BitSet FOLLOW_set_in_term700956 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000000CL});
    public static final BitSet FOLLOW_term500_in_term7001031 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term700_in_term9001058 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_68_in_term9001069 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term900_in_term9001073 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term900_in_term10001096 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_term10001099 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term1000_in_term10001103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term1000_in_term10501127 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_31_in_term10501130 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term1050_in_term10501134 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term1050_in_term11001158 = new BitSet(new long[]{0x0000000040000002L});
    public static final BitSet FOLLOW_30_in_term11001161 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term1100_in_term11001165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term1100_in_term12001189 = new BitSet(new long[]{0x0000000021000002L});
    public static final BitSet FOLLOW_24_in_term12001197 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_29_in_term12001203 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term1100_in_term12001208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_69_in_term12001220 = new BitSet(new long[]{0x5FFFFFFFE40001E0L,0x000000000000001CL});
    public static final BitSet FOLLOW_term1100_in_term12001224 = new BitSet(new long[]{0x0000000000000002L});

}