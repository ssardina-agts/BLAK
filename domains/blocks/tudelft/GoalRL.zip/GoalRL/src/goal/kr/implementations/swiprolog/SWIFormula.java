package goal.kr.implementations.swiprolog;

import java.util.ArrayList;

import goal.core.kr.language.*;
import goal.kr.language.prolog.BasicTerm;
import goal.kr.language.prolog.FuncTerm;
import goal.kr.language.prolog.PrologTerm;
import goal.kr.language.prolog.VariableTerm;
import goal.tools.errorhandling.Warning;

/** @author W.Pasman 15jul08 */
public class SWIFormula extends SWIExpression implements Formula {
	
	// Following annoys me. We have to create new SWIFormula object but it is in fact
	// just a clone of the SWIExpression....
	// KH 02Aug08 but it is not...?
	// CHECK should exclude all expressions that do not have a truth value (possibly after instantiating variables) as well as single variables...
	public SWIFormula(Expression expr) {
		super(expr);
		// check if expr can be a formula: exclude variables, dynamic, assert, retract, fail.
		String problem = "";
		if (expr instanceof SWIExpression) {
			PrologTerm term = ((SWIExpression)expr).getTerm();
			if (term instanceof VariableTerm)
				problem += "Variable is not a logical expression.";
			else if (term instanceof BasicTerm) {
				if (((BasicTerm)term).getName().equals("fail"))
					problem += "Fail is not a logical expression.";
			}
			else if (term instanceof FuncTerm) {
				String name = ((FuncTerm)term).getName();
				if (name.equals("assert") || name.equals("retract") || name.equals("dynamic"))
				// CHECK probably we don't need to extend this list with mathematical operators +, -, etc because
				// grammar will prevent exclude expressions with such operators as main operators already as possible
				// formula.
					problem += name+" is not a logical expression.";
			}
		} else
			problem += "Unknown expression type.";
		if (problem.equals(""))
			return;
		new Warning("BUG (SWIFormula): "+problem);
	}
	
	public SWIFormula(PrologTerm term) { 
		super(term);
		// check if e can be a formula
		String problem = "";
		if (term instanceof VariableTerm)
			problem += "Variable is not a logical expression.";
		else if (term instanceof BasicTerm) {
			if (((BasicTerm)term).getName().equals("fail"))
				problem += "Fail is not a logical expression.";
		}
		else if (term instanceof FuncTerm) {
			String name = ((FuncTerm)term).getName();
			if (name.equals("assert") || name.equals("retract") || name.equals("dynamic"))
			// CHECK probably we don't need to extend this list with mathematical operators +, -, etc because
			// grammar will prevent exclude expressions with such operators as main operators already as possible
			// formula.
				problem += name+" is not a logical expression.";
		}
		if (problem.equals(""))
			return;
		new Warning("BUG (SWIFormula): variable cannot be a formula.");
	}

	public Expression clone() {
		return new SWIFormula(this);
	}
	
	public SWIFormula applySubst(Substitution s) 	{ 
		// bit tricky, cannot cast Expression to Formula directly!
		return new SWIFormula(((SWIExpression)super.applySubst(s)).getTerm()); }
	
	/** @author Koen?
	 * Wouter: modified 30sept, DO NOT USE HashSet! Order IS important. 
	 * Multiple occurences of clause may have special meaning??
	 * Wouter: documentation needed.
	 */
	public ArrayList<String> getClauses() { // Ignores negative literals that occur in SWIFormula.
		ArrayList<String> formulae = new ArrayList<String>();
		PrologTerm term = this.getTerm();
		
		if (term instanceof FuncTerm) {
			String name = ((FuncTerm)term).getName();
			if (name.equals("not"))
				return formulae;
			if (name.equals(",")) {
				ArrayList<PrologTerm> args = ((FuncTerm)term).getArguments();
				SWIFormula leftconjunct = new SWIFormula(args.get(0));
				SWIFormula rightconjunct = new SWIFormula(args.get(1));
				formulae.addAll(leftconjunct.getClauses());
				formulae.addAll(rightconjunct.getClauses());
				return formulae;
			}
		}
		// remaining cases: must be either clause, fact or basicterm
		formulae.add(new SWIFormula(this).toString());
		return formulae;
	}
	
	/** @author Koen
	 * Wouter: this assumes that the current formula is a conjunction of terms.
	 * @returns list of all terms insidde the conjunction with a "not" head.
	 * Wouter: replaced Set with LinkedHashSet 30sept. See comments above. */
	public ArrayList<String> getNegations() {
		ArrayList<String> formulae = new ArrayList<String>();
		PrologTerm term = this.getTerm();
		
		if (term instanceof FuncTerm) {
			String name = ((FuncTerm)term).getName();
			ArrayList<PrologTerm> args = ((FuncTerm)term).getArguments();
			if (name.equals("not"))
				formulae.add(new SWIFormula(args.get(0)).toString());
			if (name.equals(",")) {
				SWIFormula leftconjunct = new SWIFormula(args.get(0));
				SWIFormula rightconjunct = new SWIFormula(args.get(1));
				formulae.addAll(leftconjunct.getNegations());
				formulae.addAll(rightconjunct.getNegations());
			}
		}
		return formulae;
	}

	 /** Wouter: re-enabled 5aug09 trac 717  */
	public boolean equals(Object o) {
		if (!(o instanceof SWIFormula))	return false;
		return getTerm().equals(((SWIFormula) o).getTerm());
	}
	
	/*
	//@Override
	public int hashCode() {
		return ((SWIExpression)this).hashCode();
	}
	*/

}