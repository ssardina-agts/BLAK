package goal.kr.language.prolog;


import java.io.*;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.ArrayList;
/** run this using 1 argument: the file to be parsed 
 * @author W.Pasman
 * */

public class TestTheParser {
    public static void main(String args[]) throws Exception {
        PrologLexer lex = new PrologLexer(new ANTLRFileStream(args[0]));
        CommonTokenStream tokens = new CommonTokenStream(lex);

        PrologParser parser = new PrologParser(tokens);
        ArrayList<PrologTerm> results = parser.prologtext(); // launch parsing
        //ArrayList<PrologTerm> results = new ArrayList<PrologTerm>();
        //results.add(parser.term1200()); // parsing
        // print tree if building trees
        if (results==null) System.out.println("parse failed");
		else 
		{
			for (PrologTerm t:results) 
				try { System.out.println(">"+t); }
				catch (Exception e) { System.out.println("print failed:"+e); }
		}
    }
}
