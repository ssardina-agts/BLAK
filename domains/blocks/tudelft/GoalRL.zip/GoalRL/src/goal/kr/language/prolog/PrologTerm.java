package goal.kr.language.prolog;

/*
 * PrologTerm is an object containing an ISO prolog structure.
 * It has no functionality, it only stores ISO prolog terms.
 */
public interface PrologTerm {
	//TODO implement var checking and mgu function.
	
	public String getName();
	
	public String toString();
	
	 /** special function to pretty print tails of a cons (".") function */
	public String ListToString();
	
	/** @returns priority of the term.  */
	public int GetPriority();
	/** @returns  spec of the term: fx, fy, xfy, xfx, etc. returns NOT_OPERATOR for non-operator terms. */
	public int GetSpec();
	
	public boolean equals(Object o);
	
	public PrologTerm clone();
	
	static final int NOT_OPERATOR=0;
	static final int XFX=1;
	static final int FX=2;
	static final int XFY=3;
	static final int YFX=4;
	static final int FY=5;
	static final int XF=6;
}
