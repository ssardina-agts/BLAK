package goal.kr.language.prolog;

public class VariableTerm implements PrologTerm {
	
	String name;
	
	public VariableTerm(String v) { name=v; }
	
	public String toString() { return name; }
	public String ListToString()  { return "|"+name; } // the special end with vars.
	public int GetPriority() { return 0; }
	public int GetSpec() { return NOT_OPERATOR; }
	public String getName() { return name; }
	
	public boolean equals(Object o) {
		if (!(o instanceof VariableTerm)) return false;
		return name.equals(((VariableTerm) o).getName());
	}
	
	public PrologTerm clone() {
		return new VariableTerm(name);
	}
}