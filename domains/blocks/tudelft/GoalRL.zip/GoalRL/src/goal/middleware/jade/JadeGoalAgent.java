package goal.middleware.jade;

import goal.core.env.Percept;
import goal.core.program.Action;
import goal.core.program.SendAction;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import goal.tools.errorhandling.Warning;

import java.util.ArrayList;

/**
 * @author Wouter de Vries (At least, I think so - Wouter)
 */

public class JadeGoalAgent extends Agent { // extends a JADE agent, not a GOAL agent!
	
	// Class fields
	private goal.core.agent.Agent fAgent;
	
	// Constructor
	public JadeGoalAgent(goal.core.agent.Agent pAg) {
		assert(pAg == null);
		fAgent = pAg;
	}
	
	// Class methods
	// DOC: Just need to override one JADE method, setup() to get things started. 
	public void setup() {
		System.out.println("JADE Agent ID is " + this.getAID().getName()+".");
		fAgent.getDebugger().bp("IN", "Jade-GOAL agent "+fAgent.getName()+" initialised", 1); // high level, to stop all agents here.
		
		addBehaviour(new CyclicBehaviour(this) {

			public void action() {
				/**
				 * @author Wouter de Vries
				 * Here we listen for messages. Messages can come from either the Scheduler, in which case
				 * the message contents are an array of Percepts, or from another agent.
				 */
				// CHECK: Why have the scheduler send messages through JADE as well? Can we bypass JADE, is there an alternative?
				// CHECK: As coded below, are we getting messages one at a time every 'action selection round'? Why not clear the message queue? How to avoid flooding?
				// CHECK: Why not simply check who is sending these messages?

				// get all pending messages
				ArrayList<ACLMessage> msgs = new ArrayList<ACLMessage>();
				ACLMessage msg = receive();
				while (msg!=null) {
					msgs.add(msg);
					msg = receive();
				}
				
				// ASSUMES at most one QUERY_REF will have been received via scheduler (assumption not used in code
				// below, but scheduler is assumed to select one agent and allow it to take one action at a time right
				// now).
				
				for (ACLMessage message: msgs) {
					StringHandler pSH;
					String lAct="";
					switch(message.getPerformative()) {
					case ACLMessage.INFORM: // Wouter: apparently used to communicate goal "send" objects
						// TODO: Need to write some generic methods to do this...
						pSH = new StringHandler('@');
						ArrayList<String> lAgentID = pSH.safeSplit(message.getSender().getName());
						// HACK: without any checks now, simply assert content of message into mailbox of agent.
						fAgent.getMentalState().getMailbox().insert("received("+lAgentID.get(0)+","+message.getContent()+")");
						break;
					case ACLMessage.CONFIRM: // Wouter: added 19jan09 to communicate execution results from actions on environment
							// this is needed to get debugger notice what happened with action in the environemnt
						pSH = new StringHandler(';');
						ArrayList<String> confirmation = pSH.safeSplit(message.getContent());
						lAct=confirmation.get(0);
						boolean recognised="true".equals(confirmation.get(1));
						Exception err=null;
						if (!("null".equals(confirmation.get(2)))) err=new Exception(confirmation.get(2));
						fAgent.actionWasPerformed(lAct, recognised, err); // HACK , fix this via messaging. 
						break;
					case ACLMessage.QUERY_REF:
						try { // CHECK: Performative QUERY_REF reserved for percepts?
							pSH = new StringHandler(';');
							// DOC: Modified 08-03-24 KH: added check whether percept message is empty.
							// Wouter: fixed, see mantis 305.
							ArrayList<Percept> lPercepts = new ArrayList<Percept>();
							if (!message.getContent().equals("")) {
								ArrayList<String> lPerceptsString = pSH.safeSplit(message.getContent());
								
								// Switch to inner separator
								pSH.setSep('#');
								
								for (String s : lPerceptsString) {
									ArrayList<String> thisPercept = pSH.safeSplit(s);
									if (thisPercept.size() != 2) {
										throw new Exception("JADE-GOAL Agent: Invalid Percept string: " + s);
									}
									Percept p = new Percept(thisPercept.get(1), thisPercept.get(0));
									lPercepts.add(p);
									
									// fAgent.getMentalState().getPerceptBase().updateBeliefs(p.formula.toString());
								}
							}
							fAgent.processPercepts(lPercepts);
							
							// Send selected action, if it is something for environment 
							Action lAction = fAgent.performAction();
							if (lAction!=null && !(lAction.reserved())) {
								lAct = lAction.toString(); 
							}

							// TODO: Restructure here. we may assume that JadeGOALAgent knows basics of GOAL...
							// HACK: Current send action does not synchronize with scheduler? or does it? Scheduler still dictates rythm, right? 
							// WouterP: send puts the message on in the message queue of the receiver. The receiver does not
							// yet receive CPU power to actually handle the message. So yes scheduler dictates scheduling.
							// Wouter 2sept09 moved this slightly upwards, so that send() action occurs before 
							// confirming the scheduler that we're done here.
							if (lAction instanceof SendAction) {
								//System.out.println(getAID().getName()+" is sending a message: "+lAction.toString());
								ACLMessage msg2 = new ACLMessage(ACLMessage.INFORM);
								msg2.addReceiver(new AID(((SendAction)lAction).getAgentName(), AID.ISLOCALNAME));
								msg2.setLanguage("SWIProlog");
								msg2.setContent(((SendAction)lAction).getMessage().toString());
								send(msg2);
							}							
						} catch (Exception e) { 
							new Warning("setup of Jade agent failed",e);
							lAct="failure during percept-act cycle:"+e;
						}						
						
						 // Wouter: inform scheduler always of the result. Trac 729.
						ACLMessage response = message.createReply();
						response.setContent(lAct);
						send(response);

						break;
					case ACLMessage.FAILURE:
						new Warning(fAgent.getName()+" received message back. probable cause: send("+message.getInReplyTo()+", ...) failed");
					default:
						// no messages received
					}
				}	
				block(50);
			}
		});
	}
	
	protected void takeDown() {
		//System.out.println("taking down agent "+this.getAID().getName());
		try {
			fAgent.takeDown();
		}
		catch (Exception e) {
			new Warning("takeDown of prolog engine failed: ",e);
		}
	}
	
} 

