/**
 *  This class demonstrates the use of JADE as middleware.
 *  It initializes the JADE platform, then starts a special scheduler as a JADE agent.
 *  Finally, it starts the GridWorld Environment and lets the user choose a .mas file.
 *  
 *  This mas file consists of line in the form: 
 *  
 *  	agentNickName:agentsGoalFileName
 *  
 *  Any line that is empty or starts with '%' is ignored.
 *  
 *  Wouter: 24mar09: this seems obsolete.
 */
package goal.middleware.jade;

import java.util.ArrayList;

import goal.core.mas.MASRegistry;
import goal.core.scheduler.GenericScheduler;
import goal.core.agent.Agent;
import goal.core.env.Environment;
import goal.core.env.gridworld.GridWorldFrame;
import goal.core.env.tact.TradingBoard;
import goal.tools.PlatformManager;
import goal.tools.errorhandling.Warning;

import jade.BootProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class JadeDemoMain {

	static boolean INTROSPECTOR = true;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new JadeDemoMain();
	}

	public JadeDemoMain() {
		
		/*
		 * Start GOAL platform manager
		 */
		final PlatformManager fPM = new PlatformManager();
		
		/*
		 * Setup JADE agent container
		 * Wouter: MOVED this to PlatformManager 19jun08.
		 * reason: the PM has to be able to know which agents are running,
		 * get their addresses etc. 

		BootProfileImpl profile = new BootProfileImpl();
		System.out.println(profile.toString());
		Runtime.instance().setCloseVM(true);
		AgentContainer container = Runtime.instance().createMainContainer(profile);
		*/
		
		/*
		 * Setup the GOAL agent registry
		 */
		// HACK: Assume for now we now which mas file needs to be loaded.
		try {
			System.out.println("Loading mas file...");
			fPM.loadMASfile("GOALagent/GridWalker/gridworld.mas");
			fPM.launchMAS("GOALagent/GridWalker/gridworld.mas");
		}
		catch (Exception e) { new Warning("bug in JadeDemoMain",e); }
		
		/*
		 * Start up the JADE agents
		 */
		ArrayList<String> agentNames = new ArrayList<String>();
		ArrayList<AgentController> agentControllers = new ArrayList<AgentController>();
		try {
			for (Agent lAgent : fPM.getAgents()) {
				AgentController controller =
					fPM.getMainContainer().acceptNewAgent(lAgent.getName(), new JadeGoalAgent(lAgent));
				controller.start();		// Start the JADE agent
				agentControllers.add(controller);
				agentNames.add(lAgent.getName());
			}
		} catch (Exception e) {
			System.out.println("Error starting agents:");
			e.printStackTrace();
		}
		
			/*
			 * Initialize environment
			 */
			System.out.println("Starting up environment...");
			Environment environment = new GridWorldFrame(fPM.getRegistry().getAgentNames());
			//Environment environment = new TradingBoard(agentNames);
			
			/*
			 * Initialize scheduler
			 */
			GenericScheduler goalsch=new GenericScheduler(environment)
				{ public ArrayList<Agent> getAgents() {return fPM.getAgents(); } };
			JadeScheduler scheduler = new JadeScheduler(agentControllers,environment,goalsch);
			try{
				fPM.getMainContainer().acceptNewAgent("scheduler", scheduler).start();
			} catch (Exception e) {
				new Warning("Problem with adding scheduler to JADE registry.");
			}
		

	}
}
