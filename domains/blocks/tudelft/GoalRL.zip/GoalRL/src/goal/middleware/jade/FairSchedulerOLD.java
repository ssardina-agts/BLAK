package goal.middleware.jade;

import goal.core.scheduler.GenericScheduler;
import goal.core.agent.Agent;
import java.util.ArrayList;

/**
 * Implements a round-robin schedule.
 * @author WdV
 * @modified 19jun08 W.Pasman: GenericScheduler is now round-robin, 
 * 	and also can handle real-time changing agent list. FairScheduler now obsolete.
 */

public class FairSchedulerOLD extends GenericScheduler {

	ArrayList<Agent> fAgents;
	private int lastSelected = -1;
	
	public FairScheduler(ArrayList<Agent> pAgents) {
		super(pAgents);
		fAgents = pAgents;
	}
	
	public Agent selectAgent() {
		lastSelected = (lastSelected + 1) % fAgents.size();
		return fAgents.get(lastSelected);
	}
}
