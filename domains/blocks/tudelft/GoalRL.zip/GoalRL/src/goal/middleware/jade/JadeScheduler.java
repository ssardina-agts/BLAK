package goal.middleware.jade;

import goal.core.agent.Agent;
import goal.core.env.Percept;
import goal.core.scheduler.Scheduler;
import goal.tools.errorhandling.Warning;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.wrapper.AgentController;

import java.util.ArrayList;

/** @author Wouter de Vries 
 * W.Pasman: this scheduler directly calls the pEnv functions,
 * implying that this scheduler "owns" the environment.
 * Scheduling is done by sending percepts around and reading in action messages 
 * in the order as specified in the schedule.
 * */

public class JadeScheduler extends jade.core.Agent {

	// Class fields
	ArrayList<AgentController> fAgents;
	Scheduler fSched;
	
	// Constructor
	public JadeScheduler(ArrayList<AgentController> pAgents, Scheduler pSched) {
		fAgents = pAgents;
		fSched = pSched;
	}
	
	// Class methods
	public void setup() {
		addBehaviour(new ControlLoopBehaviour(this));
	}
	
	class ControlLoopBehaviour extends CyclicBehaviour {
		JadeScheduler fJS;
		
		public ControlLoopBehaviour(JadeScheduler pJS) {
			fJS = pJS;
		}
		
		public void action() {
			
			try {
				// TODO: need to rethink code below and decide where to place which functionality (e.g. in GenericScheduler or here)
				
				Agent lAg = fSched.selectAgent();
				if (lAg==null) {
					/*
					// no agent available. sleep half a second and exit.
					try {
						Thread.sleep(500);
					} catch (InterruptedException ie) { ie.printStackTrace(); }
					*/
					return;
				}
				
				String lAgentName = lAg.getName();
				
				// Handle percepts
				ACLMessage msg = new ACLMessage(ACLMessage.QUERY_REF);
				ArrayList<Percept> lPercepts = fSched.receivePercepts(lAg);
				if (lPercepts==null) throw new NullPointerException("agent "+lAg.getName()+" has no access to environment");
				
				StringHandler sh = new StringHandler(';');
				// Inner first
				sh.setSep('#');

				ArrayList<String> lPerceptString = new ArrayList<String>();
				for (Percept percept : lPercepts) {
					lPerceptString.add(sh.catAndPrepare(new String[] {percept.getLanguage(), percept.getContent()}));
				}
				
				// Now do outer
				sh.setSep(';');
				msg.setContent(sh.catAndPrepare(lPerceptString.toArray(new String[0])));
				msg.addReceiver(new AID(lAgentName, AID.ISLOCALNAME));
				send(msg);
				
				// Get the response
				ACLMessage actionMsg = blockingReceive();
				String lAct = actionMsg.getContent();
				if (!lAct.equals("")) { // agent selected action.
				// if (fEnv.availableForInput()) { see Mantis 221?
					Exception err=null; boolean recognised=false; // default the action is not handled.
					try {
						recognised=fSched.executeAction(lAg, lAct);
					} catch (Exception e) { err=e; }
					sendActionResult(lAgentName,lAct,recognised,err);

				} // otherwise, do nothing
				//else { // ADHOC (works in BlockWorld)
					//block(5000);
					//try {lAg.reset();
					//fSched.getEnvironment().reset();
					//} catch (Exception e) { System.out.println(e); }
				//}
				
				// Wouter: moved to Agent, 17feb09: scheduler should not touch the Agent's DB.
				// if scheduler does that we will leak 100Mb memory.
				//lAg.getMentalState().getPerceptBase().eraseContent(); 
				// after using percepts in cycle, delete all. See processPercepts in Agent.
				//}
				block(1000);
				
			} catch (Exception e) { new Warning("Problem handling agent:",e); block(200); }
		}
	}

	 /**  send results of action back to agent. We use CONFIRM but this is all pretty kached....
	  * @author w.pasman
	  */
	public void sendActionResult(String aname, String act, boolean recognised, Exception err)
	{
		StringHandler sh = new StringHandler(';');
		ACLMessage msg = new ACLMessage(ACLMessage.CONFIRM);
		String errstr="null"; if (err!=null) errstr=err.toString(); // TODO figure out how Serializable works......
		msg.setContent(sh.catAndPrepare(new String[]{act,recognised? "true":"false",errstr }));
		msg.addReceiver(new AID(aname, AID.ISLOCALNAME));
		send(msg);
	}


}