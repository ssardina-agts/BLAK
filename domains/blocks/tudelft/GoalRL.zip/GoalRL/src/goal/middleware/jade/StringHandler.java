package goal.middleware.jade;
import java.text.StringCharacterIterator;
import java.util.ArrayList;

/**
 * This class provides a content-independant safe way to join Strings in 
 * preparation for transport. The general problem here is choosing a 
 * separator. Choosing a separator that is present in the content is 
 * problematic, because it becomes unclear which is the separator and
 * which is a normal original character.<p>
 * StringHandler solves this problem by duplicating each occurence of the
 * separator in the string. Upon unpacking, it can distinguish between
 * the two types by means of a parity check. 
 * 
 * @author WdV
 *
 */
public class StringHandler {
	
	private char fSep;

	public char getSep() {
		return fSep;
	}

	public void setSep(char sep) {
		fSep = sep;
	}
	
	/**
	 * Constructor. Sets a default separator.
	 */
	public StringHandler() {
		this(';');
	}
	
	
	public StringHandler(char pSeparator) {
		fSep = pSeparator;
	}

	/**
	 * Concatentates and prepares a String array for transport.
	 * If the seprator pSep occurs in a String, it is doubled.
	 * @param pString The strings that will be concatenated.
	 * @param pSep The glue that will be used to join the strings.
	 * @return A String that can be split later on.
	 */
	public String catAndPrepare(String[] pString) {
		StringBuffer sb = new StringBuffer();
		for (String s : pString) {
			sb.append(s.replaceAll(""+fSep, ""+fSep+fSep));
			sb.append(fSep);
		}
		return sb.toString();
	}
	
	/**
	 * Splits a String in a safe way, which means that it assumes that the separator
	 * may also occur in the original substrings.
	 * @param pString The string to split
	 * @return An ArrayList containing the original Strings.
	 * @see #catAndPrepare(String[] pString, char pSep)
	 */
	public ArrayList<String> safeSplit(String pString) {
		StringCharacterIterator sci = new StringCharacterIterator(pString);
		StringBuffer sb = new StringBuffer();
		ArrayList<String> tokens = new ArrayList<String>();
		for (char c = sci.first(); c != StringCharacterIterator.DONE; c = sci.next()) {
			//System.out.println(c);
			if (c == fSep) {
				/* Check if next char is also a ';' */
				char next = sci.next();
				if (next == fSep) {
					/* ok, another ';', so this was a duplicated char.
					 * insert one ';'.
					 */
					sb.append(fSep);
				} else {
					/* Apparently it really was a separator.
					 * Terminate this string.
					 */
					if (next != StringCharacterIterator.DONE) {
						tokens.add(sb.toString());
						sb.setLength(0);
						sb.append(next);
					}
				}
			}
			else {
				/* This is a normal char, so just append it to the current
				 * String.
				 */
				sb.append(c);
			}
		}
		/* End of string found, now save the last string. */
		tokens.add(sb.toString());
	
		return tokens;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String test[] = {"aabc;deb;la","jenga",";bladiebloe"};
		StringHandler sh = new StringHandler(';');
		String stream = sh.catAndPrepare(test);
		System.out.println(stream);
		
		for (String s : sh.safeSplit(stream)) {
			System.out.println(s);
		}
		System.out.println("done");
	}

}
