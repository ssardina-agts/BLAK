// $ANTLR 3.0.1 GOAL.g 2009-05-14 10:13:18

	// WARNING: DO NOT MODIFY GOALParser.java: IT IS GENERATED CODE.
	package goal.parser;

	import goal.kr.language.prolog.*;
	import java.io.Reader;
	import goal.kr.implementations.swiprolog.*;
	import goal.core.program.*;
	import goal.core.kr.language.*;
	import goal.tools.errorhandling.Warning;
	import java.util.Hashtable;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class GOALParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "MAIN", "IF", "THEN", "WHEN", "DO", "TRUE", "FALSE", "NEGATION", "BELIEF", "AGOAL", "GOALA", "GOAL", "IDENT", "DOT", "COMMA", "LBRACKET", "RBRACKET", "STRING", "COLON", "INTEGER", "COMMENT", "WS", "'{'", "'}'", "'knowledge'", "'beliefs'", "'goals'", "'program'", "'perceptrules'", "'input'", "'actionspec'", "'pre'", "'post'", "'adopt'", "'drop'", "'insert'", "'delete'", "'send'", "'#include'", "'utility'", "'horizon'", "'='"
    };
    public static final int COMMA=18;
    public static final int MAIN=4;
    public static final int GOALA=14;
    public static final int DO=8;
    public static final int IDENT=16;
    public static final int NEGATION=11;
    public static final int WHEN=7;
    public static final int WS=25;
    public static final int AGOAL=13;
    public static final int STRING=21;
    public static final int FALSE=10;
    public static final int THEN=6;
    public static final int COMMENT=24;
    public static final int LBRACKET=19;
    public static final int BELIEF=12;
    public static final int DOT=17;
    public static final int INTEGER=23;
    public static final int IF=5;
    public static final int EOF=-1;
    public static final int RBRACKET=20;
    public static final int GOAL=15;
    public static final int COLON=22;
    public static final int TRUE=9;

        public GOALParser(TokenStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "GOAL.g"; }

    
    	private GOALLexer lexer;
    	private CharStream cs;
    	private Reader fReader;
    	private int fLastPos;
    
    	// Wouter: extend error message
    	String sourcename;
    	String firsterror=null; // non-null if error occured.
    	
    	public void initialize(String name) { sourcename=name; }
    	
    	 // to avoid bug in antlr on returns[Hashtable<String,String>]
    	public class MyStringStringHashtable extends Hashtable<String,String> {}
    	
    	@Override
    	public String getErrorHeader(RecognitionException e) {
    		//e.printStackTrace();
    		String lasterror= "GOAL parse error:"+e+" in " +sourcename+" line "+
    			e.line+", position "+e.charPositionInLine;
    		if (firsterror==null) firsterror=lasterror;
    		return lasterror;
    	}	
    		
        	public void setInput(GOALLexer lexer, CharStream cs, Reader r) {
        		this.lexer = lexer;
        		this.cs = cs;
    			this.fReader = r;
        	}
    
        	public void rememberPosition() {
        		fLastPos = cs.index();
        	}
    
        	private PrologParser prepareEmbeddedParser() throws RecognitionException
     		{
        		PrologParser parser;
    
        		try {
        			//ANTLRReaderStream charstream = new ANTLRReaderStream(fReader);//new StringReader(tail));
    
        			PrologLexer lLexer = new PrologLexer((ANTLRReaderStream)cs);
    				lLexer.setSourceName(sourcename);
        			LinkedListTokenSource linker = new LinkedListTokenSource(lLexer);
        			LinkedListTokenStream tokenStream = new LinkedListTokenStream(linker);
        			parser = new PrologParser(tokenStream);
        			parser.setInput(lLexer, cs);
    				parser.setSourceName(sourcename);
    				
        		} catch (Exception e) {
    				//e.printStackTrace();
        			throw new GOALParserException(sourcename,"Init failed",e,input);
        		}
        		return parser;
        	}
        	
    /*
        	private SWIExpression ParseProlog() throws RecognitionException {
        		PrologParser parser = prepareEmbeddedParser();
        		try {
        			PrologTerm term=parser.term1200();
    				cs.seek(cs.index()-1);
    				return new SWIExpression(term);
        		} catch (RecognitionException e) {
        			new Warning(getErrorHeader(e)+": Parse of logical subexpression failed",e);
        		}
    	   		catch (Exception e) { new Warning(getErrorHeader(e)+"Error handling logical form",e);  }
        		// Get what's left from input file after parse of embedded language parser
        		//restoreInputState(parser);
        		return null;
        	}
    */
    
        	private ArrayList<Formula> ParsePrologProgram() throws RecognitionException {
        		PrologParser parser = prepareEmbeddedParser();
        		try {
        			ArrayList<PrologTerm> prologterms=parser.prologtext();
    				cs.seek(cs.index()-1);
    				ArrayList<Formula> program=new ArrayList<Formula>();
    				for (PrologTerm t: prologterms) program.add(new SWIFormula(t));
    				return program;
        		} catch (RecognitionException e) {
        			new Warning(getErrorHeader(e)+": Parse of logical subexpression failed",e);
        		}
    	   		catch (Exception e) { new Warning("Error while parsing Prolog fragment",e); }
        		// Get what's left from input file after parse of embedded language parser
        		//restoreInputState(parser);
        		return null;
        	}
    
    
        	private SWIExpression ParsePrologConjunction() throws RecognitionException {
    			try {
    	    		PrologParser parser = prepareEmbeddedParser();
    	    		PrologTerm term=parser.term1000();
    				cs.seek(cs.index()-1);
    	    		//fHelper.setFormula((SWIFormula)new SWIExpression(term));
    				return new SWIExpression(term);
    	    	} catch(RecognitionException e) {
    				new Warning(getErrorHeader(e)+" Exception in handling conjunction",e);
    	    	}
        		return null;
        	}
    
    		public  String getFirstError() { 
    			if (firsterror!=null) return firsterror;
    			return lexer.firsterror;
    		}



    // $ANTLR start program
    // GOAL.g:166:1: program returns [GOALProgram p] : 'main' ':' agentname= IDENT '{' (k= knowledgebase )? b= beliefbase g= goalbase r= actionrules a= actionspeclist (s= perceptrules )? (u= utilitysettings )? '}' ;
    public final GOALProgram program() throws RecognitionException {
        GOALProgram p = null;

        Token agentname=null;
        ArrayList<Formula> k = null;

        ArrayList<Formula> b = null;

        ArrayList<Formula> g = null;

        ArrayList<Rule> r = null;

        ArrayList<ActionRule> a = null;

        ArrayList<PerceptRule> s = null;

        MyStringStringHashtable u = null;


        try {
            // GOAL.g:167:2: ( 'main' ':' agentname= IDENT '{' (k= knowledgebase )? b= beliefbase g= goalbase r= actionrules a= actionspeclist (s= perceptrules )? (u= utilitysettings )? '}' )
            // GOAL.g:167:4: 'main' ':' agentname= IDENT '{' (k= knowledgebase )? b= beliefbase g= goalbase r= actionrules a= actionspeclist (s= perceptrules )? (u= utilitysettings )? '}'
            {
            match(input,MAIN,FOLLOW_MAIN_in_program145); 
            match(input,COLON,FOLLOW_COLON_in_program147); 
            agentname=(Token)input.LT(1);
            match(input,IDENT,FOLLOW_IDENT_in_program153); 
             p = new GOALProgram(agentname.getText()); 
            match(input,26,FOLLOW_26_in_program159); 
            // GOAL.g:169:3: (k= knowledgebase )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==28) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // GOAL.g:169:4: k= knowledgebase
                    {
                    pushFollow(FOLLOW_knowledgebase_in_program167);
                    k=knowledgebase();
                    _fsp--;

                     p.setKnowledge(k); if (k.isEmpty()) new Warning("empty knowledge base"); 

                    }
                    break;

            }

            pushFollow(FOLLOW_beliefbase_in_program178);
            b=beliefbase();
            _fsp--;

             p.setBeliefs(b); 
            pushFollow(FOLLOW_goalbase_in_program187);
            g=goalbase();
            _fsp--;

             p.setGoals(g); 
            pushFollow(FOLLOW_actionrules_in_program197);
            r=actionrules();
            _fsp--;

             p.setRules(r); 
            pushFollow(FOLLOW_actionspeclist_in_program206);
            a=actionspeclist();
            _fsp--;

             p.setActionSpec(a); 
            // GOAL.g:174:3: (s= perceptrules )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==32) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // GOAL.g:174:4: s= perceptrules
                    {
                    pushFollow(FOLLOW_perceptrules_in_program215);
                    s=perceptrules();
                    _fsp--;

                     p.setPerceptRules(s); 

                    }
                    break;

            }

            // GOAL.g:175:3: (u= utilitysettings )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==43) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // GOAL.g:175:5: u= utilitysettings
                    {
                    pushFollow(FOLLOW_utilitysettings_in_program228);
                    u=utilitysettings();
                    _fsp--;

                     p.setSettings(u); 

                    }
                    break;

            }

            match(input,27,FOLLOW_27_in_program238); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return p;
    }
    // $ANTLR end program


    // $ANTLR start knowledgebase
    // GOAL.g:179:1: knowledgebase returns [ArrayList<Formula> prolog] : 'knowledge' '{' p= prologprogram '}' ;
    public final ArrayList<Formula> knowledgebase() throws RecognitionException {
        ArrayList<Formula> prolog = null;

        ArrayList<Formula> p = null;


        try {
            // GOAL.g:180:2: ( 'knowledge' '{' p= prologprogram '}' )
            // GOAL.g:180:4: 'knowledge' '{' p= prologprogram '}'
            {
            match(input,28,FOLLOW_28_in_knowledgebase255); 
            match(input,26,FOLLOW_26_in_knowledgebase257); 
            pushFollow(FOLLOW_prologprogram_in_knowledgebase261);
            p=prologprogram();
            _fsp--;

             prolog = p; 
            match(input,27,FOLLOW_27_in_knowledgebase265); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return prolog;
    }
    // $ANTLR end knowledgebase


    // $ANTLR start beliefbase
    // GOAL.g:183:1: beliefbase returns [ArrayList<Formula> prolog] : 'beliefs' '{' p= prologprogram '}' ;
    public final ArrayList<Formula> beliefbase() throws RecognitionException {
        ArrayList<Formula> prolog = null;

        ArrayList<Formula> p = null;


        try {
            // GOAL.g:184:2: ( 'beliefs' '{' p= prologprogram '}' )
            // GOAL.g:184:4: 'beliefs' '{' p= prologprogram '}'
            {
            match(input,29,FOLLOW_29_in_beliefbase281); 
            match(input,26,FOLLOW_26_in_beliefbase283); 
            pushFollow(FOLLOW_prologprogram_in_beliefbase287);
            p=prologprogram();
            _fsp--;

             prolog = p; 
            match(input,27,FOLLOW_27_in_beliefbase291); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return prolog;
    }
    // $ANTLR end beliefbase


    // $ANTLR start goalbase
    // GOAL.g:187:1: goalbase returns [ArrayList<Formula> prolog] : 'goals' '{' p= prologprogram '}' ;
    public final ArrayList<Formula> goalbase() throws RecognitionException {
        ArrayList<Formula> prolog = null;

        ArrayList<Formula> p = null;


        try {
            // GOAL.g:188:2: ( 'goals' '{' p= prologprogram '}' )
            // GOAL.g:188:4: 'goals' '{' p= prologprogram '}'
            {
            match(input,30,FOLLOW_30_in_goalbase307); 
            match(input,26,FOLLOW_26_in_goalbase309); 
            pushFollow(FOLLOW_prologprogram_in_goalbase313);
            p=prologprogram();
            _fsp--;

            prolog=p;
            match(input,27,FOLLOW_27_in_goalbase317); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return prolog;
    }
    // $ANTLR end goalbase


    // $ANTLR start actionrules
    // GOAL.g:191:1: actionrules returns [ArrayList<Rule> actionrules] : 'program' '{' (r= actionrule )+ '}' ;
    public final ArrayList<Rule> actionrules() throws RecognitionException {
        ArrayList<Rule> actionrules = null;

        Rule r = null;


        try {
            // GOAL.g:192:2: ( 'program' '{' (r= actionrule )+ '}' )
            // GOAL.g:192:4: 'program' '{' (r= actionrule )+ '}'
            {
             actionrules=new ArrayList<Rule>(); 
            match(input,31,FOLLOW_31_in_actionrules336); 
            match(input,26,FOLLOW_26_in_actionrules338); 
            // GOAL.g:193:17: (r= actionrule )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==IF) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // GOAL.g:193:18: r= actionrule
            	    {
            	    pushFollow(FOLLOW_actionrule_in_actionrules343);
            	    r=actionrule();
            	    _fsp--;

            	     actionrules.add(r); 

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);

            match(input,27,FOLLOW_27_in_actionrules350); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return actionrules;
    }
    // $ANTLR end actionrules


    // $ANTLR start actionrule
    // GOAL.g:197:1: actionrule returns [Rule actionrule] : IF m= mentalstatecond THEN a= action DOT ;
    public final Rule actionrule() throws RecognitionException {
        Rule actionrule = null;

        MentalStateCond m = null;

        Action a = null;


        try {
            // GOAL.g:198:2: ( IF m= mentalstatecond THEN a= action DOT )
            // GOAL.g:198:4: IF m= mentalstatecond THEN a= action DOT
            {
            match(input,IF,FOLLOW_IF_in_actionrule367); 
            pushFollow(FOLLOW_mentalstatecond_in_actionrule371);
            m=mentalstatecond();
            _fsp--;

            match(input,THEN,FOLLOW_THEN_in_actionrule373); 
            pushFollow(FOLLOW_action_in_actionrule377);
            a=action();
            _fsp--;

            match(input,DOT,FOLLOW_DOT_in_actionrule379); 
             actionrule=new Rule(m,a); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return actionrule;
    }
    // $ANTLR end actionrule


    // $ANTLR start perceptrules
    // GOAL.g:201:1: perceptrules returns [ArrayList<PerceptRule> perceptrules] : 'perceptrules' '{' (r= perceptrule )* '}' ;
    public final ArrayList<PerceptRule> perceptrules() throws RecognitionException {
        ArrayList<PerceptRule> perceptrules = null;

        PerceptRule r = null;


        try {
            // GOAL.g:202:2: ( 'perceptrules' '{' (r= perceptrule )* '}' )
            // GOAL.g:202:4: 'perceptrules' '{' (r= perceptrule )* '}'
            {
             perceptrules = new ArrayList<PerceptRule>(); 
            match(input,32,FOLLOW_32_in_perceptrules401); 
            match(input,26,FOLLOW_26_in_perceptrules403); 
            // GOAL.g:203:22: (r= perceptrule )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==WHEN) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // GOAL.g:203:23: r= perceptrule
            	    {
            	    pushFollow(FOLLOW_perceptrule_in_perceptrules410);
            	    r=perceptrule();
            	    _fsp--;

            	     perceptrules.add(r); 

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            match(input,27,FOLLOW_27_in_perceptrules417); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return perceptrules;
    }
    // $ANTLR end perceptrules


    // $ANTLR start perceptrule
    // GOAL.g:206:1: perceptrule returns [PerceptRule perceptrule] : WHEN 'input' '{' '}' DO act= action DOT ;
    public final PerceptRule perceptrule() throws RecognitionException {
        PerceptRule perceptrule = null;

        Action act = null;


        try {
            // GOAL.g:207:2: ( WHEN 'input' '{' '}' DO act= action DOT )
            // GOAL.g:207:4: WHEN 'input' '{' '}' DO act= action DOT
            {
             SWIExpression cond, update; 
            match(input,WHEN,FOLLOW_WHEN_in_perceptrule437); 
            match(input,33,FOLLOW_33_in_perceptrule439); 
            match(input,26,FOLLOW_26_in_perceptrule441); 
             cond = ParsePrologConjunction(); 
            match(input,27,FOLLOW_27_in_perceptrule445); 
            match(input,DO,FOLLOW_DO_in_perceptrule449); 
            pushFollow(FOLLOW_action_in_perceptrule453);
            act=action();
            _fsp--;

            match(input,DOT,FOLLOW_DOT_in_perceptrule455); 
             
            			if ( !(act instanceof AdoptAction || act instanceof DropAction || 
            				act instanceof InsertAction || act instanceof DeleteAction))
            				// Wouter: HACK! I don't know decision and state number for this exception.
            				throw new NoViableAltException("Percept Rule only accepts adopt,drop,insert and delete actions", 0, 0, input);
            			perceptrule = new PerceptRule(new SWIFormula(cond), act); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return perceptrule;
    }
    // $ANTLR end perceptrule


    // $ANTLR start mentalstatecond
    // GOAL.g:219:1: mentalstatecond returns [MentalStateCond msc] : ma= simplecond ( COMMA ma= simplecond )* ;
    public final MentalStateCond mentalstatecond() throws RecognitionException {
        MentalStateCond msc = null;

        MentalAtom ma = null;


        try {
            // GOAL.g:220:2: (ma= simplecond ( COMMA ma= simplecond )* )
            // GOAL.g:220:4: ma= simplecond ( COMMA ma= simplecond )*
            {
             ArrayList<MentalAtom> mas=new ArrayList<MentalAtom>(); 
            pushFollow(FOLLOW_simplecond_in_mentalstatecond494);
            ma=simplecond();
            _fsp--;

             if (ma!=null) mas.add(ma); 
            // GOAL.g:222:3: ( COMMA ma= simplecond )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==COMMA) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // GOAL.g:222:4: COMMA ma= simplecond
            	    {
            	    match(input,COMMA,FOLLOW_COMMA_in_mentalstatecond502); 
            	    pushFollow(FOLLOW_simplecond_in_mentalstatecond506);
            	    ma=simplecond();
            	    _fsp--;

            	    mas.add(ma); 

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            	MentalAtom[] lMentalAtom = new MentalAtom[mas.size()];
            				lMentalAtom = mas.toArray(lMentalAtom);
            				return new MentalStateCond(lMentalAtom); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return msc;
    }
    // $ANTLR end mentalstatecond


    // $ANTLR start simplecond
    // GOAL.g:228:1: simplecond returns [MentalAtom ma] : ( TRUE | m= mentalatom[true] | NEGATION LBRACKET m= mentalatom[false] RBRACKET );
    public final MentalAtom simplecond() throws RecognitionException {
        MentalAtom ma = null;

        MentalAtom m = null;


        try {
            // GOAL.g:229:2: ( TRUE | m= mentalatom[true] | NEGATION LBRACKET m= mentalatom[false] RBRACKET )
            int alt7=3;
            switch ( input.LA(1) ) {
            case TRUE:
                {
                alt7=1;
                }
                break;
            case BELIEF:
            case AGOAL:
            case GOALA:
            case GOAL:
                {
                alt7=2;
                }
                break;
            case NEGATION:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("228:1: simplecond returns [MentalAtom ma] : ( TRUE | m= mentalatom[true] | NEGATION LBRACKET m= mentalatom[false] RBRACKET );", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // GOAL.g:229:4: TRUE
                    {
                    match(input,TRUE,FOLLOW_TRUE_in_simplecond533); 

                    }
                    break;
                case 2 :
                    // GOAL.g:230:4: m= mentalatom[true]
                    {
                    pushFollow(FOLLOW_mentalatom_in_simplecond541);
                    m=mentalatom(true);
                    _fsp--;

                    ma=m; 

                    }
                    break;
                case 3 :
                    // GOAL.g:231:4: NEGATION LBRACKET m= mentalatom[false] RBRACKET
                    {
                    match(input,NEGATION,FOLLOW_NEGATION_in_simplecond549); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_simplecond551); 
                    pushFollow(FOLLOW_mentalatom_in_simplecond555);
                    m=mentalatom(false);
                    _fsp--;

                    match(input,RBRACKET,FOLLOW_RBRACKET_in_simplecond558); 
                     ma=m; 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ma;
    }
    // $ANTLR end simplecond


    // $ANTLR start mentalatom
    // GOAL.g:234:1: mentalatom[boolean sign] returns [MentalAtom ma] : ( BELIEF LBRACKET f= poslitconj RBRACKET | GOAL LBRACKET f= poslitconj RBRACKET | AGOAL LBRACKET f= poslitconj RBRACKET | GOALA LBRACKET f= poslitconj RBRACKET );
    public final MentalAtom mentalatom(boolean sign) throws RecognitionException {
        MentalAtom ma = null;

        SWIExpression f = null;


        try {
            // GOAL.g:235:5: ( BELIEF LBRACKET f= poslitconj RBRACKET | GOAL LBRACKET f= poslitconj RBRACKET | AGOAL LBRACKET f= poslitconj RBRACKET | GOALA LBRACKET f= poslitconj RBRACKET )
            int alt8=4;
            switch ( input.LA(1) ) {
            case BELIEF:
                {
                alt8=1;
                }
                break;
            case GOAL:
                {
                alt8=2;
                }
                break;
            case AGOAL:
                {
                alt8=3;
                }
                break;
            case GOALA:
                {
                alt8=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("234:1: mentalatom[boolean sign] returns [MentalAtom ma] : ( BELIEF LBRACKET f= poslitconj RBRACKET | GOAL LBRACKET f= poslitconj RBRACKET | AGOAL LBRACKET f= poslitconj RBRACKET | GOALA LBRACKET f= poslitconj RBRACKET );", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // GOAL.g:235:9: BELIEF LBRACKET f= poslitconj RBRACKET
                    {
                    match(input,BELIEF,FOLLOW_BELIEF_in_mentalatom582); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_mentalatom584); 
                    pushFollow(FOLLOW_poslitconj_in_mentalatom588);
                    f=poslitconj();
                    _fsp--;

                    match(input,RBRACKET,FOLLOW_RBRACKET_in_mentalatom590); 
                     ma=new BeliefLiteral(sign,new SWIFormula(f)); 

                    }
                    break;
                case 2 :
                    // GOAL.g:236:4: GOAL LBRACKET f= poslitconj RBRACKET
                    {
                    match(input,GOAL,FOLLOW_GOAL_in_mentalatom598); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_mentalatom600); 
                    pushFollow(FOLLOW_poslitconj_in_mentalatom604);
                    f=poslitconj();
                    _fsp--;

                    match(input,RBRACKET,FOLLOW_RBRACKET_in_mentalatom606); 
                     ma=new GoalLiteral(sign,new SWIFormula(f)); 

                    }
                    break;
                case 3 :
                    // GOAL.g:237:4: AGOAL LBRACKET f= poslitconj RBRACKET
                    {
                    match(input,AGOAL,FOLLOW_AGOAL_in_mentalatom613); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_mentalatom615); 
                    pushFollow(FOLLOW_poslitconj_in_mentalatom619);
                    f=poslitconj();
                    _fsp--;

                    match(input,RBRACKET,FOLLOW_RBRACKET_in_mentalatom621); 
                     ma=new AGoalLiteral(sign,new SWIFormula(f)); 

                    }
                    break;
                case 4 :
                    // GOAL.g:238:4: GOALA LBRACKET f= poslitconj RBRACKET
                    {
                    match(input,GOALA,FOLLOW_GOALA_in_mentalatom628); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_mentalatom630); 
                    pushFollow(FOLLOW_poslitconj_in_mentalatom634);
                    f=poslitconj();
                    _fsp--;

                    match(input,RBRACKET,FOLLOW_RBRACKET_in_mentalatom636); 
                     ma=new GoalALiteral(sign,new SWIFormula(f)); 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ma;
    }
    // $ANTLR end mentalatom


    // $ANTLR start actionspeclist
    // GOAL.g:241:1: actionspeclist returns [ArrayList<ActionRule> ars] : 'actionspec' '{' (ar= actionspec )* '}' ;
    public final ArrayList<ActionRule> actionspeclist() throws RecognitionException {
        ArrayList<ActionRule> ars = null;

        ActionRule ar = null;


        try {
            // GOAL.g:242:2: ( 'actionspec' '{' (ar= actionspec )* '}' )
            // GOAL.g:242:4: 'actionspec' '{' (ar= actionspec )* '}'
            {
             ars=new ArrayList<ActionRule>(); 
            match(input,34,FOLLOW_34_in_actionspeclist660); 
            match(input,26,FOLLOW_26_in_actionspeclist662); 
            // GOAL.g:243:20: (ar= actionspec )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==IDENT) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // GOAL.g:243:21: ar= actionspec
            	    {
            	    pushFollow(FOLLOW_actionspec_in_actionspeclist667);
            	    ar=actionspec();
            	    _fsp--;

            	     ars.add(ar); 

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            match(input,27,FOLLOW_27_in_actionspeclist675); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ars;
    }
    // $ANTLR end actionspeclist


    // $ANTLR start actionspec
    // GOAL.g:246:1: actionspec returns [ActionRule ar] : act= userspecaction '{' pre= precondition post= postcondition '}' ;
    public final ActionRule actionspec() throws RecognitionException {
        ActionRule ar = null;

        UserSpecAction act = null;

        SWIExpression pre = null;

        SWIExpression post = null;


        try {
            // GOAL.g:247:2: (act= userspecaction '{' pre= precondition post= postcondition '}' )
            // GOAL.g:247:4: act= userspecaction '{' pre= precondition post= postcondition '}'
            {
            pushFollow(FOLLOW_userspecaction_in_actionspec695);
            act=userspecaction();
            _fsp--;

            match(input,26,FOLLOW_26_in_actionspec697); 
            pushFollow(FOLLOW_precondition_in_actionspec701);
            pre=precondition();
            _fsp--;

            pushFollow(FOLLOW_postcondition_in_actionspec705);
            post=postcondition();
            _fsp--;

            match(input,27,FOLLOW_27_in_actionspec707); 
             ar = new ActionRule(act, new SWIFormula(pre), new SWIFormula(post)); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ar;
    }
    // $ANTLR end actionspec


    // $ANTLR start precondition
    // GOAL.g:251:1: precondition returns [SWIExpression exp] : 'pre' '{' '}' ;
    public final SWIExpression precondition() throws RecognitionException {
        SWIExpression exp = null;

        try {
            // GOAL.g:252:2: ( 'pre' '{' '}' )
            // GOAL.g:252:4: 'pre' '{' '}'
            {
            match(input,35,FOLLOW_35_in_precondition728); 
            match(input,26,FOLLOW_26_in_precondition730); 
             exp=ParsePrologConjunction(); 
            match(input,27,FOLLOW_27_in_precondition734); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return exp;
    }
    // $ANTLR end precondition


    // $ANTLR start postcondition
    // GOAL.g:258:1: postcondition returns [SWIExpression exp] : 'post' '{' '}' ;
    public final SWIExpression postcondition() throws RecognitionException {
        SWIExpression exp = null;

        try {
            // GOAL.g:259:2: ( 'post' '{' '}' )
            // GOAL.g:259:4: 'post' '{' '}'
            {
            match(input,36,FOLLOW_36_in_postcondition755); 
            match(input,26,FOLLOW_26_in_postcondition757); 
             exp=ParsePrologConjunction(); 
            match(input,27,FOLLOW_27_in_postcondition761); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return exp;
    }
    // $ANTLR end postcondition


    // $ANTLR start action
    // GOAL.g:266:1: action returns [Action act] : ( 'adopt' '(' ')' | 'drop' '(' ')' | 'insert' '(' ')' | 'delete' '(' ')' | 'send' '(' lName= IDENT ',' ')' | a= userspecaction );
    public final Action action() throws RecognitionException {
        Action act = null;

        Token lName=null;
        UserSpecAction a = null;


        try {
            // GOAL.g:267:2: ( 'adopt' '(' ')' | 'drop' '(' ')' | 'insert' '(' ')' | 'delete' '(' ')' | 'send' '(' lName= IDENT ',' ')' | a= userspecaction )
            int alt10=6;
            switch ( input.LA(1) ) {
            case 37:
                {
                alt10=1;
                }
                break;
            case 38:
                {
                alt10=2;
                }
                break;
            case 39:
                {
                alt10=3;
                }
                break;
            case 40:
                {
                alt10=4;
                }
                break;
            case 41:
                {
                alt10=5;
                }
                break;
            case IDENT:
                {
                alt10=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("266:1: action returns [Action act] : ( 'adopt' '(' ')' | 'drop' '(' ')' | 'insert' '(' ')' | 'delete' '(' ')' | 'send' '(' lName= IDENT ',' ')' | a= userspecaction );", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // GOAL.g:267:4: 'adopt' '(' ')'
                    {
                    match(input,37,FOLLOW_37_in_action780); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_action782); 
                     act=new AdoptAction(new SWIQueryExpression(ParsePrologConjunction())); 
                    match(input,RBRACKET,FOLLOW_RBRACKET_in_action786); 

                    }
                    break;
                case 2 :
                    // GOAL.g:268:4: 'drop' '(' ')'
                    {
                    match(input,38,FOLLOW_38_in_action791); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_action793); 
                     act=new DropAction(new SWIQueryExpression(ParsePrologConjunction())); 
                    match(input,RBRACKET,FOLLOW_RBRACKET_in_action797); 

                    }
                    break;
                case 3 :
                    // GOAL.g:269:4: 'insert' '(' ')'
                    {
                    match(input,39,FOLLOW_39_in_action802); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_action804); 
                     act=new InsertAction(new SWIQueryExpression(ParsePrologConjunction())); 
                    match(input,RBRACKET,FOLLOW_RBRACKET_in_action808); 

                    }
                    break;
                case 4 :
                    // GOAL.g:270:4: 'delete' '(' ')'
                    {
                    match(input,40,FOLLOW_40_in_action813); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_action815); 
                     act=new DeleteAction(new SWIQueryExpression(ParsePrologConjunction())); 
                    match(input,RBRACKET,FOLLOW_RBRACKET_in_action819); 

                    }
                    break;
                case 5 :
                    // GOAL.g:271:4: 'send' '(' lName= IDENT ',' ')'
                    {
                    match(input,41,FOLLOW_41_in_action824); 
                    match(input,LBRACKET,FOLLOW_LBRACKET_in_action826); 
                    lName=(Token)input.LT(1);
                    match(input,IDENT,FOLLOW_IDENT_in_action832); 
                    match(input,COMMA,FOLLOW_COMMA_in_action834); 
                    act=new SendAction(lName.getText(),
                    			new SWIQueryExpression(ParsePrologConjunction()));
                    match(input,RBRACKET,FOLLOW_RBRACKET_in_action841); 

                    }
                    break;
                case 6 :
                    // GOAL.g:274:4: a= userspecaction
                    {
                    pushFollow(FOLLOW_userspecaction_in_action848);
                    a=userspecaction();
                    _fsp--;

                    act=a;

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return act;
    }
    // $ANTLR end action


    // $ANTLR start userspecaction
    // GOAL.g:277:1: userspecaction returns [UserSpecAction act] : lName= IDENT (args= arglist )? ;
    public final UserSpecAction userspecaction() throws RecognitionException {
        UserSpecAction act = null;

        Token lName=null;
        SWIExpression args = null;


        try {
            // GOAL.g:278:2: (lName= IDENT (args= arglist )? )
            // GOAL.g:278:4: lName= IDENT (args= arglist )?
            {
            lName=(Token)input.LT(1);
            match(input,IDENT,FOLLOW_IDENT_in_userspecaction870); 
            // GOAL.g:278:18: (args= arglist )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==LBRACKET) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // GOAL.g:278:19: args= arglist
                    {
                    pushFollow(FOLLOW_arglist_in_userspecaction875);
                    args=arglist();
                    _fsp--;


                    }
                    break;

            }

             Term[] terms={}; // empty list
                    	  if (args!=null) terms=new Term[] {new SWITerm(args)};
            			  act=new UserSpecAction(lName.getText(),terms);  

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return act;
    }
    // $ANTLR end userspecaction


    // $ANTLR start extrastuff
    // GOAL.g:284:1: extrastuff : (x=~ ( '}' | '.' | '#include' ) )* ;
    public final void extrastuff() throws RecognitionException {
        Token x=null;

        try {
            // GOAL.g:285:2: ( (x=~ ( '}' | '.' | '#include' ) )* )
            // GOAL.g:285:4: (x=~ ( '}' | '.' | '#include' ) )*
            {
            String extra="";
            // GOAL.g:286:2: (x=~ ( '}' | '.' | '#include' ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=MAIN && LA12_0<=IDENT)||(LA12_0>=COMMA && LA12_0<=26)||(LA12_0>=28 && LA12_0<=41)||(LA12_0>=43 && LA12_0<=45)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // GOAL.g:286:3: x=~ ( '}' | '.' | '#include' )
            	    {
            	    x=(Token)input.LT(1);
            	    if ( (input.LA(1)>=MAIN && input.LA(1)<=IDENT)||(input.LA(1)>=COMMA && input.LA(1)<=26)||(input.LA(1)>=28 && input.LA(1)<=41)||(input.LA(1)>=43 && input.LA(1)<=45) ) {
            	        input.consume();
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_extrastuff901);    throw mse;
            	    }

            	    extra=extra+x.getText(); 

            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             if (!extra.equals("")) 
            		// Wouter: there is no good error class to represent this error.
            		// None of the antlr error classes can take just a string to explain
            		// the problem. And printing message first and then throwing may
            		// cause extra confusion. So we just print the error text here and continue.
            		System.out.println(getErrorHeader(new RecognitionException(input))+
            			": ignoring additional characters '"+extra+"'");
            	

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end extrastuff


    // $ANTLR start prologprogram
    // GOAL.g:296:1: prologprogram returns [ArrayList<Formula> prog] : extrastuff ;
    public final ArrayList<Formula> prologprogram() throws RecognitionException {
        ArrayList<Formula> prog = null;

        try {
            // GOAL.g:297:2: ( extrastuff )
            // GOAL.g:297:4: extrastuff
            {
             prog=ParsePrologProgram(); 
            pushFollow(FOLLOW_extrastuff_in_prologprogram936);
            extrastuff();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return prog;
    }
    // $ANTLR end prologprogram


    // $ANTLR start include
    // GOAL.g:303:1: include returns [String inc] : '#include' filenamewithquotes= STRING ;
    public final String include() throws RecognitionException {
        String inc = null;

        Token filenamewithquotes=null;

        try {
            // GOAL.g:304:2: ( '#include' filenamewithquotes= STRING )
            // GOAL.g:304:5: '#include' filenamewithquotes= STRING
            {
            match(input,42,FOLLOW_42_in_include959); 
            filenamewithquotes=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_include963); 
             inc=filenamewithquotes.getText().replaceAll("\"",""); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return inc;
    }
    // $ANTLR end include


    // $ANTLR start poslitconj
    // GOAL.g:308:1: poslitconj returns [SWIExpression exp] : ;
    public final SWIExpression poslitconj() throws RecognitionException {
        SWIExpression exp = null;

        try {
            // GOAL.g:309:2: ()
            // GOAL.g:309:4: 
            {
             exp=ParsePrologConjunction(); 

            }

        }
        finally {
        }
        return exp;
    }
    // $ANTLR end poslitconj


    // $ANTLR start arglist
    // GOAL.g:316:1: arglist returns [SWIExpression exp] : LBRACKET RBRACKET ;
    public final SWIExpression arglist() throws RecognitionException {
        SWIExpression exp = null;

        try {
            // GOAL.g:317:2: ( LBRACKET RBRACKET )
            // GOAL.g:317:4: LBRACKET RBRACKET
            {
            match(input,LBRACKET,FOLLOW_LBRACKET_in_arglist1004); 
             exp=ParsePrologConjunction(); 
            match(input,RBRACKET,FOLLOW_RBRACKET_in_arglist1008); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return exp;
    }
    // $ANTLR end arglist


    // $ANTLR start utilitysettings
    // GOAL.g:322:1: utilitysettings returns [MyStringStringHashtable settings] : 'utility' '{' (s= utilsetting )* '}' ;
    public final MyStringStringHashtable utilitysettings() throws RecognitionException {
        MyStringStringHashtable settings = null;

        utilsetting_return s = null;


        try {
            // GOAL.g:323:2: ( 'utility' '{' (s= utilsetting )* '}' )
            // GOAL.g:323:5: 'utility' '{' (s= utilsetting )* '}'
            {
             settings = new MyStringStringHashtable(); 
            match(input,43,FOLLOW_43_in_utilitysettings1031); 
            match(input,26,FOLLOW_26_in_utilitysettings1033); 
            // GOAL.g:324:17: (s= utilsetting )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==COLON) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // GOAL.g:324:18: s= utilsetting
            	    {
            	    pushFollow(FOLLOW_utilsetting_in_utilitysettings1038);
            	    s=utilsetting();
            	    _fsp--;

            	     settings.put(s.key,s.value); 

            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            match(input,27,FOLLOW_27_in_utilitysettings1045); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return settings;
    }
    // $ANTLR end utilitysettings

    public static class utilsetting_return extends ParserRuleReturnScope {
        public String key;
        public String value;
    };

    // $ANTLR start utilsetting
    // GOAL.g:326:1: utilsetting returns [ String key, String value ] : COLON k= 'horizon' '=' v= INTEGER DOT ;
    public final utilsetting_return utilsetting() throws RecognitionException {
        utilsetting_return retval = new utilsetting_return();
        retval.start = input.LT(1);

        Token k=null;
        Token v=null;

        try {
            // GOAL.g:327:2: ( COLON k= 'horizon' '=' v= INTEGER DOT )
            // GOAL.g:327:4: COLON k= 'horizon' '=' v= INTEGER DOT
            {
            match(input,COLON,FOLLOW_COLON_in_utilsetting1059); 
            k=(Token)input.LT(1);
            match(input,44,FOLLOW_44_in_utilsetting1063); 
            match(input,45,FOLLOW_45_in_utilsetting1065); 
            v=(Token)input.LT(1);
            match(input,INTEGER,FOLLOW_INTEGER_in_utilsetting1069); 
            match(input,DOT,FOLLOW_DOT_in_utilsetting1071); 
             retval.key =k.getText(); retval.value =v.getText(); 

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end utilsetting


 

    public static final BitSet FOLLOW_MAIN_in_program145 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_COLON_in_program147 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_IDENT_in_program153 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_program159 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_knowledgebase_in_program167 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_beliefbase_in_program178 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_goalbase_in_program187 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_actionrules_in_program197 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_actionspeclist_in_program206 = new BitSet(new long[]{0x0000080108000000L});
    public static final BitSet FOLLOW_perceptrules_in_program215 = new BitSet(new long[]{0x0000080008000000L});
    public static final BitSet FOLLOW_utilitysettings_in_program228 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_program238 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_knowledgebase255 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_knowledgebase257 = new BitSet(new long[]{0x00003BFFFFFDFFF0L});
    public static final BitSet FOLLOW_prologprogram_in_knowledgebase261 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_knowledgebase265 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_beliefbase281 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_beliefbase283 = new BitSet(new long[]{0x00003BFFFFFDFFF0L});
    public static final BitSet FOLLOW_prologprogram_in_beliefbase287 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_beliefbase291 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_goalbase307 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_goalbase309 = new BitSet(new long[]{0x00003BFFFFFDFFF0L});
    public static final BitSet FOLLOW_prologprogram_in_goalbase313 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_goalbase317 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_actionrules336 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_actionrules338 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_actionrule_in_actionrules343 = new BitSet(new long[]{0x0000000008000020L});
    public static final BitSet FOLLOW_27_in_actionrules350 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_actionrule367 = new BitSet(new long[]{0x000000000000FA00L});
    public static final BitSet FOLLOW_mentalstatecond_in_actionrule371 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_THEN_in_actionrule373 = new BitSet(new long[]{0x000003E000010000L});
    public static final BitSet FOLLOW_action_in_actionrule377 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_DOT_in_actionrule379 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_perceptrules401 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_perceptrules403 = new BitSet(new long[]{0x0000000008000080L});
    public static final BitSet FOLLOW_perceptrule_in_perceptrules410 = new BitSet(new long[]{0x0000000008000080L});
    public static final BitSet FOLLOW_27_in_perceptrules417 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHEN_in_perceptrule437 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_perceptrule439 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_perceptrule441 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_perceptrule445 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_DO_in_perceptrule449 = new BitSet(new long[]{0x000003E000010000L});
    public static final BitSet FOLLOW_action_in_perceptrule453 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_DOT_in_perceptrule455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simplecond_in_mentalstatecond494 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_COMMA_in_mentalstatecond502 = new BitSet(new long[]{0x000000000000FA00L});
    public static final BitSet FOLLOW_simplecond_in_mentalstatecond506 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_TRUE_in_simplecond533 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_mentalatom_in_simplecond541 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEGATION_in_simplecond549 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_simplecond551 = new BitSet(new long[]{0x000000000000F000L});
    public static final BitSet FOLLOW_mentalatom_in_simplecond555 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_simplecond558 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BELIEF_in_mentalatom582 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_mentalatom584 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_poslitconj_in_mentalatom588 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_mentalatom590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GOAL_in_mentalatom598 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_mentalatom600 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_poslitconj_in_mentalatom604 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_mentalatom606 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AGOAL_in_mentalatom613 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_mentalatom615 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_poslitconj_in_mentalatom619 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_mentalatom621 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GOALA_in_mentalatom628 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_mentalatom630 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_poslitconj_in_mentalatom634 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_mentalatom636 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_actionspeclist660 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_actionspeclist662 = new BitSet(new long[]{0x0000000008010000L});
    public static final BitSet FOLLOW_actionspec_in_actionspeclist667 = new BitSet(new long[]{0x0000000008010000L});
    public static final BitSet FOLLOW_27_in_actionspeclist675 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_userspecaction_in_actionspec695 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_actionspec697 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_precondition_in_actionspec701 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_postcondition_in_actionspec705 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_actionspec707 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_precondition728 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_precondition730 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_precondition734 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_postcondition755 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_postcondition757 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_27_in_postcondition761 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_action780 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_action782 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_action786 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_action791 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_action793 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_action797 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_action802 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_action804 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_action808 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_action813 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_action815 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_action819 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_action824 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_LBRACKET_in_action826 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_IDENT_in_action832 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_COMMA_in_action834 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_action841 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_userspecaction_in_action848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENT_in_userspecaction870 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_arglist_in_userspecaction875 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_extrastuff901 = new BitSet(new long[]{0x00003BFFF7FDFFF2L});
    public static final BitSet FOLLOW_extrastuff_in_prologprogram936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_42_in_include959 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_STRING_in_include963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LBRACKET_in_arglist1004 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_RBRACKET_in_arglist1008 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_43_in_utilitysettings1031 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_utilitysettings1033 = new BitSet(new long[]{0x0000000008400000L});
    public static final BitSet FOLLOW_utilsetting_in_utilitysettings1038 = new BitSet(new long[]{0x0000000008400000L});
    public static final BitSet FOLLOW_27_in_utilitysettings1045 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_in_utilsetting1059 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_44_in_utilsetting1063 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_45_in_utilsetting1065 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_INTEGER_in_utilsetting1069 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_DOT_in_utilsetting1071 = new BitSet(new long[]{0x0000000000000002L});

}