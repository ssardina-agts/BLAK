package goal.parser;


import java.io.File;
import java.io.FileReader;
import java.io.Reader;

import org.antlr.runtime.*;
/** run this using 1 argument: the file to be parsed 
 * @author W.Pasman
 * */

public class TestTheParser {
    public static void main(String args[]) throws Exception {
 
        String pFileName=args[0];
		Reader lFileReader = new FileReader(new File(pFileName));
		System.out.println("Parsing agent file...");

		ANTLRReaderStream lCharStream = new ANTLRReaderStream(lFileReader);

		GOALLexer lLexer = new GOALLexer(lCharStream);
		lLexer.setSourceName("file "+pFileName);
		LinkedListTokenSource lLinker = new LinkedListTokenSource(lLexer);
		LinkedListTokenStream lTokenStream = new LinkedListTokenStream(lLinker);
		GOALParser lParser = new GOALParser(lTokenStream);
		lParser.initialize("file "+pFileName,null);
		lParser.setInput(lLexer, lCharStream, lFileReader);
		GOALProgram prog=lParser.program();
	       // print tree if building trees
        if (prog==null) System.out.println("parse failed");
		else System.out.println(""+prog);
        
    }
}
