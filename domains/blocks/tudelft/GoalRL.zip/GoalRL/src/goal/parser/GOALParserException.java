package goal.parser;

/**
 * typical call from .g file: 
 * new GOALParserException("error info",input)
 * @author W.Pasman
 */



import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.IntStream;

public class GOALParserException extends RecognitionException
{
	String source;
	String reason;
	String cause="";
	
	/**
	 * Stores all information about a GOAL parser error, including the
	 * exception that was raised causing the error.
	 * @param causedby is exception that caused error. May be set to null.
	 * @author W.Pasman
	 */
	GOALParserException(String sourcename,String errreason,Exception causedby, IntStream input)
	{
		super(input);
		source=sourcename;
		reason=errreason;
		if (causedby!=null) {
			cause=""+causedby+" at ";
			for (StackTraceElement s: causedby.getStackTrace())
				cause=cause+" "+s;	
		}	
	}
	
	
	public String toString() {
		return "GOAL Parser Exception:"+reason+" in "+source+", line "+line+", position "+charPositionInLine+"\nCAUSE:"+cause;
			
	}
}