package goal.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.Set;

import goal.core.kr.language.*;
import goal.core.program.*;
import goal.kr.implementations.swiprolog.SWIFormula;
import goal.kr.implementations.swiprolog.SWIQueryExpression;
import goal.kr.language.prolog.FuncTerm;
import goal.kr.language.prolog.PrologTerm;
import goal.tools.errorhandling.Warning;

/**
 * 
 * This class provides a datastructure to store a parsed GOAL program.
 * 
 */

public class GOALProgram {
	
	// Class fields
	String agentName;
	ArrayList<Formula> knowledge = new ArrayList<Formula>(); // the knowledge base is empty by default.
	ArrayList<Formula> beliefs;
	ArrayList<Formula> goals;
	// TODO: Rename class Rule to ActionRule...
	ArrayList<Rule> actionRules;
	// TODO: Sort this out. Class ActionRule that stores action specifications??
	ArrayList<ActionRule> actionSpecification;
	ArrayList<PerceptRule> perceptRules = new ArrayList<PerceptRule>(); // percept rule section is assumed empty by default.
	Hashtable<String,String> settings; // the program settings, as <key,value> pairs CHECK why is this here? which settings?

	// Class constructor
	public GOALProgram(String name) {
		agentName = name;
	}
	
	// Class methods
	public String getAgentName() {
		return agentName;
	}
	
	public ArrayList<Formula> getGoals() {
		return goals;
	}
	
	public ArrayList<Formula> getKnowledge() {
		return knowledge;
	}
	
	public ArrayList<Formula> getBeliefs() {
		return beliefs;
	}
	
	public ArrayList<Rule> getProgram() {
		return actionRules;
	}
	
	public ArrayList<ActionRule> getActionSpecification() {
		return actionSpecification;
	}
	
	/**
	 * getActionSpec DOC
	 * This method should NOT be called before all fields (TODO all?) (goals, beliefs, ...) have been set. 
	 * @return DOC document what String contains! 
	 */
	public HashMap<String, ActionSpecification> getActionSpec() {
		HashMap<String, ActionSpecification> spec = new HashMap<String, ActionSpecification>();
		
		// first create the list of all user specified actions in the program section.
		// just add the actions to the hash map and do not care yet about pre- and postconditions
		for(Rule progrule: actionRules) {
			Action action = progrule.getAction();
			if (action instanceof UserSpecAction && spec.get(action.toString())==null) {
				ActionSpecification actionSpec = new ActionSpecification((UserSpecAction)action);
				spec.put(action.toString(), actionSpec);
			}
		}
		
		// second, get the corresponding pre/post-conditions from the action specification section and add them to the hashmap 
		for (ActionRule ar : actionSpecification)
			addActionSpec(spec, ar.getAction(), ar.getPreCondition(), ar.getPostCondition());
		
		return spec;
	}
	
	public ArrayList<PerceptRule> getPerceptRules() {
		return perceptRules;
	}
	
	public void setKnowledge(ArrayList<Formula> knowledge) {
		this.knowledge = knowledge;
	}
	
	public void setBeliefs(ArrayList<Formula> beliefs) {
		this.beliefs = beliefs;
	}
	
	public void setGoals(ArrayList<Formula> goals) {
		this.goals = goals;
	}
	
	public void setRules(ArrayList<Rule> rules) {
		actionRules = rules;
	}
	
	public void setActionSpec(ArrayList<ActionRule> actionspec) {
		actionSpecification = actionspec;
	}
	
	public void setPerceptRules(ArrayList<PerceptRule> rules) {
		perceptRules = rules;
	}
	
	// settings in utility section
	public void setSettings(Hashtable<String, String> str) {
		settings = str;
	}
	
	public String toString() {
		return 
		":main: "+agentName+
		"\n{"+
		":beliefs {" + ArrayToString("\n  ", beliefs,".") +"\n}\n"+
		":goals {" + ArrayToString("\n  ", goals,".") +"\n}\n"+
		":program {" + ArrayToString("\n  ", actionRules,".") +"\n}\n"+
		":actionspec {"+ArrayToString("\n  ", actionSpecification,"") +"\n}\n"+
		"\n}";
	}
	
	public String ArrayToString(String prefix, ArrayList<?> array, String postfix) {
		String str = new String();
		for (Object o : array)
			str = str + prefix + o + postfix;
		return str;
	}
	
	
	
	/**
	 *  Adds given fAction with given pre- and post conditions to list fActionSpec
	 *  Checks that given action occurs in the program rules.
	 *  
	 *  TODO Used only above in getActionSpec(); Do we need this method??
	 *  
	 *  @param actionCalls is a list of actions in the program section: <key, value> pairs where key is
	 *  the action (converted to string) and value is an ActionSpecification: a userspecaction with a list
	 *  of attached pre- and post-conditions.
	 *  @returns updated fActionSpec .
	 */
	public void addActionSpec(HashMap<String, ActionSpecification> actionCalls, Action actionSpecified, Expression actionPreCond, Expression actionPostCond) {
		
		Set<Var> lFreeVar; //Wouter: all variables occuring in the actionspec.

		// Check whether reserved action is being redefined; this is not allowed
		if (actionSpecified.reserved()) {
			new Warning("Cannot redefine reserved action symbol "+actionSpecified.getName()+".");
			return;
		}
		// Check whether each variable in postcondition occurs in either precondition or action parameter
		lFreeVar = actionPreCond.getFreeVar();
		lFreeVar.addAll(actionSpecified.getFreeVar());
		if (!lFreeVar.containsAll(actionPostCond.getFreeVar())) {
			lFreeVar=actionPostCond.getFreeVar();
			lFreeVar.removeAll(actionPreCond.getFreeVar());
			new Warning("Variable(s) "+lFreeVar+" in postcondition of action "+actionSpecified+" does not occur in precondition;" +
					" ignoring action specification "+actionSpecified);
			
			//new Warning("Variable in postcondition of action "+actionSpecified+
			//		" does not occur in precondition nor in action parameters.");
			return;
		}
		
		// For each action in program section, check whether that action instantiates
		// the given fAction specification. If so, add specification to the corresponding action
		// specification data structure.
		// Also check whether action specified occurs in program section at all;
		boolean lInstantiated = false;
		Substitution lMGU = null;

		 // Wouter: this AnonymisingSubsti aims at solving Mantis issue 404
		 // It works as long as no combis of vars with same name but varying number of prefix '_' are
		 // used. Does GOAL accept vars starting with _ anyway? CHECK this
		Substitution AnonymisingSubsti=new Substitution();
		for (Var v: lFreeVar) { 
			AnonymisingSubsti.addBinding( AnonymisingSubsti.new Binding(v,v.getSimilar()));
		}
		
		for (ActionSpecification lSpec : actionCalls.values()) {
			
			lMGU = actionSpecified.applySubst(AnonymisingSubsti).mgu(lSpec.getAction());
			if (lMGU!=null) {
				// lSpec.getAction() instantiates actionSpecified
				// TODO: may not be true. need to make this more specific.
				// given assumption, all we need to do is add mgu as constraint to pre- and post-condition.
				lInstantiated = true;
				lSpec.addSpecification((Formula)actionPreCond.applySubst(AnonymisingSubsti).applySubst(lMGU), 
						(Formula)actionPostCond.applySubst(AnonymisingSubsti).applySubst(lMGU));
				actionCalls.put(lSpec.getAction().toString(), lSpec);
				// DEBUG:
				//System.out.println(lSpec.toString());
			}
			// TODO: Handle case where action in program section is more general than any
			// in action specification; this should produce error.
		}
		if (!lInstantiated) {
			// if action specified does not occur in program section issue warning and ignore specification.
			new Warning("Action specification for "+actionSpecified+" does not occur in program section");
		}
	}
	
	
	

	
/** 
 * @author KH Jul08
 * DECLARATION HANDLING: code to extract info to perform right imports/exports and introduction of dynamic predicates
 * for SWI-Prolog databases (modules). Also includes code to check that predicates introduced into knowledge base are
 * never updated (asserted or retracted) in a given belief or goal base.
 * 
 */
// ADHOC: Prolog specific code below. Declaration functions are needed to be able to declare predicates dynamic in Prolog.
// TODO: integrate all this stuff into parser where it seems to belong, e.g. have this list of strings to import into other bases computed once by the parser.
// DOC: need to document methods below.
	
	public LinkedHashSet<String> getDeclarations(ArrayList<Formula> formulae) {
		LinkedHashSet<String> declarations = new LinkedHashSet<String>();
		
		for (Formula formula : formulae) { 
			PrologTerm term = (PrologTerm)((SWIFormula)formula).getTerm();
			declarations.addAll(getDeclarationNames(term));
		}
		return declarations;
	}
	
	private LinkedHashSet<String> getDeclarationNames(PrologTerm term) {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		String name = term.getName();
		int arity;
		
		if (term instanceof FuncTerm)
			arity = ((FuncTerm)term).getArguments().size();
		else
			arity = 0;
		
		// TODO: make code below more robust, add checks
		// ASSUMES formula is either a clause (main operator = ':-'), conjunction (main operator = ','), or predicate 
		if (name.equals(":-")) { // clause, get head of clause
			names.addAll(getDeclarationNames((((FuncTerm)term).getArguments().get(0))));
		} else if (name.equals(",")) { // conjunction
			names.addAll(getDeclarationNames((((FuncTerm)term).getArguments().get(0))));
			names.addAll(getDeclarationNames((((FuncTerm)term).getArguments().get(1))));
		} else // predicate
			if (!prologBuiltin(name+"/"+arity))
				names.add(makeName(name, arity));
		return names;
	}
	
	public LinkedHashSet<String> getCalls(ArrayList<Formula> formulae) {
		LinkedHashSet<String> calls = new LinkedHashSet<String>();
		
		for (Formula formula : formulae) { 
			PrologTerm term = (PrologTerm)((SWIFormula)formula).getTerm();
			if (term.getName().equals(":-")) // only add names of calls in body of clause
				calls.addAll(getCallNames(term));
		}
		return calls;
	}
	
	private LinkedHashSet<String> getCallNames(PrologTerm term) {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		String name = term.getName();
		int arity;
		
		if (term instanceof FuncTerm)
			arity = ((FuncTerm)term).getArguments().size();
		else
			arity = 0;
		
		// below all Prolog operators (see method prologBuiltin) should be handled that give rise to additional Prolog calls when the operator is evaluated. 
		if (name.equals(":-")) { // clause, get names in body
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(1))));
		} else if (name.equals("not")) { // negation, get name of argument
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(0))));
		} else if (name.equals(",")) { // conjunction
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(0))));
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(1))));
		} // Do NOT add the cases below to getDeclarationNames.
		  else if (name.equals("forall")) { // forall quantifier
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(0))));
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(1))));
		} else if (name.equals("findall") || name.equals("setof")) { // findall, setof operator
			names.addAll(getCallNames((((FuncTerm)term).getArguments().get(1))));
		} else if (name.equals("aggregate") || name.equals("aggregate_all")) { // aggregate operators, SWI Prolog specific (not part of ISO standard)
			if (((FuncTerm)term).getArguments().size()==3)
				names.addAll(getCallNames((((FuncTerm)term).getArguments().get(1))));
			else // 4 arguments
				names.addAll(getCallNames((((FuncTerm)term).getArguments().get(2))));
		} else // predicate
			if (!prologBuiltin(name+"/"+arity))
			names.add(makeName(name, arity));
		return names;
	}
	
	private String makeName(String name, int arity) {
		name += (arity>0 ? "(" : ""); 
		for (int i=0; i<arity; i++) {
			name += "_,";
		}
		name = (arity>0 ? name.substring(0,name.length()-1)+")" : name); // depending on arity remove last "," and add ")"
		return name;
	}

	/**
	 * prologBuiltin contains a list of all (SWI-)Prolog operators that may be used within a GOAL program.
	 * The list of operators includes all those included in class FuncTerm. 
	 * 
	 * The operators 'dynamic', 'assert', or 'retract' are not available and should NOT be added.
	 * Including these operators would give rise to unexpected behavior of a GOAL program.
	 * 
	 * @return true if the string is a Prolog operator that may be used in a GOAL program, false otherwise.
	 */
	public boolean prologBuiltin(String operator) {
		final Hashtable<String,Integer> operators = new Hashtable<String,Integer>();

		operators.put(":/1", 50);
		operators.put("@/1",100); 
		operators.put("-/1",200); 
		operators.put("\\/1",200);
		operators.put("**/2",200);
		operators.put("^/2",200);
		operators.put("*/2",400);
		operators.put("//2",400);
		operators.put("///2",400);
		operators.put("rem/2",400);
		operators.put("mod/2",400);
		operators.put("<</2",400);
		operators.put(">>/2",400);
		operators.put("+/2",500);
		operators.put("-/2",500);
		operators.put("/\\/2",500);
		operators.put("\\//2",500);
		operators.put("\\=/2",700);
		operators.put("is/2",700);
		operators.put("=:=/2",700);
		operators.put("=\\=/2",700);
		operators.put("</2",700);
		operators.put("=</2",700);
		operators.put(">/2",700);
		operators.put(">=/2",700); 
		operators.put("=../2",700); 
		operators.put("==/2",700); 
		operators.put("\\==/2",700); 
		operators.put("@<2",700); 
		operators.put("@=</2",700); 
		operators.put("@>/2",700); 
		operators.put("@>=/2",700); 
		operators.put("=/2",700); 
		operators.put("=\\=/2",700); 
		operators.put(",/2",1000); 
		operators.put("->/2",1050); 
		operators.put(";/2",1100); 
		operators.put(":-/1",1200); 
		operators.put("?-/1",1200); 
		operators.put(":-/2",1200);
		operators.put("-->/2",1200);
		
		// priority of operators below not really important in this context.
		// true, cut, fail, conjunction, ;_, not, var operators.
		operators.put("true/0",0);
		operators.put("!/0", 0);
		operators.put("fail/0", 0);
		operators.put("var/1",0);
		operators.put(",/2",0);
		operators.put(":-/2",0);
		operators.put("not/1",0);
		// list operators.
		operators.put("is_list/1",0);
		operators.put("length/2",0);
		operators.put("last/2",0);
		operators.put("sort/2",0);
		operators.put("merge/3",0);
		operators.put("maplist/2",0);
		operators.put("maplist/3",0);
		operators.put("maplist/4",0);
		operators.put("sublist/3",0);
		operators.put("include/3",0);
		operators.put("reverse/2",0);
		operators.put("flatten/2",0);
		operators.put("member/2", 0);
		operators.put("append/3", 0);
		// mathematics
		operators.put("between/3",0);
		operators.put("sqrt/1",0);
		operators.put("floor/1",0);
		operators.put("ceiling/1",0);
		operators.put("truncate/1",0);
		operators.put("round/1",0);
		operators.put("min/2",0);
		operators.put("max/2",0);
		operators.put("sign/1",0);
		operators.put("abs/1",0);
		// random
		operators.put("random/1",0);
		// operators that quantify over variables.
		operators.put("setof/3",0);
		operators.put("findall/3", 0);
		operators.put("aggregate/3", 0);
		operators.put("aggregate/4", 0);
		operators.put("aggregate_all/3", 0);
		operators.put("aggregate_all/4", 0);
		operators.put("forall/2",0);
		// operators used within context of operators that quantify over variables
		operators.put("max/1",0);
		operators.put("min/1",0);
		operators.put("count/1",0);
		operators.put("sum/1",0);
		operators.put("set/1",0);
		operators.put("bag/1",0);
		// operators for time
		operators.put("time/3",0);
		operators.put("get_time/1",0);
		operators.put("date/3",0);
		operators.put("date/9",0);


		return operators.containsKey(operator);
	}
	
	public LinkedHashSet<String> getAdoptDropDeclarationsFromRules() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();

		// TODO: check code below. Other actions??
		for (Rule rule : actionRules) {
			Action act = rule.getAction();
			// ASSUMES grammar does not allow adopt or drop action that has argument containing clauses (':-')
			if (act instanceof AdoptAction) 
				names.addAll(getCallNames(((SWIQueryExpression)((AdoptAction)act).getGoal()).getTerm()));
			else if (act instanceof DropAction) 
				names.addAll(getCallNames(((SWIQueryExpression)((DropAction)act).getGoal()).getTerm()));
		}
		return names;
	}
	
	public LinkedHashSet<String> getBBConditionDeclarationsFromRules() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();

		for (Rule rule : actionRules) {
			// ASSUMES grammar does not allow mental state conditions that have arguments containing clauses (':-')
			MentalStateCond cond = rule.getCondition();
			for (MentalAtom lit : cond.getLiterals())
				if (lit.getType()==LITERALTYPE.BELIEF)
					names.addAll(getCallNames(((SWIFormula)lit.getFormula()).getTerm()));
		}
		return names;
	}

	public LinkedHashSet<String> getGBConditionDeclarationsFromRules() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();

		for (Rule rule : actionRules) {
			// ASSUMES grammar does not allow mental state conditions that have arguments containing clauses (':-')
			MentalStateCond cond = rule.getCondition();
			for (MentalAtom lit : cond.getLiterals())
				if (lit.getType()!=LITERALTYPE.BELIEF)
					names.addAll(getCallNames(((SWIFormula)lit.getFormula()).getTerm()));
		}
		return names;
	}
	
	public LinkedHashSet<String> getPreConditionDeclarations() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		
		for (ActionRule rule : actionSpecification) {
			names.addAll(getCallNames(((SWIFormula)rule.getPreCondition()).getTerm()));
		}
		return names;
	}
	
	public LinkedHashSet<String> getPostConditionDeclarations() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		
		for (ActionRule rule : actionSpecification) {
			names.addAll(getCallNames(((SWIFormula)rule.getPostCondition()).getTerm()));
		}
		return names;
	}

	public LinkedHashSet<String> getPerceptRuleCondDeclarations() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		
		for (PerceptRule rule : perceptRules) {
			names.addAll(getCallNames(((SWIFormula)rule.getCondition()).getTerm()));
		}
		return names;
	}

	public LinkedHashSet<String> getPerceptRuleUpdateDeclarations() {
		LinkedHashSet<String> names = new LinkedHashSet<String>();
		
		for (PerceptRule rule : perceptRules) {
			names.addAll(getCallNames(((SWIFormula)rule.getUpdate()).getTerm()));
		}
		return names;
	}

	/**
	 * Actions are not allowed to update (assert or retract) predicates declared in the knowledge base. Although
	 * technically this does not introduce problems, ??GOAL would not perform as expected??.
	 * 09Mar03KH: Not so sure anymore that this is a problem. Decide to allow this for now if no problems turn up.
	 * @return false
	 */
	public boolean checkDeclarationClashes() {
	/*	boolean clash = false;
		LinkedHashSet<String> kbDecl = getDeclarations(knowledge);
		LinkedHashSet<String> names;

		// first, check action rules
		names = getAdoptDropDeclarationsFromRules();
		names.retainAll(kbDecl);
		clash = clash || !names.isEmpty();
		if (!names.isEmpty())
			for (String name : names)
				new Warning("Cannot adopt or drop predicate "+name+" declared in the knowledge base.");

		// second, check action specifications
		names = getPostConditionDeclarations();
		names.retainAll(kbDecl);
		clash = clash || !names.isEmpty();
		if (!names.isEmpty())
			for (String name : names)
				new Warning("Cannot use predicate "+name+" declared in knowledge base in postcondition.");
		
		// third, check percept rules
		// TODO
		
		return clash;
		*/
		return false;
	}

// END of declaration handling code.

}
