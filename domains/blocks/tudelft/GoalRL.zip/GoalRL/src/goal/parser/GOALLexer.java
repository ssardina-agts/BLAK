// $ANTLR 3.0.1 GOAL.g 2009-05-14 10:13:19

	// WARNING: DO NOT MODIFY GOALLexer.java: IT IS GENERATED CODE.
	package goal.parser;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class GOALLexer extends Lexer {
    public static final int COMMA=18;
    public static final int MAIN=4;
    public static final int T29=29;
    public static final int T36=36;
    public static final int FALSE=10;
    public static final int THEN=6;
    public static final int T35=35;
    public static final int LBRACKET=19;
    public static final int T45=45;
    public static final int T34=34;
    public static final int DOT=17;
    public static final int INTEGER=23;
    public static final int T37=37;
    public static final int T26=26;
    public static final int RBRACKET=20;
    public static final int T32=32;
    public static final int GOAL=15;
    public static final int T38=38;
    public static final int T41=41;
    public static final int T39=39;
    public static final int T44=44;
    public static final int GOALA=14;
    public static final int IDENT=16;
    public static final int DO=8;
    public static final int NEGATION=11;
    public static final int T33=33;
    public static final int WHEN=7;
    public static final int AGOAL=13;
    public static final int WS=25;
    public static final int STRING=21;
    public static final int T43=43;
    public static final int T28=28;
    public static final int T42=42;
    public static final int T40=40;
    public static final int COMMENT=24;
    public static final int BELIEF=12;
    public static final int IF=5;
    public static final int EOF=-1;
    public static final int Tokens=46;
    public static final int COLON=22;
    public static final int T31=31;
    public static final int T27=27;
    public static final int TRUE=9;
    public static final int T30=30;
    
    	String sourcename;
    	String firsterror=null; // non-null if error occured.
    	
    	public void setSourceName(String name) { sourcename=name; }
    	
    	@Override 
    	public String getErrorHeader(RecognitionException e) {
    		String lasterror= "GOAL lexer error, "+e+" in "+sourcename+" line "+
    			e.line+", position "+e.charPositionInLine;
    		if (firsterror==null) firsterror=lasterror;
    	return lasterror;
    	}

    public GOALLexer() {;} 
    public GOALLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "GOAL.g"; }

    // $ANTLR start MAIN
    public final void mMAIN() throws RecognitionException {
        try {
            int _type = MAIN;
            // GOAL.g:22:6: ( 'main' )
            // GOAL.g:22:8: 'main'
            {
            match("main"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end MAIN

    // $ANTLR start IF
    public final void mIF() throws RecognitionException {
        try {
            int _type = IF;
            // GOAL.g:23:4: ( 'if' )
            // GOAL.g:23:6: 'if'
            {
            match("if"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end IF

    // $ANTLR start THEN
    public final void mTHEN() throws RecognitionException {
        try {
            int _type = THEN;
            // GOAL.g:24:6: ( 'then' )
            // GOAL.g:24:8: 'then'
            {
            match("then"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end THEN

    // $ANTLR start WHEN
    public final void mWHEN() throws RecognitionException {
        try {
            int _type = WHEN;
            // GOAL.g:25:6: ( 'when' )
            // GOAL.g:25:8: 'when'
            {
            match("when"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end WHEN

    // $ANTLR start DO
    public final void mDO() throws RecognitionException {
        try {
            int _type = DO;
            // GOAL.g:26:4: ( 'do' )
            // GOAL.g:26:6: 'do'
            {
            match("do"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end DO

    // $ANTLR start TRUE
    public final void mTRUE() throws RecognitionException {
        try {
            int _type = TRUE;
            // GOAL.g:27:6: ( 'true' )
            // GOAL.g:27:8: 'true'
            {
            match("true"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end TRUE

    // $ANTLR start FALSE
    public final void mFALSE() throws RecognitionException {
        try {
            int _type = FALSE;
            // GOAL.g:28:7: ( 'false' )
            // GOAL.g:28:9: 'false'
            {
            match("false"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end FALSE

    // $ANTLR start NEGATION
    public final void mNEGATION() throws RecognitionException {
        try {
            int _type = NEGATION;
            // GOAL.g:29:10: ( 'not' )
            // GOAL.g:29:12: 'not'
            {
            match("not"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NEGATION

    // $ANTLR start BELIEF
    public final void mBELIEF() throws RecognitionException {
        try {
            int _type = BELIEF;
            // GOAL.g:30:8: ( 'bel' )
            // GOAL.g:30:10: 'bel'
            {
            match("bel"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end BELIEF

    // $ANTLR start AGOAL
    public final void mAGOAL() throws RecognitionException {
        try {
            int _type = AGOAL;
            // GOAL.g:31:7: ( 'a-goal' )
            // GOAL.g:31:9: 'a-goal'
            {
            match("a-goal"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end AGOAL

    // $ANTLR start GOALA
    public final void mGOALA() throws RecognitionException {
        try {
            int _type = GOALA;
            // GOAL.g:32:7: ( 'goal-a' )
            // GOAL.g:32:9: 'goal-a'
            {
            match("goal-a"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end GOALA

    // $ANTLR start GOAL
    public final void mGOAL() throws RecognitionException {
        try {
            int _type = GOAL;
            // GOAL.g:33:6: ( 'goal' )
            // GOAL.g:33:8: 'goal'
            {
            match("goal"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end GOAL

    // $ANTLR start T26
    public final void mT26() throws RecognitionException {
        try {
            int _type = T26;
            // GOAL.g:34:5: ( '{' )
            // GOAL.g:34:7: '{'
            {
            match('{'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T26

    // $ANTLR start T27
    public final void mT27() throws RecognitionException {
        try {
            int _type = T27;
            // GOAL.g:35:5: ( '}' )
            // GOAL.g:35:7: '}'
            {
            match('}'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T27

    // $ANTLR start T28
    public final void mT28() throws RecognitionException {
        try {
            int _type = T28;
            // GOAL.g:36:5: ( 'knowledge' )
            // GOAL.g:36:7: 'knowledge'
            {
            match("knowledge"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T28

    // $ANTLR start T29
    public final void mT29() throws RecognitionException {
        try {
            int _type = T29;
            // GOAL.g:37:5: ( 'beliefs' )
            // GOAL.g:37:7: 'beliefs'
            {
            match("beliefs"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T29

    // $ANTLR start T30
    public final void mT30() throws RecognitionException {
        try {
            int _type = T30;
            // GOAL.g:38:5: ( 'goals' )
            // GOAL.g:38:7: 'goals'
            {
            match("goals"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T30

    // $ANTLR start T31
    public final void mT31() throws RecognitionException {
        try {
            int _type = T31;
            // GOAL.g:39:5: ( 'program' )
            // GOAL.g:39:7: 'program'
            {
            match("program"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T31

    // $ANTLR start T32
    public final void mT32() throws RecognitionException {
        try {
            int _type = T32;
            // GOAL.g:40:5: ( 'perceptrules' )
            // GOAL.g:40:7: 'perceptrules'
            {
            match("perceptrules"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T32

    // $ANTLR start T33
    public final void mT33() throws RecognitionException {
        try {
            int _type = T33;
            // GOAL.g:41:5: ( 'input' )
            // GOAL.g:41:7: 'input'
            {
            match("input"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T33

    // $ANTLR start T34
    public final void mT34() throws RecognitionException {
        try {
            int _type = T34;
            // GOAL.g:42:5: ( 'actionspec' )
            // GOAL.g:42:7: 'actionspec'
            {
            match("actionspec"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T34

    // $ANTLR start T35
    public final void mT35() throws RecognitionException {
        try {
            int _type = T35;
            // GOAL.g:43:5: ( 'pre' )
            // GOAL.g:43:7: 'pre'
            {
            match("pre"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T35

    // $ANTLR start T36
    public final void mT36() throws RecognitionException {
        try {
            int _type = T36;
            // GOAL.g:44:5: ( 'post' )
            // GOAL.g:44:7: 'post'
            {
            match("post"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T36

    // $ANTLR start T37
    public final void mT37() throws RecognitionException {
        try {
            int _type = T37;
            // GOAL.g:45:5: ( 'adopt' )
            // GOAL.g:45:7: 'adopt'
            {
            match("adopt"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T37

    // $ANTLR start T38
    public final void mT38() throws RecognitionException {
        try {
            int _type = T38;
            // GOAL.g:46:5: ( 'drop' )
            // GOAL.g:46:7: 'drop'
            {
            match("drop"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T38

    // $ANTLR start T39
    public final void mT39() throws RecognitionException {
        try {
            int _type = T39;
            // GOAL.g:47:5: ( 'insert' )
            // GOAL.g:47:7: 'insert'
            {
            match("insert"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T39

    // $ANTLR start T40
    public final void mT40() throws RecognitionException {
        try {
            int _type = T40;
            // GOAL.g:48:5: ( 'delete' )
            // GOAL.g:48:7: 'delete'
            {
            match("delete"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T40

    // $ANTLR start T41
    public final void mT41() throws RecognitionException {
        try {
            int _type = T41;
            // GOAL.g:49:5: ( 'send' )
            // GOAL.g:49:7: 'send'
            {
            match("send"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T41

    // $ANTLR start T42
    public final void mT42() throws RecognitionException {
        try {
            int _type = T42;
            // GOAL.g:50:5: ( '#include' )
            // GOAL.g:50:7: '#include'
            {
            match("#include"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T42

    // $ANTLR start T43
    public final void mT43() throws RecognitionException {
        try {
            int _type = T43;
            // GOAL.g:51:5: ( 'utility' )
            // GOAL.g:51:7: 'utility'
            {
            match("utility"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T43

    // $ANTLR start T44
    public final void mT44() throws RecognitionException {
        try {
            int _type = T44;
            // GOAL.g:52:5: ( 'horizon' )
            // GOAL.g:52:7: 'horizon'
            {
            match("horizon"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T44

    // $ANTLR start T45
    public final void mT45() throws RecognitionException {
        try {
            int _type = T45;
            // GOAL.g:53:5: ( '=' )
            // GOAL.g:53:7: '='
            {
            match('='); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T45

    // $ANTLR start IDENT
    public final void mIDENT() throws RecognitionException {
        try {
            int _type = IDENT;
            // GOAL.g:334:2: ( ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '$' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' | '$' )* )
            // GOAL.g:334:4: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '$' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' | '$' )*
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // GOAL.g:334:32: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' | '$' )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0=='$'||(LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||LA1_0=='_'||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // GOAL.g:
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end IDENT

    // $ANTLR start INTEGER
    public final void mINTEGER() throws RecognitionException {
        try {
            int _type = INTEGER;
            // GOAL.g:337:9: ( '0' | ( '1' .. '9' ( '0' .. '9' )* ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0=='0') ) {
                alt3=1;
            }
            else if ( ((LA3_0>='1' && LA3_0<='9')) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("337:1: INTEGER : ( '0' | ( '1' .. '9' ( '0' .. '9' )* ) );", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // GOAL.g:337:11: '0'
                    {
                    match('0'); 

                    }
                    break;
                case 2 :
                    // GOAL.g:337:17: ( '1' .. '9' ( '0' .. '9' )* )
                    {
                    // GOAL.g:337:17: ( '1' .. '9' ( '0' .. '9' )* )
                    // GOAL.g:337:18: '1' .. '9' ( '0' .. '9' )*
                    {
                    matchRange('1','9'); 
                    // GOAL.g:337:27: ( '0' .. '9' )*
                    loop2:
                    do {
                        int alt2=2;
                        int LA2_0 = input.LA(1);

                        if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                            alt2=1;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // GOAL.g:337:28: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);


                    }


                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end INTEGER

    // $ANTLR start LBRACKET
    public final void mLBRACKET() throws RecognitionException {
        try {
            int _type = LBRACKET;
            // GOAL.g:339:10: ( '(' )
            // GOAL.g:339:12: '('
            {
            match('('); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end LBRACKET

    // $ANTLR start RBRACKET
    public final void mRBRACKET() throws RecognitionException {
        try {
            int _type = RBRACKET;
            // GOAL.g:340:10: ( ')' )
            // GOAL.g:340:12: ')'
            {
            match(')'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RBRACKET

    // $ANTLR start DOT
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            // GOAL.g:341:7: ( '.' )
            // GOAL.g:341:9: '.'
            {
            match('.'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end DOT

    // $ANTLR start COMMA
    public final void mCOMMA() throws RecognitionException {
        try {
            int _type = COMMA;
            // GOAL.g:342:8: ( ',' )
            // GOAL.g:342:10: ','
            {
            match(','); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end COMMA

    // $ANTLR start COLON
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            // GOAL.g:343:8: ( ':' )
            // GOAL.g:343:10: ':'
            {
            match(':'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end COLON

    // $ANTLR start COMMENT
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            // GOAL.g:346:9: ( '%' (~ ( '\\n' | '\\r' ) )* )
            // GOAL.g:346:11: '%' (~ ( '\\n' | '\\r' ) )*
            {
            match('%'); 
            // GOAL.g:346:15: (~ ( '\\n' | '\\r' ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>='\u0000' && LA4_0<='\t')||(LA4_0>='\u000B' && LA4_0<='\f')||(LA4_0>='\u000E' && LA4_0<='\uFFFE')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // GOAL.g:346:16: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             skip(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end COMMENT

    // $ANTLR start STRING
    public final void mSTRING() throws RecognitionException {
        try {
            int _type = STRING;
            int string;

            // GOAL.g:349:8: ( '\"' (string= (~ ( '\\n' | '\\r' | '\"' ) ) )* '\"' )
            // GOAL.g:349:10: '\"' (string= (~ ( '\\n' | '\\r' | '\"' ) ) )* '\"'
            {
            match('\"'); 
            // GOAL.g:349:20: (string= (~ ( '\\n' | '\\r' | '\"' ) ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='\u0000' && LA5_0<='\t')||(LA5_0>='\u000B' && LA5_0<='\f')||(LA5_0>='\u000E' && LA5_0<='!')||(LA5_0>='#' && LA5_0<='\uFFFE')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // GOAL.g:349:20: string= (~ ( '\\n' | '\\r' | '\"' ) )
            	    {
            	    // GOAL.g:349:21: (~ ( '\\n' | '\\r' | '\"' ) )
            	    // GOAL.g:349:22: ~ ( '\\n' | '\\r' | '\"' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            match('\"'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end STRING

    // $ANTLR start WS
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            // GOAL.g:351:7: ( ( ' ' | '\\t' | '\\f' | ( '\\r' | '\\n' ) )+ )
            // GOAL.g:351:11: ( ' ' | '\\t' | '\\f' | ( '\\r' | '\\n' ) )+
            {
            // GOAL.g:351:11: ( ' ' | '\\t' | '\\f' | ( '\\r' | '\\n' ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='\t' && LA6_0<='\n')||(LA6_0>='\f' && LA6_0<='\r')||LA6_0==' ') ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // GOAL.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

             skip(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end WS

    public void mTokens() throws RecognitionException {
        // GOAL.g:1:8: ( MAIN | IF | THEN | WHEN | DO | TRUE | FALSE | NEGATION | BELIEF | AGOAL | GOALA | GOAL | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | T35 | T36 | T37 | T38 | T39 | T40 | T41 | T42 | T43 | T44 | T45 | IDENT | INTEGER | LBRACKET | RBRACKET | DOT | COMMA | COLON | COMMENT | STRING | WS )
        int alt7=42;
        switch ( input.LA(1) ) {
        case 'm':
            {
            int LA7_1 = input.LA(2);

            if ( (LA7_1=='a') ) {
                int LA7_30 = input.LA(3);

                if ( (LA7_30=='i') ) {
                    int LA7_53 = input.LA(4);

                    if ( (LA7_53=='n') ) {
                        int LA7_77 = input.LA(5);

                        if ( (LA7_77=='$'||(LA7_77>='0' && LA7_77<='9')||(LA7_77>='A' && LA7_77<='Z')||LA7_77=='_'||(LA7_77>='a' && LA7_77<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=1;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'i':
            {
            switch ( input.LA(2) ) {
            case 'n':
                {
                switch ( input.LA(3) ) {
                case 'p':
                    {
                    int LA7_54 = input.LA(4);

                    if ( (LA7_54=='u') ) {
                        int LA7_78 = input.LA(5);

                        if ( (LA7_78=='t') ) {
                            int LA7_101 = input.LA(6);

                            if ( (LA7_101=='$'||(LA7_101>='0' && LA7_101<='9')||(LA7_101>='A' && LA7_101<='Z')||LA7_101=='_'||(LA7_101>='a' && LA7_101<='z')) ) {
                                alt7=33;
                            }
                            else {
                                alt7=20;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                    }
                    break;
                case 's':
                    {
                    int LA7_55 = input.LA(4);

                    if ( (LA7_55=='e') ) {
                        int LA7_79 = input.LA(5);

                        if ( (LA7_79=='r') ) {
                            int LA7_102 = input.LA(6);

                            if ( (LA7_102=='t') ) {
                                int LA7_123 = input.LA(7);

                                if ( (LA7_123=='$'||(LA7_123>='0' && LA7_123<='9')||(LA7_123>='A' && LA7_123<='Z')||LA7_123=='_'||(LA7_123>='a' && LA7_123<='z')) ) {
                                    alt7=33;
                                }
                                else {
                                    alt7=26;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                    }
                    break;
                default:
                    alt7=33;}

                }
                break;
            case 'f':
                {
                int LA7_32 = input.LA(3);

                if ( (LA7_32=='$'||(LA7_32>='0' && LA7_32<='9')||(LA7_32>='A' && LA7_32<='Z')||LA7_32=='_'||(LA7_32>='a' && LA7_32<='z')) ) {
                    alt7=33;
                }
                else {
                    alt7=2;}
                }
                break;
            default:
                alt7=33;}

            }
            break;
        case 't':
            {
            switch ( input.LA(2) ) {
            case 'r':
                {
                int LA7_33 = input.LA(3);

                if ( (LA7_33=='u') ) {
                    int LA7_57 = input.LA(4);

                    if ( (LA7_57=='e') ) {
                        int LA7_80 = input.LA(5);

                        if ( (LA7_80=='$'||(LA7_80>='0' && LA7_80<='9')||(LA7_80>='A' && LA7_80<='Z')||LA7_80=='_'||(LA7_80>='a' && LA7_80<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=6;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            case 'h':
                {
                int LA7_34 = input.LA(3);

                if ( (LA7_34=='e') ) {
                    int LA7_58 = input.LA(4);

                    if ( (LA7_58=='n') ) {
                        int LA7_81 = input.LA(5);

                        if ( (LA7_81=='$'||(LA7_81>='0' && LA7_81<='9')||(LA7_81>='A' && LA7_81<='Z')||LA7_81=='_'||(LA7_81>='a' && LA7_81<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=3;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            default:
                alt7=33;}

            }
            break;
        case 'w':
            {
            int LA7_4 = input.LA(2);

            if ( (LA7_4=='h') ) {
                int LA7_35 = input.LA(3);

                if ( (LA7_35=='e') ) {
                    int LA7_59 = input.LA(4);

                    if ( (LA7_59=='n') ) {
                        int LA7_82 = input.LA(5);

                        if ( (LA7_82=='$'||(LA7_82>='0' && LA7_82<='9')||(LA7_82>='A' && LA7_82<='Z')||LA7_82=='_'||(LA7_82>='a' && LA7_82<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=4;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'd':
            {
            switch ( input.LA(2) ) {
            case 'o':
                {
                int LA7_36 = input.LA(3);

                if ( (LA7_36=='$'||(LA7_36>='0' && LA7_36<='9')||(LA7_36>='A' && LA7_36<='Z')||LA7_36=='_'||(LA7_36>='a' && LA7_36<='z')) ) {
                    alt7=33;
                }
                else {
                    alt7=5;}
                }
                break;
            case 'r':
                {
                int LA7_37 = input.LA(3);

                if ( (LA7_37=='o') ) {
                    int LA7_61 = input.LA(4);

                    if ( (LA7_61=='p') ) {
                        int LA7_83 = input.LA(5);

                        if ( (LA7_83=='$'||(LA7_83>='0' && LA7_83<='9')||(LA7_83>='A' && LA7_83<='Z')||LA7_83=='_'||(LA7_83>='a' && LA7_83<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=25;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            case 'e':
                {
                int LA7_38 = input.LA(3);

                if ( (LA7_38=='l') ) {
                    int LA7_62 = input.LA(4);

                    if ( (LA7_62=='e') ) {
                        int LA7_84 = input.LA(5);

                        if ( (LA7_84=='t') ) {
                            int LA7_107 = input.LA(6);

                            if ( (LA7_107=='e') ) {
                                int LA7_124 = input.LA(7);

                                if ( (LA7_124=='$'||(LA7_124>='0' && LA7_124<='9')||(LA7_124>='A' && LA7_124<='Z')||LA7_124=='_'||(LA7_124>='a' && LA7_124<='z')) ) {
                                    alt7=33;
                                }
                                else {
                                    alt7=27;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            default:
                alt7=33;}

            }
            break;
        case 'f':
            {
            int LA7_6 = input.LA(2);

            if ( (LA7_6=='a') ) {
                int LA7_39 = input.LA(3);

                if ( (LA7_39=='l') ) {
                    int LA7_63 = input.LA(4);

                    if ( (LA7_63=='s') ) {
                        int LA7_85 = input.LA(5);

                        if ( (LA7_85=='e') ) {
                            int LA7_108 = input.LA(6);

                            if ( (LA7_108=='$'||(LA7_108>='0' && LA7_108<='9')||(LA7_108>='A' && LA7_108<='Z')||LA7_108=='_'||(LA7_108>='a' && LA7_108<='z')) ) {
                                alt7=33;
                            }
                            else {
                                alt7=7;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'n':
            {
            int LA7_7 = input.LA(2);

            if ( (LA7_7=='o') ) {
                int LA7_40 = input.LA(3);

                if ( (LA7_40=='t') ) {
                    int LA7_64 = input.LA(4);

                    if ( (LA7_64=='$'||(LA7_64>='0' && LA7_64<='9')||(LA7_64>='A' && LA7_64<='Z')||LA7_64=='_'||(LA7_64>='a' && LA7_64<='z')) ) {
                        alt7=33;
                    }
                    else {
                        alt7=8;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'b':
            {
            int LA7_8 = input.LA(2);

            if ( (LA7_8=='e') ) {
                int LA7_41 = input.LA(3);

                if ( (LA7_41=='l') ) {
                    switch ( input.LA(4) ) {
                    case 'i':
                        {
                        int LA7_87 = input.LA(5);

                        if ( (LA7_87=='e') ) {
                            int LA7_109 = input.LA(6);

                            if ( (LA7_109=='f') ) {
                                int LA7_126 = input.LA(7);

                                if ( (LA7_126=='s') ) {
                                    int LA7_137 = input.LA(8);

                                    if ( (LA7_137=='$'||(LA7_137>='0' && LA7_137<='9')||(LA7_137>='A' && LA7_137<='Z')||LA7_137=='_'||(LA7_137>='a' && LA7_137<='z')) ) {
                                        alt7=33;
                                    }
                                    else {
                                        alt7=16;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                        }
                        break;
                    case '$':
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                    case 'A':
                    case 'B':
                    case 'C':
                    case 'D':
                    case 'E':
                    case 'F':
                    case 'G':
                    case 'H':
                    case 'I':
                    case 'J':
                    case 'K':
                    case 'L':
                    case 'M':
                    case 'N':
                    case 'O':
                    case 'P':
                    case 'Q':
                    case 'R':
                    case 'S':
                    case 'T':
                    case 'U':
                    case 'V':
                    case 'W':
                    case 'X':
                    case 'Y':
                    case 'Z':
                    case '_':
                    case 'a':
                    case 'b':
                    case 'c':
                    case 'd':
                    case 'e':
                    case 'f':
                    case 'g':
                    case 'h':
                    case 'j':
                    case 'k':
                    case 'l':
                    case 'm':
                    case 'n':
                    case 'o':
                    case 'p':
                    case 'q':
                    case 'r':
                    case 's':
                    case 't':
                    case 'u':
                    case 'v':
                    case 'w':
                    case 'x':
                    case 'y':
                    case 'z':
                        {
                        alt7=33;
                        }
                        break;
                    default:
                        alt7=9;}

                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'a':
            {
            switch ( input.LA(2) ) {
            case '-':
                {
                alt7=10;
                }
                break;
            case 'd':
                {
                int LA7_43 = input.LA(3);

                if ( (LA7_43=='o') ) {
                    int LA7_66 = input.LA(4);

                    if ( (LA7_66=='p') ) {
                        int LA7_89 = input.LA(5);

                        if ( (LA7_89=='t') ) {
                            int LA7_110 = input.LA(6);

                            if ( (LA7_110=='$'||(LA7_110>='0' && LA7_110<='9')||(LA7_110>='A' && LA7_110<='Z')||LA7_110=='_'||(LA7_110>='a' && LA7_110<='z')) ) {
                                alt7=33;
                            }
                            else {
                                alt7=24;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            case 'c':
                {
                int LA7_44 = input.LA(3);

                if ( (LA7_44=='t') ) {
                    int LA7_67 = input.LA(4);

                    if ( (LA7_67=='i') ) {
                        int LA7_90 = input.LA(5);

                        if ( (LA7_90=='o') ) {
                            int LA7_111 = input.LA(6);

                            if ( (LA7_111=='n') ) {
                                int LA7_128 = input.LA(7);

                                if ( (LA7_128=='s') ) {
                                    int LA7_138 = input.LA(8);

                                    if ( (LA7_138=='p') ) {
                                        int LA7_145 = input.LA(9);

                                        if ( (LA7_145=='e') ) {
                                            int LA7_151 = input.LA(10);

                                            if ( (LA7_151=='c') ) {
                                                int LA7_154 = input.LA(11);

                                                if ( (LA7_154=='$'||(LA7_154>='0' && LA7_154<='9')||(LA7_154>='A' && LA7_154<='Z')||LA7_154=='_'||(LA7_154>='a' && LA7_154<='z')) ) {
                                                    alt7=33;
                                                }
                                                else {
                                                    alt7=21;}
                                            }
                                            else {
                                                alt7=33;}
                                        }
                                        else {
                                            alt7=33;}
                                    }
                                    else {
                                        alt7=33;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            default:
                alt7=33;}

            }
            break;
        case 'g':
            {
            int LA7_10 = input.LA(2);

            if ( (LA7_10=='o') ) {
                int LA7_45 = input.LA(3);

                if ( (LA7_45=='a') ) {
                    int LA7_68 = input.LA(4);

                    if ( (LA7_68=='l') ) {
                        switch ( input.LA(5) ) {
                        case 's':
                            {
                            int LA7_112 = input.LA(6);

                            if ( (LA7_112=='$'||(LA7_112>='0' && LA7_112<='9')||(LA7_112>='A' && LA7_112<='Z')||LA7_112=='_'||(LA7_112>='a' && LA7_112<='z')) ) {
                                alt7=33;
                            }
                            else {
                                alt7=17;}
                            }
                            break;
                        case '-':
                            {
                            alt7=11;
                            }
                            break;
                        case '$':
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                        case 'A':
                        case 'B':
                        case 'C':
                        case 'D':
                        case 'E':
                        case 'F':
                        case 'G':
                        case 'H':
                        case 'I':
                        case 'J':
                        case 'K':
                        case 'L':
                        case 'M':
                        case 'N':
                        case 'O':
                        case 'P':
                        case 'Q':
                        case 'R':
                        case 'S':
                        case 'T':
                        case 'U':
                        case 'V':
                        case 'W':
                        case 'X':
                        case 'Y':
                        case 'Z':
                        case '_':
                        case 'a':
                        case 'b':
                        case 'c':
                        case 'd':
                        case 'e':
                        case 'f':
                        case 'g':
                        case 'h':
                        case 'i':
                        case 'j':
                        case 'k':
                        case 'l':
                        case 'm':
                        case 'n':
                        case 'o':
                        case 'p':
                        case 'q':
                        case 'r':
                        case 't':
                        case 'u':
                        case 'v':
                        case 'w':
                        case 'x':
                        case 'y':
                        case 'z':
                            {
                            alt7=33;
                            }
                            break;
                        default:
                            alt7=12;}

                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case '{':
            {
            alt7=13;
            }
            break;
        case '}':
            {
            alt7=14;
            }
            break;
        case 'k':
            {
            int LA7_13 = input.LA(2);

            if ( (LA7_13=='n') ) {
                int LA7_46 = input.LA(3);

                if ( (LA7_46=='o') ) {
                    int LA7_69 = input.LA(4);

                    if ( (LA7_69=='w') ) {
                        int LA7_92 = input.LA(5);

                        if ( (LA7_92=='l') ) {
                            int LA7_115 = input.LA(6);

                            if ( (LA7_115=='e') ) {
                                int LA7_130 = input.LA(7);

                                if ( (LA7_130=='d') ) {
                                    int LA7_139 = input.LA(8);

                                    if ( (LA7_139=='g') ) {
                                        int LA7_146 = input.LA(9);

                                        if ( (LA7_146=='e') ) {
                                            int LA7_152 = input.LA(10);

                                            if ( (LA7_152=='$'||(LA7_152>='0' && LA7_152<='9')||(LA7_152>='A' && LA7_152<='Z')||LA7_152=='_'||(LA7_152>='a' && LA7_152<='z')) ) {
                                                alt7=33;
                                            }
                                            else {
                                                alt7=15;}
                                        }
                                        else {
                                            alt7=33;}
                                    }
                                    else {
                                        alt7=33;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'p':
            {
            switch ( input.LA(2) ) {
            case 'o':
                {
                int LA7_47 = input.LA(3);

                if ( (LA7_47=='s') ) {
                    int LA7_70 = input.LA(4);

                    if ( (LA7_70=='t') ) {
                        int LA7_93 = input.LA(5);

                        if ( (LA7_93=='$'||(LA7_93>='0' && LA7_93<='9')||(LA7_93>='A' && LA7_93<='Z')||LA7_93=='_'||(LA7_93>='a' && LA7_93<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=23;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            case 'e':
                {
                int LA7_48 = input.LA(3);

                if ( (LA7_48=='r') ) {
                    int LA7_71 = input.LA(4);

                    if ( (LA7_71=='c') ) {
                        int LA7_94 = input.LA(5);

                        if ( (LA7_94=='e') ) {
                            int LA7_117 = input.LA(6);

                            if ( (LA7_117=='p') ) {
                                int LA7_131 = input.LA(7);

                                if ( (LA7_131=='t') ) {
                                    int LA7_140 = input.LA(8);

                                    if ( (LA7_140=='r') ) {
                                        int LA7_147 = input.LA(9);

                                        if ( (LA7_147=='u') ) {
                                            int LA7_153 = input.LA(10);

                                            if ( (LA7_153=='l') ) {
                                                int LA7_156 = input.LA(11);

                                                if ( (LA7_156=='e') ) {
                                                    int LA7_158 = input.LA(12);

                                                    if ( (LA7_158=='s') ) {
                                                        int LA7_159 = input.LA(13);

                                                        if ( (LA7_159=='$'||(LA7_159>='0' && LA7_159<='9')||(LA7_159>='A' && LA7_159<='Z')||LA7_159=='_'||(LA7_159>='a' && LA7_159<='z')) ) {
                                                            alt7=33;
                                                        }
                                                        else {
                                                            alt7=19;}
                                                    }
                                                    else {
                                                        alt7=33;}
                                                }
                                                else {
                                                    alt7=33;}
                                            }
                                            else {
                                                alt7=33;}
                                        }
                                        else {
                                            alt7=33;}
                                    }
                                    else {
                                        alt7=33;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
                }
                break;
            case 'r':
                {
                switch ( input.LA(3) ) {
                case 'o':
                    {
                    int LA7_72 = input.LA(4);

                    if ( (LA7_72=='g') ) {
                        int LA7_95 = input.LA(5);

                        if ( (LA7_95=='r') ) {
                            int LA7_118 = input.LA(6);

                            if ( (LA7_118=='a') ) {
                                int LA7_132 = input.LA(7);

                                if ( (LA7_132=='m') ) {
                                    int LA7_141 = input.LA(8);

                                    if ( (LA7_141=='$'||(LA7_141>='0' && LA7_141<='9')||(LA7_141>='A' && LA7_141<='Z')||LA7_141=='_'||(LA7_141>='a' && LA7_141<='z')) ) {
                                        alt7=33;
                                    }
                                    else {
                                        alt7=18;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                    }
                    break;
                case 'e':
                    {
                    int LA7_73 = input.LA(4);

                    if ( (LA7_73=='$'||(LA7_73>='0' && LA7_73<='9')||(LA7_73>='A' && LA7_73<='Z')||LA7_73=='_'||(LA7_73>='a' && LA7_73<='z')) ) {
                        alt7=33;
                    }
                    else {
                        alt7=22;}
                    }
                    break;
                default:
                    alt7=33;}

                }
                break;
            default:
                alt7=33;}

            }
            break;
        case 's':
            {
            int LA7_15 = input.LA(2);

            if ( (LA7_15=='e') ) {
                int LA7_50 = input.LA(3);

                if ( (LA7_50=='n') ) {
                    int LA7_74 = input.LA(4);

                    if ( (LA7_74=='d') ) {
                        int LA7_97 = input.LA(5);

                        if ( (LA7_97=='$'||(LA7_97>='0' && LA7_97<='9')||(LA7_97>='A' && LA7_97<='Z')||LA7_97=='_'||(LA7_97>='a' && LA7_97<='z')) ) {
                            alt7=33;
                        }
                        else {
                            alt7=28;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case '#':
            {
            alt7=29;
            }
            break;
        case 'u':
            {
            int LA7_17 = input.LA(2);

            if ( (LA7_17=='t') ) {
                int LA7_51 = input.LA(3);

                if ( (LA7_51=='i') ) {
                    int LA7_75 = input.LA(4);

                    if ( (LA7_75=='l') ) {
                        int LA7_98 = input.LA(5);

                        if ( (LA7_98=='i') ) {
                            int LA7_120 = input.LA(6);

                            if ( (LA7_120=='t') ) {
                                int LA7_133 = input.LA(7);

                                if ( (LA7_133=='y') ) {
                                    int LA7_142 = input.LA(8);

                                    if ( (LA7_142=='$'||(LA7_142>='0' && LA7_142<='9')||(LA7_142>='A' && LA7_142<='Z')||LA7_142=='_'||(LA7_142>='a' && LA7_142<='z')) ) {
                                        alt7=33;
                                    }
                                    else {
                                        alt7=30;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case 'h':
            {
            int LA7_18 = input.LA(2);

            if ( (LA7_18=='o') ) {
                int LA7_52 = input.LA(3);

                if ( (LA7_52=='r') ) {
                    int LA7_76 = input.LA(4);

                    if ( (LA7_76=='i') ) {
                        int LA7_99 = input.LA(5);

                        if ( (LA7_99=='z') ) {
                            int LA7_121 = input.LA(6);

                            if ( (LA7_121=='o') ) {
                                int LA7_134 = input.LA(7);

                                if ( (LA7_134=='n') ) {
                                    int LA7_143 = input.LA(8);

                                    if ( (LA7_143=='$'||(LA7_143>='0' && LA7_143<='9')||(LA7_143>='A' && LA7_143<='Z')||LA7_143=='_'||(LA7_143>='a' && LA7_143<='z')) ) {
                                        alt7=33;
                                    }
                                    else {
                                        alt7=31;}
                                }
                                else {
                                    alt7=33;}
                            }
                            else {
                                alt7=33;}
                        }
                        else {
                            alt7=33;}
                    }
                    else {
                        alt7=33;}
                }
                else {
                    alt7=33;}
            }
            else {
                alt7=33;}
            }
            break;
        case '=':
            {
            alt7=32;
            }
            break;
        case '$':
        case 'A':
        case 'B':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
        case 'G':
        case 'H':
        case 'I':
        case 'J':
        case 'K':
        case 'L':
        case 'M':
        case 'N':
        case 'O':
        case 'P':
        case 'Q':
        case 'R':
        case 'S':
        case 'T':
        case 'U':
        case 'V':
        case 'W':
        case 'X':
        case 'Y':
        case 'Z':
        case '_':
        case 'c':
        case 'e':
        case 'j':
        case 'l':
        case 'o':
        case 'q':
        case 'r':
        case 'v':
        case 'x':
        case 'y':
        case 'z':
            {
            alt7=33;
            }
            break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            {
            alt7=34;
            }
            break;
        case '(':
            {
            alt7=35;
            }
            break;
        case ')':
            {
            alt7=36;
            }
            break;
        case '.':
            {
            alt7=37;
            }
            break;
        case ',':
            {
            alt7=38;
            }
            break;
        case ':':
            {
            alt7=39;
            }
            break;
        case '%':
            {
            alt7=40;
            }
            break;
        case '\"':
            {
            alt7=41;
            }
            break;
        case '\t':
        case '\n':
        case '\f':
        case '\r':
        case ' ':
            {
            alt7=42;
            }
            break;
        default:
            NoViableAltException nvae =
                new NoViableAltException("1:1: Tokens : ( MAIN | IF | THEN | WHEN | DO | TRUE | FALSE | NEGATION | BELIEF | AGOAL | GOALA | GOAL | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | T35 | T36 | T37 | T38 | T39 | T40 | T41 | T42 | T43 | T44 | T45 | IDENT | INTEGER | LBRACKET | RBRACKET | DOT | COMMA | COLON | COMMENT | STRING | WS );", 7, 0, input);

            throw nvae;
        }

        switch (alt7) {
            case 1 :
                // GOAL.g:1:10: MAIN
                {
                mMAIN(); 

                }
                break;
            case 2 :
                // GOAL.g:1:15: IF
                {
                mIF(); 

                }
                break;
            case 3 :
                // GOAL.g:1:18: THEN
                {
                mTHEN(); 

                }
                break;
            case 4 :
                // GOAL.g:1:23: WHEN
                {
                mWHEN(); 

                }
                break;
            case 5 :
                // GOAL.g:1:28: DO
                {
                mDO(); 

                }
                break;
            case 6 :
                // GOAL.g:1:31: TRUE
                {
                mTRUE(); 

                }
                break;
            case 7 :
                // GOAL.g:1:36: FALSE
                {
                mFALSE(); 

                }
                break;
            case 8 :
                // GOAL.g:1:42: NEGATION
                {
                mNEGATION(); 

                }
                break;
            case 9 :
                // GOAL.g:1:51: BELIEF
                {
                mBELIEF(); 

                }
                break;
            case 10 :
                // GOAL.g:1:58: AGOAL
                {
                mAGOAL(); 

                }
                break;
            case 11 :
                // GOAL.g:1:64: GOALA
                {
                mGOALA(); 

                }
                break;
            case 12 :
                // GOAL.g:1:70: GOAL
                {
                mGOAL(); 

                }
                break;
            case 13 :
                // GOAL.g:1:75: T26
                {
                mT26(); 

                }
                break;
            case 14 :
                // GOAL.g:1:79: T27
                {
                mT27(); 

                }
                break;
            case 15 :
                // GOAL.g:1:83: T28
                {
                mT28(); 

                }
                break;
            case 16 :
                // GOAL.g:1:87: T29
                {
                mT29(); 

                }
                break;
            case 17 :
                // GOAL.g:1:91: T30
                {
                mT30(); 

                }
                break;
            case 18 :
                // GOAL.g:1:95: T31
                {
                mT31(); 

                }
                break;
            case 19 :
                // GOAL.g:1:99: T32
                {
                mT32(); 

                }
                break;
            case 20 :
                // GOAL.g:1:103: T33
                {
                mT33(); 

                }
                break;
            case 21 :
                // GOAL.g:1:107: T34
                {
                mT34(); 

                }
                break;
            case 22 :
                // GOAL.g:1:111: T35
                {
                mT35(); 

                }
                break;
            case 23 :
                // GOAL.g:1:115: T36
                {
                mT36(); 

                }
                break;
            case 24 :
                // GOAL.g:1:119: T37
                {
                mT37(); 

                }
                break;
            case 25 :
                // GOAL.g:1:123: T38
                {
                mT38(); 

                }
                break;
            case 26 :
                // GOAL.g:1:127: T39
                {
                mT39(); 

                }
                break;
            case 27 :
                // GOAL.g:1:131: T40
                {
                mT40(); 

                }
                break;
            case 28 :
                // GOAL.g:1:135: T41
                {
                mT41(); 

                }
                break;
            case 29 :
                // GOAL.g:1:139: T42
                {
                mT42(); 

                }
                break;
            case 30 :
                // GOAL.g:1:143: T43
                {
                mT43(); 

                }
                break;
            case 31 :
                // GOAL.g:1:147: T44
                {
                mT44(); 

                }
                break;
            case 32 :
                // GOAL.g:1:151: T45
                {
                mT45(); 

                }
                break;
            case 33 :
                // GOAL.g:1:155: IDENT
                {
                mIDENT(); 

                }
                break;
            case 34 :
                // GOAL.g:1:161: INTEGER
                {
                mINTEGER(); 

                }
                break;
            case 35 :
                // GOAL.g:1:169: LBRACKET
                {
                mLBRACKET(); 

                }
                break;
            case 36 :
                // GOAL.g:1:178: RBRACKET
                {
                mRBRACKET(); 

                }
                break;
            case 37 :
                // GOAL.g:1:187: DOT
                {
                mDOT(); 

                }
                break;
            case 38 :
                // GOAL.g:1:191: COMMA
                {
                mCOMMA(); 

                }
                break;
            case 39 :
                // GOAL.g:1:197: COLON
                {
                mCOLON(); 

                }
                break;
            case 40 :
                // GOAL.g:1:203: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 41 :
                // GOAL.g:1:211: STRING
                {
                mSTRING(); 

                }
                break;
            case 42 :
                // GOAL.g:1:218: WS
                {
                mWS(); 

                }
                break;

        }

    }


 

}