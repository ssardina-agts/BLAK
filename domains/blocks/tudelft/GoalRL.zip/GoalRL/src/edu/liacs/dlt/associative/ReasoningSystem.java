 /*
 * ReasoningSystem.java
 *
 * Created on August 5, 2002, 9:45 PM
 */

/**
 *
 * @author  Administrator
 * @version 
 */
package edu.liacs.dlt.associative;
import edu.liacs.dlt.associative.utils.*;


public class ReasoningSystem {
    /** Creates new ReasoningSystem */
	public ReasoningSystem() {
    }

    
    public Tree getActionList(Network memory)
    {   //This method sums up the weighted collective reward values for all equal associated actions in all next interactions
        //that fire. Therefore every different action only appears ones in the final action list.
        //this is plausible if we assume the interactions inhibit and excite actions, thereby promoting certain actions while penalizing others.
    	//The result of such process is a list of weighted actions, which is the result of this method.
        Node candidateNode=null;
        Tree parent=new Tree("root", 0);
        
        for (int i=0;i<memory.nodesFired.size;i++)
        {   
        	Node n=memory.nodesFired.elementAt(i);
            NodeVector choices=n.getAllChoices();
            //calculate the total 
            double total=0.0;
            for (int j=0;j<choices.size;j++)
            {   candidateNode=choices.elementAt(j);
                if (candidateNode.getHypothesis().value!=null)
                    total+=candidateNode.getUsage();
            }

            for (int j=0;j<choices.size;j++)
            {   candidateNode=choices.elementAt(j);
                if (candidateNode.getHypothesis().value!=null)
                {   Tree curEvent=parent.get(candidateNode.getHypothesis().value.substring(0, 1));
                    if (curEvent==null)
                    {   //weighted reward using getUsage
                        curEvent=new Tree(candidateNode.getHypothesis().value.substring(0,1), (candidateNode.getValue()*(candidateNode.getUsage()/total)));
                        curEvent.occur+=(candidateNode.getUsage()/total);
                        //unweighted reward
                        //curEvent=new Tree(candidateNode.getHypothesis().value, (candidateNode.avgHormoneLevel));
                        //curEvent.occur++; 
                        parent.addChild(curEvent);
                    } else
                    {   
                        //weighted reward using getUsage()
                        curEvent.value+=(candidateNode.getValue()*(candidateNode.getUsage()/total));
                        curEvent.occur+=(candidateNode.getUsage()/total);
                        //unweighted reward
                        //curEvent.occur++;
                        //curEvent.value+=(candidateNode.avgHormoneLevel);
                    }
                } else
                {   System.out.println("Error: hypothesis no simple node/event");
                }
            }
        }
        //first calculate the total of the support for all actions
        //and construct the final weighted support for the individual actions by dividing the total weighted reward 
        //by the total found support. This is correct because to create a weighted support we have to first
        //calculate the sum over all n interactions that prepare a certain action x x_sum_n(x_reward_i*x_support_i) and then divide
        //this by the total support found for action x x_sum_n(x_support_i).
        //Since a weighted avg over a vector x is always of the form x1*w1+...+xn*wn/(w1+...+wn)
        //x_sum_n(x_support_i)=occur.
        //support_i= candidateNode.getUsage()/total = relative support for an action by one interaction, 
        //reward_i=candidateNode.avgHormoneLevel*support_i = relative reward.
        for (int i=0;i<parent.getBranching();i++) 
        {   //Since value is summed over all conditional occurences, the total support for 
        	//the actions is not normalized anymore (e.g. if 10 active interactrons predict the same action with the 
        	//same reward of 0.5 with the same chance of 0.5, the total support=0.5*0.5*10=2.5
        	//however, if one interactions predicts another action with chance 1 and reward 1, support=1
        	//the first action is worst than the second, so the second should be favored. So, we have
        	//to divide the value (cumulative reward) by the total occurence to re-normalize the value 
            parent.getChild(i).value/=parent.getChild(i).occur;
        }
        //Now return the action list
        return parent; 
    }
    
    public Tree getInteractionList(Network memory)
    {   //This method sums up the weighted collective reward values for all equal associated interactions in all nodes
        //that fire. Therefore every different interactions (in contrast to action as in the getActionList() method only appears ones in the final interaction list.
        //this is needed to create a list of interactions to imagine. Interactions are senory-motor contingies, and therefore the 
    	//element of simulation. Actions are only motor outputs, thus not the element of simulation by themselves.
        //for further notes see previous method
    	Node candidateNode=null;
        Tree parent=new Tree("root", 0);
        
        
        for (int i=0;i<memory.nodesFired.size;i++)
        {   
        	Node n=memory.nodesFired.elementAt(i);
            NodeVector choices=n.getAllChoices();
            //calculate the total 
            double total=0.0;
            for (int j=0;j<choices.size;j++)
            {   candidateNode=choices.elementAt(j);
                if (candidateNode.getHypothesis().value!=null)
                    total+=candidateNode.getUsage();
            }

            for (int j=0;j<choices.size;j++)
            {   candidateNode=choices.elementAt(j);
                if (candidateNode.getHypothesis().value!=null)
                {   Tree curEvent=parent.get(candidateNode.getHypothesis().value);
                    if (curEvent==null)
                    {   //weighted reward using getUsage
                        curEvent=new Tree(candidateNode.getHypothesis().value, (candidateNode.getValue()*(candidateNode.getUsage()/total)));
                        curEvent.occur+=(candidateNode.getUsage()/total);
                        //unweighted reward
                        //curEvent=new Tree(candidateNode.getHypothesis().value, (candidateNode.avgHormoneLevel));
                        //curEvent.occur++; 
                        parent.addChild(curEvent);
                    } else
                    {   
                        //weighted reward using getUsage()
                        curEvent.value+=(candidateNode.getValue()*(candidateNode.getUsage()/total));
                        curEvent.occur+=(candidateNode.getUsage()/total);
                        //unweighted reward
                        //curEvent.occur++;
                        //curEvent.value+=(candidateNode.avgHormoneLevel);
                    }
                } else
                {   System.out.println("Error: hypothesis no simple node/event");
                }
            }
        }
        for (int i=0;i<parent.getBranching();i++) 
        {   parent.getChild(i).value/=parent.getChild(i).occur;
        }
        return parent; 
    }
    
    private void restoreNetwork(NodeVector oldNodesFired, NodeVector oldNodesActive, Node firingInputNode, Network memory, double oldHormoneLevel, int oldTime)
    {   //Restore network must be called after each simulated event !!!
    	//important, must clone the vector since the oldVectors are used multiple times for backup.
    	//first restore the firestamp of all simulated nodes to the firestamp before simulation 
    	//this is needed for consistent usage active() etc.. of the nodes 
        for (int i=0;i<memory.nodesFired.size;i++)
            (memory.nodesFired.elementAt(i)).resetSimulationFirestamp();
        //then restore the old nodesFired list and all the rest of the network state
        memory.nodesFired=(NodeVector)oldNodesFired.clone();
        memory.firingInputNode=firingInputNode;
        memory.currentHormoneLevel=oldHormoneLevel;
        memory.nodesActive=(NodeVector)oldNodesActive.clone();
        memory.time=oldTime;
    }
   
}
