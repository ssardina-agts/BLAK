/*
 * Tree.java
 *
 * Created on August 11, 2002, 8:48 PM
 */

/**
 *
 * @author  Administrator
 * @version
 */
package edu.liacs.dlt.associative.utils;
import java.util.*;

public class Tree {
	//an event tree
    public Vector childs;
    public String event;
    public double value;
    public double occur=0;
    /** Creates new Tree */
    public Tree(String e, double v) {
        childs=new Vector();
        value=v;
        event=e;
    }
    public void addChild(Tree t)
    {   childs.addElement(t);
    }
    public Tree getChild(int i)
    {   return (Tree)childs.elementAt(i);
    }
    public void deleteChild(int i)
    {   childs.remove(i);
    }
    public void deleteChild(Tree t)
    {   childs.remove(t);
    }
    public String print(int level)
    {   String result=event+":"+value+":"+occur+"\n";
        String indent="";
        for (int i=0;i<level;i++)
            indent+="  | ";
        indent+="  |-";
        for (int i=0;i<childs.size();i++)
        {   result+=indent+getChild(i).print(level+1)+"";
        }
        return result;
    }
    public int getBranching()
    {   return childs.size();
    }
    
    public Tree get(String e)
    {	for (int i=0;i<childs.size();i++)
        {	if (((Tree)childs.elementAt(i)).event.equals(e))
                    return (Tree)childs.elementAt(i);
                    //return ((Tree)childs.elementAt(i)).value;
        }
        return null;
    }
    public Tree getBest(){
    	Tree bestChild=null;
		for (int i=0;i<childs.size();i++)
        {	if (bestChild==null || ((Tree)childs.elementAt(i)).value>bestChild.value)
        		bestChild=(Tree)childs.elementAt(i);
        }
        return bestChild;
    }
    public String toString()
    {   return event+":"+value;
    }
    
    public void smartAdd(Tree t){
    	//merges this tree with Tree t such that:
    	//an event at depth 0 in t is copied to this if and only there is no 
    	//event in t with the same <event> filed.
    	//else (there is an event), the new <value> of such event in t 
    	//is merged with the <value> of the event by addition.
    	for (int i=0;i<t.getBranching();i++){
        	Tree temp=t.getChild(i);
        	Tree lt=get(temp.event);
        	if (lt==null){//event in t not found in this --> add the event to this
        		addChild(new Tree(temp.event, temp.value));
        	} else {//event found in this, merge the valuesvalue of t event to this event
        		lt.value+=temp.value;
        	}
        }
    }
    public void filter(Tree eventsMask){
    	//removes all events from this Tree that are not part of the set of events in filterMask
    	for (int i=0;i<getBranching();i++){
    		if (eventsMask.get(getChild(i).event)==null){
    			deleteChild(i);
    		}
    	}
    }
}
