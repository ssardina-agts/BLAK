/*
 * MyVector.java
 *
 * Created on January 28, 2005, 12:04 PM
 */

package edu.liacs.dlt.associative.utils;

import edu.liacs.dlt.associative.Node;
/**
 *
 * @author  broekens
 */
public class NodeVector {
    public int size, max, startMax;
    protected Node[] data;
    /** Creates a new instance of MyVector */
    public NodeVector(int capacity) {
        max=capacity;
        startMax=max;
        this.size=0;
        data=new Node[max];
    }
    public NodeVector() {
        max=20;
        startMax=max;
        this.size=0;
        data=new Node[max];
    }
    public Node elementAt(int index)
    {   if (index<size)
            return data[index];
        else
            return null;
    }
    public Node firstElement()
    {   if (size>0)
            return data[0];
        else
            return null;
    }
    public void addElementStatic(Node n)
    {   data[size++]=n;
    }
    public void addElement(Node n)
    {   if (size<max)
            data[size++]=n;
        else
        {   Node[] dataTemp=new Node[max*2];
            System.arraycopy(data,0,dataTemp,0,max);
            data=dataTemp;
            max=max*2;
            data[size++]=n;
        }
    }
    public boolean removeElement(Object n)
    {   int i=0;
        while (i<size && data[i]!=n)
            i++;
        if (i!=size){
            System.arraycopy(data, i+1, data, i, size-i-1);
            size--;
            return true;
        }
        else
            return false;
    }
    public boolean removeElementAt(int i)
    {   if (i<size){
            System.arraycopy(data, i+1, data, i, size-i-1);
            size--;
            return true;
        } else
            return false;
    }
    public boolean contains(Object n)
    {   int i=0;
        while (i<size && data[i]!=n)
            i++;
        return (i!=size);
    }
    public Object clone()
    {   NodeVector target=new NodeVector(max);
        System.arraycopy(data, 0, target.data, 0, size);
        target.size=size;
        target.startMax=startMax;
        return target;
    }
    public void clear()
    {   data=new Node[startMax];
        size=0;
        max=startMax;
    }
    
    public String toString()
    {   String result="";
        for (int i=0;i<size;i++)
            result+=data[i].toString()+"\n";
        return result;
    }
}
