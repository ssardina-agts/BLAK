package edu.liacs.dlt.associative;

public class Constants{
    
	public static boolean BASIC_MDP_LEARNING=true;
	public static boolean EXTENDED_SARSA_LEARNING=false; //if false R_Rate is used as alfa
	
    //Cycle penalty constants
    public static boolean USE_CYCLE_DETECTION=false;
    public static double CYCLE_PENALTY=-1.0;
    //the decay per step used for CYCLE_PENALTY
    public static double CYCLE_DECAY=.5;
    
    //to toggle eligibility traces
    public static boolean USE_DECAY_REINFORCEMENT=false;
    public static double DECAY_REINFORCEMENT_RATE=0.5; //eligibility fall_off
    public static int DECAY_PERIOD=10;//maximum of 10 steps trace length!
    
    //to toggle imagination on or off (0=no imagination, 1 is one step ahead, 2 is two steps etc)
    public static int IMAGINE=0;
    //the percentage of possible interactions used for simulation
    //(minimum interactions is always 1 when IMAGINE_WTA=0)
    //unused when DYNAMIC_SIM_INFLUENCE=true 
    public static double IMAGINE_WTA=0;
    //the maximum influence of imagined interactions (1=full influence (as if the simulated interaction was actullay perceived), 0=no influence)
    //on the value of next interactions (see code in updateHormoneLevel in Class Node)
    //set this value <1 to prevent simultaion being evalutated as important as real interaction
    public static double MAX_IMAGINATION_INFLUENCE=0.9;
    //to toggle actual learning based on simulation (thus a simulation state-value at t+1 changes the actual state-value at t following normal learning (thus MAX_IMAGINATION_INFLUENCE has no effect here))
    public static boolean IMAGINATION_LEARNING=false;
    
    //to toggle on or off dynamic selection of imagined interactions 
    //dynamic selection means that number of simulated interactions
    //(thus the value IMAGE_WTA is unused) is determined by a
    //metaparameter (imaginationInfluence) calculated from the agent's affect 
    public static boolean DYNAMIC_SIM_INFLUENCE=false;
    //to toggle on or off dynamic selection of action (action-selection) 
    //dynamic selection means that Boltzmann selection  is changed acroding to the ranges below and 
    //a metaparameter (imaginationInfluence) calculated from the agent's affect 
    public static boolean DYNAMIC_SELECTION_INFLUENCE=false;
//  a noise parameter to avoid getting into chaotic beta behavior when no changes occur in the environment
    public static boolean USE_NOISE_IN_DYNAMIC=false;
    public static double NOISE_FACTOR=0.1;//the average reward noise factor
    public static boolean DEFAULT_PLEASURE_TO_ZERO=true;//if true the pleasure variables runing averages ltar and star at 0, else they build up.
    //the range of values used for dynamic Boltzmann selection.
    public static double DYNAMIC_SELECTION_MIN=3;
    public static double DYNAMIC_SELECTION_MAX=9;

    //different forms of affect (and imaginationInfluence) calculation
    //toggle between posaffect-exploit versus poasaffect-explore 
    //if true then overwrite and ignore INTENSITY_BASED_DYN_SIM setting
    public static boolean INVERSE_DYN=false;
    //choose to use dynamic influence of affect based on the intensity of the emotion
    //thus: if pos then simulate a lot, if neg then simulta a lot if neutral then simulate less (best).
    public static boolean INTENSITY_BASED_DYN_SIM=false;
    //to inverse previous setting (i.e., pos and neg simulate little, while neutral simulates a lot)
    public static boolean INVERSE_INTENSITY=false;
    //used in ExperimentRunner to define if a strategy change (forced INVERSE_DYN halfway experient) is allowed
    public static boolean ALLOW_STRATEGY_CHANGE=false;
    //Not a parameter !!, used during execution by Animal and ExperimentRunner  to keep track if strategy has been switched
    public static boolean CHANGE_STRAT=false; 
    //toggle use of suprise to set affect to min value (0) when an unexpected reward is found
    public static boolean SURPISE_SWITCH_EXPLORE=false;
    //when true, only set affect to min value if unexpected reward is more negative (and SURPISE_SWITCH_EXPLORE==true)
    public static boolean NEGATIVE_SURPIRISE_ONLY=false;
    //settings to define the behavior of affect based on history
    public static int TASK_AVG_SAMPLE_SIZE=50;
    public static int ENVIRONMENT_AVG_SAMPLE_SIZE=375;
    public static double STDRANGE=1;
    //sets affect randomly, instead of based on the history 
    //Result: action-selection and simulation-selection use a random dynamic value 
    public static boolean RANDOM_AFFECT=false;
    public static double RANDOM_AFFECT_MEAN=.5;
    //end settings relevant to DYNAMIC_SIM_INFLUENCE=true or DYNAMIC_SELECTION_INFLUENCE=true
    
    //Learning rate and forgetting parameters
    public static double RATE=1; 
    public static double R_RATE=1;//R_Rate is the rate used for R(s) and non-extended sarsa learning
    //discount factor
    public static double DISCOUNT=0.9;
    //set this to true if training the memory must be based on a discounted sum of rewards insteda of the
    //real reward received at t. So the actual reward is ar=ar*R_DISCOUNT+r
    public static boolean USE_DISCOUNTED_REWARD_FOR_TRAINING=false;
    public static double R_DISCOUNT=0.5;
    //if relative usage of a node is below this value, the node is forgotten (deleted)
    //EXTINCTION_THRESHOLD=0 means no forgetting ( as the relative usage of node is never below 0, 1 means forget everything) 
    public static double EXTINCTION_THRESHOLD=0;
    public static double USAGE_DECAY=0.99;
    public static boolean USE_USAGE=true;
    public static boolean USE_PROB_CORRECT_USAGE=true;//the deafult up until ICML
}