/*
 * Normalize.java
 *
 * Created on December 6, 2004, 5:07 PM
 */

package edu.liacs.dlt.associative.utils;

/**
 *
 * @author  broekens
 */
public class Normalize {
    double sum, squaredDiffSum, mean, var, std, minMean, maxMean, min, max;
    int counter, size;
    /** Creates a new instance of Normalize */
    public Normalize(int initialSampleSize) {
        size=initialSampleSize;
        sum=0;
        squaredDiffSum=0;
        counter=0;
        mean=0;
        var=0;
        std=0;
        minMean=0;
        maxMean=0;
    }
    
    public void addSample(double x)
    {   counter++;
        buildNormalDistribution(x);
        if (x<min)
            min=x;
        else if (x>max)
            max=x;
    }
    
    public double getMean()
    {   return mean;
    }
    public void setMean(double m)
    {   //this function sets the mean to m,
    	//but keeps the current running variance (in squaredDiffSum)
    	//as this class keeps track of a running average, we have to assume the 
    	//sum=m*size (window size times the new m) and
    	//we have to set the counter to size;
    	mean=m;
    	sum=mean*size;
    	counter=size+1;
    }
    public void setVar(double v)
    {   //this function sets the variance to v,
    	//but keeps the current running mean (in sum)
    	//as this class keeps track of a running average, we have to assume the 
    	//squaredDiffSum=*size (window size times the new m) and
    	//we have to set the counter to size;
    	var=v;
    	squaredDiffSum=var*(size-1);
    	counter=size+1;
    }
    public double getVar()
    {   return var;
    }
    
    public double getStd()
    {   return std;
    }
    public double getMinMean()
    {   return minMean;
    }
    public double getMaxMean()
    {   return maxMean;
    }
    public double getMin()
    {   return min;
    }
    public double getMax()
    {   return max;
    }
    public boolean isIn(double v, double stdrange)
    {   return (v>(mean-stdrange*std) & v< (mean+stdrange*std));
    }
    public boolean isSmaller(double v, double stdrange)
    {   return v<(mean-stdrange*std);
    }
    public boolean isLarger(double v, double stdrange)
    {   return v>(mean+stdrange*std);
    }
    private void buildNormalDistribution(double x)
    {   if (counter==0){
            mean=0;
            var=0;
        } else
        {   if (counter<=size)//mathematically correct mean and var 
        	{	sum+=x;
        		mean=sum/counter;
        		squaredDiffSum+=(Math.pow(x-mean, 2));
        		if (counter==1)
        			var=0;
        		else
        			var=squaredDiffSum/(counter-1);
        	} else	//running estimate of mean and var 
        	{
        		sum=sum-mean+x;
        		mean=sum/size;
        		squaredDiffSum=squaredDiffSum-(squaredDiffSum/size)+Math.pow(x-mean,2);
        		var=squaredDiffSum/(size-1);
        	}
            std=Math.sqrt(var);
        }
        if (mean<minMean)
            minMean=mean;
        if (mean>maxMean)
            maxMean=mean;
    }
   
}
