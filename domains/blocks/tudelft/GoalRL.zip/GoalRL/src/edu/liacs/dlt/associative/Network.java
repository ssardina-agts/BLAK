package edu.liacs.dlt.associative;
import edu.liacs.dlt.associative.utils.*;

public class Network
{   public NodeVector nodes;
    public NodeVector inputNodes; 

    public int maxLayer;
    
    protected boolean imagining=false;
    public boolean surprised; 
    
    //state of the network is backed-up during simulation
    public NodeVector simulatedNodes;
    public NodeVector nodesFired;
    public Node firingInputNode;
    public NodeVector nodesActive;
    protected NodeVector newNodesFired;
    //The time is a counter used to record the total amount of events entered into the memory
    //in fact it is the triggeredCounter for the network i.s.o. for the Node
    protected int time=0;
    //end state
    
    protected double currentHormoneLevel;//used by all nodes to read the current hormonal values
    
    private int max;
    
    public Network(int maxSize, int maxL, int maxHormones)
    {   simulatedNodes=new NodeVector();
        nodes=new NodeVector(maxSize);
        inputNodes=new NodeVector();
        nodesFired=new NodeVector();
        newNodesFired=new NodeVector();
        nodesActive=new NodeVector();
        max=maxSize;
        maxLayer=maxL;
        currentHormoneLevel=0.0;
        System.out.print(" Creating network max:"+max+":"+maxLayer);
    }
    public Network(int maxSize, int maxL)
    {   simulatedNodes=new NodeVector();
        nodes=new NodeVector(maxSize);
        inputNodes=new NodeVector();
        nodesFired=new NodeVector();
        newNodesFired=new NodeVector();
        nodesActive=new NodeVector();
        max=maxSize;
        maxLayer=maxL;
        currentHormoneLevel=0.0;
        System.out.println(" Creating network max:"+max+":"+maxLayer);
    }
    public void train(String value, double hormoneLevel, double scaledAvgReinforcement)
    {   currentHormoneLevel=hormoneLevel;
        time++;
        input(value, true, scaledAvgReinforcement);
    }
    
    
    public void input(String value, boolean train, double scaledAvgReinforcement)
    {   boolean triggered=false, first=true;
        if (Constants.BASIC_MDP_LEARNING && maxLayer!=1){
    		System.out.println("Error: cannot use higher order MDPs (ASSOCIATION_LENGTH!=2) together with BASIC_MDP_LEARNING");
    		System.exit(0);
    	}
        //clear the newNodesFired vector and trigger all input nodes
        newNodesFired=new NodeVector();
        for (int i=0;i<inputNodes.size;i++)
        {   triggered|=(inputNodes.elementAt(i)).trigger(value, train, null);
            if (triggered==true && first)
            {
                firingInputNode=(inputNodes.elementAt(i));
                first=false;
            }
        }
        if (!triggered)
        {   //no input node triggered so create a new one, trigger it and add it to the inputNodes vector
            //node starts at layer=0
        	if (!train)
                System.out.println("error: no simple node exists for event:"+value);
            else
            {   Node dumNode=new Node(value, this, 0);
                inputNodes.addElement(dumNode);
                dumNode.trigger(value, train, null);
                firingInputNode=dumNode;
            }
        }
        //if we receive a reinforcemtn that is very different from the expected one, we are "surprised"
        if ((!Constants.NEGATIVE_SURPIRISE_ONLY && imagining==false && triggered && Math.abs(firingInputNode.directReinforcement-currentHormoneLevel)>0) ||
        		(Constants.NEGATIVE_SURPIRISE_ONLY && imagining==false && triggered && firingInputNode.directReinforcement-currentHormoneLevel>0)){
        	surprised=true;
        }
        	

//      copy the new firing nodes to the nodesFired vector so that the next round we have all new conditions
        //defined in nodesFired
        //we also check if there are active nodes that need to be copied to te nodesFired.
        //this is done to allow decay, note that if Constants.DECAY_PERIOD==1, this function just copies newNodesFired to nodesFired
        //because the .isActive() functions returs fales for all nodes that are not currently triggered (active)
        //This is the same behaviour as if there is no decay.
        NodeVector oldNodesActive=nodesActive;
        nodesFired=newNodesFired;
        nodesActive=(NodeVector)newNodesFired.clone();
        
        
        //update the list of activated nodes (nodes of which the values will be updated through learning)
        //(active nodes are those nodes activated at t-1, t-2, etc..., t-DECAY_PERIOD)
        if (Constants.USE_DECAY_REINFORCEMENT){
            for (int i=0;i<oldNodesActive.size;i++)
            {   if ((oldNodesActive.elementAt(i)).isActive() & !nodesActive.contains(oldNodesActive.elementAt(i)))
                {   nodesActive.addElement(oldNodesActive.elementAt(i));
                }
            }
        }
        //mark all active nodes with the current reinforcement value, except when simultaing
        //When simulating (and learning while simulating is off),
        //adapt only those nodes that fired (not the ones that are still active as eligibility trace)
        //Thus, sim has an effect for current and future nodes, not past ones,
        //i.e. no eligibility learning while simulating.
        if (train){ //only when actually training will any change in the values be done, so no effect of sim without training either
	       if (imagining & !Constants.IMAGINATION_LEARNING){
		       for (int i=0;i<nodesFired.size;i++)
			          (nodesFired.elementAt(i)).updateHormoneLevel(currentHormoneLevel, scaledAvgReinforcement);
	    	   
	       } else{
		       for (int i=0;i<nodesActive.size;i++)
		          (nodesActive.elementAt(i)).updateHormoneLevel(currentHormoneLevel, scaledAvgReinforcement);
	       }
	       
	       //before processing the nodes and the network the next time, determine which nodes should be deleted!!
	       //Delete nodes that aren't used (relative probability of occurence<extinction_threshold)
	       //only delete if not simulating and if the nodes are predicted by firing nodes.
	       //this effectively removes all influence from the node before further processing.
	       if (!imagining & Constants.EXTINCTION_THRESHOLD>0){
	           for (int i=0;i<nodesFired.size;i++)
	           {   NodeVector temp=nodesFired.elementAt(i).getAllChoices();
	               double total=0;
	               
	               for (int j=0;j<temp.size;j++)
	               {	total+=temp.elementAt(j).getRelativeFireCounter();
	               }
	               for (int j=0;j<temp.size;j++)
	               {	temp.elementAt(j).extinct(total);
	               }
	           }
	       }
        }
    }
    
    public void resetSimulation()
    {   //reset the avgHormnoneLevel and imagineAvgHormoneLevel of all nodes in the simulatedNodes vector to their
        //original values. This is needed to get clean effect of simulations.
        for (int i=0;i<simulatedNodes.size;i++)
            simulatedNodes.elementAt(i).resetSimulation();
        simulatedNodes.clear();
    }
    
    
    public void reset()
    {   nodesFired.clear();
        nodesActive.clear();
        newNodesFired.clear();
        if (Constants.USE_CYCLE_DETECTION)
        {
            for (int i=0;i<nodes.size;i++)
                (nodes.elementAt(i)).reset();
        }
    }

    public double freeCapacity()
    {   return (double)nodes.size/(double)max;
    }
    
    public void addNode(Node n)
    {   if (nodes.size<max)
            nodes.addElementStatic(n);
        else
        {   //need to fix this. This is very slow!
            double minUsage=Double.POSITIVE_INFINITY;//the highest usage number never attainable by any node
            int minNode=0;
            for (int i=0;i<nodes.size;i++)
            {   Node dum=(nodes.elementAt(i));
                if (dum.getRelativeFireCounter()<minUsage & dum.layer>1) 
                {   //throw away the least used node
                    minNode=i;
                    minUsage=(nodes.elementAt(i)).getRelativeFireCounter();//lower minFitness to match this node's fitness
                }
            }
            //remove the node with the lowest fitness.
            removeNode(nodes.elementAt(minNode));
            nodes.addElementStatic(n);
        }
    }
    public boolean removeNode(Node n)
    {   //attempt to remove node n from the network but only if the layer > 1, the most primitive interactions are never thrown away
        if (n.layer>=0){
            nodes.removeElement(n);
            nodesActive.removeElement(n);
            if (inputNodes.contains(n))
            {
                System.out.println("Error, attempting to delete an input node");
                System.exit(0);
            }

            //detach node n from the structure recursively
            //System.out.print("r");
            n.delete();
            return true;
        } else
            return false;
    }
    
    public String printState(){
        String result="currentHormoneLevel="+currentHormoneLevel;
        result+=": imagining="+imagining;
        result+=": time="+time;
        result+="\nFired Nodes:\n";
        for (int i=0;i<nodesFired.size;i++)
        {   Node n=nodesFired.elementAt(i);
            result+="\n+"+n.toString();
            result+="\n|";
            NodeVector choices=n.getAllChoices();
            for (int j=0;j<choices.size;j++)
            {   result+=("\n|--"+(choices.elementAt(j)).toString());
            }
            
        }
        return result;
    }
}