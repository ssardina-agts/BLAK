/*
 * MyVector.java
 *
 * Created on January 28, 2005, 12:04 PM
 */

package edu.liacs.dlt.associative.utils;
/**
 *
 * @author  broekens
 */
public class floatVector {
    public int size, max, startMax;
    protected float[] data;
    /** Creates a new instance of MyVector */
    public floatVector(int capacity) {
        max=capacity;
        startMax=max;
        this.size=0;
        data=new float[max];
    }
    public floatVector() {
        max=20;
        startMax=max;
        this.size=0;
        data=new float[max];
    }
    public float elementAt(int index)
    {   if (index<size)
            return data[index];
        else
            return Float.NaN;
    }
    public float firstElement()
    {   if (size>0)
            return data[0];
        else
        	return Float.NaN;
    }
    public void addElementStatic(float n)
    {   data[size++]=n;
    }
    public void addElement(float n)
    {   if (size<max)
            data[size++]=n;
        else
        {   float[] dataTemp=new float[max*2];
            System.arraycopy(data,0,dataTemp,0,max);
            data=dataTemp;
            max=max*2;
            data[size++]=n;
        }
    }
    public boolean removeElement(float n)
    {   int i=0;
        while (i<size && data[i]!=n)
            i++;
        if (i!=size){
            System.arraycopy(data, i+1, data, i, size-i-1);
            size--;
            return true;
        }
        else
            return false;
    }
    public boolean removeElementAt(int i)
    {   if (i<size){
            System.arraycopy(data, i+1, data, i, size-i-1);
            size--;
            return true;
        } else
            return false;
    }
    public boolean contains(float n)
    {   int i=0;
        while (i<size && data[i]!=n)
            i++;
        return (i!=size);
    }
    public Object clone()
    {   NodeVector target=new NodeVector(max);
        System.arraycopy(data, 0, target.data, 0, size);
        target.size=size;
        target.startMax=startMax;
        return target;
    }
    public void clear()
    {   data=new float[startMax];
        size=0;
        max=startMax;
    }
    
    public String toString(String separator)
    {   String result="";
        for (int i=0;i<size;i++)
            result+=data[i]+separator;
        return result;
    }
}
