package edu.liacs.dlt.associative;
import edu.liacs.dlt.associative.utils.*;

public class Node {
    //Network this node is in
    private Network myNet;
    //this node's value (null if inference node)
    public String value;
    //this node's hierarchical layer in the network (always smaller than Network.maxLayer)
    public int layer;
    //Connections to and from other nodes
    private NodeVector connectionsIn;
    private NodeVector connectionsOut;
    
    //stats for this node usage
    private double timeAtCreation;//the time of the network when this node was created (used to define usage, and age of the node)
    private double fireCounter;//the number of times this node was active
    private double usage;//the usage counter (if usage is not defined by USE_PROB_CORRECT_USAGE)
    
    //cycle checking variables
    private double lastPeriod=0.0;
    private int lastTotal=0;
    private int lastPenaltyTime=0;
    
    //values used by this node
    public double realAvgHormoneLevel=0.0;//the real averaged hormone level for all triggers,(combination of throwse local and the sum of its children)
    public double directReinforcement=0.0;
    private double indirectReinforcement=0.0;
    public double imagineAvgHormoneLevel=0.0;
    private double imaginationReinforcement=0.0;
    private double imaginationIndirectReinforcement=0.0;
    
    private double cyclePenaltyValue=0.0;//the penalty counter for cycling through the same events.
    
    //used to store the activity of the s1 (hypothesis) node at the moment of the creation of this interaction node
    //necessary to implement node decay
    protected int lastFireStamp=0;
    private int oldLastFireStamp;
    
    public Node(String val, Network net, int la)
    {   connectionsIn=new NodeVector();
        connectionsOut=new NodeVector();
        if (val==null)
            value=null;
        else
            value=new String(val);
        
        myNet=net;
        timeAtCreation=net.time-1;//start at a usage of 100%
        fireCounter=1;
        usage=0;
        
        layer=la;
        if (layer>myNet.maxLayer) {
            System.out.println("Error: node above max layer");
            System.exit(0);
        }
        //a new node is automatically  added to the network
        net.addNode(this);
    }
    public void reset()//only used if we are using complex nodes (not supported for now)
    {   lastPeriod=0.0;
        lastTotal=0;
    }
    public void addNodeIn(Node n)
    {   connectionsIn.addElement(n);
    }
    public void addNodeOut(Node n)
    {   connectionsOut.addElement(n);
    }
    public boolean isLogicalLink(Node n) //assumes that n fired at t-1 (is in myNet.nodesFired)
    {   //Checks if n is already linked to this i.e. n in nodesFired and tempNode Elem(connOut) in myNet.newNodesFired
        boolean result=false;
        for (int i=0;i<connectionsOut.size;i++)
        {   Node tempNode=connectionsOut.elementAt(i);
            result= result || (myNet.newNodesFired.contains(tempNode) & tempNode.connectionsIn.contains(n));
        }
        return result;
    }
    private void internalAddNodeIn(Node n)
    {   connectionsIn.addElement(n);
        n.addNodeOut(this);
    }
    private void internalAddNodeOut(Node n)
    {   connectionsOut.addElement(n);
        n.addNodeIn(this);
    }
    public void resetSimulation()
    {   imagineAvgHormoneLevel=realAvgHormoneLevel;
        imaginationReinforcement=directReinforcement;
        
    }
    public double getValue(){
    	if (myNet.imagining)
    		return imagineAvgHormoneLevel+getCyclePenalty();
    	else
    		return realAvgHormoneLevel+getCyclePenalty();
    }
    public void updateHormoneLevelIndirect(){
    	updateHormoneLevel(directReinforcement, 0);
    }
    public void updateHormoneLevel(double hormoneLevel, double imaginationInfluence) {   
        //Adapt the avgHormone level based on new hormone level and the avgHormone levels of all associated next events.
        double total=0.0, sum=0.0, goal;
        NodeVector temp;
        if (layer==0) return;
        
        if (Constants.EXTENDED_SARSA_LEARNING){//xxx must understand the effect of usage if sarsa is used!!! Converges but much slower
        	//get either a next state based on a longer history prediction (n-MPD; if any available)
        	//or (history too long or no state available) the next 1-MDP state.
        	if (this.layer==myNet.maxLayer){
        		temp=getHypothesis().getAllChoices();
        	} else{
        		temp=getAllChoices();
        		if (temp.size==0)
        			temp=getHypothesis().getAllChoices();
        	}
        	//learn using sarsa, but use probabilistic state predictions
        	//and learn a model of r(s) separately from v(s)
        	//for comments see later
        	if (myNet.imagining && !Constants.IMAGINATION_LEARNING){
    		    myNet.simulatedNodes.addElement(this);
	            for (int i=0;i<temp.size;i++)
	            {	total+=temp.elementAt(i).getUsage();
	            }
	            for (int i=0;i<temp.size;i++)
	            {	sum+=((temp.elementAt(i).getUsage()/total)*temp.elementAt(i).imagineAvgHormoneLevel);//use the real hormone level (without the cycle penalty of the tempNode)
	            }
	
	            //set the new reinforcement values
	            imaginationReinforcement=imaginationReinforcement+imaginationInfluence*Constants.R_RATE*getR_Eligibility()*(hormoneLevel-imaginationReinforcement);
	            imaginationIndirectReinforcement=imaginationIndirectReinforcement+imaginationInfluence*Constants.RATE*getEligibility()*(Constants.DISCOUNT*sum-imaginationIndirectReinforcement);
	            imagineAvgHormoneLevel=imaginationReinforcement+imaginationIndirectReinforcement;
	            
	            if (imagineAvgHormoneLevel>Math.max(imaginationIndirectReinforcement, imaginationReinforcement))//if we need to increase, our top value will be max(hormoneLevel, sum)
	            	imagineAvgHormoneLevel=Math.max(imaginationIndirectReinforcement, imaginationReinforcement);
	            else if (imagineAvgHormoneLevel<Math.min(imaginationIndirectReinforcement, imaginationReinforcement))//if we need to decrease, our bottom will be min(hormoneLevel, sum)
	            	imagineAvgHormoneLevel=Math.min(imaginationIndirectReinforcement, imaginationReinforcement);
	        } else
	        {
	            
	            for (int i=0;i<temp.size;i++)
	            {	total+=temp.elementAt(i).getUsage();
	            }
	            for (int i=0;i<temp.size;i++)
	            {	sum+=((temp.elementAt(i).getUsage()/total)*temp.elementAt(i).realAvgHormoneLevel);//use the real hormone level (without the cycle penalty of the tempNode)
	            }
	
//	          set the new reinforcement values
	            directReinforcement=directReinforcement+Constants.R_RATE*getR_Eligibility()*(hormoneLevel-directReinforcement);
	            indirectReinforcement=indirectReinforcement+Constants.RATE*getEligibility()*(Constants.DISCOUNT*sum-indirectReinforcement);
	            realAvgHormoneLevel=directReinforcement+indirectReinforcement;
	            
	            if (realAvgHormoneLevel>Math.max(indirectReinforcement, directReinforcement))//if we need to increase, our top value will be max(hormoneLevel, sum)
	            	realAvgHormoneLevel=Math.max(indirectReinforcement, directReinforcement);
	            else if (realAvgHormoneLevel<Math.min(indirectReinforcement, directReinforcement))//if we need to decrease, our bottom will be min(hormoneLevel, sum)
	            	realAvgHormoneLevel=Math.min(indirectReinforcement, directReinforcement);
	            
	            
	            //copy to the imagine values for correct imagination (learning)
	            imagineAvgHormoneLevel=realAvgHormoneLevel;
	            imaginationIndirectReinforcement=indirectReinforcement;
	            imaginationReinforcement=directReinforcement;
	            
	        }
        } else{
	        	if (Constants.BASIC_MDP_LEARNING){
	        	//this is a classical form of MDP learning that updates the values of 
	        	//states v(s) according to (1) the reinforcement of state s, r(s), and
	        	//(2) predcited learned values of next possible states v(s') as follows:
	        	//e(s)=e(s)+lambda(WEIGHTED_SUM(v(s'1),...,v(s'n))-e(s))
	        	//v(s)=r(s)+i(s)
	        	//where i(s) is the learned (e)stimated value of v(s')
	        	//so:
	        	//instead of getting all possible next states up the hierarchy (as in; BKV, 2006)
	        	//get all poss. next states based just on the current stimulus,
	        	//thus go back to the stimulus (state) that this node predicts, and retreive all
	        	//states that taht state predicts
	        	temp=getHypothesis().getAllChoices();
	        } else {
	//        	this is the hierarchical learning model as described in (Broekens, Kosters, Verbeek, 2006)
	        	//it uses only higher order interactions between states to predict the value of the current state.
	        	//this does mean that propagation of values is restricted in the reinforcement delay such that:
	        	//reinforcements can only be propagated back ASSOCIATION_LENGTH steps. 
	            	temp=getAllChoices();
	        }
	        
	    	if (myNet.imagining && !Constants.IMAGINATION_LEARNING){
	            myNet.simulatedNodes.addElement(this);
	            for (int i=0;i<temp.size;i++)
	            {	total+=temp.elementAt(i).getUsage();
	            }
	            for (int i=0;i<temp.size;i++)
	            {	sum+=((temp.elementAt(i).getUsage()/total)*temp.elementAt(i).imagineAvgHormoneLevel);//use the real hormone level (without the cycle penalty of the tempNode)
	            }
	
	            //adapt the direct reinforcement signal using the learning rate.
	            imaginationReinforcement=(hormoneLevel-imaginationReinforcement)*Constants.R_RATE*getEligibility()+imaginationReinforcement;
	            
	            //now add the directReinforcement to the implicit reinforcement (the sum).
	            goal=imaginationReinforcement+(sum*Constants.DISCOUNT);
	
	            //our goal is the reinforcement value for this node combined with the average of all its direct children.
	            //however, since the sum could become larger than both the avg of the children and the value for this node
	            //this heuristic will deliver an ever increasing (or decreasing) value. (since the previous node will convert to sum_p+sum+hormoneLevel --> is not bounded)
	            //therefore the next check is done to "top_off" the goal value in the positive or negative range.
	            //this is plausible since we can assume that exhibition of a "pleasure centre" can never be more than full exhibition.
	
	            if (goal>Math.max(sum, imaginationReinforcement))//if we need to increase, our top value will be max(hormoneLevel, sum)
	                goal=Math.max(sum, imaginationReinforcement);
	            else if (goal<Math.min(sum, imaginationReinforcement))//if we need to decrease, our bottom will be min(hormoneLevel, sum)
	                goal=Math.min(sum, imaginationReinforcement);
	            
	            //adapt the imagineAvgHormoneLevel according to the scaledAvgReinforcement [0,1] of the agent, based on the same function
	            //as the one in the ReasoingSystem for imagination.
	            
	            imagineAvgHormoneLevel=(goal-imagineAvgHormoneLevel)*imaginationInfluence+imagineAvgHormoneLevel;
	        } else
	        {
	            
	            for (int i=0;i<temp.size;i++)
	            {	total+=temp.elementAt(i).getUsage();
	            }
	            for (int i=0;i<temp.size;i++)
	            {	sum+=((temp.elementAt(i).getUsage()/total)*temp.elementAt(i).realAvgHormoneLevel);//use the real hormone level (without the cycle penalty of the tempNode)
	            }
	
	            //adapt the direct reinforcement signal using the learning rate.
	            directReinforcement=(hormoneLevel-directReinforcement)*Constants.R_RATE*getEligibility()+directReinforcement;
	            
	            //now add the directReinforcement level to the implicit reinforcement (the sum).
	            goal=directReinforcement+(sum*Constants.DISCOUNT);
	
	            //our goal is the reinforcement value for this node combined with the average of all its direct children.
	            //however, since the sum could become larger than both the avg of the children and the value for this node
	            //this heuristic will deliver an ever increasing (or decreasing) value. (since the previous node will convert to sum_p+sum+hormoneLevel --> is not bounded)
	            //therefore the next check is done to "top_off" the goal value in the positive or negative range.
	            //this is plausible since we can assume that exhibition of a "pleasure centre" can never be more than full exhibition.
	
	            if (goal>Math.max(sum, directReinforcement))//if we need to increase, our top value will be max(hormoneLevel, sum)
	                goal=Math.max(sum, directReinforcement);
	            else if (goal<Math.min(sum, directReinforcement))//if we need to decrease, our bottom will be min(hormoneLevel, sum)
	                goal=Math.min(sum, directReinforcement);
	
	            realAvgHormoneLevel=goal;//always update our internal real hormone value.

	            //copy values for imagination
	            imaginationReinforcement=directReinforcement;
	        	imagineAvgHormoneLevel=realAvgHormoneLevel;
	            
	            
	        }
        }
    }
    private double getCyclePenalty(){
    	if (Constants.USE_CYCLE_DETECTION)
    		return cyclePenaltyValue*Math.pow(Constants.CYCLE_DECAY, myNet.time-lastPenaltyTime);// as used for ICML experiment (decays according to Constants.USAGE_DECAY)
    	else
    		return 0;
    }
    private void checkCycle()
    {   //Should be called every REAL (not simulated) time a node is activated
    	//A cycle is defined as follows:
    	//a node that is activated twice with the same period as interval.
    	//so: t1,t2,t3 with t2-t1=t3-t2
        //If this is the case, the probability of a cycle is high. We assume there is one
    	//and attribute a penalty to the value of this node to promote exploration
        if (!myNet.imagining && Constants.USE_CYCLE_DETECTION)
        {
            if (lastPeriod==myNet.time-lastTotal){
            	cyclePenaltyValue=getCyclePenalty()+Constants.CYCLE_PENALTY;
            	lastPenaltyTime=myNet.time;
            }
            lastPeriod=myNet.time-lastTotal;
            lastTotal=myNet.time;
        }
    } 
    public void resetSimulationFirestamp(){
    	lastFireStamp=oldLastFireStamp;
    }
    public boolean trigger(String val, boolean train, Node inputEvent)
    {   if (myNet.newNodesFired.contains(this)){
    		//each node can only be triggered once per time step.
    		//however, if a node is both the hypothesis and the condition of a refernec node (in non MDP environments)
    		//the triggering of connectionsOut that have <this> as hypothesis will trigger the same node twice.
    	 	//so we need to check this here and do nothing if triggered twice.
    		return false;
    	}
    	if (value!=null && val.equals(this.value)) {   //a trigger due to equality of content
            //set the time at which this node fires (used to define the activityTimestamp)
            if (myNet.imagining)//if we are simulating, store the old time this node was last triggered so that this can be restored after simultaion using the resetSimulationFirestamp() method 
            	oldLastFireStamp=lastFireStamp;
            lastFireStamp=myNet.time;
            
            //Add me to the new firing nodes.
            myNet.newNodesFired.addElement(this);    
            for (int i=0;i<connectionsOut.size;i++)//evaluate all reference nodes that have me as hypothesis.
            {   if ((connectionsOut.elementAt(i)).isHypothesis(this))
                {   (connectionsOut.elementAt(i)).trigger(null, train, this);
                }
            }
            if (train) {
                //eventually create new inferenced nodes (if they are not existing already) with me as hypo and the old firing nodes as condition
                
                if (!myNet.imagining){
                    connectFromFiredNodes();
                    fireCounter++;
                    usage=getUsage()+1;//add one to the old usage
                    //we are triggered and active, so we have to check
                	//if we are being activated in a cyclic way
                    checkCycle();
                }
                
            } 
            return true;
        } else if (val==null) {   //a trigger on an inferenced node
            if (layer>myNet.maxLayer) //meaning that we were part of a longer association string including "options" or merged nodes
            {   System.out.println("Debug: Error, 'node created with hierarchy larger than max:"+this.toString());
                System.exit(0);
            }
            if (connectionsIn.size>=2)
            {   if (myNet.nodesFired.contains(connectionsIn.elementAt(0)) && inputEvent==connectionsIn.elementAt(1))
                {   
                    //set the time at which this node fires (used to define the activityTimestamp)
	            	if (myNet.imagining)//if we are simulating, store the old time this node was last triggered so that this can be restored after simultaion using the resetSimulationFirestamp() method 
	                	oldLastFireStamp=lastFireStamp;
	                lastFireStamp=myNet.time;
                    //if my next condition fires (my hypothesis fires, because else I would not be invoked) 
                    //I too fire, so add me to the new firing nodes.
                    myNet.newNodesFired.addElement(this);    
                    
                    if (train & !myNet.imagining) {
                        fireCounter++;
                        usage=getUsage()+1;//add 1 to the old usage
                        //we are triggered and active, so we have to check
                    	//if we are being activated in a cyclic way
                        checkCycle();
                    } 
                }
            } else
            {   System.out.println("Debug: Error during trigger, 'inferenced node has illegal connectionsIn length, missing either a condition or a hypothesis' has occurred in node:"+this.toString());
                System.exit(0);
            }
            return true;
        } else//no trigger
            return false;
    }
    
    public double getUsage()
    {   //by deviding the absolute usage by the time of creation, we facilitate the use of novel knowledge
    	//i.e., myNet.time-timeAtCreation=1 and fireCounter=1 at creation,
    	//so e newly created node automatically has high usage, and therefore will 
    	//count heavily in the weighted sum to construct the back-prop value in learning.
    	if (Constants.USE_USAGE){
	    	if (Constants.USE_PROB_CORRECT_USAGE) //as used in all other experiments up until ICML
	    		return fireCounter/(myNet.time-timeAtCreation);
	    	else
	    		return usage*Math.pow(Constants.USAGE_DECAY, myNet.time-lastFireStamp);// as used for ICML experiment (decays according to Constants.USAGE_DECAY)
    	} else
    		return 1.0;
    }
    public double getRelativeFireCounter(){
    	return fireCounter/(myNet.time-timeAtCreation);
    }
    
    public void extinct(double total)
    {   //remove this node if it is used less then EXTINCTION_THRESHOLD relative to the other nodes
        if (getRelativeFireCounter()/total<Constants.EXTINCTION_THRESHOLD)
        {   myNet.removeNode(this);
        }
    }
    public boolean isActive()
    {   //used to determine if this node has been activated within the last DECAY_PERIOD
    	//of timesteps (used for USE_DECAY_INTERACTIONS, and USE_DECAY_REINFORCEMENT)
    	return lastFireStamp>(myNet.time-Constants.DECAY_PERIOD);
    }
    public double getR_Eligibility()
    {	//returns 1 if the state is currently active, 0 else
    	return (myNet.time==lastFireStamp?1:0);
    }
    public double getEligibility()
    {   //the activity function when decay is active
        //return exponential decay starting at 1 with rate DECAY_REINFORCEMENT_RATE
        return Math.pow(Constants.DECAY_REINFORCEMENT_RATE, myNet.time-lastFireStamp);
    }
    public void delete()
    {   //detach this node from all incomming nodes (and recursively delete those incomming nodes when they become obsolete in the structure)
        while (connectionsIn.size>0)
        {   Node temp=connectionsIn.firstElement();
            if (temp.removeEdge(this)==0) //if after removing the the edge to this node there are no outgoing edges are available result=0
                myNet.removeNode(temp); //no connectionsOut left in node temp thus delete temp
            connectionsIn.removeElementAt(0);
        }
        //delete all outgoing nodes recursively (which automatically detaches this node from them)
        while (connectionsOut.size>0)
        {   myNet.removeNode(connectionsOut.firstElement());
        } 
    }
    public int removeEdge(Node n)
    {   connectionsOut.removeElement(n);
        return connectionsOut.size;
    }
    private void connectFromFiredNodes() {   
        //connect all myNet.nodesFired to this node
        //but only if no link already exists.
        
        for (int i=0;i<myNet.nodesFired.size;i++)
        {   //System.out.println("nf:"+myNet.nodesFired.elementAt(i));
            if (!isLogicalLink(myNet.nodesFired.elementAt(i))) {
                createConnection(myNet.nodesFired.elementAt(i));
            }
        }
    }
    private void createConnection(Node n) {   
        //create a connection, link it and make a node with two
        //incomming connections first from myNet.nodesFired node and second from this.
        //System.out.println("connecting:"+n+" to "+this+":"+isLogicalLink(n));
        
        
        
        if (n.layer<myNet.maxLayer)//no connections are made if the association string would become longer than maxLayer
        {   Node dumNode=null;
            dumNode=new Node(null, myNet, n.layer+1);
            //connect n -> dumNode
            dumNode.internalAddNodeIn(n);
            //connect this -> dumNode
            internalAddNodeOut(dumNode);
            //force trigger only on the created nodes.
            //this is done because the created nodes have the trigger condition right i.e. their first
            //incomming node fired at t-1 and their second incomming node fires now
            //(this is true because they are only contructed if this is true)
            dumNode.trigger(null, true, this);
        }
    }
    public Node getHypothesis()
    {   //returns the current hypothesis for this node based on the last activated condition
        if (connectionsIn.size>=2) {
            if ((connectionsIn.elementAt(1)).value!=null)
                return (connectionsIn.elementAt(1));
            else {
                System.out.println("Debug: Error, 'hypothesis has null value' has occurred in node:"+this.toString());
                System.exit(0);
                return null;
            }
        } else
        {
            System.out.println("Debug: Error, 'inferenced node has no hypothesis' has occurred in node:"+this.toString());
            new Exception().printStackTrace();
            System.exit(0);
            return null;
        }
    }
    public boolean isHypothesis(Node n)
    {   //Node n is the next hypothesis of this node if it equals the next Node after the current activated condition
        return connectionsIn.elementAt(1)==n;
    }
    //the condition for a reference node = first node in vector (due to construction of ref nodes)
    public Node getCondition()
    {   if (connectionsIn.size>=2)
        {   return connectionsIn.elementAt(0);
        } else
        {   System.out.println("Debug: Error, 'inferenced node has illegal connectionsIn length, missing either a condition or a hypothesis' has occurred in node:"+this.toString());
            System.exit(0);
            return null;
        }
    }
    
    public String printAllChoices()
    {   String result="";
        NodeVector temp=getAllChoices();
        for (int i=0;i<temp.size;i++)
        {   result+=temp.elementAt(i).toString()+temp.elementAt(i).getUsage()+"\n      ";
        }
        return result;
    }
    public NodeVector getAllChoices()
    {   NodeVector result=new NodeVector();
        Node oldNode=null;
        for (int i=0;i<connectionsOut.size;i++)
        {   //a candidate associations is a node representing a connection,
            //with this node as condition.
            
            //dit klopt volgens mij niet, moet ook checken op node met inhoud node
            //Ja wel, pas op klopt wel node=connection
            
            //oldNode check: omdat bij twee keer zelfde node trigger achter elkaar,
            //twee connecties naar dezelfde inference node gemaakt worden vanuit dezelfde node.
            //geeft probleem bij bepaling total
            
            if (oldNode!=connectionsOut.elementAt(i) && connectionsOut.elementAt(i).value==null && connectionsOut.elementAt(i).getCondition()==this)
            {   result.addElement(connectionsOut.elementAt(i));
            }
            oldNode=connectionsOut.elementAt(i);
        }
        return result;
    }
    public String toString()
    {   if (value==null)
        {   if (connectionsIn.size<1)
            {   return "floating";
            } else if (connectionsIn.size==1)
            {   return "childOf:"+connectionsIn.elementAt(0).toString();
            } else
            {   String result;
                result="("+connectionsIn.elementAt(connectionsIn.size-1).toString()+", t="+getValue()+", r="+realAvgHormoneLevel+","+directReinforcement+","+indirectReinforcement+", s="+imagineAvgHormoneLevel+","+imaginationReinforcement+","+imaginationIndirectReinforcement+","+getUsage()+")"+"<-";
                result+=connectionsIn.elementAt(0).toString();
                /*for (int i=1;i<connectionsIn.size-1;i++)
                    result+="+"+(connectionsIn.elementAt(i)).toString();
                
                result+="->"+(connectionsIn.elementAt(connectionsIn.size-1)).toString();
                */
                return result;
            }
        } else
        {   return value;
        }
        
    }
}