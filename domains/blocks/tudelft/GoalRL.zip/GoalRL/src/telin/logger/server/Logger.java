package telin.logger.server;


import java.io.*;
import java.util.*;


public class Logger implements Runnable{
	static Vector eventStack;
	private Vector components;
	private static int FRAMERATE=20;
	private int msTrigger=5;
	
	
	public Logger(){
		eventStack=new Vector();
		components=new Vector();
		
	}
	
	public void setTriggerEffectSpeed(int milliseconds){
		msTrigger=20*milliseconds/1000;
		
	}
	public int getTicks(){
		//we use 1/4 of a second block activity
		return msTrigger;
	}
	public void handleEvent(String event){
		eventStack.add(event);
	}
	
	public void run(){
		while (true){
			while (eventStack.size()>0){
				StringTokenizer event;
				String eventString="null";
				try {
					eventString=(String)(eventStack.remove(0));
					event=new StringTokenizer(eventString, ";");
					processEvent(event.nextToken(), event.nextToken(), event.nextToken());
				} catch (Exception e){MonitorServer.out.appendText("\nError parsing event "+eventString+" in lightweight monitor server"); e.printStackTrace();}
			}
			try {Thread.sleep(1000/FRAMERATE);}
			catch (Exception e){MonitorServer.out.appendText("\nError sleeping in lightweight monitor"); e.printStackTrace();}
		}
	}
	private void processEvent(String componentId, String arg1, String arg2){
		MonitorServer.out.appendText("\nProcessing event from client:"+ componentId+" "+arg1+" "+arg2);
		//log the event to a file with as filename the componentId
		try {
			File f=new File("C:\\GoalRL\\"+componentId+".txt");
			RandomAccessFile raf=new RandomAccessFile(f, "rw");
			if (f.exists())
				raf.seek(f.length());
			raf.writeBytes(arg1+"\t"+arg2+"\r\n");
			raf.close();
		} catch (Exception e){
			MonitorServer.out.appendText("\n"+e.toString());
			e.printStackTrace();
		}
		
	}
}
