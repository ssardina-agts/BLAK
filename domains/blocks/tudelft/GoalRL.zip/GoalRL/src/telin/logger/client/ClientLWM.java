package telin.logger.client;


import java.awt.Frame;
import java.io.*;
import java.net.*;
import java.util.*;

public class ClientLWM extends Thread{
	
	//NOTE: only one lightweigth monitor server host can be used per ClientLWM at the moment.
	//As the ClientLWM is created as a static object,
	//this means that per Java Virtual Machine only one lightweight monitor server can be used.
	static Frame alert;
	
	private static ClientLWM me;
	private static final String defaultHost="noord.twi.tudelft.nl";
	
	private Socket socket;
	private DataOutputStream out;
	private String connectedHost;
	int port=8080;
	private Vector events;
	public static final String code="privatecode123";
	
	public static synchronized void sendEvent(String monitorHost, String componentName, String argument, String value){
		//first check if we have static reference to a lightweight client object
		//if not create one, and start the sending thread
		if (me==null){
			me = new ClientLWM();
			me.start();
		}
		//push the to be sent event onto the evtn stack, and return afterwards immediately so that no 
		//delay will be caused for the monitored code.
		me.pushEvent(monitorHost, componentName, argument, value);
		System.out.println("Client event received for sending.");
	}
	
	public static synchronized void sendEvent(String componentName, String argument, String value){
		//just route the call to sendEvent using the defaultHost for monitor server.
		sendEvent(defaultHost, componentName, argument, value);
	}
	
	private ClientLWM(){
		events=new Vector();
		System.out.println("ClientLWM generated");
	}
	
	private void pushEvent(String monitorHost, String componentName, String argument, String value){
		events.add(new ClientLWM.Event(monitorHost, componentName, argument, value));
	}
	
	public void run(){
		ClientLWM.Event e=null;
		while (true){
			try {
				if (events.size()>0){
					System.out.println(events.size());
					//we have events to be send to the monitor on the stack, so get the first and send it.
					e=(ClientLWM.Event)events.remove(0);
					//first check if the event is in the right format
					if (e.componentName==null || e.componentName.trim().equals("") || e.monitorHost==null || e.monitorHost.trim().equals(""))
					{
						System.out.println("Wrong message format: need lightweight monitor hostname AND component name as arguments for sending message to lightweight monitoring. Message not sent.");
						return;
					}
					if (e.argument==null || e.argument.trim().equals(""))
						e.argument="triggered";
					if (e.value==null || e.value.trim().equals(""))
						e.value="null";	
					
					
					
					//check if this Client is sending to the host to which it is connected, if not, generate an error and abort sending
					//only one host can be used per ClinetLWM at the moment.
					if (connectedHost==null || connectedHost.equals(e.monitorHost)){
						try {
//							send the event over the socket and keep the socket alive
							out.writeBytes(makeEvent(code, e.componentName, e.argument, e.value));
							out.flush();
							System.out.println("Client event sent to lightweight monitor");
						} catch (Exception e2){
							//sending failed, so recreate the socket and try to send again
							socket = new Socket(InetAddress.getByName(e.monitorHost), port);
							out= new DataOutputStream(socket.getOutputStream());
							connectedHost=e.monitorHost;
							System.out.println("Client lightweight monitor is connected to "+connectedHost);
//							again send the event over the socket and keep the socket alive
							out.writeBytes(makeEvent(code, e.componentName, e.argument, e.value));
							out.flush();
							System.out.println("Client event sent to lightweight monitor");
						}


					} else {
//						connectedHost is different from the host the event should be sent to: this is an error
						System.out.println("Client did not send event to lightweight monitor, connectedHost "+connectedHost+" is different from "+ e.monitorHost);
					}
					
				} else {
					//no events to be send to the monitor, so sleep a while.
					sleep(50);
				}
			} catch (Exception ev){
				System.out.println("Error: client could not send event to lightweight monitor: "+connectedHost); ev.printStackTrace(); if (e!=null) events.insertElementAt(e, 0);
				if (alert==null){
					alert=new Frame();
					alert.setBounds(400, 300, 400, 200);
					alert.setVisible(true);
				}
				alert.getGraphics().drawString("Error: do not continue, data cannot be send to server.", 50, 100);
				alert.getGraphics().drawString("Contact joost.broekens@gmail.com", 50, 130);
			}
		}
	}
	
	private String makeEvent(String code, String component, String arg, String val){
		return code+component+";"+arg+";"+val+"\n";
	}
	private class Event{
		public String monitorHost, componentName, argument, value;
		
		public Event(String monitorHost, String componentName, String argument, String value){
			this.monitorHost=monitorHost;
			this.componentName=componentName;
			this.argument=argument;
			this.value=value;
		}
	}
}
