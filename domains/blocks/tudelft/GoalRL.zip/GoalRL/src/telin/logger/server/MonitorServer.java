
package telin.logger.server;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;


public class MonitorServer extends Frame implements Runnable{
	Vector clientSockets;
	Logger vis;
	private int port;
	public static final int DEFAULT_PORT=8080;
	public static TextArea out;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Logger s=createMonitorServer();
	}
	public MonitorServer(int port, Logger vis){
		clientSockets=new Vector();
		this.vis=vis;
		this.port=port;
		setVisible(true);
		setBounds(0, 0, 600, 200);
		addWindowListener(new VisListener());
		out=new TextArea();
		out.setBounds(5,20,590,180);
		this.add(out);
	}
	public void run(){
		MonitorServer.out.appendText("\nLightweight monitor is creating listener at port "+port);
		ServerSocket listener=null, listener2;
		try{
			listener=new ServerSocket(port);
		} catch (Exception e){MonitorServer.out.appendText("\nError opening serversocket for lightweight monitor"); e.printStackTrace();}
		MonitorServer.out.appendText("\nLightweight monitor is listening for clients at "+listener.getInetAddress()+":"+listener.getLocalPort());
		while (listener!=null && !listener.isClosed()){
			try {clientSockets.add(new ClientSocketListener(listener.accept(), vis));}
			catch (Exception e){MonitorServer.out.appendText("\nError accepting client socket for lightweight monitor"); e.printStackTrace();}
		}
		MonitorServer.out.appendText("\nLightweight monitor has STOPPED listening for clients at "+listener.getLocalSocketAddress()+":"+listener.getLocalPort());
		
	}
	
	public static Logger createMonitorServer(){
		Logger vis=new Logger();
		(new Thread(vis)).start();
		(new Thread(new MonitorServer(DEFAULT_PORT, vis))).start();
		return vis;
	}
	public class VisListener implements WindowListener{
		public void windowActivated(WindowEvent w){
		}
		public void windowDeactivated(WindowEvent w){
		}
		public void windowOpened(WindowEvent w){
		}
		public void windowClosed(WindowEvent w){
		}
		public void windowClosing(WindowEvent w){
			System.exit(0);
		}
		public void windowDeiconified(WindowEvent w){
		}
		public void windowIconified(WindowEvent w){
		}
	}
}
