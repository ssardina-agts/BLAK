package telin.logger.server;
import java.net.*;
import java.io.*;

public class ClientSocketListener extends Thread {
	Socket socket;
	DataInputStream in;
	Logger vis;
	
	public ClientSocketListener(Socket s, Logger vis){
		socket=s;
		this.vis=vis;
		try {in=new DataInputStream(s.getInputStream());}
		catch (Exception e){System.out.println("Error opening inputsream for socket "+s.getInetAddress()+"serversocket for lightweight monitor"); e.printStackTrace();}
		start();
	}
	public void run(){
		System.out.println("ClientSocket is listening to client "+ socket.getRemoteSocketAddress());
		boolean error=false;
		while (!error){
			try {
				String eventString=in.readLine();
				if (eventString.startsWith("privatecode123"))
					vis.handleEvent(eventString.substring(14, eventString.length()));
				else
					error=true;
			} catch (Exception e){error=true; System.out.println("Error reading event from socket "+socket.getInetAddress()+" for lightweight monitor."); e.printStackTrace();}
		}
		
		System.out.println("ClientSocket is closed for "+ socket.getRemoteSocketAddress());
		try {
			socket.close();
		} catch (Exception e){}
	}
}
