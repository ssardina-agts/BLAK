This directory contains the Blocksworld world example for GOAL.
GOAL can be downloaded from http://graphics.tudelft.nl/~koen/goal
readme file by W.Pasman 16 dec2008

Wouter: The Blocks world simulator seems to have been ripped out of 
a 3D version of SHRDLU. In 2009 this could be downloaded from http://hci.stanford.edu/~winograd/shrdlu/. The simulator is by Andy Adrian in 2000. There seems to be no license available for this.

You can change the initial configuration of the blocks world 
by editing the BlocksWorld/BlocksworldEnv/bwconfig.txt file. You then also have to modify the goal file so that the agent's initial beliefs matches the real initial configuration.

IMPORTANT : To run the BlocksWorld environment, you need to have java3D installed on your machine.
java3D will enable the blocksworld to show a 3D rendering of the actual blocks world, in which you can fly around (with the keyboard) while the simulation is running. 

You can download java3D for linux, mac osx, solaris, and windows from 

https://java3d.dev.java.net/binary-builds.html



If you do not wish to install java3D you can still run the BlocksWorld demos.
This is because solving a blocksworld puzzle is mostly a "mental puzzle", 
and environment interaction is not really necessary.
To do this, modify the .mas file by removing the environment definion (the first rule in the mas file)
and by removing all fragments "@environment" from the other rules. 
Now you need to introspect the agents to see that running the goal program really has the intended effect.


