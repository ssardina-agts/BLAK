// @ KH: Not needed...
//% FIRST SOME SUPPORT FUNCTIONS......
//or(X,_):- X.
//or(_,Y):- Y.

// @Integrated into Wumpus.goal ==> Beliefbase
//%infrontof(+OldPos,+Ori,-NewPos).
//infrontof([Xold,Yold],0,[X,Y]):-X is Xold+1, Y is Yold.
//infrontof([Xold,Yold],90,[X,Y]):-X is Xold, Y is Yold+1.
//infrontof([Xold,Yold],180,[X,Y]):-X is Xold-1, Y is Yold.
//infrontof([Xold,Yold],270,[X,Y]):-X is Xold, Y is Yold-1.

// Observe that 'behind' can be defined in terms of infrontof.
//% The following is a shame. Just the inverse of infrontof but 
//% the computation XOld+1 etc prevent the other inverse of the infrontof rule.
//behind([Xold,Yold],0,[X,Y]):-X is Xold-1, Y is Yold.
//behind([Xold,Yold],90,[X,Y]):-X is Xold, Y is Yold-1.
//behind([Xold,Yold],180,[X,Y]):-X is Xold+1, Y is Yold.
//behind([Xold,Yold],270,[X,Y]):-X is Xold, Y is Yold+1.

// @Integrated into Wumpus.goal ==> Action Spec 'turn'
//% turning support: newdir(+Dirmin1, +Action,  -Dir)
//newdir(Dirmin1,turn(left),Dir):-Dir is mod(Dirmin1 + 90,360).
//newdir(Dirmin1,turn(right),Dir):-Dir is mod(Dirmin1 + 270,360).
//newdir(Dir,OtherA,Dir):- not(or(OtherA = turn(left),OtherA = turn(right))).

// @PARTLY Integrated into Wumpus.goal ==> Beliefbase. DOES NOT YET TAKE ACTION FAILURE INTO ACCOUNT.
//% new position support.
//% newpos(+OldPos +Action +Bumped +Ori -NewPos)
//% Action is the action that the agent took: forward, turn(left), grab,...
//% Bumped=null if not bumped, and bump if agent bumped in this timestep to a wall.
//% Ori is the orientation of the agent before the action: 0 90 180 270. 
//newpos(Pos,Action,Bumped,_,Pos):-or(not(Action = forward),Bumped=bump).
//newpos(OldPos,forward,null,Ori,NewPos):-infrontof(OldPos,Ori,NewPos).

//% VISUALIZE FUNCTIONS
// @ KH: ?? What does next statement mean?
//% These are relying on CURRENT TIME and can not be used for time independent functions!!
//% gold(-Pos). holds as long as perceived the gold but gold not yet picked up.
//% note, we update agentposori only in "at", causing maybe delay in other display funcs.
// @Integrated into Wumpus.goal ==> Beliefbase.
//gold(Pos) :- percept(_,_,_,_,glitter,T),agentposori(Pos,_,T),not(pickedupgold(T)).
// @Integrated into Wumpus.goal ==> Action spec 'grab'
//   % pickedupgold is tricky. It calls action which is expensive.
//pickedupgold :- percept(_,_,_,_,glitter,T),action(grab,T),time(Now),Now>T.
// @Integrated into Wumpus.goal ==> Beliefbase
//breezy(Pos):-percept(breeze,_,_,_,_,T),agentposori(Pos,_,T).
//smelly(Pos):-percept(_,stench,_,_,_,T),agentposori(Pos,_,T).
//at(agent,Pos,T):-updateAgentCoord(T),agentposori(Pos,_,T).
// @Integrated into Wumpus.goal ==> Action spec 'turn'. See also newPos predicate in beliefbase.
//orientation(agent,Dir,T):-updateAgentCoord(T),agentposori(_,Dir,T).
// @Integrated into Wumpus.goal ==> Beliefbase 'at(Pos)' clause.
//wall(Pos):-
//	percept(_,_,bump,_,_,T),agentposori(AgtPos,AgtOri,T),infrontof(AgtPos,AgtOri,Pos).

// @Do not need this in Wumpus.goal. Maintain all at(Pos,T) predicates in beliefbase, so no need for 'visited'.
//%visited(-Pos)
//%This works since we add the agentposori predicate to the prolog KB.
//%if agentposori would be derived, we would have to determine T first.
//visited(Pos):-agentposori(Pos,_,_).
// @ ?? KH: Why?
//% safevisited is same as visited, but with extra cut to work around backtracking issue in SwiPL
//safevisited(Pos):-agentposori(Pos,_,_),!.

// @Integrated into Wumpus.goal ==> Beliefbase. See predicates 'at' and 'orientation'.
//%the thought position is stored in the KB, with predicate agentposori.
//%agentposori(Pos,Ori,Time).
//:- dynamic agentposori/3.
//agentposori([0,0],0,0).

// @Integrated into Wumpus.goal ==> Action Specification 'forward' and Beliefbase 'at(Pos)' clauses.
//% updateAgentCoord(+T) adds agentposori(Pos,Ori,T) to the database, 
//% prerequisite is that agentposori(..,T-1) and percept(T) has been set properly.
//updateAgentCoord(0).
//updateAgentCoord(T):-T>0,agentposori(_,_,T).
//updateAgentCoord(T):-T>0,
//	not(agentposori(_,_,T)),%avoid double work
//	%write('update for time '),writeln(T),
//	T>0,Tmin1 is T-1, 
//	agentposori(Posmin1,Dirmin1,Tmin1), 
//	action(A,Tmin1),
//	newdir(Dirmin1,A,Dir),
//	percept(_,_,Bumped,_,_,T),
//	%writeln('percept is there.'),
//	newpos(Posmin1,A,Bumped,Dir,Pos),
//	assert(agentposori(Pos,Dir,T)).

	
//%
//% DETERMINING NEXT ACTION
//%

//% action(-Action,+Time). This clause is queried by the Scheduler.
//% note, updateAgentCoord will usually not do anything here,
//% because the percept was received already earlier and updated
//% when "at" or "orientatin" was queried.
//% it is not so nice that the percept is ADDED to the KB,
//% it would have been easier if it would be queried so that WE
//% could also update other parts in the KB.
//:-dynamic doneaction/2.

//action(Action,T):-doneaction(Action,T).
//action(Action,T):-not(doneaction(_,T)),updateAgentCoord(T),agentposori(Pos,Dir,T),whichaction(Action,Pos,Dir,T),assert(doneaction(Action,T)).

//% whichaction(-Action,+Pos,+Ori,+Time).
//% whichaction determines next action given a situation.
//% This should work for any T, not just the current time.
//% without cut, we would have to re-test all higher-priority tests.
//% pick up gold has top priority.
//% we can not yet handle failed searches.

// @ KH: Next two lines only for debugging?
//% check if this is going to work anyway to give warning message.
//whichaction(_,_,_,T):-not(percept(_,_,_,_,_,T)),writeln('FAILURE! percept not available').

// @Integrated into Wumpus.goal ==> Program section.
//whichaction(grab,_,_,T):- percept(_,_,_,_,glitter,T),!.
// @Integrated into Wumpus.goal ==> Program section.
//whichaction(climb,[0,0],_,T):-or(pickedupgoldbefore(T),not(unexploredplaces)).
// @Integrated into Wumpus.goal ==> Program section. Adopt goal to go to exit in both cases.
//whichaction(Action,[X,Y],Ori,T):-
//	or(pickedupgoldbefore(T),not(unexploredplaces)),
//	shortestpath([X,Y,Ori],findexit,[Action | _]),!.
//	% got the gold, or out of options, so head for the exit
//	% this *should* work if we are not yet at the start position.
//	% note that this is a bit overkill, we compute all subsequent actions 
//	% but throw away all but the first action...
//	% we use cut to get first solution of shortestpath only.
// @Integrated into Wumpus.goal ==> Program section. Adopt new goal to go to nearest unexplored place.
//% OK, there are unexplored places.
//% find next interesting pos&ori and go there.
//whichaction(Action,[X,Y],Ori,T):-
//	not(pickedupgoldbefore(T)),unexploredplaces,
//	shortestpath([X,Y,Ori],findnearestunexplored,NextActions),
//	% cut, we want only ONE shortest path, not all.
//	% we could use allsolutions instead of cut
//	% which would be much more expensive.
//	!,
//	picknext(NextActions,Action).

// @ ?? KH: Why do we need next predicate on top of 'pickedupgold'?
//pickedupgoldbefore(T):-percept(_,_,_,_,glitter,T1),T1<T.

picknext([],forward).
picknext([Action|_],Action).

// @ KH: Next not needed in Wumpus.goal
//checked(Pos):-or(safevisited(Pos),wall(Pos)).
//unexploredplaces :- agentposori([X,Y],_,_),someorientation(Ori),explorableposori(X,Y,Ori).
// @ KH: 'someorientation' not needed. Use don't care '_' instead.
//someorientation(0).
//someorientation(90).
//someorientation(180).
//someorientation(270).


%
%-------- PATH PLANNING STUFF --------------
%

// @ KH: Predicate 'goodposori' used to indicate Pos is a (potential) location to go to (goal)
// Covered in Wumpus.goal by adopting goal to go somewhere...
//% goodposori(+searchcriterion, +posori)
//% determine which positions are good to go to in next step.
//% This only determines if position qualifies 'unexplored' or 'exit'
//% but not if it is nearest.
//goodposori(findexit,[0,0,_]).
//% good unexplored means that stepping forward from there would lead to new knowledge.
//% currently we just don''t explore from a dangerous position.
//% a more powerful algorithm seems possible but more work.
//goodposori(findnearestunexplored,[X,Y,Ori]):-explorableposori(X,Y,Ori).
// @Integrated into Wumpus.goal ==> Beliefbase
//explorableposori(X,Y,Ori):-not(danger([X,Y])),infrontof([X,Y],Ori,NewPos),not(checked(NewPos)).
//danger(Pos):-percept(breeze,_,_,_,_,T),agentposori(Pos,_,T).
//danger(Pos):-percept(_,stench,_,_,_,T),agentposori(Pos,_,T).

// @Integrated by Lee Routing algorithm in Wumpus.goal

//% shortestpath(+StartPosOri,+SearchCriterion,-Path) finds shortest path from start to good point.
//% SearchCriterion is either findexit or findnearestunexplored.
//% NOTE. If there are multiple "shortest path" then backtracking will give all of them.
//shortestpath([X,Y,Ori],SearchCriterion,Path):-
//	shortestpath1([[X,Y,Ori,0]],SearchCriterion,Checked,GoodPoint),
//	recoverpath(Checked,GoodPoint,Path).

//% containsgoodpoint(+Set,+SearchCriterion,+Element).
//% determines if our current search scope (Set) already contains a good point.
//% and returns that point
//containsgoodpoint(Set,SearchCriterion,[X,Y,Ori,N]):-
//	member([X,Y,Ori,N],Set),goodposori(SearchCriterion,[X,Y,Ori]).

//% shortestpath1(+Visited,-Nsteps,-ExtendedVisited)
//% Visited is a list of numbers [X,Y,Ori,N], Nsteps indicating #steps from start
//% EndVisited is similar list, but extended until End is in the list.
//% note, we have the global predicate goodpoint that determines goodness of a point.
//% IMHO this function should really be passed as a parameter but that is not possible in prolog...
//shortestpath1(Visited,SearchCriterion,Visited,[X,Y,Ori,N]):-
//	containsgoodpoint(Visited,SearchCriterion,[X,Y,Ori,N]).
	
//shortestpath1(Visited,SearchCriterion,XXVisited,GoodPoint):- 
//	not(containsgoodpoint(Visited,SearchCriterion,_)),
//	extend(Visited,ExtendedVisited),
//	shortestpath1(ExtendedVisited,SearchCriterion,XXVisited,GoodPoint).

//%extend(+Visited,-ExtendedVisited) returns new list with all neighbours added.
//% I don''t like this extend code. It reads pretty bad.
//% would like to write forall(v in visited), newv=newv+extend1(v,newv)...
//extend(Visited,Newv):-extend3(Visited,Visited,Newv).
//extend3([],Visited,Visited).
//extend3([OldPosOri | Rest],Visited,Newv):-
//	extend3(Rest,Visited,Newv1),extend1(OldPosOri,Newv1,Newv).

//extend1([X,Y,Ori,N],Visited,Newv3):-
//	N1 is N+1,
//	OriL is mod(Ori +270,360), addnewposori([X,Y,OriL,N1],Visited,Newv1),
//	OriR is mod(Ori +90,360), addnewposori([X,Y,OriR,N1],Newv1,Newv2),
//	infrontof([X,Y],Ori,[Xn,Yn]), addnewposori([Xn,Yn,Ori,N1],Newv2,Newv3).

//% addnewposori(+PosOriN,+OldChecked,-NewChecked)
//% add only if pos reachable (visited before) AND if not already in OldChecked (with smaller N).
//addnewposori([X,Y,_,_],Checked,Checked):-not(safevisited([X,Y])). 
//addnewposori([X,Y,Ori,_],Checked,Checked):-safevisited([X,Y]),member([X,Y,Ori,_],Checked).
//addnewposori([X,Y,Ori,N],Checked,NewC):-
//	safevisited([X,Y]),not(member([X,Y,Ori,_],Checked)),append([[X,Y,Ori,N]],Checked,NewC).

//%onestepback(+Pos,-PrevPos)
//onestepback([X,Y,Ori,N],[X1,Y1,Ori,N1],forward):-N1 is N-1,behind([X,Y],Ori,[X1,Y1]).
//onestepback([X,Y,Ori,N],[X,Y,OriL,N1],turn(left)):-N1 is N-1,OriL is mod(Ori +270,360).
//onestepback([X,Y,Ori,N],[X,Y,OriR,N1],turn(right)):-N1 is N-1,OriR is mod(Ori +90,360).

// @ Integrated into Wumpus.goal by 'path' and 'extract_plan' predicates in Beliefbase.
//%recoverpath(+Checked,+EndPosOriN,-Path)
//%search path back through the checked tree to the start point with N=0.
//recoverpath(_,[_,_,_,0],[]).
//recoverpath(Checked,[X,Y,Ori,N],Path):-N>0, 
//	onestepback([X,Y,Ori,N],PrevPosOriN,Step),
//	member(PrevPosOriN,Checked),
//	recoverpath(Checked,PrevPosOriN,PathToHere),
//	append(PathToHere,[Step],Path).
