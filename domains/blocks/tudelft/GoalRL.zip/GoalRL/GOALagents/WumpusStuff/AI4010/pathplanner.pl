% Compute next action for shortest path to Pos
% Assumes that agent currently is at initial position of path with current orientation
shortestPathTo(Pos,Action) :- at(From), orientation(Dir), shortestPathPlanner(From,Pos,Path1),
	reverse(Path1,Path2), extract_plan(Path2,[Action|_],Dir,_).
% Based on Lee Routing Algorithm in The Art of Prolog, pp. 275-276
shortestPathPlanner(From,To,Path) :- waves(To,[[From],[]],Waves), path(From,To,Waves,Path).
waves(To,[Wave|Waves],Waves) :- member(To,Wave),!.
waves(To,[Wave,LastWave|LastWaves],Waves) :- 
	next_wave(Wave,LastWave,NextWave),
	waves(To,[NextWave,Wave,LastWave|LastWaves],Waves).
next_wave(Wave,LastWave,NextWave) :- setof(X,admissible(X,Wave,LastWave),NextWave).
admissible(X,Wave,LastWave) :- neighbor(X,Wave), not(member(X,LastWave)), not(member(X,Wave)).
neighbor(Pos,Wave) :- member(Pos1,Wave), adjacent(Pos,Pos1), at(Pos,_).
adjacent([X1,Y],[X2,Y]) :- next_to(X1,X2).
adjacent([X,Y1],[X,Y2]) :- next_to(Y1,Y2).
next_to(A,B) :- is(A,+(B,1)).
next_to(A,B) :- is(A,-(B,1)).
path(Pos,Pos,Waves,[Pos]) :- !.
path(Pos1,Pos2,[Wave|Waves],[Pos2|Path]) :-
	member(Pos,Wave), adjacent(Pos,Pos2), !, path(Pos1,Pos,Waves,Path).
extract_plan([],[],_,_).
extract_plan([Pos],[],_,_).
extract_plan([Pos1,Pos2],[forward],Dir,Dir) :- inFrontOf(Pos1,Dir,Pos2).
extract_plan([Pos1,Pos2],[turn(left),forward],Dir,NewDir) :-
	is(NewDir,mod(+(Dir,90),360)), inFrontOf(Pos1,NewDir,Pos2).
extract_plan([Pos1,Pos2],[turn(right),forward],Dir,NewDir) :-
	is(NewDir,mod(+(Dir,270),360)), inFrontOf(Pos1,NewDir,Pos2).
extract_plan([Pos1,Pos2],[turn(left),turn(left),forward],Dir,NewDir) :-
	is(NewDir,mod(+(Dir,180),360)), inFrontOf(Pos1,NewDir,Pos2).
extract_plan([Pos1,Pos2|Path],Plan,Dir,_) :-
	extract_plan([Pos1,Pos2],Plan1,Dir,NewDir), extract_plan([Pos2|Path],Plan2,NewDir,_),
	append(Plan1,Plan2,Plan).
