This directory contains the Wumpus world example for GOAL.
GOAL can be downloaded from http://graphics.tudelft.nl/~koen/goal
readme file by W.Pasman 17dec2008

The wumpusagent.goal file is extremely simple, for educational reasons.
The environment is fully functional and the agent can be improved easily 
by modifying the goal program from using the GOAL IDE.

You can edit environments, load and save them using the "Load World" and "Save World" menus. A number of sample worlds are provided in this directory.

Note that the environment does not respond to agents until you switch the environment to the run mode by pressing the "Wumpus Runner" button.