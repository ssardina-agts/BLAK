// Author W.Pasman 26 sept 2007
// This is a library to enable native C calls to PL_open_foreign_frame from Java

#include <SWI-Prolog.h>
#include <jni.h>
/* #include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>    */
#include <fcntl.h>
//#include <unistd.h>

//#include "ForeignFrame.h" /*Make sure to have compatible code */

/* 
get the required signatures (.h files) with 
javah ReadFile
Unfortunately that seems broken.

compile this on OSX with
setenv CPATH /System/Library/Frameworks/JavaVM.framework/Versions/A/Headers
gcc foreign.c -I/Volumes/Apps/swiprolog/local/lib/swipl-5.6.37/include/ -L/Volumes/Apps/swiprolog/local/lib/swipl-5.6.37/lib/i386-darwin8.10.1 -lpl -dynamiclib -dynamic -o libforeign.jnilib

Gewone lib contents kan je zien met 'strings', maar 
ze gebruiken in swi prolog natuurlijk weer geen gewone lib maar een static linked lib...
Benodigde fucnties komen uit libpl.a. Kan je zien met
ar -tv libpl.a

*/

//extern fid_t PL_open_foreign_frame();
//extern void PL_close_foreign_frame(fid_t cid);


/* we return a pointer to a fid_t. Just easier than making a java object and manipulating fields 
	For now we just dump error messages on console. To be improved with throw in Java or so...
*/

 // Init prolog engine 
void maybeInitializeEngine()
{
	int r;

	//fprintf(stderr,"this thread=%d\n",PL_thread_self());fflush(stderr);
	// Someone else usually already calls PL_thread_self.
	// TODO what do we do if someone else called PL_thread_self but did
	// did not set theMainEngine?
	
	if (PL_thread_self()<0)
	{		
		//fprintf(stderr,"Needed new engine for thread%d\n",PL_thread_self());fflush(stderr);
		PL_engine_t newEngine;
		
		/* Wouter: 12sept: if you pass 0 to PL_create_engine SWIprolog uses the default sizes for 
		local_size, global_size, trail_size and argument_size. Check swipl src/pl-thread.c (line 438) and
		pl-main.c lne 313 etc.... 
		default local_size=4096K*4 (win32; *8 on win64), global_size= trail_size=8192K*4, argument_size=250K*4, alias=??? 
		see also http://gollem.science.uva.nl/SWI-Prolog/Manual/foreignthread.html
		*/
		
		
		/*
		//ENABLE THIS AND DISABLE THE default TO MAKE 100 THREADS POSSIBLE.
		PL_thread_attr_t *attri=malloc(sizeof(PL_thread_attr_t));// customized prolog stack properties. Default is bit large at 100M each thread.
		if (attri==0) { fprintf(stderr,"out of memory in foreign.c!"); return ; }
		attri->local_size=100;// K;
		attri->global_size=200;// K;
		attri->trail_size=200;// K;
		attri->argument_size=20;// K;
		attri->alias=0;
		attri->cancel=0;
		newEngine=PL_create_engine(attri); // use modified stacks. 
		*/
		
		/*
		//Test with extra local stack size: 32M instead of 16M.
		fprintf(stderr,"using customized prolog stack\n");	fflush(stderr);
		PL_thread_attr_t *attri=malloc(sizeof(PL_thread_attr_t));// customized prolog stack properties. Default is bit large at 100M each thread.
		if (attri==0) { fprintf(stderr,"out of memory in foreign.c!\n"); fflush(stderr); return ; }
		attri->local_size=1*1024;// K;
		attri->global_size=32*1024;// K;
		attri->trail_size=32*1024;// K;
		attri->argument_size=16*1024;// K; Wouter: this should be at most global/2
		attri->alias=0;
		attri->cancel=0;
		newEngine=PL_create_engine(attri); // use modified stacks. 
		*/
		
		newEngine=PL_create_engine(0); // default attributes
		
		
		if (newEngine==0)
		{
			fprintf(stderr,"Failed to create new engine. Maybe SWI multithreading is off?\n");fflush(stderr);
			return; //TODO throw Java exception.
		}
		r=PL_set_engine(newEngine,0);
	
		if (r != PL_ENGINE_SET) {
			char* msg;
			switch (r)
			{
				case PL_ENGINE_INVAL: msg="Invalid engine handle"; break;
				case PL_ENGINE_INUSE: msg="Engine in use"; break;
				default: msg="Unknown error";
			}
			fprintf(stderr,"ERROR setting prolog engine:%d:%s\n",r,msg); fflush(stderr);
		}
	}
	//fprintf(stderr,"Returning from maybeInitializeEngine\n"); fflush(stderr);
}
	



JNIEXPORT jint JNICALL Java_foreignframe_ForeignFrame_JPLopenforeignframe
  (JNIEnv * env, jobject someobj) {
	fid_t fid; 
	/* 
	 Wouter: WHERE is the manual for PL_open_foreign_frame???
	see source in src/pl_wam.c
	what is returned from PL_open... is a consTermRef which is a Word 
	which is a (word*). In OSX a pointer is 4 bytes, and the same size as a long.
	ASSUMPTION is that also in windows and other OS, long is large enough to hold pointer.
	A jint is large enough (4 bytes in OSX) and should be safe to use.
	CHECK this in Windows: run the test program.
	 */ 
	//fprintf(stderr,"openforeign arrived\n"); fflush(stderr);
	maybeInitializeEngine();
	fid=PL_open_foreign_frame();
	//fprintf(stderr,"openforeign complete. res=%d\n",fid);	fflush(stderr);
	
	return (jint)fid;
}


JNIEXPORT void JNICALL Java_foreignframe_ForeignFrame_JPLcloseforeignframe
  (JNIEnv * env, jobject jobj, jint f) {
	PL_close_foreign_frame((fid_t)f);
	// test, 21jan09. 
	// Makes no difference as long as you 
	// always call the bugfixPL_discard_foreign_frame((fid_t)f);
}



JNIEXPORT void JNICALL Java_foreignframe_ForeignFrame_JPLdestroyengine
  (JNIEnv * env, jobject someobj) {
	PL_thread_destroy_engine();
}
