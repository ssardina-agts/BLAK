package foreignframe;

import foreignframe.ForeignFrame;
import jpl.*;

/**
@author W.Pasman 19sept07
Demo to illustrate use of ForeignFrame.
compile with
javac -classpath .\:../dep/jpl.jar foreignframe/Test.java
run with
java -classpath .\:../dep/jpl.jar -Djava.library.path=bugfix_prolog/foreignfre:/usr/local/lib/swipl-5.6.55/lib/i386-darwin8.11.1\:foreignframe foreignframe.Test

*/

class Test
{
  public static void main( java.lang.String argv[] ) throws Exception
  { 
	int n,totaln=0;
	ForeignFrame foreignframe=new ForeignFrame();
	
	new Query("statistics").allSolutions(); 
	for (int m=1; m<1000; m++)
	{	
		for (n=1; n<1000; n++)
		{
			foreignframe.open();
			new Query("assert(beliefbase42:(thetime("+m+")))").allSolutions();
			foreignframe.close();
			foreignframe.open();
			new Query("beliefbase42:(thetime(X))").allSolutions();
			foreignframe.close();
			foreignframe.open();
			new Query("retractall(beliefbase42:thetime("+m+"))").allSolutions();
			foreignframe.close();
		}
		totaln=totaln+n;
		System.out.println("total queries="+totaln);
		foreignframe.open();
		new Query("statistics").allSolutions(); 
		foreignframe.close();

	}
  }
}