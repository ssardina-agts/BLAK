// compile with:
// javac JPLtest.java -cp /usr/local/lib/swipl-5.6.64/lib/jpl.jar:/Volumes/Documents/Wouter/GOAL/EclipseWorkspaces/Interpreter/bugfix_prolog/foreignframe/foreignframe.jar
// run with
// setenv DYLD_LIBRARY_PATH /Volumes/Documents/Wouter/GOAL/EclipseWorkspaces/Interpreter/bugfix_prolog/foreignframe/\:/usr/local/lib/swipl-5.6.64/lib/i386-darwin8.11.1/
//
// java -cp .:/usr/local/lib/swipl-5.6.64/lib/jpl.jar:/Volumes/Documents/Wouter/GOAL/EclipseWorkspaces/Interpreter/bugfix_prolog/foreignframe/foreignframe.jar JPLtest

import java.util.Hashtable;
import jpl.*;
import foreignframe.ForeignFrame;

public class JPLtest
{
	public static void
	main( java.lang.String argv[] )
	{
		try {
			do_query("X is 3");
			do_query("X is 4");
			
			do_query("member(X,L)");
			do_query("true");
		}
		catch (Exception e) {
			System.out.println("top level halt: "+e);
		}
	}
	
	static ForeignFrame foreignframe=null; // any call to rawquery will instantiate it and load bugfix.
	
	static void do_query(String querystr) throws Exception {
		if (foreignframe==null) foreignframe=new ForeignFrame(); // load it if first time call
		System.out.println("foreignframe="+foreignframe.theforeignframe);
		foreignframe.open();
		try {
			Query query = new Query(querystr);
			System.out.println("query="+query);
			Hashtable[] solutions = query.allSolutions();
			System.out.println("solutions:"+solutions);
			
		}
		catch (Error e) {
			System.out.println("no solution because of error:"+e);
			//foreignframe.close();
			//foreignframe.destroyEngine();
			//foreignframe=null;
			//System.out.println("engine destroyed");
			//return;
		}
		foreignframe.close();
		
	}
}
