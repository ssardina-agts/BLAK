package foreignframe;

import java.util.*;

import jpl.*;
import java.util.Hashtable;
import jpl.fli.fid_t;

/* Wouter: concerning compilation... javah is permanently bugged.
It just seems broken when you have a package 
Quote from onjava.com/pub:
It turns out that the call to the function includes the package name, but javah doesn't account for this. So, when method bar in class foo inside package mumble is called, the method name invoked is Java_mumble_foo_bar(JNIEnv * env, .... ). If the C code isn't constructed this way the call won't be resolved.
*/


/**
@author W.Pasman 19sept2007. Made threadsafe 25mar2008

This object creates a SWI foreign frame and deletes it when the ForeignFrame
object is killed.

usage: create new object ForeignFrame and keep handle to it until after a SWI prolog query.

compilation: see the README file.

*/



public class ForeignFrame {

	static {
		new Query("true").allSolutions();
		System.out.println("foreignframe query OK");
		System.loadLibrary("foreign"); 
		System.out.println("Prolog bugfix loaded OK");
		// TODO: Automatically select right library by automatic detection of platform.
		// becomes libforeign.jnilib on OSX, which should be in your LD_LIBRARY_PATH.
	}

	public static native int JPLopenforeignframe();
	public static native void JPLcloseforeignframe(int t ); 
	public static native int JPLdestroyengine();

	public static int theforeignframe=0;
	
	public  ForeignFrame()
	{	
	}

	/** call PL_open_foreign_frame().
	This will throw exception if called before close of previous frame. 
	TODO We need to check what openforeignframe really does before making this threadsafe*/
	public synchronized void open() throws Exception
	{
		if (theforeignframe!=0)
			throw new Exception("Can not open new frame: the previous frame did not close.");
		//System.out.println("going to create new frame "+theforeignframe+" in thread "+Thread.currentThread().getId());

		theforeignframe=JPLopenforeignframe();
	}
	
	public synchronized void close() throws Exception
	{
		if (theforeignframe==0)
			throw new Exception("There is no frame open.");
		//System.out.println("closing frame "+theforeignframe+" in thread "+Thread.currentThread().getId());

		JPLcloseforeignframe(theforeignframe);
		theforeignframe=0;
		//System.out.println("closed foreign frame");
	}
	
	/**
	 * added W.Pasman 9feb2009 to free the memory when agent is killed.
	 * Call only sparsely, making and removing engines is expensive
	*/
	public synchronized void destroyEngine() throws Exception {
		JPLdestroyengine();
	}

}