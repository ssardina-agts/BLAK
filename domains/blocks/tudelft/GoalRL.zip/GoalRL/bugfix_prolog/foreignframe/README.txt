
Author W.Pasman 19sept 2007
Modified Dmytro, Wouter, 26 sept 2007
Wouter: Added Linux part, 29 jan 2008
Wouter: Corrected linux part, 25 may 2008
Wouter: updated parts and recompiled for swi5.6.64, 29jan 2009

WHAT'S THIS?
foreignframe is a workaround for a memory leak in swi prolog.
For the workaround we need to call C functions called 
PL_open_foreign_frame and PL_close_foreign_frame.
To do C calls we need JNI which requires messing around with dll (windows) or .jnilib files (OSX).

-----------------------------------------------------------------------------------------------
INSTALL INTO ECLIPSE

INSTALL INTO ECLIPSE

- open Eclipse
- go to /"Referenced Libraries" tab in the project in the package explorer
- right/control click on it (or go to menu project/properties/select Build Path/Configure Build Path --> go to the Libraries Tab)
- Click "Add JARs" and browse to bugfix_prolog directory and select the foreignframe.jar file

- Make sure to include: -Djava.library.path=".\bugfix_prolog\foreignframe;C:\Program Files\pl\bin" as VM argument in run/debug configuration


MAC NOTE
ADD libforeign.jnilib or foreign.dll to the classpath in Eclipse.
- Use Open Debug Dialog (click on the down-arrow next to the "bug")
- Goto the arguments tab
- enter in the box "VM arguments" the following (machine dependent)
-Djava.library.path=bugfix_prolog/foreignframe:/usr/local/lib/swipl-5.6.64/lib/i386-darwin8.11.1/

MAC NOTE:
Copy the libforeign.jnilib to some good place (???) that is in your DYLD_LIBRARY_PATH.
For instance, put it in /Volumes/Apps/swiprolog/local/lib/swipl-5.6.37/lib/i386-darwin8.10.1/

-----------------------------------------------------------------------------------------------

ANYTHING BELOW IS NEEDED ONLY IF YOU CHANGE THE FOREIGNFRAME CODE

-----------------------------------------------------------------------------------------------
COMPILING on OSX 
NOTE. OSX10.4 and OSX10.5 compile libforeign.jnilib differently, and the file compiled on 10.4
does not work on 10.5 and vice versa. Java will throw UnsatisfiedLinkError on loading the lib
if you have wrong version.



/* javah is bugged, you currently can use it only if the java file is not a package. */

//Following may differ depending on where your JavaVM lives.
setenv CPATH /System/Library/Frameworks/JavaVM.framework/Versions/A/Headers

// Following will differ for other architectures using other lib names etc.
// note, I compiled and installed swipl myself, and in that case swi is installed in /usr instead of /opt.
gcc foreign.c -I/usr/local/lib/swipl-5.6.64/include/ -L/usr/local/lib/swipl-5.6.64/lib/i386-darwin8.11.1 -lpl -dynamiclib -dynamic -o libforeign.jnilib

//on PPC in the past I needed a more elaborate command, similar to Linux:
gcc foreign.c -I/Volumes/Apps/swiprolog/local/lib/swipl-5.6.37/include/ -L/Volumes/Apps/swiprolog/local/lib/swipl-5.6.37/lib/i386-darwin8.10.1 -lpl -lgmp -lncurses -lc -lpthread -lm -ldl -dynamiclib -dynamic -o libforeign.jnilib
// but jan2009 I compiled it succesfully to running version using only
gcc foreign.c -I/opt/local/lib/swipl-5.6.64/include -L/opt/local/lib/swipl-5.6.64/lib/powerpc-darwin8.11.0 -lpl -dynamiclib -dynamic -o libforeign.jnilib

// on OSX10.5 use
gcc foreign.c -I/opt/local/lib/swipl-5.6.64/include -L/opt/local/lib/swipl-5.6.64/lib/i386-darwin9.6.0 -lpl -dynamiclib -dynamic -o libforeign.jnilib

// now make the JAR file
go to directory above the foreignframe eg with
cd ..
javac -classpath .\:../dep/jpl.jar foreignframe/ForeignFrame.java
jar cf foreignframe.jar foreignframe/ForeignFrame.class
mv foreignframe.jar foreignframe/

-----------------------------------------------------------------------------------------------
COMPILING on Linux 

Use the oldest Linux machine you can get. The older, the older the platform that is supported, and newer platforms can still run that.  Note that up to now (jan2009) we only support 32bit platforms, not 64bit. I usually compile on the dutidp.

get proper installation (java 1.5 or higher; use alien rpm-to-dpkg package converter to install
on Ubuntu. 

add the JPL.jar file to the class path 

compile from command line with:

javac ForeignFrame.java
# OLD :gcc -o libforeign.so foreign.c -L/opt/pl-5.6.49/lib/i686-linux/ -lpl -I/usr/lib/jvm/java-1.5.0-sun-1.5.0.13/include/ -I/usr/lib/jvm/java-1.5.0-sun-1.5.0.13/include/linux/ -shared -lc

#oud
# added extra linking, dynamic linking is not working very nicely in Linux...
#  gcc -lgmp -fPIC -o libforeign.so foreign.c -L/opt/pl-5.6.55/lib/i686-linux/ -L/usr/lib -I/opt/pl-5.6.55/include -lpl -I/usr/lib/jvm/java-1.5.0-sun-1.5.0.13/include/ -I/usr/lib/jvm/java-1.5.0-sun-1.5.0.13/include/linux/ -lc -lpl -lpthread -lm -ldl -lncurses -lrt -share
#jar cf foreignframe.jar foreignframe/ForeignFrame.class
#


#DEBUG INFO: This thing still does not run on Linux.
#To run GOAL from console, use the oneliner 
#java -Djava.library.path=./bugfix_prolog/foreignframe:/usr/lib/pl-5.6.55/lib/i386-linux/ -cp ./:../dep/antlr-3.0.jar:../dep/jpl.jar:../dep/jade.jar:../bugfix_prolog/foreignframe/foreignframe.jar -Djava.library.path=../bugfix_prolog/foreignframe:/usr/lib/pl-5.6.55/lib/i386-linux/ goal.tools.Main

#29jan2009, now it works.
Use a machine having jvm 1.5 or higher. (On dutidp we have 1.4...)
The machine must have libncurses.a in /usr/lib. Standard ubuntu only installs .so dynamic libs and I don't know how to link to those. The static lib requires the development version of libncurses to be installed with apt-get install libncurses5-dev
IMPORTANT: we don't get a libpl.so anymore (used to get one in the past???) and therfore we can not use -lpl but have to use -ljpl below. 


setenv PROLOG /home/wouter/plll/lib/pl-5.6.64
cd foreignframe/
gcc -fPIC -o libforeign.so foreign.c -L$PROLOG/lib/i686-linux/ -L/usr/lib -I$PROLOG/include -ljpl -I/opt/jdk1.5.0_17/include/ -I/opt/jdk1.5.0_17/include/linux/ -lc -shared



-----------------------------------------------------------------------------------------------
COMPILING ON WINDOWS

compile from command line with:

javac ForeignFrame.java
 
compile foreign.c (adjust the paths to the Visual Studio and JDK\inlcude folders):

"C:\Program Files\Microsoft Visual Studio 8\VC\bin\cl" foreign.c /I "C:\Program Files\pl\include" /I "C:\Program Files\Java\jdk1.6.0\include" /I "C:\Program Files\Microsoft Visual Studio 8\VC\include" /I "C:\Program Files\Java\jdk1.6.0\include\win32" /LD /link /LIBPATH:"C:\Program Files\Microsoft Visual Studio 8\VC\lib" /LIBPATH:"C:\Program Files\pl\lib" libpl.lib

// now make the JAR file
go to directory above the foreignframe
jar cf foreignframe.jar foreignframe/ForeignFrame.class


-----------------------------------------------------------------------------------------------
RUN DEMO (MAC+WINDOWS)

to run Demo.class use the following command line (go to directory above):

java -Djava.library.path=".\bugfix_prolog\foreignframe;C:\Program Files\pl\bin"  foreignframe.Demo

------------------------------------------------------------------------------------------------
RUN GOAL (MAC, LINUX)

run GOAL on Linux

On LINUX You must set the following to get stuff running. Even when using Eclipse.
setenv LD_LIBRARY_PATH /opt/pl-5.6.55/lib/i686-linux/:/opt/pl-5.6.55/packages/jpl/:/home/wouter/java3d/i386

java -Djava.library.path=../bugfix_prolog/foreignframe:/opt/pl-5.6.55/lib/i686-linux/ -cp ./:../dep/antlr-3.0.jar:../dep/jpl.jar:../dep/jade.jar:../bugfix_prolog/foreignframe/foreignframe.jar goal.tools.Main
 java -cp ./:bin/:dep/antlr-3.0.jar:dep/jpl.jar:dep/jade.jar:bugfix_prolog/foreignframe/foreignframe.jar:/home/wouter/java3d/ext/j3dcore.jar:/home/wouter/java3d/ext/j3dutils.jar:/home/wouter/java3d/ext/vecmath.jar -Djava.library.path=bugfix_prolog/foreignframe:/opt/pl-5.6.55/lib/i686-linux/:/opt/pl-5.6.55/packages/jpl/ goal.middleware.jade.JadeDemoMain
 

run op OSX met alleen libjpl.dylib:
 java -cp bin/:dep/antlr-3.0.jar:dep/jpl.jar:dep/jade.jar:bugfix_prolog/foreiframe/foreignframe.jar:/home/wouter/java3d/ext/j3dcore.jar:/home/wouter/java3d/ext/j3dutils.jar:/home/wouter/java3d/ext/vecmath.jar -Djava.library.path=bugfix_prolog/foreignframe:libs goal.middleware.jade.JadeDemoMain
