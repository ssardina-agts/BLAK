public class Blocks 
{
	String blocks = "";
	Blocks(){}
	String getBlocks()
	{
		return blocks;
	}
	
	void setBlocks(String b)
	{
		blocks = b;
	}
}
